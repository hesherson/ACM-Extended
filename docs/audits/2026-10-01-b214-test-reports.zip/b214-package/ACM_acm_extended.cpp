class Extended_PreInit_EventHandlers {
    class ACM_Extended {
        init = "call compile preprocessFileLineNumbers '\acm_extended\XEH_preInit.sqf'";
    };
};
class Extended_PostInit_EventHandlers {
    class ACM_Extended {
        init = "call compile preprocessFileLineNumbers '\acm_extended\functions\fn_postInit.sqf'";
    };
};
class RscDisplayEmpty;
class ACME_MainMenuHelperDumpDebug: RscDisplayEmpty {
    onLoad = "[] call ACME_fnc_debugDumpToClipboard; (_this select 0) closeDisplay 0;";
};
class CfgMovesBasic {
    class ManActions {
        ACME_SeizureSpasm3[] = {"ACME_SeizureSpasm3", "Gesture"};
        ACME_SeizureSpasm4[] = {"ACME_SeizureSpasm4", "Gesture"};
        ACME_SeizureSpasm5[] = {"ACME_SeizureSpasm5", "Gesture"};
        ACME_SeizureSpasm6[] = {"ACME_SeizureSpasm6", "Gesture"};
    };
};
class CfgMovesMaleSdr: CfgMovesBasic {
    class States {
        class AinvPknlMstpSnonWnonDnon_medic4;
        class ACME_RollProviderWork: AinvPknlMstpSnonWnonDnon_medic4 {
            looped = 0;
            disableWeapons = 1;
            disableWeaponsLong = 1;
            disableWeaponsShort = 1;
            disableReload = 1;
            canPullTrigger = 0;
            enableOptics = 0;
            enableBinocular = 0;
            connectFrom[] = {"AmovPknlMstpSnonWnonDnon", 0.15};
            connectTo[] = {};
            interpolateFrom[] = {"AmovPknlMstpSnonWnonDnon", 0.15};
            interpolateTo[] = {
                "AmovPknlMstpSnonWnonDnon",
                0.15,
                "Unconscious",
                0.02
            };
        };
        class ACME_ChestInspectWork: AinvPknlMstpSnonWnonDnon_medic4 {
            looped = 0;
            disableWeapons = 1;
            disableWeaponsLong = 1;
            disableWeaponsShort = 1;
            disableReload = 1;
            canPullTrigger = 0;
            enableOptics = 0;
            enableBinocular = 0;
            connectFrom[] = {"AmovPknlMstpSnonWnonDnon", 0.15};
            connectTo[] = {};
            interpolateFrom[] = {"AmovPknlMstpSnonWnonDnon", 0.15};
            interpolateTo[] = {
                "AmovPknlMstpSnonWnonDnon",
                0.15,
                "Unconscious",
                0.02
            };
        };
        class ACM_CPR_Stop;
        class AinvPknlMstpSnonWnonDnon_medicEnd;
        class ACME_ChestSealWorkspace: ACM_CPR_Stop {
            looped = 1;
            disableWeapons = 1;
            disableWeaponsLong = 1;
            disableWeaponsShort = 1;
            disableReload = 1;
            canPullTrigger = 0;
            enableOptics = 0;
            enableBinocular = 0;
            connectFrom[] = {
                "AmovPknlMstpSnonWnonDnon",
                0.12,
                "AinvPknlMstpSnonWnonDnon_medic4",
                0.08
            };
            connectTo[] = {
                "AmovPknlMstpSnonWnonDnon",
                0.12,
                "AinvPknlMstpSnonWnonDnon_medic4",
                0.08,
                "AinvPknlMstpSnonWnonDnon_medicEnd",
                0.08
            };
            interpolateFrom[] = {
                "AmovPknlMstpSnonWnonDnon",
                0.12,
                "AinvPknlMstpSnonWnonDnon_medic4",
                0.08
            };
            interpolateTo[] = {
                "AmovPknlMstpSnonWnonDnon",
                0.12,
                "AinvPknlMstpSnonWnonDnon_medic4",
                0.08,
                "AinvPknlMstpSnonWnonDnon_medicEnd",
                0.08,
                "Unconscious",
                0.02
            };
        };
        class AmovPercMstpSlowWrflDnon_AcinPknlMwlkSlowWrflDb_1;
        class ACME_HeadElevProviderLift: AmovPercMstpSlowWrflDnon_AcinPknlMwlkSlowWrflDb_1 {
            looped = 0;
            ConnectTo[] = {"AcinPknlMstpSnonWnonDnon_AmovPknlMstpSnonWnonDnon", 0.12};
            InterpolateTo[] = {"AcinPknlMstpSnonWnonDnon_AmovPknlMstpSnonWnonDnon", 0.12};
        };
        class AinjPpneMrunSnonWnonDb_grab;
        class ACME_HeadElevPatientGrab: AinjPpneMrunSnonWnonDb_grab {
            disableWeapons = 1;
            disableWeaponsLong = 1;
            disableWeaponsShort = 1;
            canPullTrigger = 0;
            looped = 0;
            ConnectTo[] = {"ACME_HeadElevPatientHold", 0.05};
            InterpolateTo[] = {"ACME_HeadElevPatientHold", 0.05};
        };
        class AinjPpneMrunSnonWnonDb_release;
        class ACME_HeadElevPatientHold: AinjPpneMrunSnonWnonDb_release {
            disableWeapons = 1;
            disableWeaponsLong = 1;
            disableWeaponsShort = 1;
            canPullTrigger = 0;
            looped = 1;
            speed = 0;
            ConnectTo[] = {};
            InterpolateTo[] = {};
        };
        class ACME_HeadElevPatientRelease: AinjPpneMrunSnonWnonDb_release {
            disableWeapons = 1;
            disableWeaponsLong = 1;
            disableWeaponsShort = 1;
            canPullTrigger = 0;
            looped = 0;
            ConnectTo[] = {"ACM_LyingState", 0.1};
            InterpolateTo[] = {"Unconscious", 0.02};
        };
        class AinvPknlMstpSnonWrflDr_medic3_old;
        class ACME_ResponseCheckWork: AinvPknlMstpSnonWrflDr_medic3_old {
            looped = 0;
            disableWeapons = 1;
            disableWeaponsLong = 1;
            disableWeaponsShort = 1;
            disableReload = 1;
            canPullTrigger = 0;
            enableOptics = 0;
            enableBinocular = 0;
            connectFrom[] = {"AmovPknlMstpSnonWnonDnon", 0.15};
            connectTo[] = {};
            interpolateFrom[] = {"AmovPknlMstpSnonWnonDnon", 0.15};
            interpolateTo[] = {
                "AmovPknlMstpSnonWnonDnon",
                0.15,
                "Unconscious",
                0.02
            };
        };
        class AinvPknlMstpSnonWrflDr_medic4_old;
        class ACME_AirwayCheckWork: AinvPknlMstpSnonWrflDr_medic4_old {
            looped = 0;
            disableWeapons = 1;
            disableWeaponsLong = 1;
            disableWeaponsShort = 1;
            disableReload = 1;
            canPullTrigger = 0;
            enableOptics = 0;
            enableBinocular = 0;
            connectFrom[] = {"AmovPknlMstpSnonWnonDnon", 0.15};
            connectTo[] = {};
            interpolateFrom[] = {"AmovPknlMstpSnonWnonDnon", 0.15};
            interpolateTo[] = {
                "AmovPknlMstpSnonWnonDnon",
                0.15,
                "Unconscious",
                0.02
            };
        };
        class ACME_JunctionalWork: AinvPknlMstpSnonWnonDnon_medic4 {
            looped = 1;
            disableWeapons = 1;
            disableWeaponsLong = 1;
            canPullTrigger = 0;
            connectTo[] = {};
            interpolateFrom[] = {"AmovPknlMstpSnonWnonDnon", 0.2};
            interpolateTo[] = {
                "AmovPknlMstpSnonWnonDnon",
                0.2,
                "Unconscious",
                0.02
            };
        };
        class ACME_DirectPressureHold: ACM_CPR_Stop {
            looped = 1;
            disableWeapons = 1;
            disableWeaponsLong = 1;
            canPullTrigger = 0;
            connectFrom[] = {"AmovPknlMstpSnonWnonDnon", 0.15};
            connectTo[] = {
                "AmovPknlMstpSnonWnonDnon",
                0.15,
                "AinvPknlMstpSnonWnonDnon_medic4",
                0.08,
                "AinvPknlMstpSnonWnonDnon_medicEnd",
                0.08,
                "AinvPknlMstpSnonWnonDr_medic4",
                0.08,
                "ACME_StethoscopeWork",
                0.08
            };
            interpolateFrom[] = {
                "AmovPknlMstpSnonWnonDnon",
                0.15,
                "AinvPknlMstpSnonWnonDnon_AinvPknlMstpSnonWnonDnon_medic",
                0.1
            };
            interpolateTo[] = {
                "AmovPknlMstpSnonWnonDnon",
                0.15,
                "AinvPknlMstpSnonWnonDnon_medic4",
                0.08,
                "AinvPknlMstpSnonWnonDnon_medicEnd",
                0.08,
                "AinvPknlMstpSnonWnonDr_medic4",
                0.08,
                "ACME_StethoscopeWork",
                0.08,
                "Unconscious",
                0.02
            };
        };
        class UnconsciousReviveMedic_B;
        class ACME_StethoscopeWork: UnconsciousReviveMedic_B {
            looped = 1;
            disableWeapons = 1;
            disableWeaponsLong = 1;
            disableWeaponsShort = 1;
            disableReload = 1;
            canPullTrigger = 0;
            enableOptics = 0;
            enableBinocular = 0;
            connectTo[] = {"AmovPknlMstpSnonWnonDnon", 0.2};
            interpolateFrom[] = {"AmovPknlMstpSnonWnonDnon", 0.2};
            interpolateTo[] = {
                "AmovPknlMstpSnonWnonDnon",
                0.2,
                "Unconscious",
                0.02
            };
        };
        class Acts_JetsCrewaidFCrouchThumbup_in;
        class ACM_GenericContinuous;
        class ACME_Acts_JetsCrewaidFCrouchThumbup_in: Acts_JetsCrewaidFCrouchThumbup_in {
            head = "headNo";
            aiming = "aimingNo";
            aimingBody = "aimingNo";
            forceAim = 1;
            static = 1;
            turnSpeed = 0;
            enableDirectControl = 0;
            canBlendStep = 0;
            disableWeapons = 1;
            disableWeaponsLong = 1;
            disableWeaponsShort = 1;
            disableReload = 1;
            canPullTrigger = 0;
            enableOptics = 0;
            enableBinocular = 0;
            soundEnabled = 0;
            looped = 0;
            connectFrom[] = {
                "AmovPknlMstpSnonWnonDnon",
                0.2,
                "ACM_GenericContinuous",
                0.15
            };
            interpolateFrom[] = {
                "AmovPknlMstpSnonWnonDnon",
                0.2,
                "ACM_GenericContinuous",
                0.15
            };
            connectTo[] = {};
            interpolateTo[] = {"ACME_Acts_JetsCrewaidFCrouchThumbup_loop", 1};
        };
        class Acts_LyingWounded_loop3;
        class ACME_ObtundedBack: Acts_LyingWounded_loop3 {
            head = "headNo";
            aiming = "aimingNo";
            aimingBody = "aimingNo";
            forceAim = 1;
            static = 1;
            turnSpeed = 0;
            enableDirectControl = 0;
            canBlendStep = 0;
            disableWeapons = 1;
            disableWeaponsLong = 1;
            disableWeaponsShort = 1;
            disableReload = 1;
            canPullTrigger = 0;
            enableOptics = 0;
            enableBinocular = 0;
            speed = -100;
            looped = 1;
            interpolateTo[] = {};
            connectTo[] = {};
        };
        class Acts_JetsCrewaidFCrouchThumbup_loop;
        class ACME_Acts_JetsCrewaidFCrouchThumbup_loop: Acts_JetsCrewaidFCrouchThumbup_loop {
            head = "headNo";
            aiming = "aimingNo";
            aimingBody = "aimingNo";
            forceAim = 1;
            static = 1;
            turnSpeed = 0;
            enableDirectControl = 0;
            canBlendStep = 0;
            disableWeapons = 1;
            disableWeaponsLong = 1;
            disableWeaponsShort = 1;
            disableReload = 1;
            canPullTrigger = 0;
            enableOptics = 0;
            enableBinocular = 0;
            soundEnabled = 0;
            speed = -1000000;
            looped = 1;
            connectFrom[] = {
                "AmovPknlMstpSnonWnonDnon",
                0.15,
                "ACM_GenericContinuous",
                0.15,
                "ACME_Acts_JetsCrewaidFCrouchThumbup_in",
                0.05
            };
            interpolateFrom[] = {
                "AmovPknlMstpSnonWnonDnon",
                0.15,
                "ACM_GenericContinuous",
                0.15,
                "ACME_Acts_JetsCrewaidFCrouchThumbup_in",
                0.05
            };
            connectTo[] = {};
            interpolateTo[] = {
                "ACME_Acts_JetsCrewaidFCrouchThumbup_out",
                0.05,
                "AmovPknlMstpSnonWnonDnon",
                0.15,
                "Unconscious",
                0.02
            };
        };
        class Acts_JetsCrewaidFCrouchThumbup_out;
        class ACME_Acts_JetsCrewaidFCrouchThumbup_out: Acts_JetsCrewaidFCrouchThumbup_out {
            head = "headNo";
            aiming = "aimingNo";
            aimingBody = "aimingNo";
            static = 0;
            enableDirectControl = 1;
            canBlendStep = 1;
            disableWeapons = 1;
            disableWeaponsLong = 1;
            disableReload = 1;
            canPullTrigger = 0;
            enableOptics = 0;
            enableBinocular = 0;
            soundEnabled = 0;
            looped = 0;
            connectFrom[] = {"ACME_Acts_JetsCrewaidFCrouchThumbup_loop", 0.05};
            interpolateFrom[] = {"ACME_Acts_JetsCrewaidFCrouchThumbup_loop", 0.05};
            connectTo[] = {"AmovPknlMstpSnonWnonDnon", 0.12};
            interpolateTo[] = {
                "AmovPknlMstpSnonWnonDnon",
                0.12,
                "Unconscious",
                0.02
            };
        };
    };
};
class CfgPatches {
    class ACM_Extended {
        acmeBuildBatch = "B214";
        acmeNetworkProtocol = 1;
        acmeComponent = "extended";
        name = "ACM Extended";
        units[] = {
            "ACME_ModuleMegacodeKelly",
            "ACME_ModuleBloodFridge",
            "ACME_BloodFridge_Closed",
            "ACME_BloodFridge_Open",
            "ACME_ModuleInflictBlastLung",
            "ACME_ModuleInflictJunctional",
            "ACME_ModuleInduceObtundation",
            "ACME_ModuleInflictTBI",
            "ACME_ModuleClearTBI",
            "ACME_ModuleInsertIV",
            "ACME_ModuleInflictEdema",
            "ACME_ModuleClearEdema",
            "ACME_BloodCoolerBox_CSWB1U",
            "ACME_BloodCoolerBox_CSWB2U",
            "ACME_BloodCoolerBox_CSWB4U"
        };
        weapons[] = {
            "ACME_HTSBag",
            "ACME_MagnesiumBag",
            "ACME_MannitolBag",
            "ACM_EsmololBag",
            "ACM_Vial_Norepinephrine",
            "ACM_Vial_Ceftriaxone",
            "ACM_Vial_Rocuronium",
            "ACM_Vial_Sugammadex",
            "ACM_IV_18g",
            "ACM_IV_20g",
            "ACM_SalineFlush_10",
            "ACME_Vial_EpinephrineCardiac",
            "ACM_Thermometer",
            "ACM_NRBMask",
            "ACM_HPMK",
            "ACM_EMMA",
            "ACM_CombatGauze",
            "ACME_NARSPEAR",
            "ACME_XStat",
            "ACME_Ventilator",
            "ACME_VentBattery",
            "ACME_Laryngoscope",
            "ACME_ETTube",
            "ACME_HTSBullet",
            "ACME_MannitolVial",
            "ACME_PlasmaLyteBag",
            "ACME_PlasmaLyteBag_500",
            "ACME_PlasmaLyteBag_250",
            "ACME_PlasmaLyteBag_100",
            "ACME_SalineBag_50",
            "ACME_SalineBag_100",
            "ACME_Spray_Esketamine",
            "ACM_Vial_Phentolamine",
            "ACM_Vial_Hyaluronidase",
            "ACM_Vial_CalciumGluconate",
            "ACM_Vial_Propofol",
            "ACM_Vial_Midazolam",
            "ACM_Vial_Fentanyl",
            "ACME_IVLine",
            "ACME_YTubing",
            "ACME_BloodWarmer",
            "ACME_PressureInfuser",
            "ACME_NARBOA",
            "ACME_AAJT_S",
            "ACME_SpoiledBlood",
            "ACME_BloodCooler_CSWB1U",
            "ACME_BloodCooler_CSWB2U",
            "ACME_BloodCooler_CSWB4U"
        };
        requiredVersion = 2.18;
        requiredAddons[] = {
            "A3_Data_F",
            "A3_Anims_F",
            "cba_main",
            "ace_main",
            "ace_fastroping",
            "ace_interact_menu",
            "ace_map",
            "ace_medical_status",
            "ace_medical_treatment",
            "ace_medical_gui",
            "ACM_gui",
            "ACM_core",
            "ACM_damage",
            "ACM_circulation",
            "ACM_breathing",
            "ACM_airway",
            "ACM_disability"
        };
        author = "mavis";
        version = "1.2.4.1";
        acme_developmentBuild = 0;
    };
};
class CfgMods {
    class ACM_Extended {
        dir = "@ACM Extended";
        name = "ACM Extended";
        picture = "\acm_extended\ui\ACME_logo.paa";
        logo = "\acm_extended\ui\ACME_logo.paa";
        logoOver = "\acm_extended\ui\ACME_logo.paa";
        logoSmall = "\acm_extended\ui\ACME_logo_small.paa";
        hidePicture = 0;
        hideName = 0;
        tooltip = "ACM Extended";
        tooltipOwned = "ACM Extended";
        actionName = "";
        action = "";
        overview = "ACM Extended";
        author = "mavis";
    };
};
class CfgMagazines {
    class CA_Magazine;
    class ACM_Paracetamol: CA_Magazine {
        scope = 2;
        author = "Blue";
        picture = "\x\ACM\addons\circulation\ui\paracetamol_ca.paa";
        displayName = "Acetaminophen";
        displayNameShort = "APAP";
        descriptionShort = "$STR_ACM_Circulation_Paracetamol_Desc";
        nameSound = "";
        ACE_isMedicalItem = 1;
        ACE_asItem = 1;
        count = 10;
        mass = 0.3;
    };
    class ACM_Paracetamol_DoublePack: ACM_Paracetamol {
        scope = 1;
        picture = "\x\ACM\addons\circulation\ui\paracetamol_doublepack_ca.paa";
        displayName = "Acetaminophen (Double Pack)";
        displayNameShort = "APAP";
        count = 2;
        mass = 0.06;
    };
    class ACM_Syringe_10_Epinephrine;
    class ACM_Syringe_10_EpinephrineCardiac: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_10_ca.paa";
        displayName = "Syringe (10 mL) [Epinephrine 1:10,000]";
        descriptionShort = "Cardiac epinephrine 0.1 mg/mL. Actual dose equals filled volume times concentration. IV/IO only.";
        count = 1000;
        mass = 0.9;
    };
    class ACM_Syringe_5_EpinephrineCardiac: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_5_ca.paa";
        displayName = "Syringe (5 mL) [Epinephrine 1:10,000]";
        descriptionShort = "Cardiac epinephrine 0.1 mg/mL. Actual dose equals filled volume times concentration. IV/IO only.";
        count = 500;
        mass = 0.7;
    };
    class ACM_Syringe_3_EpinephrineCardiac: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_3_ca.paa";
        displayName = "Syringe (3 mL) [Epinephrine 1:10,000]";
        descriptionShort = "Cardiac epinephrine 0.1 mg/mL. Actual dose equals filled volume times concentration. IV/IO only.";
        count = 300;
        mass = 0.6;
    };
    class ACM_Syringe_1_EpinephrineCardiac: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_1_ca.paa";
        displayName = "Syringe (1 mL) [Epinephrine 1:10,000]";
        descriptionShort = "Cardiac epinephrine 0.1 mg/mL. Actual dose equals filled volume times concentration. IV/IO only.";
        count = 100;
        mass = 0.5;
    };
    class ACM_Syringe_10_Norepinephrine: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_10_ca.paa";
        displayName = "Syringe (10ml) [Norepinephrine]";
        descriptionShort = "Prepared syringe of Norepinephrine.";
        count = 1000;
        mass = 0.9;
    };
    class ACM_Syringe_5_Norepinephrine: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_5_ca.paa";
        displayName = "Syringe (5ml) [Norepinephrine]";
        descriptionShort = "Prepared syringe of Norepinephrine.";
        count = 500;
        mass = 0.7;
    };
    class ACM_Syringe_3_Norepinephrine: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_3_ca.paa";
        displayName = "Syringe (3ml) [Norepinephrine]";
        descriptionShort = "Prepared syringe of Norepinephrine.";
        count = 300;
        mass = 0.6;
    };
    class ACM_Syringe_1_Norepinephrine: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_1_ca.paa";
        displayName = "Syringe (1ml) [Norepinephrine]";
        descriptionShort = "Prepared syringe of Norepinephrine.";
        count = 100;
        mass = 0.5;
    };
    class ACM_Syringe_10_Phentolamine: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_10_ca.paa";
        displayName = "Syringe (10ml) [Phentolamine]";
        descriptionShort = "Prepared syringe of Phentolamine. Reverses vasopressor extravasation.";
        count = 1000;
        mass = 0.9;
    };
    class ACM_Syringe_5_Phentolamine: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_5_ca.paa";
        displayName = "Syringe (5ml) [Phentolamine]";
        descriptionShort = "Prepared syringe of Phentolamine. Reverses vasopressor extravasation.";
        count = 500;
        mass = 0.7;
    };
    class ACM_Syringe_3_Phentolamine: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_3_ca.paa";
        displayName = "Syringe (3ml) [Phentolamine]";
        descriptionShort = "Prepared syringe of Phentolamine. Reverses vasopressor extravasation.";
        count = 300;
        mass = 0.6;
    };
    class ACM_Syringe_1_Phentolamine: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_1_ca.paa";
        displayName = "Syringe (1ml) [Phentolamine]";
        descriptionShort = "Prepared syringe of Phentolamine. Reverses vasopressor extravasation.";
        count = 100;
        mass = 0.5;
    };
    class ACM_Syringe_10_Hyaluronidase: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_10_ca.paa";
        displayName = "Syringe (10ml) [Hyaluronidase]";
        descriptionShort = "Prepared syringe of Hyaluronidase. Disperses extravasated hyperosmolar/irritant drugs.";
        count = 1000;
        mass = 0.9;
    };
    class ACM_Syringe_5_Hyaluronidase: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_5_ca.paa";
        displayName = "Syringe (5ml) [Hyaluronidase]";
        descriptionShort = "Prepared syringe of Hyaluronidase. Disperses extravasated hyperosmolar/irritant drugs.";
        count = 500;
        mass = 0.7;
    };
    class ACM_Syringe_3_Hyaluronidase: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_3_ca.paa";
        displayName = "Syringe (3ml) [Hyaluronidase]";
        descriptionShort = "Prepared syringe of Hyaluronidase. Disperses extravasated hyperosmolar/irritant drugs.";
        count = 300;
        mass = 0.6;
    };
    class ACM_Syringe_1_Hyaluronidase: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_1_ca.paa";
        displayName = "Syringe (1ml) [Hyaluronidase]";
        descriptionShort = "Prepared syringe of Hyaluronidase. Disperses extravasated hyperosmolar/irritant drugs.";
        count = 100;
        mass = 0.5;
    };
    class ACM_Syringe_10_Midazolam: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_10_ca.paa";
        displayName = "Syringe (10ml) [Midazolam]";
        descriptionShort = "Prepared syringe of Midazolam.";
        count = 1000;
        mass = 0.9;
    };
    class ACM_Syringe_5_Midazolam: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_5_ca.paa";
        displayName = "Syringe (5ml) [Midazolam]";
        descriptionShort = "Prepared syringe of Midazolam.";
        count = 500;
        mass = 0.7;
    };
    class ACM_Syringe_3_Midazolam: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_3_ca.paa";
        displayName = "Syringe (3ml) [Midazolam]";
        descriptionShort = "Prepared syringe of Midazolam.";
        count = 300;
        mass = 0.6;
    };
    class ACM_Syringe_1_Midazolam: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_1_ca.paa";
        displayName = "Syringe (1ml) [Midazolam]";
        descriptionShort = "Prepared syringe of Midazolam.";
        count = 100;
        mass = 0.5;
    };
    class ACM_Syringe_10_Rocuronium: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_10_ca.paa";
        displayName = "Syringe (10ml) [Rocuronium]";
        descriptionShort = "Prepared syringe of Rocuronium (paralytic).";
        count = 1000;
        mass = 0.9;
    };
    class ACM_Syringe_5_Rocuronium: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_5_ca.paa";
        displayName = "Syringe (5ml) [Rocuronium]";
        descriptionShort = "Prepared syringe of Rocuronium (paralytic).";
        count = 500;
        mass = 0.7;
    };
    class ACM_Syringe_3_Rocuronium: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_3_ca.paa";
        displayName = "Syringe (3ml) [Rocuronium]";
        descriptionShort = "Prepared syringe of Rocuronium (paralytic).";
        count = 300;
        mass = 0.6;
    };
    class ACM_Syringe_1_Rocuronium: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_1_ca.paa";
        displayName = "Syringe (1ml) [Rocuronium]";
        descriptionShort = "Prepared syringe of Rocuronium (paralytic).";
        count = 100;
        mass = 0.5;
    };
    class ACM_Syringe_10_Sugammadex: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_10_ca.paa";
        displayName = "Syringe (10ml) [Sugammadex]";
        descriptionShort = "Prepared syringe of Sugammadex (rocuronium reversal).";
        count = 1000;
        mass = 0.9;
    };
    class ACM_Syringe_5_Sugammadex: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_5_ca.paa";
        displayName = "Syringe (5ml) [Sugammadex]";
        descriptionShort = "Prepared syringe of Sugammadex (rocuronium reversal).";
        count = 500;
        mass = 0.7;
    };
    class ACM_Syringe_3_Sugammadex: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_3_ca.paa";
        displayName = "Syringe (3ml) [Sugammadex]";
        descriptionShort = "Prepared syringe of Sugammadex (rocuronium reversal).";
        count = 300;
        mass = 0.6;
    };
    class ACM_Syringe_1_Sugammadex: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_1_ca.paa";
        displayName = "Syringe (1ml) [Sugammadex]";
        descriptionShort = "Prepared syringe of Sugammadex (rocuronium reversal).";
        count = 100;
        mass = 0.5;
    };
    class ACM_Syringe_10_CalciumGluconate: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_10_ca.paa";
        displayName = "Syringe (10ml) [CalciumGluconate]";
        descriptionShort = "Prepared syringe of CalciumGluconate.";
        count = 1000;
        mass = 0.9;
    };
    class ACM_Syringe_5_CalciumGluconate: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_5_ca.paa";
        displayName = "Syringe (5ml) [CalciumGluconate]";
        descriptionShort = "Prepared syringe of CalciumGluconate.";
        count = 500;
        mass = 0.7;
    };
    class ACM_Syringe_3_CalciumGluconate: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_3_ca.paa";
        displayName = "Syringe (3ml) [CalciumGluconate]";
        descriptionShort = "Prepared syringe of CalciumGluconate.";
        count = 300;
        mass = 0.6;
    };
    class ACM_Syringe_1_CalciumGluconate: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_1_ca.paa";
        displayName = "Syringe (1ml) [CalciumGluconate]";
        descriptionShort = "Prepared syringe of CalciumGluconate.";
        count = 100;
        mass = 0.5;
    };
    class ACM_Syringe_10_Propofol: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_10_ca.paa";
        displayName = "Syringe (10ml) [Propofol]";
        descriptionShort = "Prepared syringe of Propofol.";
        count = 1000;
        mass = 0.9;
    };
    class ACM_Syringe_5_Propofol: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_5_ca.paa";
        displayName = "Syringe (5ml) [Propofol]";
        descriptionShort = "Prepared syringe of Propofol.";
        count = 500;
        mass = 0.7;
    };
    class ACM_Syringe_3_Propofol: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_3_ca.paa";
        displayName = "Syringe (3ml) [Propofol]";
        descriptionShort = "Prepared syringe of Propofol.";
        count = 300;
        mass = 0.6;
    };
    class ACM_Syringe_1_Propofol: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_1_ca.paa";
        displayName = "Syringe (1ml) [Propofol]";
        descriptionShort = "Prepared syringe of Propofol.";
        count = 100;
        mass = 0.5;
    };
    class ACM_Syringe_10_Ceftriaxone: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_10_ca.paa";
        displayName = "Syringe (10ml) [Ceftriaxone]";
        descriptionShort = "Prepared syringe of Ceftriaxone.";
        count = 1000;
        mass = 0.9;
    };
    class ACM_Syringe_5_Ceftriaxone: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_5_ca.paa";
        displayName = "Syringe (5ml) [Ceftriaxone]";
        descriptionShort = "Prepared syringe of Ceftriaxone.";
        count = 500;
        mass = 0.7;
    };
    class ACM_Syringe_3_Ceftriaxone: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_3_ca.paa";
        displayName = "Syringe (3ml) [Ceftriaxone]";
        descriptionShort = "Prepared syringe of Ceftriaxone.";
        count = 300;
        mass = 0.6;
    };
    class ACM_Syringe_1_Ceftriaxone: ACM_Syringe_10_Epinephrine {
        author = "mavis";
        dlc = "ACM_Extended";
        picture = "\x\ACM\addons\circulation\ui\syringe_1_ca.paa";
        displayName = "Syringe (1ml) [Ceftriaxone]";
        descriptionShort = "Prepared syringe of Ceftriaxone.";
        count = 100;
        mass = 0.5;
    };
};
class CfgWeapons {
    class ACE_ItemCore;
    class CBA_MiscItem_ItemInfo;
    class ACM_NCDKit;
    class ACM_Paracetamol_SinglePack {
        displayName = "Acetaminophen (Single Pack)";
    };
    class ACME_HTSBag: ACE_ItemCore {
        author = "mavis";
        dlc = "ACM_Extended";
        scope = 2;
        displayName = "Hypertonic Saline 3% (250mL)";
        picture = "\acm_extended\ui\items\htsiv_ca.paa";
        descriptionShort = "Premixed 3% hypertonic saline. Osmotherapy for raised ICP.";
        ACE_isMedicalItem = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 3;
        };
    };
    class ACME_HTSBullet: ACE_ItemCore {
        author = "mavis";
        dlc = "ACM_Extended";
        scope = 2;
        displayName = "Hypertonic Saline 23.4% (30mL)";
        picture = "\acm_extended\ui\items\htsiv_ca.paa";
        descriptionShort = "Concentrated osmotherapy bolus for herniation. Central access preferred. Buys minutes, does not fix the lesion.";
        ACE_isMedicalItem = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 1;
        };
    };
    class ACME_MannitolVial: ACE_ItemCore {
        author = "mavis";
        dlc = "ACM_Extended";
        scope = 2;
        displayName = "Mannitol 20% (50g Push)";
        picture = "\acm_extended\ui\items\mannitolbag_iv_ca.paa";
        descriptionShort = "Osmotic diuretic push for raised ICP. Lowers circulating volume as it works.";
        ACE_isMedicalItem = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 2;
        };
    };
    class ACME_Ventilator: ACE_ItemCore {
        author = "mavis";
        dlc = "ACM_Extended";
        scope = 2;
        displayName = "Ventway Sparrow Robust";
        picture = "\acm_extended\ui\vent\ventway_sparrow_robust_ca.paa";
        descriptionShort = "Portable transport ventilator. Carry it and use the self-interaction to open the control panel.";
        ACE_isMedicalItem = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 29;
        };
    };
    class ACME_VentBattery: ACE_ItemCore {
        author = "mavis";
        dlc = "ACM_Extended";
        scope = 2;
        displayName = "Ventway Sparrow Battery";
        descriptionShort = "Spare lithium battery pack for the Ventway Sparrow. Replaces a depleted battery in the field.";
        picture = "\acm_extended\ui\vent\ventway_sparrow_robust_battery_ca.paa";
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 5;
        };
    };
    class ACME_Laryngoscope: ACE_ItemCore {
        author = "mavis";
        dlc = "ACM_Extended";
        scope = 2;
        displayName = "Laryngoscope";
        picture = "\acm_extended\ui\vent\laryngoscope_ca.paa";
        descriptionShort = "Rigid laryngoscope for direct-vision orotracheal intubation. Needed with an ET tube to intubate.";
        ACE_isMedicalItem = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 4;
        };
    };
    class ACME_ETTube: ACE_ItemCore {
        author = "mavis";
        dlc = "ACM_Extended";
        scope = 2;
        displayName = "Endotracheal Tube";
        picture = "\acm_extended\ui\vent\et_tube_ca.paa";
        descriptionShort = "Cuffed endotracheal tube. Passed under direct laryngoscopy to secure a definitive airway.";
        ACE_isMedicalItem = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 1;
        };
    };
    class ACME_MagnesiumBag: ACE_ItemCore {
        author = "mavis";
        dlc = "ACM_Extended";
        scope = 2;
        displayName = "Magnesium Sulfate (2g / 50mL)";
        picture = "\acm_extended\ui\items\mgbag_50ml_iv_ca.paa";
        descriptionShort = "Premixed magnesium sulfate, 2 g in 50 mL. First-line for torsades / polymorphic VT.";
        ACE_isMedicalItem = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 2;
        };
    };
    class ACME_MannitolBag: ACE_ItemCore {
        author = "mavis";
        dlc = "ACM_Extended";
        scope = 2;
        displayName = "Mannitol 20% (500mL)";
        picture = "\acm_extended\ui\items\mannitolbag_iv_ca.paa";
        descriptionShort = "Premixed 20% mannitol in 500 mL. Osmotic diuretic for raised ICP.";
        ACE_isMedicalItem = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 5;
        };
    };
    class ACME_PlasmaLyteBag: ACE_ItemCore {
        author = "mavis";
        dlc = "ACM_Extended";
        scope = 2;
        displayName = "Plasma-Lyte A (1000mL)";
        picture = "\acm_extended\ui\items\plasmalyte-a_ca.paa";
        descriptionShort = "Balanced crystalloid, 1000 mL. Volume resuscitation + buffers metabolic acidosis. Shelf-stable; no cells/protein/clotting factors (not plasma).";
        ACE_isMedicalItem = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 10;
        };
    };
    class ACME_PlasmaLyteBag_500: ACME_PlasmaLyteBag {
        author = "mavis";
        dlc = "ACM_Extended";
        displayName = "Plasma-Lyte A (500mL)";
        descriptionShort = "Balanced crystalloid, 500 mL. Volume resuscitation + buffers metabolic acidosis. Shelf-stable.";
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 5;
        };
    };
    class ACME_PlasmaLyteBag_250: ACME_PlasmaLyteBag {
        author = "mavis";
        dlc = "ACM_Extended";
        displayName = "Plasma-Lyte A (250mL)";
        descriptionShort = "Balanced crystalloid, 250 mL. Volume resuscitation + buffers metabolic acidosis. Shelf-stable.";
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 3;
        };
    };
    class ACME_PlasmaLyteBag_100: ACME_PlasmaLyteBag {
        author = "mavis";
        dlc = "ACM_Extended";
        displayName = "Plasma-Lyte A (100mL)";
        descriptionShort = "Balanced crystalloid, 100 mL. Small volume / carrier. Shelf-stable.";
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 2;
        };
    };
    class ACME_SalineBag_50: ACE_ItemCore {
        author = "mavis";
        dlc = "ACM_Extended";
        scope = 2;
        displayName = "Saline IV (50mL)";
        picture = "\acm_extended\ui\items\salineiv_50ml_ca.paa";
        descriptionShort = "0.9% sodium chloride, 50 mL. Small flush / keep-vein-open volume. As a Y-line reserve this is one line flush.";
        ACE_isMedicalItem = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 1;
        };
    };
    class ACME_SalineBag_100: ACE_ItemCore {
        author = "mavis";
        dlc = "ACM_Extended";
        scope = 2;
        displayName = "Saline IV (100mL)";
        picture = "\acm_extended\ui\items\salineiv_100ml_ca.paa";
        descriptionShort = "0.9% sodium chloride, 100 mL. Small flush / keep-vein-open volume. As a Y-line reserve this is two line flushes.";
        ACE_isMedicalItem = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 2;
        };
    };
    class ACME_Spray_Esketamine: ACE_ItemCore {
        author = "mavis";
        dlc = "ACM_Extended";
        scope = 2;
        displayName = "Esketamine Atomizer (IN, 50mg)";
        picture = "\acm_extended\ui\items\esketamine_in_ca.paa";
        descriptionShort = "Intranasal esketamine for moderate-to-severe pain when IV access isn't available. Well tolerated in shock / hemodynamic instability; far less respiratory depression than opioids; preserves airway reflexes.";
        ACE_isMedicalItem = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 1;
        };
    };
    class ACE_bloodIV;
    class ACE_salineIV_250;
    class ACE_salineIV_500;
    class ACM_Vial_Epinephrine;
    class ACME_Vial_EpinephrineCardiac: ACM_Vial_Epinephrine {
        dlc = "ACM_Extended";
        scope = 2;
        scopeArsenal = 2;
        author = "mavis";
        displayName = "Epinephrine 1:10,000 (1 mg / 10 mL)";
        picture = "\acm_extended\ui\items\vial_epinephrine_1_10000_ca.paa";
        descriptionShort = "0.1 mg/mL cardiac epinephrine. IV/IO source. For a 10 mcg/mL mixture: 1 mL of this source plus 9 mL saline. The full mixture contains 100 mcg, not 10 mcg.";
        ACE_isMedicalItem = 1;
        ACM_isVial = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 1;
        };
    };
    class ACM_Vial_EpinephrineCardiac: ACME_Vial_EpinephrineCardiac {
        author = "mavis";
        dlc = "ACM_Extended";
        scope = 1;
        scopeArsenal = 0;
    };
    class ACM_Vial_Norepinephrine: ACE_ItemCore {
        dlc = "ACM_Extended";
        scope = 2;
        author = "mavis";
        displayName = "Norepinephrine (4mg/4ml)";
        descriptionShort = "Vasopressor. CPP support AFTER volume resuscitation.";
        picture = "\acm_extended\ui\items\vial_norepinephrine_ca.paa";
        ACE_isMedicalItem = 1;
        ACM_isVial = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 1;
        };
    };
    class ACM_Vial_Phentolamine: ACE_ItemCore {
        dlc = "ACM_Extended";
        scope = 2;
        author = "mavis";
        displayName = "Phentolamine (5mg/1ml)";
        descriptionShort = "Alpha-blocker. Antidote for vasopressor (norepi/epi) extravasation.";
        picture = "\acm_extended\ui\items\vial_norepinephrine_ca.paa";
        ACE_isMedicalItem = 1;
        ACM_isVial = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 1;
        };
    };
    class ACM_Vial_Hyaluronidase: ACE_ItemCore {
        dlc = "ACM_Extended";
        scope = 2;
        author = "mavis";
        displayName = "Hyaluronidase (150U/1ml)";
        descriptionShort = "Spreading-factor enzyme. Antidote for hyperosmolar/irritant extravasation.";
        picture = "\acm_extended\ui\items\vial_norepinephrine_ca.paa";
        ACE_isMedicalItem = 1;
        ACM_isVial = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 1;
        };
    };
    class ACM_Vial_Rocuronium: ACE_ItemCore {
        dlc = "ACM_Extended";
        scope = 2;
        author = "mavis";
        displayName = "Rocuronium Bromide (100mg/10ml)";
        descriptionShort = "Non-depolarizing paralytic for RSI. NO sedation: paralyzes and stops breathing. Sedate first.";
        picture = "\acm_extended\ui\items\vial_rocuronium_ca.paa";
        ACE_isMedicalItem = 1;
        ACM_isVial = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 1;
        };
    };
    class ACM_Vial_Sugammadex: ACE_ItemCore {
        dlc = "ACM_Extended";
        scope = 2;
        author = "mavis";
        displayName = "Sugammadex (500mg/5ml)";
        descriptionShort = "Reverses rocuronium. Restores spontaneous breathing in ~2-3 min. Rescues a failed RSI. Dose by WEIGHT: 16 mg/kg to reverse a fresh intubating dose. Under-dose and the block RETURNS. NOT a sedative: does not undo awareness.";
        picture = "\acm_extended\ui\items\vial_sugammadex_ca.paa";
        ACE_isMedicalItem = 1;
        ACM_isVial = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 1;
        };
    };
    class ACM_Vial_Ceftriaxone: ACE_ItemCore {
        dlc = "ACM_Extended";
        scope = 2;
        author = "mavis";
        displayName = "Ceftriaxone (1g/10ml)";
        descriptionShort = "Broad-spectrum antibiotic. Satisfies the evacuation antibiotic requirement (same as ertapenem).";
        picture = "\acm_extended\ui\items\vial_ceftriaxone_ca.paa";
        ACE_isMedicalItem = 1;
        ACM_isVial = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 1;
        };
    };
    class ACM_Vial_CalciumGluconate: ACE_ItemCore {
        dlc = "ACM_Extended";
        scope = 2;
        author = "mavis";
        displayName = "Calcium Gluconate (5g/50ml)";
        descriptionShort = "Calcium salt for hypocalcemia / hyperkalemia / post-transfusion. Far gentler on peripheral veins than calcium chloride.";
        picture = "\acm_extended\ui\items\vial_calcium_gluconate_ca.paa";
        ACE_isMedicalItem = 1;
        ACM_isVial = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 1;
        };
    };
    class ACM_Vial_Propofol: ACE_ItemCore {
        dlc = "ACM_Extended";
        scope = 2;
        author = "mavis";
        displayName = "Propofol (500mg/50ml)";
        descriptionShort = "Sedative-hypnotic for induction and procedural sedation. Causes dose-dependent hypotension and apnea; half of Ketofol.";
        picture = "\acm_extended\ui\items\vial_propofol_ca.paa";
        ACE_isMedicalItem = 1;
        ACM_isVial = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 1;
        };
    };
    class ACM_Vial_Midazolam: ACE_ItemCore {
        dlc = "ACM_Extended";
        scope = 2;
        author = "mavis";
        displayName = "Midazolam (5mg/5ml)";
        descriptionShort = "Benzodiazepine for sedation / seizure control. IV variant for push or infusion.";
        picture = "\acm_extended\ui\items\vial_midazolam_ca.paa";
        ACE_isMedicalItem = 1;
        ACM_isVial = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 1;
        };
    };
    class ACM_Vial_Fentanyl: ACE_ItemCore {
        dlc = "ACM_Extended";
        scope = 2;
        author = "mavis";
        displayName = "Fentanyl (500mcg/10ml)";
        descriptionShort = "Synthetic opioid. Analgesia at 25-50mcg. At 2-3mcg/kg given three minutes before laryngoscopy it blunts the sympathetic response and the ICP surge that comes with it.";
        picture = "\acm_extended\ui\items\vial_midazolam_ca.paa";
        ACE_isMedicalItem = 1;
        ACM_isVial = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 1;
        };
    };
    class ACME_IVLine: ACE_ItemCore {
        dlc = "ACM_Extended";
        scope = 2;
        author = "mavis";
        displayName = "IV Line (Administration Set) (QTTS)";
        descriptionShort = "Spike set / tubing. Required to spike a fluid bag before it can be hung. One per bag.";
        picture = "\acm_extended\ui\items\iv_line_qtts_ca.paa";
        ACE_isMedicalItem = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 0.1;
        };
    };
    class ACME_YTubing: ACE_ItemCore {
        dlc = "ACM_Extended";
        scope = 2;
        author = "mavis";
        displayName = "Y-Type Blood Tubing Set (QTTS)";
        descriptionShort = "Blood administration set (dual-spike, in-line filter). Pair blood with a compatible saline bag. Flush the line when prompted; no 250mL bag minimum.";
        picture = "\acm_extended\ui\items\y_tubing_qtts_ca.paa";
        ACE_isMedicalItem = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 0.2;
        };
    };
    class ACME_BloodWarmer: ACE_ItemCore {
        dlc = "ACM_Extended";
        scope = 2;
        author = "mavis";
        displayName = "LifeWarmer Quantum";
        descriptionShort = "Inline blood/fluid warmer. Non-cold blood runs at 200 mL/min; cold-stored blood uses the cold-flow ladder. Warms transfused blood and counters hypothermia.";
        picture = "\acm_extended\ui\items\quantum_bloodwarmer_ca.paa";
        ACE_isMedicalItem = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 0.3;
        };
    };
    class ACME_PressureInfuser: ACE_ItemCore {
        dlc = "ACM_Extended";
        scope = 2;
        author = "mavis";
        displayName = "Pressure Infuser Bag";
        descriptionShort = "Pressure cuff for a blood/fluid bag. Apply it to a hung line and pump it up to force the unit in fast (rapid transfuser). Reusable.";
        picture = "\acm_extended\ui\items\pressure_infuser_ca.paa";
        ACE_isMedicalItem = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 0.4;
        };
    };
    class ACME_NARBOA: ACE_ItemCore {
        dlc = "ACM_Extended";
        scope = 2;
        author = "mavis";
        displayName = "NAR BOA Constricting Band";
        descriptionShort = "Wide elastic constricting band. Applied proximal to the IV site to engorge the veins for an easier stick.";
        picture = "\acm_extended\ui\nar_boa_ca.paa";
        ACE_isMedicalItem = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 0.2;
        };
    };
    class ACM_EsmololBag: ACE_salineIV_250 {
        dlc = "ACM_Extended";
        scope = 2;
        author = "mavis";
        displayName = "Esmolol 2500mg/250ml (10mg/ml)";
        descriptionShort = "Premixed esmolol drip. Rate control for AFib-RVR / atrial tach (titrate to mcg/kg/min). Transfusable bag.";
        picture = "\acm_extended\ui\items\esmololbagiv_ca.paa";
        ACE_isMedicalItem = 1;
        ACME_premixedBag = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 8;
        };
    };
    class ACE_esmololIV_250: ACE_salineIV_250 {
        scope = 1;
        author = "mavis";
        displayName = "Esmolol 2500mg/250ml (10mg/ml)";
        picture = "\acm_extended\ui\items\esmololbagiv_ca.paa";
    };
    class ACE_htsIV_250: ACE_salineIV_250 {
        scope = 1;
        author = "mavis";
        displayName = "Hypertonic Saline 3% (250ml)";
        picture = "\acm_extended\ui\items\htsiv_ca.paa";
    };
    class ACE_mannitolIV_500: ACE_salineIV_500 {
        scope = 1;
        author = "mavis";
        displayName = "Mannitol 20% (500ml)";
        picture = "\acm_extended\ui\items\mannitolbag_iv_ca.paa";
    };
    class ACE_magnesiumIV_50: ACE_salineIV_250 {
        scope = 1;
        author = "mavis";
        displayName = "Magnesium Sulfate (2g / 50ml)";
        picture = "\acm_extended\ui\items\mgbag_50ml_iv_ca.paa";
    };
    class ACM_IV_18g: ACE_ItemCore {
        dlc = "ACM_Extended";
        scope = 2;
        author = "mavis";
        displayName = "18g IV";
        descriptionShort = "Smaller-bore peripheral IV. Slower flow than 16G. Distal limb sites risk a hypertensive surge with drips/pressors.";
        picture = "\acm_extended\ui\items\iv_18g_ca.paa";
        ACE_isMedicalItem = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 0.1;
        };
    };
    class ACM_IV_16g: ACE_ItemCore {
        picture = "\acm_extended\ui\items\iv_16g_ca.paa";
    };
    class ACM_IV_14g: ACM_IV_16g {
        descriptionShort = "Large-bore peripheral IV. Wrist placement requires an extremely accurate central stick or the vein blows.";
        picture = "\acm_extended\ui\items\iv_14g_ca.paa";
    };
    class ACM_IV_20g: ACE_ItemCore {
        dlc = "ACM_Extended";
        scope = 2;
        author = "mavis";
        displayName = "20g IV";
        descriptionShort = "Smallest-bore peripheral IV. Slowest flow. Most forgiving placement margin at the wrist.";
        picture = "\acm_extended\ui\items\iv_20g_ca.paa";
        ACE_isMedicalItem = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 0.1;
        };
    };
    class ACM_SalineFlush_10: ACE_ItemCore {
        dlc = "ACM_Extended";
        scope = 2;
        author = "mavis";
        displayName = "Saline Flush (10ml)";
        descriptionShort = "Prefilled 10 mL flush. Base for improvised push-dose epi (1:100,000).";
        picture = "\acm_extended\ui\items\salineFlush_ca.paa";
        ACE_isMedicalItem = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 1;
        };
    };
    class ACM_Thermometer: ACE_ItemCore {
        dlc = "ACM_Extended";
        scope = 2;
        author = "mavis";
        displayName = "SureTemp Plus 690";
        descriptionShort = "Welch Allyn SureTemp Plus 690 electronic thermometer. Measures patient core temperature for hypothermia assessment. Reusable. 215 mm x 81 mm x 62 mm, 12.6 oz (~357 g).";
        picture = "\acm_extended\ui\items\suretemp690_thermometer_ca.paa";
        ACE_isMedicalItem = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 1;
        };
    };
    class ACM_NRBMask: ACE_ItemCore {
        dlc = "ACM_Extended";
        scope = 2;
        author = "mavis";
        displayName = "Non-Rebreather Mask";
        descriptionShort = "High-flow oxygen mask (15 L/min, FiO2 ~0.9). Reusable. Apply on the patient's head.";
        picture = "\acm_extended\ui\items\nrbmask_ca.paa";
        ACE_isMedicalItem = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 2;
        };
    };
    class ACM_HPMK: ACE_ItemCore {
        dlc = "ACM_Extended";
        scope = 2;
        author = "mavis";
        displayName = "NAR HPMK";
        descriptionShort = "Hypothermia Prevention &amp; Management Kit. Reusable warming blanket.";
        picture = "\acm_extended\ui\items\HPMK_ca.paa";
        nameSound = "";
        ACE_isMedicalItem = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 8;
        };
    };
    class ACM_EMMA: ACE_ItemCore {
        dlc = "ACM_Extended";
        scope = 2;
        author = "mavis";
        displayName = "EMMA Capnograph";
        descriptionShort = "Mainstream end-tidal CO2 monitor. Attach it to your own BVM; it stays in inventory and follows your BVM between patients.";
        picture = "\acm_extended\ui\emma\emma_etco2_ca.paa";
        ACE_isMedicalItem = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 2;
        };
    };
    class ACM_CombatGauze: ACE_ItemCore {
        dlc = "ACM_Extended";
        scope = 2;
        author = "mavis";
        model = "\z\ace\addons\medical_treatment\data\bandage.p3d";
        displayName = "Combat Gauze";
        descriptionShort = "Hemostatic gauze for packing junctional hemorrhage. Pack the wound, then secure with a pressure bandage.";
        picture = "\acm_extended\ui\items\combat_gauze_ca.paa";
        ACE_isMedicalItem = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 1;
        };
    };
    class ACME_NARSPEAR: ACM_NCDKit {
        dlc = "ACM_Extended";
        scope = 2;
        author = "mavis";
        displayName = "NAR SPEAR";
        descriptionShort = "Needle decompression device for pneumothorax and tension pneumothorax.";
        picture = "\acm_extended\ui\items\nar_spear_ca.paa";
    };
    class ACME_AAJT_S: ACE_ItemCore {
        dlc = "ACM_Extended";
        scope = 2;
        author = "mavis";
        model = "\z\ace\addons\medical_treatment\data\bandage.p3d";
        displayName = "NAR AAJT-S";
        descriptionShort = "Abdominal Aortic &amp; Junctional Tourniquet (Stabilized). Inguinal placement occludes one selected leg; axillary placement occludes one selected arm; Zone 3 REBOA placement occludes both lower extremities. Bulky (~7.5 x 6.5 x 2 in, ~17 oz).";
        picture = "\acm_extended\ui\items\aajt-s_ca.paa";
        ACE_isMedicalItem = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 16;
        };
    };
    class ACME_XStat: ACE_ItemCore {
        dlc = "ACM_Extended";
        scope = 2;
        author = "mavis";
        model = "\z\ace\addons\medical_treatment\data\bandage.p3d";
        displayName = "XStat 30";
        descriptionShort = "Injectable hemostatic sponge bolus for inguinal junctional hemorrhage. Extreme-case: very fast, controls bleeding completely, but permanently impairs the leg and requires surgical removal.";
        picture = "\acm_extended\ui\items\xstat_ca.paa";
        ACE_isMedicalItem = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 1;
        };
    };
    class ACME_SpoiledBlood: ACE_ItemCore {
        dlc = "ACM_Extended";
        scope = 2;
        author = "mavis";
        displayName = "Blood Bag (SPOILED)";
        descriptionShort = "This blood lost its cold chain and is no longer safe to transfuse. Discard it.";
        picture = "\acm_extended\ui\items\spoiled_bloodiv_ca.paa";
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 4;
        };
    };
    class ACME_BloodCooler_CSWB1U: ACE_ItemCore {
        dlc = "ACM_Extended";
        scope = 2;
        author = "mavis";
        displayName = "Golden Hour CSWB-1U";
        descriptionShort = "Single-unit blood cold-chain carrier (1x 500 ml). Keeps one unit of blood cold and transfusable; longest coolant life of the three.";
        picture = "\acm_extended\ui\items\goldenhour_cswb1u_ca.paa";
        ACE_isMedicalItem = 1;
        ACME_coolerCapacityMl = 500;
        ACME_coolerColdChainTime = 7200;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 50;
        };
    };
    class ACME_BloodCooler_CSWB2U: ACE_ItemCore {
        dlc = "ACM_Extended";
        scope = 2;
        author = "mavis";
        displayName = "Golden Minute CSWB-2U";
        descriptionShort = "Two-unit blood cold-chain carrier. 2000 mL total capacity.";
        picture = "\acm_extended\ui\items\goldenminute_cswb2u_ca.paa";
        ACE_isMedicalItem = 1;
        ACME_coolerCapacityMl = 1000;
        ACME_coolerColdChainTime = 5400;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 100;
        };
    };
    class ACME_BloodCooler_CSWB4U: ACE_ItemCore {
        dlc = "ACM_Extended";
        scope = 2;
        author = "mavis";
        displayName = "Golden Hour CSWB-4U";
        descriptionShort = "Four-unit blood cold-chain container. 2000 mL total capacity.";
        picture = "\acm_extended\ui\items\goldenhour_cswb4u_ca.paa";
        ACE_isMedicalItem = 1;
        ACME_coolerCapacityMl = 2000;
        ACME_coolerColdChainTime = 10800;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 330;
        };
    };
};
class ace_medical_treatment {
    class IV {
        class SalineIV;
        class EsmololIV_250: SalineIV {
            type = "Esmolol";
            volume = 250;
        };
        class HTSIV_250: SalineIV {
            type = "HTS";
            volume = 250;
        };
        class MagnesiumIV_50: SalineIV {
            type = "Magnesium";
            volume = 50;
        };
        class MannitolIV_500: SalineIV {
            type = "Mannitol";
            volume = 500;
        };
        class PlasmaLyteIV_1000: SalineIV {
            type = "PlasmaLyte";
            volume = 1000;
        };
        class PlasmaLyteIV_500: SalineIV {
            type = "PlasmaLyte";
            volume = 500;
        };
        class PlasmaLyteIV_250: SalineIV {
            type = "PlasmaLyte";
            volume = 250;
        };
        class PlasmaLyteIV_100: SalineIV {
            type = "PlasmaLyte";
            volume = 100;
        };
        class SalineIV_50: SalineIV {
            type = "Saline";
            volume = 50;
        };
        class SalineIV_100: SalineIV {
            type = "Saline";
            volume = 100;
        };
    };
};
class CfgNonAIVehicles {
    class ACME_IVLine_Segment {
        scope = 2;
        displayName = "IV Line Segment";
        simulation = "ropesegment";
        autocenter = 0;
        animated = 0;
        model = "\acm_extended\models\iv_line_segment.p3d";
    };
};
class CfgGesturesMale {
    class Default;
    class States {
        class GestureFreezeStand;
        class GestureSpasm3;
        class GestureSpasm4;
        class GestureSpasm5;
        class GestureSpasm6;
        class ACME_IV_Gesture: GestureFreezeStand {
            file = "\acm_extended\animations\acm_iv_stand_lh.rtm";
            looped = 1;
            speed = 0.5;
            disableWeapons = 1;
            canPullTrigger = 0;
            enableOptics = 0;
        };
        class ACME_SeizureSpasm3: GestureSpasm3 {
            speed = 0.2499;
        };
        class ACME_SeizureSpasm4: GestureSpasm4 {
            speed = 0.244125;
        };
        class ACME_SeizureSpasm5: GestureSpasm5 {
            speed = 0.217245;
        };
        class ACME_SeizureSpasm6: GestureSpasm6 {
            speed = 0.135135;
        };
    };
};
class CfgFunctions {
    class ACME {
        tag = "ACME";
        class infusion {
            file = "\acm_extended\functions";
            class postInit {};
            class initMedicationRegistry {};
            class initTrainingCasualty {};
            class initInfusionConfig {};
            class initThoracostomyConfig {};
            class initCirculationConfig {};
            class initConsciousnessConfig {};
            class initIVProcedureConfig {};
            class initPatientPositioningConfig {};
            class initMegacodeConfig {};
            class initDrugPhysiologyConfig {};
            class initResuscitationConfig {};
            class initTbiProgressionConfig {};
            class initProcedurePainConfig {};
            class initBlastLungConfig {};
            class initFlightMotionConfig {};
            class initVentilatorClinicalConfig {};
            class initMedicalMenuConfig {};
            class initVentilatorUiPowerConfig {};
            class initPerfusionConfig {};
            class initVentilatorRuntimeConfig {};
            class initFlightPhysiologyConfig {};
            class initAirwayProcedureConfig {};
            class initNarcBoxConfig {};
            class registerTbiRuntime {};
            class registerBlastLungRuntime {};
            class registerCirculationRuntime {};
            class registerVentilatorAudioRuntime {};
            class initNrbRuntime {};
            class initHangBagRuntime {};
            class initHpmkCoreRuntime {};
            class initProcedureEnvironmentConfig {};
            class registerHpmkVisualRuntime {};
            class registerChestSealPresenceRuntime {};
            class registerHpmkTransportCleanupRuntime {};
            class initHypothermiaRuntime {};
            class registerMedicalBodyBaseRuntime {};
            class initBloodStorageRuntime {};
            class registerClinicalLifecycleRuntime {};
            class initHeadAirwayRuntime {};
            class initBlastOverpressureRuntime {};
            class initJunctionalConfig {};
            class initChestSealProcedureRuntime {};
            class registerInjuryPresentationRuntime {};
            class initRhythmTriggerConfig {};
            class initPressureAndAuscultationConfig {};
            class initRhythmHemodynamicsConfig {};
            class initMinigameVentDefaults {};
            class initCardioversionSafetyConfig {};
            class registerCompatibilityCheck {};
            class initMonitorSyncConfig {};
            class registerConsciousnessRuntime {};
            class registerProviderStanceReleaseRuntime {};
            class providerAnimSpeedOwned {};
            class registerHeadElevationTransportRuntime {};
            class registerRhythmLifecycleRuntime {};
            class registerInfusionProcessingRuntime {};
            class initEmmaRuntime {};
            class registerBvmVentRuntime {};
            class initAedMonitorRuntime {};
            class initRhythmThresholdRuntime {};
            class registerTransfusionUiRuntime {};
            class initHardcoreRuntime {};
            class registerTreatmentRollRuntime {};
            class registerHeadElevationTreatmentRuntime {};
            class registerChestAccessVestRuntime {};
            class chestAccessManeuverActive {};
            class chestAccessVestEvent {};
            class chestAccessVestAcquire {};
            class chestAccessVestPark {};
            class chestAccessVestRestore {};
            class chestAccessVestProvider {};
            class chestAccessPreparing {};
            class manualPlateCarrierCanToggle {};
            class manualPlateCarrierCommit {};
            class manualPlateCarrierAutoReturn {};
            class manualPlateCarrierHeadElevSupport {};
            class registerManualPlateCarrierRuntime {};
            class chestSealProviderHoldStart {};
            class registerMegacodeInteractionRuntime {};
            class registerVentilatorKeybindRuntime {};
            class initMinigameInteractionRuntime {};
            class registerMedicationDeliveryRuntime {};
            class registerEcgJostleRuntime {};
            class resetPersonalMedicationKit {};
            class registerSyringeLifecycleRuntime {};
            class initForkStartupRuntime {};
            class preoxygenationTick {};
            class shockPhenotypeTick {};
            class shockSetPhenotype {};
            class coagulationTick {};
            class coagulationBase {};
            class medicationCountCompat {};
            class treatmentSupplyOrder {};
            class treatmentSupplyCount {};
            class treatmentSupplyTake {};
            class treatmentSupplyTakeMany {};
            class treatmentSupplyRefund {};
            class choreographyRate {};
            class aspirationTick {};
            class pulsePerfusionProfile {};
            class expansionBootstrap {};
            class expansionRegisterRuntime {};
            class megacodeAARRecord {};
            class megacodeAARReset {};
            class megacodeAARShow {};
            class megacodeAARTick {};
            class registerDebugWatchdogRuntime {};
            class registerThoracicMenuPresentationRuntime {};
            class registerMedicalMenuOpenRuntime {};
            class registerClinicalMenuPresentationRuntime {};
            class initVesicantRuntime {};
            class registerRoscBreathingRuntime {};
            class registerClampDragRuntime {};
            class initTbiCoreState {};
            class initTbiCoreConfig {};
            class registerProcedureIntegrationRuntime {};
            class ivBagsCommit {};
            class tbiStateCommit {};
            class circStateCommit {};
            class infusionMedicationStateCommit {};
            class yLinesCommit {};
            class detachedBagsCommit {};
            class initNetworkSyncConfig {};
            class medicationRouteAllowed {};
            class medicationTakeSources {};
            class medicationAvailability {};
            class medicationCountRaw {};
            class medicationToxicityTick {};
            class medicationCBRNTick {};
            class medicationRecordIDs {};
            class medicationLineLocal {};
            class medicationRequest {};
            class medicationEscrowCommit {};
            class medicationLineIdentity {};
            class medicationLineBloodBusy {};
            class medicationLineFraction {};
            class medicationLeak {};
            class medicationRefund {};
            class medicationAck {};
            class medicationRetry {};
            class medicationExposure {};
            class medicationToxicityFiredCommit {};
            class medicationInteractions {};
            class medicationDriveAdd {};
            class medicationDriveTick {};
            class hardcoreMedicationRateEffect {};
            class ecgJostleLocal {};
            class ecgJostleRequest {};
            class ecgArtifactStrength {};
            class ecgArtifactApply {};
            class sedationThreshold {};
            class sedationPhysiology {};
            class adenosineTick {};
            class suctionStateLocal {};
            class suctionPhysiologyTick {};
            class suctionPublish {};
            class suctionObservers {};
            class ownerDispatch {};
            class patientInteractionDistance {};
            class headElevEffective {};
            class canCheckPatientDogtags {};
            class headElevHoldStart {};
            class headElevHoldRelease {};
            class headElevHoldClear {};
            class headElevHoldStop {};
            class headElevTreatmentEvent {};
            class clinicalInit {};
            class clinicalFields {};
            class clinicalCodec {};
            class clinicalEncodedValid {};
            class clinicalValidate {};
            class clinicalBagRecover {};
            class preparedAttachRequest {};
            class preparedAttachLocal {};
            class preparedAttachAck {};
            class preparedHangCommit {};
            class preparedHangResult {};
            class bagIdentity {};
            class infusionRegisterLocal {};
            class infusionRegisterCore {};
            class infusionAck {};
            class infusionRetire {};
            class infusionRemoveLocal {};
            class yFlushStart {};
            class yFlushTick {};
            class clinicalBagMove {};
            class infusionFlow {};
            class clinicalEpoch {};
            class clinicalNotice {};
            class arrestLocal {};
            class rhythmRelease {};
            class rhythmNative {};
            class shockRequest {};
            class shockLocal {};
            class shockROSC {};
            class clinicalTickDelta {};
            class bpCompute {};
            class clinicalBindings {};
            class clinicalInspect {};
            class clinicalSnapshot {};
            class clinicalRestore {};
            class clinicalReset {};
            class deathFreeze {};
            class deadPhysiologyFreeze {};
            class fluidCommit {};
            class infusionDeliver {};
            class injuryEvent {};
            class aajtOccludes {};
            class junctionalResume {};
            class netNotice {};
            class ownerRegister {};
            class ownerInit {};
            class aiProtectionWanted {};
            class aiProtectionSync {};
            class aiProtectionTick {};
            class aiProtectionInit {};
            class transientStateReconcile {};
            class providerStateReconcile {};
            class nrbStateLocal {};
            class nrbStateCommit {};
            class nrbSoundServer {};
            class nrbOxygenDraw {};
            class nrbOxygenSource {};
            class nrbOxygenAck {};
            class chestSealKey {};
            class chestSealActualSide {};
            class chestSealCanPhysicalRoll {};
            class chestSealReset {};
            class chestSealSession {};
            class chestSealRequest {};
            class chestSealEdit {};
            class chestSealAck {};
            class chestSealSyncUI {};
            class chestSealEffectLocal {};
            class chestSealLogOnce {};
            class chestSealNetInit {};
            class a11yColor {};
            class menuLeftAlignTick {};
            class bpNative {};
            class checkTemperature {};
            class tempInjuryEntry {};
            class acmSpawnerArmor {};
            class openFromTransfusionMenu {};
            class openPrepFromInventoryMenu {};
            class givePreparedBag {};
            class openDrawMenu {};
            class patchDrawDialog {};
            class injectIntoBag {};
            class infusionDone {};
            class infusionRefreshTally {};
            class transfusionSpikeOrAdd {};
            class bloodThermalStateCommit {};
            class transfusionYTubing {};
            class transfusionFlushLine {};
            class transfusionPullBag {};
            class transfusionPullCommit {};
            class transfusionPullResult {};
            class rehangUsedBagCommit {};
            class rehangUsedBagResult {};
            class yRefillCommit {};
            class yRefillResult {};
            class discardYTubingCommit {};
            class discardYTubingResult {};
            class discardYTubing {};
            class resumeSiteFlow {};
            class togglePreparedSets {};
            class hangPreparedSet {};
            class yLineAttach {};
            class ySalineSetup {};
            class ySalinePin {};
            class bloodFridgeModuleInit {};
            class bloodFridgeSetup {};
            class bloodFridgeTakeMenu {};
            class bloodFridgeTake {};
            class bloodFridgeTick {};
            class bloodFridgeMenuPoll {};
            class coolerInvHook {};
            class coolerOpenDialog {};
            class coolerOpenCarried {};
            class coolerAutoStore {};
            class coolerRefresh {};
            class coolerClearSlots {};
            class cheyneStokesTick {};
            class debugCheyneStokes {};
            class installRmbCancelGuard {};
            class airwayMedicPose {};
            class assessmentTime {};
            class assessmentStart {};
            class assessmentTick {};
            class assessmentStop {};
            class assessmentFinish {};
            class assessmentProgress {};
            class assessmentCompletion {};
            class assessmentAdvance {};
            class assessmentProgressBar {};
            class respirationStart {};
            class respirationStep {};
            class respirationTick {};
            class respirationStop {};
            class respirationRate {};
            class airwayInjuryRelabel {};
            class animQueue {};
            class headElevMedicSeq {};
            class ptxTensionTick {};
            class ptxEnsure {};
            class ptxPublish {};
            class ptxInjury {};
            class ptxStep {};
            class ptxTreat {};
            class ptxAmbientChange {};
            class ptxContext {};
            class ivCathSetFrame {};
            class ivMinigamePullTick {};
            class ivMinigamePullStop {};
            class ivNeedleTip {};
            class thoraOutput {};
            class thoraOutputStateCommit {};
            class thoraOutputEntry {};
            class ivSiteIndex {};
            class laryngoTubeEject {};
            class ivCathTex {};
            class ivCathGeometry {};
            class ivLimbBounds {};
            class ivCathPose {};
            class ivMinigameHookCtrl {};
            class ivInfiltrated {};
            class ivMinigameGrabLine {};
            class ivMinigameBandFlag {};
            class ivMinigameSyncBand {};
            class ivMinigameSaveState {};
            class ivMinigameRestoreState {};
            class ivMinigameResetView {};
            class ivMinigamePrepView {};
            class ivMinigameViewValid {};
            class ivMinigameInsertStart {};
            class ivMinigameInsertAdvance {};
            class ivMinigameScroll {};
            class ivMinigameRetract {};
            class ivMinigameLineConnect {};
            class ivSiteRelabel {};
            class ivGaugeRelabel {};
            class ivLogRelabel {};
            class bodyPartName {};
            class medLog {};
            class clinTerm {};
            class inspectForFracture {};
            class woundNameRelabel {};
            class bleedStatusRelabel {};
            class descriptorSelfTest {};
            class ioPainResponse {};
            class ivSiteData {};
            class ivHeldRaise {};
            class ivSeedHub {};
            class doAnim {};
            class providerAnimation {};
            class medicAnimationPrep {};
            class rollProviderStart {};
            class obtundedMasterChanged {};
            class obtundedWeaponIntent {};
            class ivSiteAtPoint {};
            class ivEnforceSite {};
            class ivPlacementLocal {};
            class ivUiValid {};
            class ivStateLocal {};
            class ivPrepPaint {};
            class ivVenousPhenotype {};
            class ivVeinSet {};
            class ivVeinNearest {};
            class ivPalpModel {};
            class netReport {};
            class networkDiagnostics {};
            class ivSiteDifficulty {};
            class ivStickBlows {};
            class ivVeinDist {};
            class ivVeinCatalog {};
            class ivLogSite {};
            class ivMinigameCursor {};
            class ivMinigameGrabBand {};
            class ivMinigameGrabNeedle {};
            class ivMinigameGrabPad {};
            class ivMinigameCleanDone {};
            class ivMinigameRelease {};
            class ivMinigameRenderMarks {};
            class ivExtravasationState {};
            class visualBruiseState {};
            class ivMinigameAddMark {};
            class ivMarkCommit {};
            class ivMinigameClick {};
            class ivMinigameRefreshBandSlot {};
            class ivTrayHover {};
            class ivMinigameRemoveBand {};
            class ivMinigameStickSuccess {};
            class ivMinigameFlip {};
            class ivMinigameRegister {};
            class ivMinigameOpen {};
            class ivMinigamePrepare {};
            class ivMinigameInit {};
            class ivMinigamePan {};
            class ivMinigameTick {};
            class ivMinigameClose {};
            class ivMinigameDone {};
            class coolerLoad {};
            class coolerStateCommit {};
            class coolerUnload {};
            class coolerContentsTick {};
            class take4U {};
            class coolerBoxDeploy {};
            class coolerBoxApplyScale {};
            class coolerBoxPackUp {};
            class coolerBoxColdChainTick {};
            class popClots {};
            class clotPopTick {};
            class cancelInfusionDraw {};
            class restoreMedicationList {};
            class findBestSyringe {};
            class registerBagMedication {};
            class registerPreparedBag {};
            class findPreparedBagIndex {};
            class findTrackedBag {};
            class bagInfusionEntry {};
            class findRunningDirtyEpi {};
            class isYLineAccess {};
            class isYLineBagContext {};
            class canMedicateBagContext {};
            class findNewestBagContext {};
            class getSelectedActiveBagContext {};
            class getSelectedInventoryBagContext {};
            class getSelectedInfusionEntryIndexes {};
            class isSalineItem {};
            class getSalineVolumeFromItem {};
            class handleInfusions {};
            class updateTransfusionControls {};
            class updateTransfusionAccessHotspots {};
            class selectTransfusionAccess {};
            class transfusionAccessValid {};
            class transfusionRemoveBagCommit {};
            class transfusionRemoveBagResult {};
            class transfusionFlowToggleCommit {};
            class updateEJTransfusionMenu {};
            class selectEJTransfusionSite {};
            class adjustDripRate {};
            class cycleDropSet {};
            class formatDose {};
            class formatRate {};
            class formatPreparedLabel {};
            class formatInfusionLabel {};
            class getSelectedPreparedInfusion {};
            class restorePausedFlow {};
            class clampPositionToDrops {};
            class dropsToClampPosition {};
            class openRollerClamp {};
            class onClampLoad {};
            class updateClampDialog {};
            class setClampPosition {};
            class scrollClamp {};
            class placeClampWheel {};
            class playClampSfx {};
            class syringeKitOpen {};
            class syringeKitOnLoad {};
            class syringeKitRender {};
            class syringeKitTick {};
            class syringeKitGrab {};
            class syringeKitInfo {};
            class syringeKitSize {};
            class syringeKitSource {};
            class syringeKitWaste {};
            class syringeKitDraw {};
            class skOpenDraw {};
            class uiCanvas {};
            class skInject {};
            class givePremixedSet {};
            class pressureInfuserCan {};
            class reopenTransfusion {};
            class skClickSound {};
            class skUpdateBody {};
            class menuActionInfo {};
            class menuDropdownState {};
            class menuExamineGroups {};
            class procedureAllowed {};
            class procedureActionAllowed {};
            class thoraKitItem {};
            class thoraCanOpen {};
            class thoraAftercare {};
            class skClose {};
            class skIMGeometry {};
            class skListRefresh {};
            class skListSelect {};
            class skSiteClick {};
            class skSiteGeometry {};
            class skUiTick {};
            class skPickSize {};
            class skApplySize {};
            class skPageNavigate {};
            class skPickFlush {};
            class skWasteBegin {};
            class skWasteToggleMove {};
            class skWasteCommit {};
            class skWasteDraw {};
            class skFlushSave {};
            class epinephrineTakeSource {};
            class epinephrineRecipe {};
            class epinephrinePrepare {};
            class skEpinephrineStock {};
            class epinephrineDrawCardiac {};
            class skEpinephrineDose {};
            class epinephrinePushStored {};
            class epinephrineBolusLocal {};
            class skWasteEnd {};
            class skCompoundLabel {};
            class skCompoundBegin {};
            class skCompoundDraw {};
            class skCompoundSave {};
            class skCompoundCommit {};
            class skRefreshDrawn {};
            class skFinalName {};
            class skCarouselToggle {};
            class skCarouselMove {};
            class skCarouselRender {};
            class skStoreEnsureIds {};
            class narcStoreCommit {};
            class skSelectStored {};
            class skSelectedIndex {};
            class skAfterStoredRemoval {};
            class skBodySyringeRender {};
            class skBodySyringeMove {};
            class skTagCommit {};
            class skTagColor {};
            class skTagEditOpen {};
            class skTagEditDone {};
            class skSyringeSummary {};
            class skSyringeRemembered {};
            class skDefaultTagColor {};
            class skApplyPendingTag {};
            class skPendingTagReset {};
            class skPendingTagCommit {};
            class skPendingTagColor {};
            class skPendingTagRender {};
            class skPendingTagEnsure {};
            class skAfterSaveOpenBody {};
            class skDynamicLayout {};
            class skCarouselHover {};
            class skCarouselPick {};
            class skSyringeSelfMenu {};
            class skOpenStoredSyringe {};
            class skPickDrawn {};
            class skToggleView {};
            class skSiteName {};
            class medDescriptor {};
            class laryngoIcpSurge {};
            class fentanylOnBoard {};
            class skSetView {};
            class skBuildHotspots {};
            class skInjectSite {};
            class skBeginInjection {};
            class skConfirmInjection {};
            class medicationSuggestedPushSec {};
            class hardcorePushStart {};
            class hardcorePushTick {};
            class hardcorePushSendBatch {};
            class hardcorePushStop {};
            class hardcorePushFinalize {};
            class hardcorePushRetire {};
            class hardcorePushAck {};
            class hardcorePushRestoreDelta {};
            class hardcorePushOverlay {};
            class hardcorePushReopen {};
            class hardcorePushRestoreUi {};
            class skBodyActionRender {};
            class skBodyActionClick {};
            class skDiscardSelected {};
            class skFlushSite {};
            class skToggleRoute {};
            class actionClaimValidate {};
            class actionClaimLedger {};
            class directPressureStart {};
            class directPressureClaimLocal {};
            class directPressureClaimAck {};
            class directPressureRetire {};
            class directPressureHasFracture {};
            class directPressureFracturePain {};
            class directPressureSelf {};
            class directPressureTorso {};
            class directPressureLimb {};
            class directPressureTick {};
            class directPressureStop {};
            class directPressureAssess {};
            class directPressureDraw3D {};
            class measureBPWrap {};
            class updateJunctionalImage {};
            class updateEJImage {};
            class updateETTubeImage {};
            class removeEJ {};
            class junctionalInflict {};
            class junctionalPackDone {};
            class junctionalPackSfxStart {};
            class junctionalPackSfxStop {};
            class aajtDownedTick {};
            class aajtDownedStop {};
            class aajtForceProne {};
            class aajtPainTick {};
            class junctionalWrapDone {};
            class junctionalRollSpawn {};
            class junctionalStartBleed {};
            class junctionalWrapSfxStart {};
            class junctionalWrapSfxStop {};
            class wrapSfxInit {};
            class wrapSfxStart {};
            class wrapSfxStop {};
            class wrapSfxServer {};
            class markImportantSfx {};
            class directPressurePose {};
            class directPressurePoseEnter {};
            class directPressurePoseRetire {};
            class directPressurePoseExit {};
            class directPressurePoseExitSync {};
            class directPressurePoseBusy {};
            class patientAnimRequest {};
            class patientAnimRelease {};
            class treatmentPatientSettle {};
            class junctionalInjuryEntry {};
            class junctionalGuiSyncTick {};
            class aajtInjuryEntry {};
            class seizureInjuryEntry {};
            class seizureCollapse {};
            class benzoOnBoard {};
            class seizureControl {};
            class forceRagdoll {};
            class aajtApply {};
            class aajtRemove {};
            class aajtStateCommit {};
            class aajtSetLegTQ {};
            class aajtTqHideImage {};
            class aajtTqHideInjury {};
            class cyanosisHideInjury {};
            class xstatApply {};
            class junctionalFullHeal {};
            class bloodColdChainTick {};
            class bloodColdChainNudge {};
            class ccApply {};
            class assessBleeding {};
            class chestSealOpen {};
            class chestSealPatientBegin {};
            class chestSealPatientEnd {};
            class chestSealParkCarrier {};
            class chestSealInit {};
            class chestSealGenHoles {};
            class chestSealBumpVer {};
            class chestSealPeel {};
            class chestSealBurp {};
            class chestSealBurpReady {};
            class chestSealOcclusionTick {};
            class hcCircTick {};
            class hcVentTick {};
            class chestSealPresenceSend {};
            class chestSealPresenceRender {};
            class chestSealTrackWound {};
            class chestSealRender {};
            class chestSealTick {};
            class chestSealMouseCoords {};
            class chestSealMouseDown {};
            class chestSealMouseUp {};
            class chestSealScroll {};
            class chestSealSealAt {};
            class chestSealSnd {};
            class chestSealFlip {};
            class chestSealFlipTick {};
            class thoraOpen {};
            class thoraInit {};
            class thoraClose {};
            class thoraRender {};
            class thoraRenderBruises {};
            class thoraFlip {};
            class thoraTick {};
            class thoraBumpVer {};
            class thoraMouseDown {};
            class thoraAftercareLocal {};
            class thoraAftercareRequest {};
            class thoraAftercareAck {};
            class thoraDrainBloodLocal {};
            class thoraCanSweep {};
            class thoraSealAt {};
            class thoraSealScroll {};
            class thoraSideStateCommit {};
            class thoraMouseUp {};
            class thoraPrepFlush {};
            class thoraSelectTool {};
            class thoraClosureMode {};
            class thoraClosureArt {};
            class thoraSlotHover {};
            class thoraCursorUV {};
            class thoraDrawIncision {};
            class thoraRenderPrep {};
            class thoraRenderOpen {};
            class thoraRenderTube {};
            class thoraUpdateTrayIcons {};
            class thoraPassiveDrain {};
            class thoraSutureTube {};
            class surgicalCasualtyCommit {};
            class thoraBloodStain {};
            class breathSoundsStart {};
            class chestSealRoll {};
            class chestSealRefreshSlot {};
            class chestSealToggleHeld {};
            class chestSealApply {};
            class chestSealPrompt {};
            class chestSealCanApply {};
            class chestSealCanNAR {};
            class chestSealRefreshSpearSlot {};
            class chestSealToggleSpear {};
            class chestSealApplyNCD {};
            class chestSealClose {};
            class moveInfusionBag {};
            class removeInfusionBag {};
            class relinkInfusionBag {};
            class tbiInit {};
            class tbiGetMAP {};
            class tbiIsVolumeAdequate {};
            class tbiHandle {};
            class evacuationRequirementCommit {};
            class tbiApplyOsmotherapy {};
            class tbiApplyPressorMAP {};
            class tbiApplyVitals {};
            class tbiAssessPupils {};
            class tbiOsmoBolus {};
            class headElevateCanStart {};
            class headElevateStart {};
            class headElevateStop {};
            class headElevYieldForRoll {};
            class releasePatient {};
            class patientHeldByOther {};
            class headElevAnimGuard {};
            class doAnimHeld {};
            class setVarNet {};
            class setVarNetApprox {};
            class headElevDeathRelease {};
            class headElevVestRestore {};
            class headElevWatch {};
            class headElevMedicReady {};
            class headElevMedicStart {};
            class headElevateCancelSeq {};
            class headElevApplyTilt {};
            class headElevSuspend {};
            class headElevRestAnim {};
            class headElevPinPose {};
            class headElevCollision {};
            class headElevResume {};
            class headElevTryResume {};
            class headElevTuneOpen {};
            class headElevPropApply {};
            class propEaseTo {};
            class headElevTuneLoad {};
            class headElevTuneUpdate {};
            class headElevTuneReport {};
            class circHandle {};
            class salineAcidosisTrack {};
            class administerPushDoseEpi {};
            class administerCalcium {};
            class applyCalciumCredit {};
            class calciumCreditCommit {};
            class toggleShock {};
            class toggleOverResus {};
            class setObtunded {};
            class obtundedTick {};
            class obtundedInputLock {};
            class obtundedVoice {};
            class obtundedApply {};
            class obtundedTransition {};
            class obtundedSet {};
            class obtundedStateCommit {};
            class debugObtundedBack {};
            class obtundedAuto {};
            class consciousnessBudget {};
            class toggleHypothermia {};
            class readCoreTemp {};
            class nrbAirwayCompatible {};
            class nrbApply {};
            class nrbRemove {};
            class hpmkWrap {};
            class hpmkRemove {};
            class hpmkPrep {};
            class hpmkPickUp {};
            class remoteSay3D {};
            class worldSfxNearby {};
            class remoteDeleteVehicle {};
            class forceWalkLocal {};
            class updateHpmkImage {};
            class hpmkUnwrap {};
            class hpmkExposeChest {};
            class hpmkCoverChest {};
            class updateHpmkUnwrapped {};
            class emmaAttach {};
            class emmaAttachIGel {};
            class emmaIGelStateCommit {};
            class emmaCanAttachIGel {};
            class emmaAirwayKind {};
            class emmaCanRemoveIGel {};
            class emmaClearIGelForMedic {};
            class emmaMarkContact {};
            class emmaRemove {};
            class emmaRemoveIGel {};
            class emmaTick {};
            class emmaBuildDisplay {};
            class bvmVentTick {};
            class vesicantRouteAllows {};
            class vesicantInjure {};
            class vesicantRegistryCommit {};
            class vesicantTick {};
            class vesicantReverse {};
            class ivExtravasationCheck {};
            class hpmkTick {};
            class hpmkStateCommit {};
            class hpmkBlanketTick {};
            class hpmkSpawnBlanket {};
            class nrbTick {};
            class suctionSfxStart {};
            class suctionSfxStop {};
            class headInjuryTBI {};
            class genRhythmEKG {};
            class rhythmTick {};
            class rhythmToggle {};
            class minigameOpen {};
            class minigameClose {};
            class minigameReopen {};
            class aceCursorRestore {};
            class rhythmGet {};
            class peaIsWide {};
            class rhythmSet {};
            class rhythmActiveCommit {};
            class rhythmNativeHoldCommit {};
            class rhythmNativeHighHRFloorCommit {};
            class rhythmNativeShockGraceCommit {};
            class rhythmAFibRVR {};
            class rhythmAFib {};
            class rhythmAtrialTach {};
            class rhythmTorsades {};
            class rhythmSVT {};
            class rhythmDiag {};
            class salineFlush {};
            class place18g {};
            class remove18g {};
            class syncPremixedBags {};
            class debugMenu {};
            class debugMenuClinical {};
            class debugMenuNetwork {};
            class ejTexturePath {};
            class debugDumpToClipboard {};
            class debugEnabled {};
            class autoBPCondition {};
            class toggleAutoBP {};
            class autoBPTick {};
            class toggleClamp {};
            class closeClamp {};
            class aedSyncSetup {};
            class aedBeatClockTick {};
            class rhythmThresholdTick {};
            class lidoEffectiveness {};
            class lidoToxTick {};
            class debugInduceSeizure {};
            class seizureMotion {};
            class seizureGestureAdvance {};
            class seizureGestureSync {};
            class clearAllAilments {};
            class syncToggle {};
            class syncCardiovert {};
            class syncFlagsTick {};
            class ambientTemp {};
            class hypothermiaTick {};
            class hypothermiaTemperatureCommit {};
            class skinSigns {};
            class feelSkin {};
            class skinInjuryEntry {};
            class tbiBlast {};
            class administerMagnesium {};
            class hangBagCanStart {};
            class hangBagFromMenu {};
            class pressureInfuserAttach {};
            class pressureInfuserCommit {};
            class pressureInfuserStateCommit {};
            class pressureInfuserAck {};
            class pressureInfuserTick {};
            class hangBagPrep {};
            class hangBagPrepStop {};
            class hangBagFluidType {};
            class hangBagStart {};
            class hangBagActivate {};
            class hangBagClaimLocal {};
            class hangBagClaimAck {};
            class hangBagVisualSync {};
            class hangBagTick {};
            class hangBagStop {};
            class hangBagRestoreWeapons {};
            class hangBagInputLock {};
            class hangBagHint {};
            class hangBagTuneOpen {};
            class hangBagTuneLoad {};
            class hangBagTuneUpdate {};
            class hangBagTuneReport {};
            class inspectChestPoseStart {};
            class inspectChestPoseStop {};
            class treatmentPoseStart {};
            class treatmentGesture {};
            class treatmentPoseStop {};
            class treatmentPoseSync {};
            class providerStanceOwned {};
            class beginStethoscopeAction {};
            class stethoscopeInit {};
            class stethoscopeSetView {};
            class stethoscopeEntryFlip {};
            class stethoscopeEntryFlipTick {};
            class stethoscopeFlip {};
            class stethoscopeFlipTick {};
            class stethoscopeTick {};
            class stethoscopeBreathGain {};
            class stethoscopeWeights {};
            class stethoscopeClose {};
            class rollProviderCancel {};
            class patientRollCancel {};
            class ivLineCreate {};
            class ivLineDestroy {};
            class megacodeSpawn {};
            class megacodeModuleInit {};
            class zeusInflictJunctional {};
            class zeusInflictJunctionalLocal {};
            class zeusInduceObtundation {};
            class zeusInflictBlastLung {};
            class zeusInflictEdema {};
            class zeusClearEdema {};
            class edemaSet {};
            class zeusInflictTBI {};
            class zeusInsertIV {};
            class zeusIVDialogConfirm {};
            class zeusIVDialogSite {};
            class zeusTBIDialogConfirm {};
            class zeusTBIApplyLocal {};
            class zeusClearTBI {};
            class zeusClearTBILocal {};
            class bloodFridgeSpawn {};
            class bloodFridgeDialogConfirm {};
            class bloodFridgeContents {};
            class bloodFridgeContentsFill {};
            class ventPanelOpen {};
            class ventLevelWindow {};
            class ventVeilRaise {};
            class ventFlip {};
            class ventBootStart {};
            class laryngoFlash {};
            class airwayGrade {};
            class airwayHasFacialBurn {};
            class laryngoFail {};
            class laryngoAbort {};
            class laryngoCanAttempt {};
            class laryngoDrag {};
            class laryngoTeeth {};
            class laryngoTeethArt {};
            class laryngoBleed {};
            class ventFaceGate {};
            class ventPanelShowDyn {};
            class ventPanelHideScreen {};
            class ventConnectPatient {};
            class ventDisconnectPatient {};
            class ventAirwayLoss {};
            class ventDeviceFields {};
            class ventRecoveryNear {};
            class ventPatientClear {};
            class ventInventoryLocal {};
            class ventCustodyInit {};
            class ventCustodyRequest {};
            class ventCustodyAck {};
            class ventCustodyTick {};
            class ventItemGate {};
            class ventMinuteVolume {};
            class ventMVLimits {};
            class ventTechPrompt {};
            class ventModeTitle {};
            class permHypoBleedMult {};
            class oxygenDelivery {};
            class cbColor {};
            class ventColor {};
            class ventBatteryTick {};
            class swapVentBattery {};
            class canSwapVentBattery {};
            class ventPanelInit {};
            class ventPanelTick {};
            class ventPanelRefresh {};
            class ventPanelFieldClick {};
            class ventPanelKnob {};
            class ventPanelStripClick {};
            class ventPanelClose {};
            class ventPanelShowScreen {};
            class ventPanelListRefresh {};
            class ventPanelValueFields {};
            class ventCustomLayout {};
            class ventAlarmLetter {};
            class ventLogbookAdd {};
            class ventLeashTick {};
            class ventPanelSetValue {};
            class ventNavStrip {};
            class ventPanelListClick {};
            class ventPanelActivateSel {};
            class ventPanelLiveEdit {};
            class applyHardcore {};
            class ventPanelLiveRefresh {};
            class ventDriveTick {};
            class ventEffectiveSettings {};
            class ventSimpleManualBreath {};
            class ventManualBreath {};
            class ventManualBreathCommit {};
            class ventAlarmTick {};
            class ventHoldClear {};
            class ventMmbUp {};
            class ventHoldTick {};
            class ventPowerOff {};
            class ventPowerDown {};
            class ventStopHard {};
            class ventHardStopCommit {};
            class ventAlarmSilence {};
            class ventAlarmWindow {};
            class ventAlarmSeverity {};
            class ventStatusTick {};
            class ventFormatIE {};
            class motionShake {};
            class motionSmooth {};
            class animBlocked {};
            class uiShakeApply {};
            class lightSelect {};
            class lightExtras {};
            class installLightKey {};
            class flashlightDiag {};
            class debugForceShake {};
            class initVisualEffectsConfig {};
            class visualFxTick {};
            class visualFxDebugCycle {};
            class visualFxDebugClear {};
            class compatCheck {};
            class networkCompatInit {};
            class networkCompatManifest {};
            class networkCompatCompare {};
            class networkCompatReceive {};
            class networkCompatRetry {};
            class networkCompatPeer {};
            class networkCompatNotice {};
            class altitudeTick {};
            class altitudeDatum {};
            class altitudeTrue {};
            class vomitDislodgeOPA {};
            class flightChill {};
            class vehicleOpenness {};
            class ventOxygenation {};
            class darknessShade {};
            class minigameVisionClear {};
            class minigameVisionProfile {};
            class minigameVisionNative {};
            class minigameVisionTick {};
            class minigameInputBindings {};
            class minigameInputMatch {};
            class minigameInputMouse {};
            class minigameInput {};
            class minigameInputInstall {};
            class ventFlipKeyHint {};
            class capnoMorph {};
            class ettAirwayStateCommit {};
            class ettMigrationStateCommit {};
            class ettMainstemTick {};
            class laryngoFrames {};
            class laryngoCreak {};
            class laryngoScroll {};
            class laryngoRegrip {};
            class laryngoCuff {};
            class laryngoCuffDone {};
            class laryngoTubePose {};
            class laryngoCollarSet {};
            class laryngoTubeAnchor {};
            class laryngoCollarRemove {};
            class laryngoCuffDeflate {};
            class laryngoFluid {};
            class laryngoGag {};
            class laryngoSuction {};
            class laryngoExtubate {};
            class laryngoSuctionPin {};
            class laryngoSuctionDrain {};
            class laryngoFluidSync {};
            class laryngoFluidState {};
            class laryngoFluidDrain {};
            class laryngoFluidDrainLocal {};
            class suctionDevice {};
            class suctionSelectDevice {};
            class suctionBulb {};
            class zeroPad {};
            class suctionOpen {};
            class ettMigrate {};
            class ettObstructTick {};
            class ettWakeGuard {};
            class airwayVomitOPA {};
            class laryngoPersistBleed {};
            class laryngoTubeFrames {};
            class sedationOnBoard {};
            class sedationActive {};
            class preparedComponents {};
            class vialHolder {};
            class vialClass {};
            class vialMedication {};
            class vialItemCount {};
            class itemCount {};
            class itemTake {};
            class itemList {};
            class vialCapacity {};
            class vialPreview {};
            class medicationSourceRows {};
            class patientUpright {};
            class poseUprightState {};
            class menuPoseStart {};
            class menuPoseStop {};
            class skMedicationSync {};
            class skMedicationStockRefresh {};
            class skMedicationSelect {};
            class vialSession {};
            class vialTake {};
            class openVialStoreCommit {};
            class vialRefund {};
            class vialRefundLocal {};
            class vialLeaseCommit {};
            class vialLeaseEnsure {};
            class vialLeaseRelease {};
            class vialLeaseResult {};
            class infusionVialVolume {};
            class infusionTakeSupplies {};
            class infusionRefundSupplies {};
            class queueInfusionClamp {};
            class infusionDrawStock {};
            class syringeDrawSetAmount {};
            class sedationComponents {};
            class proceduralAnalgesiaOnBoard {};
            class proceduralAnesthetized {};
            class laryngoStimulusLocal {};
            class laryngoStimulusEffect {};
            class laryngoView {};
            class laryngoConsequence {};
            class laryngoConsequenceLocal {};
            class laryngoReflexChance {};
            class laryngoIrritationTick {};
            class infusionClampLocal {};
            class propofolOnBoard {};
            class midazolamTick {};
            class sugammadexTick {};
            class sugammadexOnBoard {};
            class ettAirwayProtect {};
            class blastLungInflict {};
            class blastLungStateCommit {};
            class blastLungArdsCommit {};
            class blastLungEpisodeCommit {};
            class blastSolve {};
            class ncdAirLeakTick {};
            class blastApply {};
            class blastDetonated {};
            class blastLungTick {};
            class ventShuntCommit {};
            class ventPanelNavClick {};
            class laryngoOpen {};
            class laryngoInit {};
            class laryngoTick {};
            class laryngoGrab {};
            class laryngoClick {};
            class laryngoRefreshSlots {};
            class traySlotState {};
            class laryngoPassTube {};
            class laryngoClose {};
            class reopenMedicalMenu {};
            class ketamineOnBoard {};
            class ketamineSedationTick {};
            class rocuroniumOnBoard {};
            class rocuroniumTick {};
            class rocParalysisCommit {};
            class rocStressStateCommit {};
            class rocAwarenessStateCommit {};
            class rocAwakeParalysisCommit {};
            class rocApneaCommit {};
            class megacodeStanceLock {};
            class megacodeOpenPanel {};
            class megacodeClosePanel {};
            class megacodePanelLoad {};
            class megacodeCableTunerOpen {};
            class megacodeCableTunerLoad {};
            class megacodeCableApply {};
            class megacodeLaptopOrient {};
            class megacodeLaptopMove {};
            class megacodePanelTick {};
            class megacodeMenu {};
            class megacodeLog {};
            class megacodeResetUnit {};
            class megacodeRespawn {};
            class megacodePanelRetarget {};
            class megacodeWatch {};
            class megacodeDie {};
            class megacodeScenario {};
            class megacodeScenarioTick {};
            class megacodeSetVital {};
            class megacodeSetRhythm {};
            class megacodeAddWound {};
            class megacodeSpawnJunctional {};
            class megacodeClearWounds {};
            class megacodeSetAirway {};
            class megacodeSetFeature {};
            class megacodeReset {};
            class megacodeArrest {};
            class megacodeChestInjury {};
        };
    };
};
class CfgFontFamilies {
    class ACME_QEDaveMergens {
        fonts[] = {"\acm_extended\ui\fonts\QEDaveMergens\QEDaveMergens96"};
        spaceWidth = 0.42;
        spacing = 0.02;
    };
};
class RscText;
class RscButton;
class RscPicture;
class RscPictureKeepAspect;
class RscListBox;
class RscXSliderH;
class RscEdit;
class RscControlsGroupNoScrollbars;
class RscControlsGroupNoHScrollbars;
class ace_medical_gui_BodyImage: RscControlsGroupNoScrollbars {
    class Controls {
        class Torso_ChestSeal;
        class ACME_Torso_ChestTube_Right: Torso_ChestSeal {
            idc = 70190;
            text = "\acm_extended\ui\chest_tube_body_right_ca.paa";
            colorText[] = {0.19, 0.91, 0.93, 1};
            show = 0;
        };
        class ACME_Torso_ChestTube_Left: Torso_ChestSeal {
            idc = 70191;
            text = "\acm_extended\ui\chest_tube_body_left_ca.paa";
            colorText[] = {0.19, 0.91, 0.93, 1};
            show = 0;
        };
        class ACME_Torso_BlastLung_Right: Torso_ChestSeal {
            idc = 70192;
            text = "\acm_extended\ui\blast_lung_right_ca.paa";
            colorText[] = {0.62, 0.28, 0.72, 1};
            show = 0;
        };
        class ACME_Torso_BlastLung_Left: Torso_ChestSeal {
            idc = 70193;
            text = "\acm_extended\ui\blast_lung_left_ca.paa";
            colorText[] = {0.62, 0.28, 0.72, 1};
            show = 0;
        };
    };
};
class ACE_Medical_Menu {
    class Controls {
        class Triage;
        class Medication: Triage {
            tooltip = "IV / Medication";
        };
    };
};
class ACM_circulation_SyringeDraw_Dialog {
    class Controls {
        class Button_Draw: RscButton {
            soundClick[] = {"\a3\ui_f\data\sound\rscbutton\soundClick", 0.09, 1};
            soundEnter[] = {"\a3\ui_f\data\sound\rscbutton\soundEnter", 0.09, 1};
            soundPush[] = {"\a3\ui_f\data\sound\rscbutton\soundPush", 0.09, 1};
            soundEscape[] = {"\a3\ui_f\data\sound\rscbutton\soundEscape", 0.09, 1};
        };
        class Button_Inject: Button_Draw {
            soundClick[] = {"\a3\ui_f\data\sound\rscbutton\soundClick", 0.09, 1};
            soundEnter[] = {"\a3\ui_f\data\sound\rscbutton\soundEnter", 0.09, 1};
            soundPush[] = {"\a3\ui_f\data\sound\rscbutton\soundPush", 0.09, 1};
            soundEscape[] = {"\a3\ui_f\data\sound\rscbutton\soundEscape", 0.09, 1};
        };
        class Button_Push: Button_Inject {
            soundClick[] = {"\a3\ui_f\data\sound\rscbutton\soundClick", 0.09, 1};
            soundEnter[] = {"\a3\ui_f\data\sound\rscbutton\soundEnter", 0.09, 1};
            soundPush[] = {"\a3\ui_f\data\sound\rscbutton\soundPush", 0.09, 1};
            soundEscape[] = {"\a3\ui_f\data\sound\rscbutton\soundEscape", 0.09, 1};
        };
    };
};
class ACME_MedicalMenu_LeftText: RscText {
    idc = -1;
    style = 0;
    text = "";
    font = "RobotoCondensed";
    sizeEx = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) * 0.72)";
    colorText[] = {0.898, 0.898, 0.898, 1};
    colorBackground[] = {0, 0, 0, 0};
    shadow = 0;
};
class ACME_AEDSyncButton: RscButton {
    style = 0;
    text = "";
    colorText[] = {1, 1, 1, 0};
    colorDisabled[] = {1, 1, 1, 0};
    colorBackground[] = {1, 1, 1, 0};
    colorBackgroundDisabled[] = {1, 1, 1, 0};
    colorBackgroundActive[] = {1, 1, 1, 0};
    colorFocused[] = {1, 1, 1, 0};
    colorBorder[] = {0, 0, 0, 0};
    soundEnter[] = {};
    soundPush[] = {};
    soundClick[] = {};
    soundEscape[] = {};
    shadow = 0;
};
class ACME_EJTransfusionHotspot: RscButton {
    style = 0;
    text = "";
    colorText[] = {1, 1, 1, 0};
    colorDisabled[] = {1, 1, 1, 0};
    colorBackground[] = {0, 0, 0, 0};
    colorBackgroundDisabled[] = {0, 0, 0, 0};
    colorBackgroundActive[] = {0, 0, 0, 0};
    colorFocused[] = {0, 0, 0, 0};
    colorBorder[] = {0, 0, 0, 0};
    soundEnter[] = {};
    soundPush[] = {};
    soundClick[] = {"\a3\ui_f\data\sound\rscbutton\soundClick", 0.09, 1};
    soundEscape[] = {};
    shadow = 0;
    sizeEx = 0;
};
class ACME_CoolerHotspot: RscButton {
    style = 0;
    text = "";
    colorText[] = {1, 1, 1, 0};
    colorDisabled[] = {1, 1, 1, 0};
    colorBackground[] = {0, 0, 0, 0};
    colorBackgroundDisabled[] = {0, 0, 0, 0};
    colorBackgroundActive[] = {1, 0.85, 0.3, 0.22};
    colorFocused[] = {1, 0.85, 0.3, 0.14};
    colorBorder[] = {0, 0, 0, 0};
    soundEnter[] = {};
    soundPush[] = {};
    soundClick[] = {};
    soundEscape[] = {};
    shadow = 0;
};
class ACM_circulation_Lifepak_Monitor_Dialog {
    onLoad = "_this call ACME_fnc_aedSyncSetup";
    onUnload = "uiNamespace setVariable ['ACM_circulation_AEDMonitor_DLG', nil]; uiNamespace setVariable ['ACME_sync_localArmed', nil]; missionNamespace setVariable ['ACM_circulation_AED_Monitor_Medic', objNull]";
};
class ACME_RollerClamp_Dialog {
    idd = 86200;
    movingEnable = 0;
    enableSimulation = 1;
    onLoad = "[_this select 0] call ACME_fnc_minigameInputInstall; call ACME_fnc_onClampLoad";
    onMouseZChanged = "_this call ACME_fnc_scrollClamp";
    onUnload = "[uiNamespace getVariable ['ACME_RollerClamp_Position',1], true, false] call ACME_fnc_setClampPosition; uiNamespace setVariable ['ACME_RollerClamp_DLG', displayNull]; uiNamespace setVariable ['ACME_RollerClamp_InitDisplay', displayNull]; uiNamespace setVariable ['ACME_RollerClamp_Dragging', false]; uiNamespace setVariable ['ACME_RollerClamp_ReleaseOnUp', false]; uiNamespace setVariable ['ACME_RollerClamp_Track', []];";
    class ControlsBackground {
        class ACME_Backdrop: RscText {
            idc = 86210;
            text = "";
            x = "safeZoneX + (safeZoneW / 2) - (safeZoneW / 4.65)";
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 2.55)";
            w = "safeZoneW / 2.33";
            h = "safeZoneH / 1.28";
            colorBackground[] = {0, 0, 0, 0.78};
            colorText[] = {1, 1, 1, 1};
        };
        class ACME_ClampBG: RscPicture {
            idc = 86201;
            text = "\acm_extended\ui\roller_clamp_bg.paa";
            x = "safeZoneX + (safeZoneW / 2) - (safeZoneW / 18)";
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 2.95)";
            w = "safeZoneW / 9";
            h = "safeZoneH / 1.55";
            colorText[] = {1, 1, 1, 1};
        };
    };
    class Controls {
        class ACME_Wheel: RscPicture {
            idc = 86202;
            text = "\acm_extended\ui\roller_clamp_whl.paa";
            x = "safeZoneX + (safeZoneW / 2) - (safeZoneW / 45)";
            y = "safeZoneY + (safeZoneH / 2)";
            w = "safeZoneW / 18";
            h = "safeZoneH / 7";
            colorText[] = {1, 1, 1, 1};
        };
        class ACME_DragOverlay: RscButton {
            idc = 86203;
            text = "";
            colorText[] = {1, 1, 1, 0};
            colorDisabled[] = {1, 1, 1, 0};
            colorBackground[] = {1, 1, 1, 0.01};
            colorBackgroundDisabled[] = {1, 1, 1, 0};
            colorBackgroundActive[] = {1, 1, 1, 0.01};
            colorFocused[] = {1, 1, 1, 0.01};
            colorBorder[] = {0, 0, 0, 0};
            x = "safeZoneX + (safeZoneW / 2) - (safeZoneW / 18)";
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 2.95)";
            w = "safeZoneW / 9";
            h = "safeZoneH / 1.55";
            shadow = 0;
            font = "RobotoCondensed";
            sizeEx = "0";
            action = "";
            tooltip = "Click the wheel to grab it (click again to release), or press and hold to drag. Scroll for fine adjustment.";
        };
        class ACME_Title: RscText {
            idc = 86205;
            text = "Roller Clamp";
            x = "safeZoneX + (safeZoneW / 2) - (safeZoneW / 6.6)";
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 2.75)";
            w = "safeZoneW / 3.3";
            h = "safeZoneH / 24";
            colorText[] = {1, 1, 1, 1};
            colorBackground[] = {0, 0, 0, 0};
            font = "RobotoCondensed";
            sizeEx = "safeZoneH / 34";
            style = 2;
            shadow = 0;
        };
        class ACME_RateText: ACME_Title {
            idc = 86206;
            text = "20 gtt/mL | 60 gtt/min | 3 mL/min";
            x = "safeZoneX + (safeZoneW / 2) - (safeZoneW / 4.65)";
            y = "safeZoneY + (safeZoneH / 2) + (safeZoneH / 3.38)";
            w = "safeZoneW / 2.33";
            h = "safeZoneH / 19";
            sizeEx = "safeZoneH / 76";
            colorBackground[] = {0, 0, 0, 0.65};
            style = 2;
        };
        class ACME_DropSet: RscButton {
            idc = 86207;
            text = "Drop Set: 20";
            x = "safeZoneX + (safeZoneW / 2) - (safeZoneW / 6.3)";
            y = "safeZoneY + (safeZoneH / 2) + (safeZoneH / 2.85)";
            w = "safeZoneW / 10.5";
            h = "safeZoneH / 26";
            colorText[] = {1, 1, 1, 1};
            colorDisabled[] = {1, 1, 1, 0.25};
            colorBackground[] = {0, 0, 0, 1};
            colorBackgroundDisabled[] = {0, 0, 0, 0.35};
            colorBackgroundActive[] = {0.12, 0.12, 0.12, 1};
            colorFocused[] = {0, 0, 0, 1};
            colorBorder[] = {0, 0, 0, 0};
            style = 2;
            shadow = 0;
            font = "RobotoCondensed";
            sizeEx = "safeZoneH / 50";
            action = "call ACME_fnc_cycleDropSet";
            tooltip = "Cycle drop set: 10, 15, 20, or 60 gtt/mL";
        };
        class ACME_ToggleClamp: ACME_DropSet {
            idc = 86208;
            text = "Clamp Closed";
            x = "safeZoneX + (safeZoneW / 2) - (safeZoneW / 21)";
            action = "call ACME_fnc_toggleClamp";
            tooltip = "Fully close or reopen the roller clamp";
        };
        class ACME_Close: ACME_DropSet {
            idc = 86209;
            text = "Done";
            x = "safeZoneX + (safeZoneW / 2) + (safeZoneW / 15.3)";
            action = "call ACME_fnc_closeClamp";
            tooltip = "Close roller clamp controls";
        };
    };
};
class ACME_SK_RowGroup: RscControlsGroupNoHScrollbars {};
class ACME_SK_RightText: RscText {
    style = 1;
};
class ACME_SK_StyledList: RscListBox {
    rowHeight = "safeZoneH / 20";
    colorText[] = {1, 1, 1, 1};
    colorSelect[] = {0, 0, 0, 1};
    colorSelect2[] = {0, 0, 0, 1};
    colorBackground[] = {0, 0, 0, 0.1};
    colorSelectBackground[] = {0.7, 0.7, 0.7, 1};
    colorSelectBackground2[] = {0.7, 0.7, 0.7, 1};
    sizeEx = "(safeZoneH / 20) * 0.5";
};
class ACME_SK_TagList: ACME_SK_StyledList {
    rowHeight = "safeZoneH / 27";
    colorBackground[] = {0.04, 0.04, 0.04, 0.96};
    colorSelectBackground[] = {0.38, 0.38, 0.38, 1};
    colorSelectBackground2[] = {0.38, 0.38, 0.38, 1};
    sizeEx = "(safeZoneH / 27) * 0.58";
};
class ACME_SK_NameEdit: RscEdit {
    style = 0;
    maxChars = 25;
    colorText[] = {1, 1, 1, 1};
    colorSelection[] = {0.7, 0.7, 0.7, 1};
    colorBackground[] = {0.02, 0.02, 0.02, 0.85};
    font = "RobotoCondensed";
    sizeEx = "safeZoneH / 44";
    autocomplete = "";
};
class ACME_SK_PushDurationEdit: ACME_SK_NameEdit {
    type = 2;
    style = 0;
    canModify = 1;
    maxChars = 3;
    text = "";
};
class ACME_SK_TagEdit: RscEdit {
    style = 512;
    colorBackground[] = {0, 0, 0, 0};
    colorText[] = {0.08, 0.08, 0.08, 1};
    colorSelection[] = {0.3, 0.5, 0.8, 0.1};
    colorDisabled[] = {0.08, 0.08, 0.08, 0.6};
    colorBorder[] = {0, 0, 0, 0};
    borderSize = 0;
    font = "Caveat";
    sizeEx = "safeZoneH / 58";
    shadow = 0;
    forceDrawCaret = 0;
    maxChars = 25;
};
class ACME_SK_TagText: RscText {
    colorBackground[] = {0, 0, 0, 0};
    colorText[] = {0.08, 0.08, 0.08, 1};
    font = "Caveat";
    shadow = 0;
    style = 0;
};
class ACME_SK_StyledLabel: RscText {
    colorText[] = {1, 1, 1, 1};
    colorBackground[] = {0, 0, 0, 0.35};
    style = 2;
    font = "RobotoCondensed";
    sizeEx = "safeZoneH / 40";
};
class ACME_SK_StyledButton: RscButton {
    colorBackground[] = {0.05, 0.05, 0.05, 0.65};
    colorBackgroundActive[] = {0.28, 0.28, 0.28, 0.9};
    colorBackgroundDisabled[] = {0, 0, 0, 0.3};
    colorFocused[] = {0.05, 0.05, 0.05, 0.65};
    colorText[] = {1, 1, 1, 1};
    colorDisabled[] = {1, 1, 1, 0.3};
    font = "RobotoCondensed";
    sizeEx = "safeZoneH / 44";
    borderSize = 0;
};
class ACME_SK_PulseButton: ACME_SK_StyledButton {
    colorBackground[] = {0, 0, 0, 0};
    colorBackgroundActive[] = {0, 0, 0, 0};
    colorBackgroundDisabled[] = {0, 0, 0, 0};
    colorFocused[] = {0, 0, 0, 0};
};
class ACME_TX_PageButton: ACME_SK_PulseButton {
    colorText[] = {0.94, 0.91, 0.82, 1};
    colorDisabled[] = {0.94, 0.91, 0.82, 0.45};
    font = "RobotoCondensed";
    sizeEx = "safeZoneH / 46";
    shadow = 0;
};
class ACME_SK_RowButton: ACME_SK_PulseButton {
    style = 0;
    sizeEx = "safeZoneH / 44";
    colorShadow[] = {0, 0, 0, 0};
    offsetX = 0;
    offsetY = 0;
    offsetPressedX = 0;
    offsetPressedY = 0;
};
class ACME_SK_HotspotButton: ACME_SK_StyledButton {
    colorBackground[] = {0, 0, 0, 0};
    colorBackgroundActive[] = {0, 0, 0, 0};
    colorBackgroundDisabled[] = {0, 0, 0, 0};
    colorFocused[] = {0, 0, 0, 0};
    colorText[] = {0, 0, 0, 0};
    sizeEx = "safeZoneH / 52";
};
class RscStructuredText;
class ACME_ChestSeal_Dialog {
    idd = 86400;
    movingEnable = 0;
    onLoad = "[_this select 0] call ACME_fnc_minigameInputInstall; _this call ACME_fnc_chestSealInit";
    onUnload = "_this call ACME_fnc_chestSealClose";
    class ControlsBackground {
        class CS_Dim: RscText {
            idc = -1;
            x = "safezoneX";
            y = "safezoneY";
            w = "safezoneW";
            h = "safezoneH";
            text = "";
            colorBackground[] = {0, 0, 0, 0.55};
        };
        class CS_Body: RscPicture {
            idc = 86401;
            x = "safezoneX + safezoneW * 0.36";
            y = "safezoneY + safezoneH * 0.10";
            w = "safezoneW * 0.28";
            h = "safezoneH * 0.80";
            text = "\x\acm\addons\gui\ui\body_background.paa";
        };
    };
    class Controls {
        class CS_Title: RscText {
            idc = -1;
            style = 2;
            x = "safezoneX";
            y = "safezoneY + safezoneH * 0.035";
            w = "safezoneW";
            h = "safezoneH * 0.05";
            text = "";
            colorText[] = {0.93, 0.89, 0.8, 1};
            colorBackground[] = {0, 0, 0, 0};
            sizeEx = "0.042 * safezoneH";
        };
        class CS_Instruction: CS_Title {
            idc = 86403;
            y = "safezoneY + safezoneH * 0.09";
            h = "safezoneH * 0.04";
            text = "";
            sizeEx = "0.026 * safezoneH";
            colorText[] = {0.82, 0.82, 0.82, 1};
        };
        class CS_Zone: RscPicture {
            idc = 86404;
            x = 0;
            y = 0;
            w = 0;
            h = 0;
            text = "\acm_extended\ui\cs_zone_front_ca.paa";
            colorText[] = {1, 1, 1, 1};
        };
        class CS_Surface: RscControlsGroupNoScrollbars {
            idc = 86410;
            x = 0;
            y = 0;
            w = 0;
            h = 0;
            colorBackground[] = {0, 0, 0, 0};
            class Controls {};
        };
        class CS_SlotBG: RscText {
            idc = 86420;
            x = "safezoneX + safezoneW * 0.80";
            y = "safezoneY + safezoneH * 0.40";
            w = "safezoneW * 0.10";
            h = "safezoneH * 0.18";
            text = "";
            colorBackground[] = {0, 0, 0, 0.85};
        };
        class CS_SlotLogo: RscPicture {
            idc = 86422;
            x = "safezoneX + safezoneW * 0.806";
            y = "safezoneY + safezoneH * 0.41";
            w = "safezoneW * 0.088";
            h = "safezoneH * 0.14";
            text = "\x\acm\addons\breathing\ui\chestseal_ca.paa";
        };
        class CS_SlotCount: RscText {
            idc = 86423;
            x = "safezoneX + safezoneW * 0.80";
            y = "safezoneY + safezoneH * 0.555";
            w = "safezoneW * 0.10";
            h = "safezoneH * 0.03";
            style = 2;
            text = "";
            colorText[] = {0.93, 0.89, 0.8, 1};
            colorBackground[] = {0, 0, 0, 0};
            sizeEx = "0.024 * safezoneH";
        };
        class CS_SlotClick: RscButton {
            idc = 86424;
            x = "safezoneX + safezoneW * 0.80";
            y = "safezoneY + safezoneH * 0.40";
            w = "safezoneW * 0.10";
            h = "safezoneH * 0.18";
            text = "";
            tooltip = "Pick up / return chest seal";
            onButtonClick = "[] call ACME_fnc_chestSealToggleHeld";
            colorText[] = {0, 0, 0, 0};
            colorDisabled[] = {0, 0, 0, 0};
            colorBackground[] = {0, 0, 0, 0};
            colorBackgroundDisabled[] = {0, 0, 0, 0};
            colorBackgroundActive[] = {1, 1, 1, 0.04};
            colorFocused[] = {0, 0, 0, 0};
            colorShadow[] = {0, 0, 0, 0};
            colorBorder[] = {0, 0, 0, 0};
            borderSize = 0;
        };
        class CS_SpearSlotBG: RscText {
            idc = 86430;
            x = 0;
            y = 0;
            w = 0;
            h = 0;
            text = "";
            colorBackground[] = {0, 0, 0, 0.85};
        };
        class CS_SpearSlotLogo: RscPicture {
            idc = 86432;
            x = 0;
            y = 0;
            w = 0;
            h = 0;
            text = "\acm_extended\ui\items\nar_spear_ca.paa";
        };
        class CS_SpearSlotCount: RscText {
            idc = 86433;
            x = 0;
            y = 0;
            w = 0;
            h = 0;
            style = 2;
            text = "";
            colorText[] = {0.93, 0.89, 0.8, 1};
            colorBackground[] = {0, 0, 0, 0};
            sizeEx = "0.024 * safezoneH";
        };
        class CS_SpearSlotClick: RscButton {
            idc = 86434;
            x = 0;
            y = 0;
            w = 0;
            h = 0;
            text = "";
            tooltip = "Pick up / return NAR SPEAR";
            onButtonClick = "[] call ACME_fnc_chestSealToggleSpear";
            colorText[] = {0, 0, 0, 0};
            colorDisabled[] = {0, 0, 0, 0};
            colorBackground[] = {0, 0, 0, 0};
            colorBackgroundDisabled[] = {0, 0, 0, 0};
            colorBackgroundActive[] = {1, 1, 1, 0.04};
            colorFocused[] = {0, 0, 0, 0};
            colorShadow[] = {0, 0, 0, 0};
            colorBorder[] = {0, 0, 0, 0};
            borderSize = 0;
        };
        class CS_Flip: RscButton {
            idc = 86426;
            x = "safezoneX + safezoneW * 0.80";
            y = "safezoneY + safezoneH * 0.70";
            w = "safezoneW * 0.10";
            h = "safezoneH * 0.055";
            text = "Flip";
            tooltip = "Turn the body over (front / back)";
            onButtonClick = "[] call ACME_fnc_chestSealFlip";
            colorBackground[] = {0.14, 0.2, 0.3, 0.9};
            colorText[] = {0.93, 0.89, 0.8, 1};
        };
        class CS_Close: RscButton {
            idc = 86427;
            text = "Close";
            onButtonClick = "[86400] call ACME_fnc_minigameClose;";
            colorBackground[] = {0.13, 0.22, 0.17, 0.9};
            colorText[] = {0.93, 0.89, 0.8, 1};
        };
        class CS_Cancel: RscButton {
            idc = 86425;
            x = "safezoneX + safezoneW * 0.80";
            y = "safezoneY + safezoneH * 0.82";
            w = "safezoneW * 0.10";
            h = "safezoneH * 0.05";
            text = "Done";
            action = "[86400] call ACME_fnc_minigameClose;";
            colorBackground[] = {0.3, 0.1, 0.1, 0.85};
            colorText[] = {0.93, 0.89, 0.8, 1};
        };
    };
};
class ACME_CS_PlacedSeal: RscPicture {
    idc = -1;
    x = 0;
    y = 0;
    w = 0;
    h = 0;
    text = "\x\acm\addons\breathing\ui\chestseal_ca.paa";
    colorText[] = {1, 1, 1, 0.95};
    show = 1;
};
class ACME_CS_Dot: RscPicture {
    idc = -1;
    x = 0;
    y = 0;
    w = 0;
    h = 0;
    text = "\acm_extended\ui\dot_grad_ca.paa";
    colorText[] = {0.95, 0.95, 0.98, 0.85};
    show = 0;
};
class ACME_CS_Hole: RscPicture {
    idc = -1;
    x = 0;
    y = 0;
    w = 0;
    h = 0;
    text = "\acm_extended\ui\holes\hole1_ca.paa";
    colorText[] = {1, 1, 1, 1};
    show = 1;
};
class ACME_CS_NCDSprite: RscPicture {
    idc = -1;
    x = 0;
    y = 0;
    w = 0;
    h = 0;
    text = "\acm_extended\ui\items\nar_spear_left_ca.paa";
    colorText[] = {1, 1, 1, 1};
    show = 1;
};
class RscMapControl;
class ACME_Thora_DrawMap: RscMapControl {
    colorBackground[] = {0, 0, 0, 0};
    colorSea[] = {0, 0, 0, 0};
    colorForest[] = {0, 0, 0, 0};
    colorForestBorder[] = {0, 0, 0, 0};
    colorRocks[] = {0, 0, 0, 0};
    colorRocksBorder[] = {0, 0, 0, 0};
    colorCountlines[] = {0, 0, 0, 0};
    colorMainCountlines[] = {0, 0, 0, 0};
    colorCountlinesWater[] = {0, 0, 0, 0};
    colorMainCountlinesWater[] = {0, 0, 0, 0};
    colorLinesWater[] = {0, 0, 0, 0};
    colorLinesRailway[] = {0, 0, 0, 0};
    colorLinesRoad[] = {0, 0, 0, 0};
    colorLinesMainRoad[] = {0, 0, 0, 0};
    colorLinesTrack[] = {0, 0, 0, 0};
    colorLinesTrail[] = {0, 0, 0, 0};
    colorGrid[] = {0, 0, 0, 0};
    colorGridMap[] = {0, 0, 0, 0};
    colorTracks[] = {0, 0, 0, 0};
    colorTracksFill[] = {0, 0, 0, 0};
    colorInactive[] = {0, 0, 0, 0};
    colorOutside[] = {0, 0, 0, 0};
    colorText[] = {0, 0, 0, 0};
    fontLabel = "PuristaMedium";
    sizeExGrid = 0;
    sizeExUnits = 0;
    sizeExNames = 0;
    sizeExInfo = 0;
    sizeExTownNames = 0;
    text = "";
    stickX[] = {0, 0};
    stickY[] = {0, 0};
    ptsPerSquareSea = 0.001;
    ptsPerSquareTxt = 0.001;
    ptsPerSquareCLn = 0.001;
    ptsPerSquareExp = 0.001;
    ptsPerSquareCost = 0.001;
    ptsPerSquareForEdge = 0.001;
    ptsPerSquareRoad = 0.001;
    ptsPerSquareObj = 0.001;
    showCountourInterval = 0;
    scaleMin = 0.001;
    scaleMax = 100000;
    scaleDefault = 0.1;
};
class ACME_Thora_SlotBtn: RscButton {
    colorText[] = {0, 0, 0, 0};
    colorDisabled[] = {0, 0, 0, 0};
    colorBackground[] = {0, 0, 0, 0};
    colorBackgroundDisabled[] = {0, 0, 0, 0};
    colorBackgroundActive[] = {0, 0, 0, 0};
    colorFocused[] = {0, 0, 0, 0};
    colorShadow[] = {0, 0, 0, 0};
    colorBorder[] = {0, 0, 0, 0};
    soundEnter[] = {"", 0, 1};
    soundPush[] = {"", 0, 1};
    soundClick[] = {"", 0, 1};
    soundEscape[] = {"", 0, 1};
};
class ACME_Thoracostomy_Dialog {
    idd = 86600;
    movingEnable = 0;
    onLoad = "[_this select 0] call ACME_fnc_minigameInputInstall; _this call ACME_fnc_thoraInit";
    onUnload = "[] call ACME_fnc_thoraClose";
    class ControlsBackground {
        class Thora_Dim: RscText {
            idc = -1;
            x = "safezoneX";
            y = "safezoneY";
            w = "safezoneW";
            h = "safezoneH";
            text = "";
            colorBackground[] = {0, 0, 0, 0.55};
        };
        class Thora_Body: RscPicture {
            idc = 86601;
            x = 0;
            y = 0;
            w = 0;
            h = 0;
            text = "\acm_extended\ui\chest_right_ca.paa";
            colorText[] = {1, 1, 1, 1};
        };
    };
    class Controls {
        class Thora_Zone: RscText {
            idc = 86604;
            x = 0;
            y = 0;
            w = 0;
            h = 0;
            text = "";
            colorBackground[] = {0.85, 0.12, 0.12, 0.35};
        };
        class Thora_Surface: RscControlsGroupNoScrollbars {
            idc = 86610;
            x = 0;
            y = 0;
            w = 0;
            h = 0;
            colorBackground[] = {0, 0, 0, 0};
            class Controls {};
        };
        class Thora_Flip: RscButton {
            idc = 86626;
            x = 0;
            y = 0;
            w = 0;
            h = 0;
            text = "Flip side";
            tooltip = "Switch between the right and left chest";
            onButtonClick = "[] call ACME_fnc_thoraFlip";
            colorText[] = {0.93, 0.89, 0.8, 1};
            colorBackground[] = {0, 0, 0, 0.85};
            colorBackgroundActive[] = {1, 1, 1, 0.06};
            sizeEx = "0.026 * safezoneH";
        };
        class Thora_Close: RscButton {
            idc = -1;
            x = "safezoneX + safezoneW * 0.44";
            y = "safezoneY + safezoneH * 0.92";
            w = "safezoneW * 0.12";
            h = "safezoneH * 0.05";
            text = "Done";
            onButtonClick = "[86600] call ACME_fnc_minigameClose;";
            colorText[] = {0.93, 0.89, 0.8, 1};
            colorBackground[] = {0, 0, 0, 0.85};
            colorBackgroundActive[] = {1, 1, 1, 0.06};
            sizeEx = "0.028 * safezoneH";
        };
    };
};
class ACME_IVMinigame_Dialog {
    idd = 86500;
    movingEnable = 0;
    onLoad = "[_this select 0] call ACME_fnc_minigameInputInstall; _this call ACME_fnc_ivMinigameInit";
    onUnload = "_this call ACME_fnc_ivMinigameClose";
    class ControlsBackground {
        class IV_Dim: RscText {
            idc = -1;
            x = "safezoneX";
            y = "safezoneY";
            w = "safezoneW";
            h = "safezoneH";
            text = "";
            colorBackground[] = {0, 0, 0, 0.62};
        };
        class IV_Limb: RscPictureKeepAspect {
            idc = 86501;
            x = 0;
            y = 0;
            w = 0;
            h = 0;
            text = "\acm_extended\ui\iv\iv_left_arm_ca.paa";
            colorText[] = {1, 1, 1, 1};
        };
        class IV_PrepLayer: RscControlsGroupNoScrollbars {
            idc = 86508;
            x = "safezoneX";
            y = "safezoneY";
            w = "safezoneW";
            h = "safezoneH";
            class Controls {};
        };
        class IV_Band: RscPictureKeepAspect {
            idc = 86502;
            x = 0;
            y = 0;
            w = 0;
            h = 0;
            text = "\acm_extended\ui\iv\iv_boa_left_arm_lower_ca.paa";
            colorText[] = {1, 1, 1, 1};
            show = 0;
        };
    };
    class Controls {
        class IV_Title: RscText {
            idc = -1;
            style = 2;
            x = "safezoneX";
            y = "safezoneY + safezoneH * 0.035";
            w = "safezoneW";
            h = "safezoneH * 0.05";
            text = "";
            colorText[] = {0.93, 0.89, 0.8, 1};
            colorBackground[] = {0, 0, 0, 0};
            sizeEx = "0.042 * safezoneH";
        };
        class IV_SiteHdr: IV_Title {
            idc = 86504;
            text = "";
            sizeEx = "0.030 * safezoneH";
            colorText[] = {0.55, 0.85, 1, 1};
        };
        class IV_Instruction: IV_Title {
            idc = 86503;
            y = "safezoneY + safezoneH * 0.09";
            h = "safezoneH * 0.04";
            text = "";
            sizeEx = "0.026 * safezoneH";
            colorText[] = {0.82, 0.82, 0.82, 1};
        };
        class IV_Surface: RscControlsGroupNoScrollbars {
            idc = 86510;
            x = 0;
            y = 0;
            w = 0;
            h = 0;
            colorBackground[] = {0, 0, 0, 0};
            class Controls {};
        };
        class IV_SlotHdr: IV_Title {
            idc = -1;
            style = 0;
            x = "safezoneX + safezoneW * 0.880";
            y = "safezoneY + safezoneH * 0.135";
            w = "safezoneW * 0.10";
            h = "safezoneH * 0.03";
            text = "";
            sizeEx = "0.020 * safezoneH";
            colorText[] = {0.55, 0.85, 1, 1};
        };
        class IV_BandSlotBG: RscText {
            idc = 86530;
            x = 0;
            y = 0;
            w = 0;
            h = 0;
            text = "";
            colorBackground[] = {0.1, 0.13, 0.17, 0.92};
        };
        class IV_BandSlotLogo: RscPictureKeepAspect {
            idc = 86531;
            x = 0;
            y = 0;
            w = 0;
            h = 0;
            text = "\acm_extended\ui\nar_boa_ca.paa";
            colorText[] = {1, 1, 1, 1};
        };
        class IV_BandSlotClick: RscButton {
            idc = 86532;
            x = 0;
            y = 0;
            w = 0;
            h = 0;
            text = "";
            colorText[] = {0, 0, 0, 0};
            colorBackground[] = {0, 0, 0, 0};
            colorBackgroundActive[] = {0.3, 0.5, 0.7, 0.3};
            colorFocused[] = {0, 0, 0, 0};
            colorBackgroundDisabled[] = {0, 0, 0, 0};
            tooltip = "Pick up the constricting band. Move it over the limb and click to apply.";
            onButtonClick = "[] call ACME_fnc_ivMinigameGrabBand";
        };
        class IV_BandLbl: RscText {
            idc = 86533;
            x = 0;
            y = 0;
            w = 0;
            h = 0;
            style = 2;
            text = "BAND";
            colorText[] = {0.95, 0.8, 0.8, 1};
            colorBackground[] = {0, 0, 0, 0};
            sizeEx = "0.018 * safezoneH";
            font = "RobotoCondensed";
        };
        class IV_PadLbl: RscText {
            idc = 86538;
            x = 0;
            y = 0;
            w = 0;
            h = 0;
            style = 2;
            text = "PAD";
            colorText[] = {0.8, 0.92, 1, 1};
            colorBackground[] = {0, 0, 0, 0};
            sizeEx = "0.018 * safezoneH";
            font = "RobotoCondensed";
        };
        class IV_PadBG: RscText {
            idc = 86535;
            x = 0;
            y = 0;
            w = 0;
            h = 0;
            text = "";
            colorBackground[] = {0.1, 0.13, 0.17, 0.92};
        };
        class IV_PadLogo: RscPictureKeepAspect {
            idc = 86536;
            x = 0;
            y = 0;
            w = 0;
            h = 0;
            text = "\acm_extended\ui\iv\alcohol_pad_left_ca.paa";
            colorText[] = {1, 1, 1, 1};
        };
        class IV_PadClick: RscButton {
            idc = 86537;
            x = 0;
            y = 0;
            w = 0;
            h = 0;
            text = "";
            colorText[] = {0, 0, 0, 0};
            colorBackground[] = {0, 0, 0, 0};
            colorBackgroundActive[] = {0.3, 0.5, 0.7, 0.3};
            colorFocused[] = {0, 0, 0, 0};
            colorBackgroundDisabled[] = {0, 0, 0, 0};
            tooltip = "Alcohol pad. Hold and wipe the site at least three times.";
            onButtonClick = "[] call ACME_fnc_ivMinigameGrabPad";
        };
        class IV_NeedleHdr: IV_SlotHdr {
            idc = 86539;
            text = "NEEDLE";
            colorText[] = {0.55, 0.85, 1, 1};
        };
        class IV_G14BG: RscText {
            idc = 86540;
            x = 0;
            y = 0;
            w = 0;
            h = 0;
            text = "";
            colorBackground[] = {0.1, 0.13, 0.17, 0.92};
        };
        class IV_G14Fan4: RscPictureKeepAspect {
            idc = 86583;
            x = 0;
            y = 0;
            w = 0;
            h = 0;
            text = "";
            colorText[] = {1, 1, 1, 0};
        };
        class IV_G14Fan3: IV_G14Fan4 {
            idc = 86582;
        };
        class IV_G14Fan2: IV_G14Fan4 {
            idc = 86581;
        };
        class IV_G14Fan1: IV_G14Fan4 {
            idc = 86580;
        };
        class IV_G14Logo: RscPictureKeepAspect {
            idc = 86541;
            x = 0;
            y = 0;
            w = 0;
            h = 0;
            text = "\acm_extended\ui\iv\tray\iv_tray_14g_0_ca.paa";
            colorText[] = {1, 1, 1, 1};
        };
        class IV_G14Lbl: RscText {
            idc = 86542;
            x = 0;
            y = 0;
            w = 0;
            h = 0;
            style = 2;
            text = "14g";
            colorText[] = {0.95, 0.75, 0.75, 1};
            colorBackground[] = {0, 0, 0, 0};
            sizeEx = "0.018 * safezoneH";
            font = "RobotoCondensed";
        };
        class IV_G14Click: RscButton {
            idc = 86543;
            x = 0;
            y = 0;
            w = 0;
            h = 0;
            text = "";
            colorText[] = {0, 0, 0, 0};
            colorBackground[] = {0, 0, 0, 0};
            colorBackgroundActive[] = {0.3, 0.5, 0.7, 0.3};
            colorFocused[] = {0, 0, 0, 0};
            colorBackgroundDisabled[] = {0, 0, 0, 0};
            tooltip = "";
            onButtonClick = "[14] call ACME_fnc_ivMinigameGrabNeedle";
        };
        class IV_G16BG: IV_G14BG {
            idc = 86544;
        };
        class IV_G16Fan4: IV_G14Fan4 {
            idc = 86587;
        };
        class IV_G16Fan3: IV_G14Fan4 {
            idc = 86586;
        };
        class IV_G16Fan2: IV_G14Fan4 {
            idc = 86585;
        };
        class IV_G16Fan1: IV_G14Fan4 {
            idc = 86584;
        };
        class IV_G16Logo: IV_G14Logo {
            idc = 86545;
            colorText[] = {1, 1, 1, 1};
            text = "\acm_extended\ui\iv\tray\iv_tray_16g_0_ca.paa";
        };
        class IV_G16Lbl: IV_G14Lbl {
            idc = 86546;
            text = "16g";
            colorText[] = {0.9, 0.95, 1, 1};
        };
        class IV_G16Click: IV_G14Click {
            idc = 86547;
            onButtonClick = "[16] call ACME_fnc_ivMinigameGrabNeedle";
        };
        class IV_G18BG: IV_G14BG {
            idc = 86548;
        };
        class IV_G18Fan4: IV_G14Fan4 {
            idc = 86591;
        };
        class IV_G18Fan3: IV_G14Fan4 {
            idc = 86590;
        };
        class IV_G18Fan2: IV_G14Fan4 {
            idc = 86589;
        };
        class IV_G18Fan1: IV_G14Fan4 {
            idc = 86588;
        };
        class IV_G18Logo: IV_G14Logo {
            idc = 86549;
            colorText[] = {1, 1, 1, 1};
            text = "\acm_extended\ui\iv\tray\iv_tray_18g_0_ca.paa";
        };
        class IV_G18Lbl: IV_G14Lbl {
            idc = 86550;
            text = "18g";
            colorText[] = {0.75, 0.9, 1, 1};
        };
        class IV_G18Click: IV_G14Click {
            idc = 86551;
            onButtonClick = "[18] call ACME_fnc_ivMinigameGrabNeedle";
        };
        class IV_G20BG: IV_G14BG {
            idc = 86556;
        };
        class IV_G20Fan4: IV_G14Fan4 {
            idc = 86595;
        };
        class IV_G20Fan3: IV_G14Fan4 {
            idc = 86594;
        };
        class IV_G20Fan2: IV_G14Fan4 {
            idc = 86593;
        };
        class IV_G20Fan1: IV_G14Fan4 {
            idc = 86592;
        };
        class IV_G20Logo: IV_G14Logo {
            idc = 86557;
            colorText[] = {1, 1, 1, 1};
            text = "\acm_extended\ui\iv\tray\iv_tray_20g_0_ca.paa";
        };
        class IV_G20Lbl: IV_G14Lbl {
            idc = 86558;
            text = "20g";
            colorText[] = {0.7, 0.88, 1, 1};
        };
        class IV_G20Click: IV_G14Click {
            idc = 86559;
            onButtonClick = "[20] call ACME_fnc_ivMinigameGrabNeedle";
        };
        class IV_LineBG: IV_G14BG {
            idc = 86552;
        };
        class IV_LineLogo: IV_G14Logo {
            idc = 86553;
            text = "\acm_extended\ui\iv\iv_line\standalone\base\iv_line_floating_base_ca.paa";
            colorText[] = {0.8, 0.95, 1, 1};
        };
        class IV_LineLbl: IV_G14Lbl {
            idc = 86554;
            text = "LINE";
            colorText[] = {0.8, 0.95, 1, 1};
        };
        class IV_LineClick: IV_G14Click {
            idc = 86555;
            tooltip = "Saline line. Connect it to a seated hub";
            onButtonClick = "[] call ACME_fnc_ivMinigameGrabLine";
        };
        class IV_Flip: RscButton {
            idc = 86560;
            x = "safezoneX + safezoneW * 0.025";
            y = "safezoneY + safezoneH * 0.84";
            w = "safezoneW * 0.12";
            h = "safezoneH * 0.05";
            text = "Flip (Front/Back)";
            onButtonClick = "[] call ACME_fnc_ivMinigameFlip";
            colorBackground[] = {0.14, 0.18, 0.24, 0.9};
            colorText[] = {0.85, 0.92, 1, 1};
        };
        class IV_Cancel: RscButton {
            idc = 86525;
            x = "safezoneX + safezoneW * 0.025";
            y = "safezoneY + safezoneH * 0.90";
            w = "safezoneW * 0.12";
            h = "safezoneH * 0.05";
            text = "Done";
            action = "[] call ACME_fnc_ivMinigameDone";
            colorBackground[] = {0.3, 0.1, 0.1, 0.85};
            colorText[] = {0.93, 0.89, 0.8, 1};
        };
        class IV_CursorBand: RscPictureKeepAspect {
            idc = 86505;
            x = 0;
            y = 0;
            w = 0;
            h = 0;
            text = "\acm_extended\ui\nar_boa_ca.paa";
            colorText[] = {1, 1, 1, 0.95};
            show = 0;
        };
        class IV_CursorNeedle: RscPictureKeepAspect {
            idc = 86506;
            x = 0;
            y = 0;
            w = 0;
            h = 0;
            text = "\acm_extended\ui\iv\18g\base\iv_catheter_18g_base_frame_00_ready_ca.paa";
            colorText[] = {1, 1, 1, 0.95};
            show = 0;
        };
        class IV_CursorPad: RscPictureKeepAspect {
            idc = 86507;
            x = 0;
            y = 0;
            w = 0;
            h = 0;
            text = "\acm_extended\ui\iv\alcohol_pad_left_ca.paa";
            colorText[] = {1, 1, 1, 0.95};
            show = 0;
        };
    };
};
class ACME_IV_Dot: RscPicture {
    idc = -1;
    x = 0;
    y = 0;
    w = 0;
    h = 0;
    text = "\acm_extended\ui\dot_grad_ca.paa";
    colorText[] = {0.95, 0.95, 0.98, 0.85};
};
class ACME_IV_Target: RscPicture {
    idc = -1;
    x = 0;
    y = 0;
    w = 0;
    h = 0;
    text = "\acm_extended\ui\dot_grad_ca.paa";
    colorText[] = {0.4, 0.95, 0.55, 0.3};
};
class ACME_IV_Catheter: RscPictureKeepAspect {
    style = 48;
    idc = -1;
    x = 0;
    y = 0;
    w = 0;
    h = 0;
    text = "\acm_extended\ui\iv\18g\base\iv_catheter_18g_base_frame_00_ready_ca.paa";
    colorText[] = {1, 1, 1, 1};
};
class ACME_IV_Clean: RscPicture {
    idc = -1;
    x = 0;
    y = 0;
    w = 0;
    h = 0;
    text = "\acm_extended\ui\dot_grad_ca.paa";
    colorText[] = {0.85, 0.2, 0.2, 0.35};
};
class ACME_IV_Hole: RscPicture {
    idc = -1;
    x = 0;
    y = 0;
    w = 0;
    h = 0;
    text = "\acm_extended\ui\holes\hole1_ca.paa";
    colorText[] = {1, 1, 1, 0.9};
};
class ACME_IV_HubMark: RscPictureKeepAspect {
    style = 48;
    idc = -1;
    x = 0;
    y = 0;
    w = 0;
    h = 0;
    text = "\acm_extended\ui\iv\18g\base\iv_catheter_18g_base_frame_14_catheter_hub_only_ca.paa";
    colorText[] = {1, 1, 1, 1};
};
class ACME_IV_Bruise: RscPictureKeepAspect {
    idc = -1;
    x = 0;
    y = 0;
    w = 0;
    h = 0;
    text = "\acm_extended\ui\iv\bruise_16g_ca.paa";
    colorText[] = {1, 1, 1, 0};
};
class ACME_IV_HeldCursor: RscPictureKeepAspect {
    idc = -1;
    x = 0;
    y = 0;
    w = 0;
    h = 0;
    text = "\acm_extended\ui\nar_boa_ca.paa";
    colorText[] = {1, 1, 1, 1};
};
class ACME_IV_CathCursor: ACME_IV_HeldCursor {
    style = 48;
};
class ACME_SyringeKit_Dialog {
    idd = 86300;
    movingEnable = 0;
    enableSimulation = 1;
    onLoad = "[_this select 0] call ACME_fnc_minigameInputInstall; call ACME_fnc_syringeKitOnLoad";
    onUnload = "private _h = uiNamespace getVariable ['ACME_SK_PFH', -1]; if (_h >= 0) then {[_h] call CBA_fnc_removePerFrameHandler;}; uiNamespace setVariable ['ACME_SK_PFH', -1]; uiNamespace setVariable ['ACME_SK_DLG', displayNull]; uiNamespace setVariable ['ACME_SK_InitDisplay', displayNull]; uiNamespace setVariable ['ACME_SK_Grab', false]; uiNamespace setVariable ['ACME_SK_Shade', []]; uiNamespace setVariable ['ACME_SK_Shade_dlg', displayNull]; uiNamespace setVariable ['ACME_flashlightMenuActive', false];";
    class ControlsBackground {
        class ACME_SK_Backdrop: RscText {
            idc = 86310;
            text = "";
            x = "safeZoneX + (safeZoneW / 2) - (safeZoneW / 4.35)";
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 2.5)";
            w = "safeZoneW / 2.17";
            h = "safeZoneH / 1.25";
            colorBackground[] = {0, 0, 0, 0.84};
            colorText[] = {1, 1, 1, 1};
        };
        class ACME_SK_Title: RscText {
            idc = 86311;
            text = "Narc Box";
            x = "safeZoneX + (safeZoneW / 2) - (safeZoneW / 4.35)";
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 2.5)";
            w = "safeZoneW / 2.17";
            h = "safeZoneH / 20";
            colorText[] = {1, 1, 1, 1};
            colorBackground[] = {0, 0, 0, 0};
            font = "RobotoCondensed";
            sizeEx = "safeZoneH / 30";
            style = 2;
            shadow = 0;
        };
        class ACME_SK_BarrelBG: RscPicture {
            idc = 86312;
            text = "#(argb,8,8,3)color(1,1,1,1)";
            colorText[] = {1, 1, 1, 0.1};
            x = "safeZoneX + (safeZoneW / 2)";
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 4)";
            w = "safeZoneW / 22";
            h = "safeZoneH / 3";
        };
    };
    class Controls {
        class ACME_SK_Fluid: RscPicture {
            idc = 86313;
            text = "#(argb,8,8,3)color(1,1,1,1)";
            colorText[] = {0.55, 0.78, 1, 0.62};
            x = "safeZoneX + (safeZoneW / 2)";
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 4)";
            w = "safeZoneW / 22";
            h = "safeZoneH / 8";
        };
        class ACME_SK_Syringe: RscPicture {
            idc = 86326;
            text = "\acm_extended\ui\items\salineFlush_ca.paa";
            colorText[] = {1, 1, 1, 1};
            x = "safeZoneX + (safeZoneW / 2)";
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 4)";
            w = "safeZoneW / 10";
            h = "safeZoneH / 3";
        };
        class ACME_SK_Plunger: RscPicture {
            idc = 86314;
            text = "#(argb,8,8,3)color(1,1,1,1)";
            colorText[] = {0.18, 0.18, 0.2, 1};
            x = "safeZoneX + (safeZoneW / 2)";
            y = "safeZoneY + (safeZoneH / 2)";
            w = "safeZoneW / 22";
            h = "safeZoneH / 80";
        };
        class ACME_SK_Rod: RscPicture {
            idc = 86315;
            text = "#(argb,8,8,3)color(1,1,1,1)";
            colorText[] = {0.5, 0.5, 0.52, 1};
            x = "safeZoneX + (safeZoneW / 2)";
            y = "safeZoneY + (safeZoneH / 2)";
            w = "safeZoneW / 90";
            h = "safeZoneH / 12";
        };
        class ACME_SK_Overlay: RscButton {
            idc = 86316;
            text = "";
            colorText[] = {1, 1, 1, 0};
            colorDisabled[] = {1, 1, 1, 0};
            colorBackground[] = {1, 1, 1, 0.01};
            colorBackgroundDisabled[] = {1, 1, 1, 0};
            colorBackgroundActive[] = {1, 1, 1, 0.01};
            colorFocused[] = {1, 1, 1, 0.01};
            colorBorder[] = {0, 0, 0, 0};
            x = "safeZoneX + (safeZoneW / 2)";
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 4)";
            w = "safeZoneW / 22";
            h = "safeZoneH / 3";
            shadow = 0;
            font = "RobotoCondensed";
            sizeEx = "0";
            action = "";
            tooltip = "Click to grab the plunger, move the mouse to draw/expel, click again to set.";
        };
        class ACME_SK_SizesLabel: RscText {
            idc = 86319;
            text = "Syringe Size";
            x = "safeZoneX + (safeZoneW / 2) - (safeZoneW / 4.6)";
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 3)";
            w = "safeZoneW / 7";
            h = "safeZoneH / 28";
            colorText[] = {0.8, 0.8, 0.8, 1};
            colorBackground[] = {0, 0, 0, 0};
            font = "RobotoCondensed";
            sizeEx = "safeZoneH / 44";
            style = 0;
        };
        class ACME_SK_SourcesLabel: ACME_SK_SizesLabel {
            idc = 86320;
            text = "Source";
        };
        class ACME_SK_SizesList: RscListBox {
            idc = 86317;
            x = "safeZoneX + (safeZoneW / 2) - (safeZoneW / 4.6)";
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 4)";
            w = "safeZoneW / 7";
            h = "safeZoneH / 4";
            rowHeight = "safeZoneH / 22";
            colorText[] = {1, 1, 1, 1};
            colorSelect[] = {0, 0, 0, 1};
            colorSelect2[] = {0, 0, 0, 1};
            colorBackground[] = {0, 0, 0, 0.25};
            colorSelectBackground[] = {0.7, 0.7, 0.7, 1};
            colorSelectBackground2[] = {0.7, 0.7, 0.7, 1};
            sizeEx = "safeZoneH / 40";
            class Items {};
        };
        class ACME_SK_SourcesList: ACME_SK_SizesList {
            idc = 86318;
            y = "safeZoneY + (safeZoneH / 2)";
            h = "safeZoneH / 6";
        };
        class ACME_SK_VolText: RscText {
            idc = 86321;
            text = "0.0 mL";
            x = "safeZoneX + (safeZoneW / 2) - (safeZoneW / 30)";
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 3)";
            w = "safeZoneW / 8";
            h = "safeZoneH / 22";
            colorText[] = {1, 1, 1, 1};
            colorBackground[] = {0, 0, 0, 0};
            font = "RobotoCondensed";
            sizeEx = "safeZoneH / 28";
            style = 2;
            shadow = 0;
        };
        class ACME_SK_Info: RscText {
            idc = 86322;
            text = "";
            x = "safeZoneX + (safeZoneW / 2) - (safeZoneW / 4.35)";
            y = "safeZoneY + (safeZoneH / 2) + (safeZoneH / 3.4)";
            w = "safeZoneW / 2.17";
            h = "safeZoneH / 22";
            colorText[] = {0.85, 0.85, 0.85, 1};
            colorBackground[] = {0, 0, 0, 0.4};
            font = "RobotoCondensed";
            sizeEx = "safeZoneH / 46";
            style = 2;
            shadow = 0;
        };
        class ACME_SK_Waste: RscButton {
            idc = 86323;
            text = "Waste";
            x = "safeZoneX + (safeZoneW / 2) - (safeZoneW / 4.35)";
            y = "safeZoneY + (safeZoneH / 2) + (safeZoneH / 2.8)";
            w = "safeZoneW / 8";
            h = "safeZoneH / 22";
            colorText[] = {1, 1, 1, 1};
            colorDisabled[] = {1, 1, 1, 0.25};
            colorBackground[] = {0, 0, 0, 1};
            colorBackgroundDisabled[] = {0, 0, 0, 0.35};
            colorBackgroundActive[] = {0.12, 0.12, 0.12, 1};
            colorFocused[] = {0, 0, 0, 1};
            colorBorder[] = {0, 0, 0, 0};
            style = 2;
            shadow = 0;
            font = "RobotoCondensed";
            sizeEx = "safeZoneH / 46";
            action = "";
            tooltip = "Expel down to the plunger and lock that as the saline base.";
        };
        class ACME_SK_Draw: ACME_SK_Waste {
            idc = 86324;
            text = "Draw";
            tooltip = "Store the prepared push-dose pressor.";
        };
        class ACME_SK_Close: ACME_SK_Waste {
            idc = 86325;
            text = "Close";
            tooltip = "Close the syringe kit.";
        };
    };
};
class ACM_circulation_TransfusionMenu_Dialog {
    class Controls {
        class StopTransfusionButton;
        class AddBagButton: StopTransfusionButton {
            idc = 86140;
            text = "Spike Bag";
            action = "call ACME_fnc_transfusionSpikeOrAdd";
            tooltip = "Spike the selected bag (consumes one IV line), then press again to hang it.";
        };
        class ACME_PullBagButton: StopTransfusionButton {
            idc = 86146;
            text = "Pull Bag";
            x = "safeZoneX - 1";
            action = "call ACME_fnc_transfusionPullBag";
            tooltip = "Pull the selected hung bag off (keeps the Y tube) into the used-bag set with its remaining volume.";
        };
        class ACME_InjectMedicationBagButton: RscButton {
            text = "Discard Y Tubing";
            colorText[] = {1, 1, 1, 1};
            colorDisabled[] = {1, 1, 1, 0.25};
            colorBackground[] = {0, 0, 0, 1};
            colorBackgroundDisabled[] = {0, 0, 0, 0.35};
            colorBackgroundActive[] = {0, 0, 0, 1};
            colorFocused[] = {0, 0, 0, 1};
            colorBorder[] = {0, 0, 0, 0};
            idc = 86120;
            style = 2;
            x = "safeZoneX + (safeZoneW / 2) - (safeZoneW / 8)";
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 10)";
            w = "safeZoneW / 22";
            h = "safeZoneH / 40";
            shadow = 0;
            font = "RobotoCondensed";
            sizeEx = "safeZoneH / 50";
            action = "call ACME_fnc_discardYTubing";
            tooltip = "Cut the Y tubing off this access: remaining fluids go to the used-bag set, the tubing is consumed, and the site is freed for any other IV setup.";
        };
        class ACME_InfuseBagButton: ACME_InjectMedicationBagButton {
            idc = 86147;
            text = "Infuse";
            x = "safeZoneX - 1";
            action = "call ACME_fnc_openFromTransfusionMenu";
            tooltip = "Inject a medication into the selected normal saline bag (any volume). The bag becomes an infusion and moves to the Infusions list.";
        };
        class ACME_PrepMedicationBagButton: ACME_InjectMedicationBagButton {
            text = "Prep Infusion";
            idc = 86121;
            x = "safeZoneX + (safeZoneW / 2) + (safeZoneW / 6.8)";
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 6)";
            w = "safeZoneW / 12";
            h = "safeZoneH / 40";
            sizeEx = "safeZoneH / 50";
            action = "call ACME_fnc_openPrepFromInventoryMenu";
            tooltip = "Inject medication into a saline bag before starting the transfusion";
        };
        class ACME_GivePreparedBagButton: ACME_PrepMedicationBagButton {
            text = "Give Infusion";
            idc = 86122;
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 6) + (safeZoneH / 20)";
            action = "call ACME_fnc_givePreparedBag";
            tooltip = "Start the selected prepared medication saline bag";
        };
        class ACME_HangBagButton: ACME_GivePreparedBagButton {
            text = "Hang Bag";
            idc = 86134;
            x = "safeZoneX + (safeZoneW / 2) - (safeZoneW / 8)";
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 15)";
            w = "safeZoneW / 22";
            sizeEx = "(((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) * 0.9) * (0.55 / (getResolution select 5))";
            action = "call ACME_fnc_hangBagFromMenu";
            tooltip = "Raise the selected hung IV/blood bag (gravity-assisted high flow). One bag at a time.";
        };
        class ACME_PressureInfuserButton: ACME_HangBagButton {
            text = "Pressure Infuse";
            idc = 86148;
            style = 2;
            sizeEx = "(((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) * 0.9) * (0.55 / (getResolution select 5))";
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 15) + (safeZoneH / 26)";
            action = "['transfusion'] call ACME_fnc_pressureInfuserAttach";
            tooltip = "Cuff the selected bag. Runs unattended and does not care about height, but bleeds down as the bag empties and must be pumped again. Use the Infusions pressure button for medicated bags.";
        };
        class ACME_InfusionPressureButton: ACME_PressureInfuserButton {
            idc = 86149;
            x = "safeZoneX - 1";
            action = "['infusion'] call ACME_fnc_pressureInfuserAttach";
            tooltip = "Apply or re-pump a cuff on the selected infusion. Pressure increases delivery through the set clamp; a closed clamp remains closed.";
        };
        class ACME_SpikeBagButton: ACME_GivePreparedBagButton {
            text = "Spike Bag";
            idc = 86141;
            x = "safeZoneX + (safeZoneW / 2) + (safeZoneW / 7.75)";
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 12)";
            w = "safeZoneW / 8.5";
            action = "call ACME_fnc_transfusionSpikeOrAdd";
            tooltip = "Spike the selected bag (consumes one IV line), then press again to hang it.";
        };
        class ACME_YTubingButton: ACME_SpikeBagButton {
            text = "Spike Y tubing";
            idc = 86142;
            action = "call ACME_fnc_transfusionYTubing";
            tooltip = "Build a Y-type blood line: consumes a Y tubing set and pairs a saline bag to the blood unit.";
        };
        class ACME_FlushLineButton: ACME_SpikeBagButton {
            text = "Flush Line";
            idc = 86143;
            action = "call ACME_fnc_transfusionFlushLine";
            tooltip = "Flush the blood line with its paired saline so the next unit is ready to hang.";
        };
        class ACME_PreparedSetsButton: ACME_SpikeBagButton {
            text = "Prepared IV sets";
            idc = 86144;
            action = "call ACME_fnc_togglePreparedSets";
            tooltip = "Show your prepared IV sets. Build one with Spike Y tubing, Select Flush Saline, then Build Y Tubing.";
        };
        class LeftPanelList;
        class ACME_PreparedSetsList: LeftPanelList {
            idc = 86145;
        };
        class ACME_PreparedInfusionTitle: RscText {
            idc = 86130;
            text = "Prepared Infusions";
            x = "safeZoneX + (safeZoneW / 2) + (safeZoneW / 7.75)";
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 6) + (safeZoneH / 10)";
            w = "safeZoneW / 8.5";
            h = "safeZoneH / 45";
            colorText[] = {1, 1, 1, 1};
            colorBackground[] = {0, 0, 0, 0.55};
            font = "RobotoCondensed";
            sizeEx = "safeZoneH / 58";
            style = 2;
            shadow = 0;
        };
        class ACME_PreparedInfusionList: RscListBox {
            idc = 86127;
            x = "safeZoneX + (safeZoneW / 2) + (safeZoneW / 7.75)";
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 6) + (safeZoneH / 10) + (safeZoneH / 45)";
            w = "safeZoneW / 8.5";
            h = "safeZoneH / 10";
            rowHeight = "safeZoneH / 25";
            colorText[] = {1, 1, 1, 1};
            colorSelect[] = {0, 0, 0, 1};
            colorSelect2[] = {0, 0, 0, 1};
            colorBackground[] = {0, 0, 0, 0.25};
            colorSelectBackground[] = {0.7, 0.7, 0.7, 1};
            colorSelectBackground2[] = {0.7, 0.7, 0.7, 1};
            font = "RobotoCondensed";
            sizeEx = "safeZoneH / 50";
            onLBSelChanged = "params ['_ctrl','_index']; if (_index >= 0) then {missionNamespace setVariable ['ACME_infusion_SelectedPreparedIndex', _ctrl lbValue _index];};";
        };
        class ACME_ActiveInfusionTitle: ACME_PreparedInfusionTitle {
            idc = 86128;
            text = "Infusions";
            x = "safeZoneX + (safeZoneW / 2) - (safeZoneW / 4.05)";
            y = "safeZoneY + (safeZoneH / 2) + (safeZoneH / 14)";
            w = "safeZoneW / 8.5";
        };
        class ACME_ActiveInfusionList: ACME_PreparedInfusionList {
            idc = 86129;
            x = "safeZoneX + (safeZoneW / 2) - (safeZoneW / 4.05)";
            y = "safeZoneY + (safeZoneH / 2) + (safeZoneH / 14) + (safeZoneH / 45)";
            w = "safeZoneW / 8.5";
            h = "safeZoneH / 8";
            onLBSelChanged = "params ['_ctrl','_index']; if (_index >= 0) then {private _v = _ctrl lbValue _index; missionNamespace setVariable ['ACME_infusion_SelectedActiveInfusionSelectionIndex', _v]; private _sel = missionNamespace getVariable ['ACM_circulation_TransfusionMenu_Selection_IVBags', []]; missionNamespace setVariable ['ACME_infusion_SelectedActiveInfusionTrueIndex', if (_v >= 0 && {_v < count _sel}) then {(_sel select _v) param [8, -1]} else {-1}]; private _native = ctrlParent _ctrl displayCtrl 86004; if (!isNull _native) then {_native lbSetCurSel -1;};};";
        };
        class ACME_RateReadout: RscText {
            idc = 86126;
            text = "Select medicated saline bag";
            x = "safeZoneX + (safeZoneW / 2) - (safeZoneW / 4.35)";
            y = "safeZoneY + (safeZoneH / 2) + (safeZoneH / 4.75)";
            w = "safeZoneW / 3.1";
            h = "safeZoneH / 32";
            colorText[] = {1, 1, 1, 1};
            colorBackground[] = {0, 0, 0, 0.55};
            font = "RobotoCondensed";
            sizeEx = "safeZoneH / 55";
            style = 2;
            shadow = 0;
        };
        class ACME_DropSetButton: ACME_InjectMedicationBagButton {
            text = "Drop Set";
            idc = 86123;
            x = "safeZoneX + (safeZoneW / 2) - (safeZoneW / 4.35)";
            y = "safeZoneY + (safeZoneH / 2) + (safeZoneH / 5.45)";
            w = "safeZoneW / 13";
            action = "call ACME_fnc_cycleDropSet";
            tooltip = "Cycle drop set: 10, 15, 20, or 60 gtt/mL";
        };
        class ACME_RateDownButton: ACME_DropSetButton {
            text = "Rate -";
            idc = 86124;
            x = "safeZoneX + (safeZoneW / 2) - (safeZoneW / 6.6)";
            action = "[-1] call ACME_fnc_adjustDripRate";
            tooltip = "Decrease medication drip rate";
        };
        class ACME_RateUpButton: ACME_DropSetButton {
            text = "Rate +";
            idc = 86125;
            x = "safeZoneX + (safeZoneW / 2) - (safeZoneW / 14.2)";
            action = "[1] call ACME_fnc_adjustDripRate";
            tooltip = "Increase medication drip rate";
        };
        class ACME_MoveInfusionButton: ACME_DropSetButton {
            text = "Move";
            idc = 86132;
            x = "safeZoneX + (safeZoneW / 2) - (safeZoneW / 4.05)";
            y = "safeZoneY + (safeZoneH / 2) + (safeZoneH / 5)";
            w = "safeZoneW / 8.5";
            h = "safeZoneH / 40";
            action = "call ACME_fnc_moveInfusionBag";
            tooltip = "Move the selected infusion's bag to another access site";
        };
        class ACME_RemoveInfusionButton: ACME_MoveInfusionButton {
            text = "Remove";
            idc = 86133;
            y = "safeZoneY + (safeZoneH / 2) + (safeZoneH / 4.4)";
            action = "call ACME_fnc_removeInfusionBag";
            tooltip = "Remove the selected infusion's bag";
        };
        class ACME_AdjustInfusionButton: ACME_DropSetButton {
            text = "Adjust Infusion";
            idc = 86131;
            colorText[] = {1, 0.85, 0.16, 1};
            colorDisabled[] = {1, 0.85, 0.16, 0.25};
            x = "safeZoneX + (safeZoneW / 2) - (safeZoneW / 4.05)";
            y = "safeZoneY + (safeZoneH / 2) + (safeZoneH / 14) - (safeZoneH / 38)";
            w = "safeZoneW / 8.5";
            h = "safeZoneH / 40";
            action = "call ACME_fnc_openRollerClamp";
            tooltip = "Open the roller clamp for the selected infusion";
        };
    };
};
class ACME_HangBag_Tuner {
    idd = 87100;
    movingEnable = 0;
    enableSimulation = 1;
    onLoad = "[_this select 0] call ACME_fnc_minigameInputInstall; _this call ACME_fnc_hangBagTuneLoad";
    class controlsBackground {
        class BG: RscText {
            idc = -1;
            x = "safeZoneX + safeZoneW - 0.44";
            y = "safeZoneY + 0.035";
            w = 0.42;
            h = 0.9;
            colorBackground[] = {0, 0, 0, 0.88};
        };
        class Title: RscText {
            idc = -1;
            text = "RIGHT-HAND IV BAG + LINE LIVE PLACEMENT";
            x = "safeZoneX + safeZoneW - 0.43";
            y = "safeZoneY + 0.045";
            w = 0.4;
            h = 0.035;
            sizeEx = 0.028;
        };
        class BagPosTitle: RscText {
            idc = -1;
            text = "BAG POSITION ON RIGHT HAND  (-5.00 m to +5.00 m)";
            x = "safeZoneX + safeZoneW - 0.43";
            y = "safeZoneY + 0.087";
            w = 0.4;
            h = 0.03;
            sizeEx = 0.021;
            colorText[] = {0.7, 0.88, 1, 1};
        };
        class BagRotTitle: BagPosTitle {
            text = "BAG ORIENTATION  (-360 deg to +360 deg)";
            y = "safeZoneY + 0.247";
        };
        class LinePosTitle: BagPosTitle {
            text = "IV PATIENT-END POSITION  (-5.00 m to +5.00 m)";
            y = "safeZoneY + 0.407";
        };
        class LineRotTitle: BagPosTitle {
            text = "IV PATIENT-END ORIENTATION  (-360 deg to +360 deg)";
            y = "safeZoneY + 0.567";
        };
    };
    class controls {
        class SX: RscXSliderH {
            idc = 87101;
            x = "safeZoneX + safeZoneW - 0.425";
            y = "safeZoneY + 0.122";
            w = 0.245;
            h = 0.024;
            onSliderPosChanged = "[] call ACME_fnc_hangBagTuneUpdate";
        };
        class SY: SX {
            idc = 87102;
            y = "safeZoneY + 0.162";
        };
        class SZ: SX {
            idc = 87103;
            y = "safeZoneY + 0.202";
        };
        class SYaw: SX {
            idc = 87104;
            y = "safeZoneY + 0.282";
        };
        class SPitch: SX {
            idc = 87105;
            y = "safeZoneY + 0.322";
        };
        class SRoll: SX {
            idc = 87106;
            y = "safeZoneY + 0.362";
        };
        class SLineX: SX {
            idc = 87107;
            y = "safeZoneY + 0.442";
        };
        class SLineY: SX {
            idc = 87108;
            y = "safeZoneY + 0.482";
        };
        class SLineZ: SX {
            idc = 87109;
            y = "safeZoneY + 0.522";
        };
        class SLineYaw: SX {
            idc = 87120;
            y = "safeZoneY + 0.602";
        };
        class SLinePitch: SX {
            idc = 87121;
            y = "safeZoneY + 0.642";
        };
        class SLineRoll: SX {
            idc = 87122;
            y = "safeZoneY + 0.682";
        };
        class LX: RscText {
            idc = 87111;
            x = "safeZoneX + safeZoneW - 0.175";
            y = "safeZoneY + 0.114";
            w = 0.145;
            h = 0.04;
            sizeEx = 0.02;
        };
        class LY: LX {
            idc = 87112;
            y = "safeZoneY + 0.154";
        };
        class LZ: LX {
            idc = 87113;
            y = "safeZoneY + 0.194";
        };
        class LYaw: LX {
            idc = 87114;
            y = "safeZoneY + 0.274";
        };
        class LPitch: LX {
            idc = 87115;
            y = "safeZoneY + 0.314";
        };
        class LRoll: LX {
            idc = 87116;
            y = "safeZoneY + 0.354";
        };
        class LLineX: LX {
            idc = 87117;
            y = "safeZoneY + 0.434";
        };
        class LLineY: LX {
            idc = 87118;
            y = "safeZoneY + 0.474";
        };
        class LLineZ: LX {
            idc = 87119;
            y = "safeZoneY + 0.514";
        };
        class LLineYaw: LX {
            idc = 87123;
            y = "safeZoneY + 0.594";
        };
        class LLinePitch: LX {
            idc = 87124;
            y = "safeZoneY + 0.634";
        };
        class LLineRoll: LX {
            idc = 87125;
            y = "safeZoneY + 0.674";
        };
        class Hint: RscText {
            idc = -1;
            text = "Bag is parented to RightHand. IV-end roll starts at 180 deg (top down). All changes apply live; F2 reopens.";
            x = "safeZoneX + safeZoneW - 0.425";
            y = "safeZoneY + 0.730";
            w = 0.395;
            h = 0.055;
            sizeEx = 0.019;
            colorText[] = {0.82, 0.82, 0.82, 1};
        };
        class Report: RscButton {
            idc = -1;
            text = "REPORT VALUES";
            x = "safeZoneX + safeZoneW - 0.425";
            y = "safeZoneY + 0.805";
            w = 0.19;
            h = 0.04;
            action = "[] call ACME_fnc_hangBagTuneReport";
            tooltip = "Show exact right-hand bag and patient-end line values";
        };
        class Close: Report {
            text = "DONE";
            x = "safeZoneX + safeZoneW - 0.225";
            w = 0.195;
            action = "closeDialog 0";
            tooltip = "Close the tuner";
        };
    };
};
class ACME_HeadElev_Tuner {
    idd = 87200;
    movingEnable = 0;
    enableSimulation = 1;
    onLoad = "[_this select 0] call ACME_fnc_minigameInputInstall; _this call ACME_fnc_headElevTuneLoad";
    onUnload = "missionNamespace setVariable ['ACME_headElev_tuning', false]";
    class controlsBackground {
        class BG: RscText {
            idc = -1;
            x = "safeZoneX + safeZoneW - 0.44";
            y = "safeZoneY + 0.035";
            w = 0.42;
            h = 0.79;
            colorBackground[] = {0, 0, 0, 0.88};
        };
        class Title: RscText {
            idc = -1;
            text = "HEAD / PLATE-CARRIER LIVE TUNER";
            x = "safeZoneX + safeZoneW - 0.43";
            y = "safeZoneY + 0.045";
            w = 0.4;
            h = 0.035;
            sizeEx = 0.028;
        };
        class TiltTitle: RscText {
            idc = -1;
            text = "EXTRA TILT  (0 = animation pose only)";
            x = "safeZoneX + safeZoneW - 0.43";
            y = "safeZoneY + 0.087";
            w = 0.4;
            h = 0.03;
            sizeEx = 0.021;
            colorText[] = {0.7, 0.88, 1, 1};
        };
        class PivotTitle: TiltTitle {
            text = "POSITION NUDGE  (-2.00 m to +2.00 m)  X / Y / Z";
            y = "safeZoneY + 0.207";
        };
        class LiftTitle: TiltTitle {
            text = "BODY LIFT  (-1.00 m to +1.00 m)";
            y = "safeZoneY + 0.367";
        };
        class VestOffTitle: TiltTitle {
            text = "PLATE-CARRIER OFFSET  (m, Spine3)  X / Y / Z";
            y = "safeZoneY + 0.450";
            colorText[] = {1, 0.85, 0.55, 1};
        };
        class VestRotTitle: VestOffTitle {
            text = "PLATE-CARRIER ORIENT  (deg)  Pitch / Yaw / Roll";
            y = "safeZoneY + 0.602";
        };
    };
    class controls {
        class STilt: RscXSliderH {
            idc = 87201;
            x = "safeZoneX + safeZoneW - 0.425";
            y = "safeZoneY + 0.122";
            w = 0.245;
            h = 0.024;
            onSliderPosChanged = "[] call ACME_fnc_headElevTuneUpdate";
        };
        class SPivotX: STilt {
            idc = 87202;
            y = "safeZoneY + 0.242";
        };
        class SPivotY: STilt {
            idc = 87203;
            y = "safeZoneY + 0.282";
        };
        class SPivotZ: STilt {
            idc = 87204;
            y = "safeZoneY + 0.322";
        };
        class SLift: STilt {
            idc = 87205;
            y = "safeZoneY + 0.402";
        };
        class SVestOffX: STilt {
            idc = 87221;
            y = "safeZoneY + 0.482";
        };
        class SVestOffY: STilt {
            idc = 87222;
            y = "safeZoneY + 0.520";
        };
        class SVestOffZ: STilt {
            idc = 87223;
            y = "safeZoneY + 0.558";
        };
        class SVestPitch: STilt {
            idc = 87224;
            y = "safeZoneY + 0.634";
        };
        class SVestYaw: STilt {
            idc = 87225;
            y = "safeZoneY + 0.672";
        };
        class SVestRoll: STilt {
            idc = 87226;
            y = "safeZoneY + 0.710";
        };
        class LTilt: RscText {
            idc = 87211;
            x = "safeZoneX + safeZoneW - 0.175";
            y = "safeZoneY + 0.114";
            w = 0.145;
            h = 0.04;
            sizeEx = 0.02;
        };
        class LPivotX: LTilt {
            idc = 87212;
            y = "safeZoneY + 0.234";
        };
        class LPivotY: LTilt {
            idc = 87213;
            y = "safeZoneY + 0.274";
        };
        class LPivotZ: LTilt {
            idc = 87214;
            y = "safeZoneY + 0.314";
        };
        class LLift: LTilt {
            idc = 87215;
            y = "safeZoneY + 0.394";
        };
        class LVestOffX: LTilt {
            idc = 87231;
            y = "safeZoneY + 0.474";
        };
        class LVestOffY: LTilt {
            idc = 87232;
            y = "safeZoneY + 0.512";
        };
        class LVestOffZ: LTilt {
            idc = 87233;
            y = "safeZoneY + 0.550";
        };
        class LVestPitch: LTilt {
            idc = 87234;
            y = "safeZoneY + 0.626";
        };
        class LVestYaw: LTilt {
            idc = 87235;
            y = "safeZoneY + 0.664";
        };
        class LVestRoll: LTilt {
            idc = 87236;
            y = "safeZoneY + 0.702";
        };
        class Hint: RscText {
            idc = -1;
            text = "Head rows tune the casualty pose. Plate-carrier rows move and rotate the upper-back prop live.";
            x = "safeZoneX + safeZoneW - 0.425";
            y = "safeZoneY + 0.752";
            w = 0.395;
            h = 0.055;
            sizeEx = 0.019;
            colorText[] = {0.82, 0.82, 0.82, 1};
        };
        class Report: RscButton {
            idc = -1;
            text = "REPORT VALUES";
            x = "safeZoneX + safeZoneW - 0.425";
            y = "safeZoneY + 0.810";
            w = 0.19;
            h = 0.04;
            action = "[] call ACME_fnc_headElevTuneReport";
            tooltip = "Show exact tilt/pivot/lift values";
        };
        class Close: RscButton {
            idc = -1;
            text = "DONE";
            x = "safeZoneX + safeZoneW - 0.225";
            y = "safeZoneY + 0.810";
            w = 0.195;
            h = 0.04;
            action = "closeDialog 0";
            tooltip = "Close the tuner";
        };
    };
};
class ACME_IVModule_Dialog {
    idd = 87900;
    movingEnable = 0;
    enableSimulation = 1;
    onLoad = "uiNamespace setVariable ['ACME_IVModule_display', _this select 0]; private _d = _this select 0; lbClear (_d displayCtrl 87901); { (_d displayCtrl 87901) lbAdd _x } forEach ['Left arm','Right arm','Left leg','Right leg','Neck (EJ)']; (_d displayCtrl 87901) lbSetCurSel 0; lbClear (_d displayCtrl 87902); { (_d displayCtrl 87902) lbAdd _x } forEach ['Upper','Middle','Lower','Left (EJ)','Right (EJ)']; (_d displayCtrl 87902) lbSetCurSel 1; call ACME_fnc_zeusIVDialogSite; lbClear (_d displayCtrl 87903); { (_d displayCtrl 87903) lbAdd _x } forEach ['14g','16g','18g','20g']; (_d displayCtrl 87903) lbSetCurSel 1;";
    class controlsBackground {
        class BG: RscText {
            idc = -1;
            x = 0.28;
            y = 0.3;
            w = 0.44;
            h = 0.4;
            colorBackground[] = {0, 0, 0, 0.9};
        };
        class Title: RscText {
            idc = -1;
            text = "PLACE IV";
            x = 0.29;
            y = 0.31;
            w = 0.42;
            h = 0.035;
            sizeEx = 0.03;
            colorText[] = {0.7, 0.88, 1, 1};
        };
        class LimbLabel: RscText {
            idc = -1;
            text = "Limb";
            x = 0.29;
            y = 0.355;
            w = 0.13;
            h = 0.03;
            sizeEx = 0.024;
        };
        class SiteLabel: RscText {
            idc = -1;
            text = "Access site";
            x = 0.43;
            y = 0.355;
            w = 0.13;
            h = 0.03;
            sizeEx = 0.024;
        };
        class GaugeLabel: RscText {
            idc = -1;
            text = "Gauge";
            x = 0.57;
            y = 0.355;
            w = 0.13;
            h = 0.03;
            sizeEx = 0.024;
        };
        class Hint: RscText {
            idc = -1;
            text = "Neck (EJ) takes a side. An arm or a leg takes a height. The rest grey out.";
            x = 0.29;
            y = 0.575;
            w = 0.42;
            h = 0.03;
            sizeEx = 0.02;
            colorText[] = {0.75, 0.75, 0.75, 1};
        };
    };
    class controls {
        class LimbList: RscListBox {
            idc = 87901;
            onLBSelChanged = "call ACME_fnc_zeusIVDialogSite";
            x = 0.29;
            y = 0.39;
            w = 0.13;
            h = 0.175;
            sizeEx = 0.024;
        };
        class SiteList: RscListBox {
            idc = 87902;
            onLBSelChanged = "call ACME_fnc_zeusIVDialogSite";
            x = 0.43;
            y = 0.39;
            w = 0.13;
            h = 0.175;
            sizeEx = 0.024;
        };
        class GaugeList: RscListBox {
            idc = 87903;
            x = 0.57;
            y = 0.39;
            w = 0.13;
            h = 0.175;
            sizeEx = 0.024;
        };
        class BtnConfirm: RscButton {
            idc = -1;
            text = "Place";
            x = 0.545;
            y = 0.635;
            w = 0.165;
            h = 0.04;
            colorBackground[] = {0.12, 0.28, 0.16, 1};
            action = "call ACME_fnc_zeusIVDialogConfirm";
        };
        class BtnCancel: RscButton {
            idc = -1;
            text = "Cancel";
            x = 0.29;
            y = 0.635;
            w = 0.165;
            h = 0.04;
            colorBackground[] = {0.2, 0.2, 0.2, 1};
            action = "closeDialog 0";
        };
    };
};
class ACME_TBIModule_Dialog {
    idd = 87500;
    movingEnable = 0;
    enableSimulation = 1;
    onLoad = "uiNamespace setVariable ['ACME_TBIModule_display', _this select 0]; lbClear ((_this select 0) displayCtrl 87502); { ((_this select 0) displayCtrl 87502) lbAdd _x } forEach ['Mild','Moderate','Severe','Herniating']; ((_this select 0) displayCtrl 87502) lbSetCurSel 1; ((_this select 0) displayCtrl 87501) sliderSetRange [0, 1]; ((_this select 0) displayCtrl 87501) sliderSetPosition 0.5;";
    class controlsBackground {
        class BG: RscText {
            idc = -1;
            x = 0.32;
            y = 0.34;
            w = 0.36;
            h = 0.32;
            colorBackground[] = {0, 0, 0, 0.9};
        };
        class Title: RscText {
            idc = -1;
            text = "INFLICT TRAUMATIC BRAIN INJURY";
            x = 0.33;
            y = 0.35;
            w = 0.34;
            h = 0.035;
            sizeEx = 0.03;
            colorText[] = {0.7, 0.88, 1, 1};
        };
        class SevLabel: RscText {
            idc = -1;
            text = "Severity (0 = mild, 1 = maximal)";
            x = 0.33;
            y = 0.4;
            w = 0.34;
            h = 0.03;
            sizeEx = 0.024;
        };
        class StateLabel: RscText {
            idc = -1;
            text = "Initial state";
            x = 0.33;
            y = 0.495;
            w = 0.34;
            h = 0.03;
            sizeEx = 0.024;
        };
    };
    class controls {
        class SevSlider: RscXSliderH {
            idc = 87501;
            x = 0.33;
            y = 0.435;
            w = 0.34;
            h = 0.04;
        };
        class StateList: RscListBox {
            idc = 87502;
            x = 0.33;
            y = 0.53;
            w = 0.34;
            h = 0.075;
            sizeEx = 0.026;
        };
        class BtnConfirm: RscButton {
            idc = -1;
            text = "Apply";
            x = 0.505;
            y = 0.615;
            w = 0.165;
            h = 0.04;
            colorBackground[] = {0.3, 0.12, 0.12, 1};
            action = "call ACME_fnc_zeusTBIDialogConfirm";
        };
        class BtnCancel: RscButton {
            idc = -1;
            text = "Cancel";
            x = 0.33;
            y = 0.615;
            w = 0.165;
            h = 0.04;
            colorBackground[] = {0.15, 0.15, 0.15, 1};
            action = "closeDialog 2";
        };
    };
};
class ACME_BloodFridgeContents_Dialog {
    idd = 87620;
    movingEnable = 0;
    enableSimulation = 1;
    onLoad = "[_this select 0] call ACME_fnc_minigameInputInstall; uiNamespace setVariable ['ACME_bfc_dlg', _this select 0]; call ACME_fnc_bloodFridgeContentsFill;";
    class controlsBackground {
        class BG: RscText {
            idc = -1;
            x = 0.28;
            y = 0.22;
            w = 0.44;
            h = 0.56;
            colorBackground[] = {0.03, 0.03, 0.05, 0.94};
        };
        class Header: RscText {
            idc = -1;
            x = 0.28;
            y = 0.22;
            w = 0.44;
            h = 0.045;
            colorBackground[] = {0.3, 0.1, 0.1, 1};
        };
        class Title: RscText {
            idc = -1;
            text = "BLOOD FRIDGE";
            x = 0.295;
            y = 0.223;
            w = 0.3;
            h = 0.04;
            sizeEx = 0.032;
            colorText[] = {0.95, 0.9, 0.85, 1};
        };
        class Sub: RscText {
            idc = 87621;
            text = "";
            x = 0.295;
            y = 0.272;
            w = 0.41;
            h = 0.03;
            sizeEx = 0.022;
            colorText[] = {0.7, 0.72, 0.78, 1};
        };
        class HdrType: RscText {
            idc = -1;
            text = "TYPE";
            x = 0.295;
            y = 0.308;
            w = 0.12;
            h = 0.028;
            sizeEx = 0.02;
            colorText[] = {0.55, 0.6, 0.68, 1};
        };
        class HdrQty: RscText {
            idc = -1;
            text = "UNITS";
            x = 0.445;
            y = 0.308;
            w = 0.08;
            h = 0.028;
            sizeEx = 0.02;
            colorText[] = {0.55, 0.6, 0.68, 1};
        };
        class HdrVol: RscText {
            idc = -1;
            text = "VOLUME";
            x = 0.535;
            y = 0.308;
            w = 0.1;
            h = 0.028;
            sizeEx = 0.02;
            colorText[] = {0.55, 0.6, 0.68, 1};
        };
        class Rule: RscText {
            idc = -1;
            x = 0.295;
            y = 0.334;
            w = 0.41;
            h = 0.002;
            colorBackground[] = {0.35, 0.38, 0.44, 1};
        };
    };
    class controls {
        class ListC: RscStructuredText {
            idc = 87622;
            x = 0.295;
            y = 0.342;
            w = 0.41;
            h = 0.3;
            size = 0.028;
        };
        class Foot: RscStructuredText {
            idc = 87623;
            x = 0.295;
            y = 0.652;
            w = 0.41;
            h = 0.08;
            size = 0.024;
        };
        class BtnClose: RscButton {
            idc = -1;
            text = "Close";
            x = 0.525;
            y = 0.738;
            w = 0.18;
            h = 0.038;
            colorBackground[] = {0.15, 0.15, 0.15, 1};
            action = "closeDialog 0";
        };
    };
};
class ACME_BloodFridge_Dialog {
    idd = 87600;
    movingEnable = 0;
    enableSimulation = 1;
    onLoad = "[_this select 0] call ACME_fnc_minigameInputInstall; uiNamespace setVariable ['ACME_bf_dlg', _this select 0]; ((_this select 0) displayCtrl 87604) setVariable ['on', true]; { private _c = (_this select 0) displayCtrl (_x select 0); _c sliderSetRange [(_x select 1), (_x select 2)]; _c sliderSetPosition (_x select 3); } forEach [[87601,0,40,6],[87602,0,40,2],[87603,0,40,0],[87605,0,72,24],[87606,0,59,0]];";
    class controlsBackground {
        class BG: RscText {
            idc = -1;
            x = 0.3;
            y = 0.26;
            w = 0.4;
            h = 0.48;
            colorBackground[] = {0, 0, 0, 0.9};
        };
        class Title: RscText {
            idc = -1;
            text = "PLACE BLOOD FRIDGE";
            x = 0.31;
            y = 0.27;
            w = 0.38;
            h = 0.035;
            sizeEx = 0.03;
            colorText[] = {0.85, 0.3, 0.3, 1};
        };
        class LOPos: RscText {
            idc = -1;
            text = "O+ units";
            x = 0.31;
            y = 0.315;
            w = 0.24;
            h = 0.03;
            sizeEx = 0.024;
        };
        class LONeg: RscText {
            idc = -1;
            text = "O- units";
            x = 0.31;
            y = 0.37;
            w = 0.24;
            h = 0.03;
            sizeEx = 0.024;
        };
        class LOther: RscText {
            idc = -1;
            text = "Each other type";
            x = 0.31;
            y = 0.425;
            w = 0.24;
            h = 0.03;
            sizeEx = 0.024;
        };
        class LRestock: RscText {
            idc = -1;
            text = "Regenerates";
            x = 0.31;
            y = 0.48;
            w = 0.24;
            h = 0.03;
            sizeEx = 0.024;
        };
        class LHours: RscText {
            idc = -1;
            text = "Regen interval: hours";
            x = 0.31;
            y = 0.535;
            w = 0.28;
            h = 0.03;
            sizeEx = 0.024;
        };
        class LMins: RscText {
            idc = -1;
            text = "Regen interval: minutes";
            x = 0.31;
            y = 0.59;
            w = 0.28;
            h = 0.03;
            sizeEx = 0.024;
        };
    };
    class controls {
        class SOPos: RscXSliderH {
            idc = 87601;
            x = 0.31;
            y = 0.34;
            w = 0.3;
            h = 0.028;
            onSliderPosChanged = "((uiNamespace getVariable 'ACME_bf_dlg') displayCtrl 87611) ctrlSetText str (round (_this select 1));";
        };
        class VOPos: RscText {
            idc = 87611;
            text = "6";
            x = 0.62;
            y = 0.315;
            w = 0.07;
            h = 0.03;
            sizeEx = 0.026;
            colorText[] = {0.85, 0.95, 1, 1};
        };
        class SONeg: RscXSliderH {
            idc = 87602;
            x = 0.31;
            y = 0.395;
            w = 0.3;
            h = 0.028;
            onSliderPosChanged = "((uiNamespace getVariable 'ACME_bf_dlg') displayCtrl 87612) ctrlSetText str (round (_this select 1));";
        };
        class VONeg: RscText {
            idc = 87612;
            text = "2";
            x = 0.62;
            y = 0.37;
            w = 0.07;
            h = 0.03;
            sizeEx = 0.026;
            colorText[] = {0.85, 0.95, 1, 1};
        };
        class SOther: RscXSliderH {
            idc = 87603;
            x = 0.31;
            y = 0.45;
            w = 0.3;
            h = 0.028;
            onSliderPosChanged = "((uiNamespace getVariable 'ACME_bf_dlg') displayCtrl 87613) ctrlSetText str (round (_this select 1));";
        };
        class VOther: RscText {
            idc = 87613;
            text = "0";
            x = 0.62;
            y = 0.425;
            w = 0.07;
            h = 0.03;
            sizeEx = 0.026;
            colorText[] = {0.85, 0.95, 1, 1};
        };
        class BtnRestock: RscButton {
            idc = 87604;
            text = "Yes";
            x = 0.55;
            y = 0.48;
            w = 0.14;
            h = 0.032;
            colorBackground[] = {0.15, 0.35, 0.15, 1};
            action = "private _c = (uiNamespace getVariable 'ACME_bf_dlg') displayCtrl 87604; private _on = !(_c getVariable ['on', true]); _c setVariable ['on', _on]; _c ctrlSetText (['No','Yes'] select _on); _c ctrlSetBackgroundColor ([[0.35,0.15,0.15,1],[0.15,0.35,0.15,1]] select _on);";
        };
        class SHours: RscXSliderH {
            idc = 87605;
            x = 0.31;
            y = 0.56;
            w = 0.3;
            h = 0.028;
            onSliderPosChanged = "((uiNamespace getVariable 'ACME_bf_dlg') displayCtrl 87615) ctrlSetText str (round (_this select 1));";
        };
        class VHours: RscText {
            idc = 87615;
            text = "24";
            x = 0.62;
            y = 0.535;
            w = 0.07;
            h = 0.03;
            sizeEx = 0.026;
            colorText[] = {0.85, 0.95, 1, 1};
        };
        class SMins: RscXSliderH {
            idc = 87606;
            x = 0.31;
            y = 0.615;
            w = 0.3;
            h = 0.028;
            onSliderPosChanged = "((uiNamespace getVariable 'ACME_bf_dlg') displayCtrl 87616) ctrlSetText str (round (_this select 1));";
        };
        class VMins: RscText {
            idc = 87616;
            text = "0";
            x = 0.62;
            y = 0.59;
            w = 0.07;
            h = 0.03;
            sizeEx = 0.026;
            colorText[] = {0.85, 0.95, 1, 1};
        };
        class BtnApply: RscButton {
            idc = -1;
            text = "Place";
            x = 0.52;
            y = 0.67;
            w = 0.18;
            h = 0.04;
            colorBackground[] = {0.3, 0.12, 0.12, 1};
            action = "call ACME_fnc_bloodFridgeDialogConfirm";
        };
        class BtnCancel: RscButton {
            idc = -1;
            text = "Cancel";
            x = 0.31;
            y = 0.67;
            w = 0.18;
            h = 0.04;
            colorBackground[] = {0.15, 0.15, 0.15, 1};
            action = "closeDialog 2";
        };
    };
};
class ACME_VentValG {
    type = 0;
    idc = -1;
    style = 2;
    shadow = 0;
    x = 0;
    y = 0;
    w = 0.1;
    h = 0.05;
    font = "PuristaMedium";
    sizeEx = 0.03;
    text = "";
    colorText[] = {0.92, 0.92, 0.92, 1};
    colorBackground[] = {0, 0, 0, 0};
};
class ACME_VentPicFill: RscPicture {
    style = 48;
    colorBackground[] = {0, 0, 0, 0};
    colorText[] = {1, 1, 1, 1};
};
class ACME_VentPic: RscPicture {
    style = 2096;
    colorBackground[] = {0, 0, 0, 0};
    colorText[] = {1, 1, 1, 1};
};
class ACME_VentText: RscText {
    shadow = 0;
};
class ACME_VentTextC: RscText {
    shadow = 0;
    style = 2;
};
class ACME_VentTextR: RscText {
    shadow = 0;
    style = 1;
};
class ACME_VentStructuredText: RscStructuredText {
    shadow = 0;
};
class ACME_Ventilator_Dialog {
    idd = 87700;
    movingEnable = 0;
    enableSimulation = 1;
    onLoad = "[_this select 0] call ACME_fnc_minigameInputInstall; uiNamespace setVariable ['ACME_vent_dlg', _this select 0]; [] call ACME_fnc_ventPanelInit;";
    onUnload = "_this call ACME_fnc_ventPanelClose;";
    class controlsBackground {
        class Dim: ACME_VentText {
            idc = 87709;
            x = "safezoneX";
            y = "safezoneY";
            w = "safezoneW";
            h = "safezoneH";
            colorBackground[] = {0, 0, 0, 0.82};
        };
        class Face: RscPicture {
            idc = 87701;
            text = "\acm_extended\ui\vent\ventway_sparrow_robust_ca.paa";
            x = 0.3;
            y = 0.3;
            w = 0.4;
            h = 0.4;
            colorText[] = {1, 1, 1, 1};
        };
        class MenuInlay: RscPicture {
            idc = 87702;
            text = "\acm_extended\ui\vent\ventway_sparrow_robust_menu_startup_inlay.paa";
            x = 0.3;
            y = 0.3;
            w = 0.4;
            h = 0.4;
            colorText[] = {1, 1, 1, 1};
        };
        class KnobRotate: RscPicture {
            idc = 87703;
            text = "\acm_extended\ui\vent\ventway_sparrow_robust_knob_rotate_left_ca.paa";
            x = 0.3;
            y = 0.3;
            w = 0.4;
            h = 0.4;
            colorText[] = {1, 1, 1, 1};
        };
    };
    class controls {
        class ScreenBG: ACME_VentText {
            idc = 87710;
            x = 0.4;
            y = 0.4;
            w = 0.2;
            h = 0.18;
            colorBackground[] = {0.02, 0.03, 0.04, 1};
        };
        class TitleBar: ACME_VentText {
            idc = 87711;
            x = 0.4;
            y = 0.4;
            w = 0.2;
            h = 0.02;
            colorBackground[] = {0.92, 0.92, 0.89, 1};
        };
        class BottomBar: ACME_VentText {
            idc = 87715;
            x = 0.4;
            y = 0.4;
            w = 0.2;
            h = 0.02;
            colorBackground[] = {0.92, 0.92, 0.89, 1};
        };
        class TitleMode: ACME_VentText {
            idc = 87712;
            text = "SIMV  VC  PS";
            x = 0.4;
            y = 0.4;
            w = 0.2;
            h = 0.02;
            colorText[] = {0.05, 0.05, 0.05, 1};
            colorBackground[] = {0, 0, 0, 0};
            style = 0;
            sizeEx = 0.023;
        };
        class TitleBatt: ACME_VentPicFill {
            idc = 87713;
            x = 0.4;
            y = 0.4;
            w = 0.03;
            h = 0.014;
            text = "";
        };
        class TitleBattFill: ACME_VentText {
            idc = 87716;
            x = 0.4;
            y = 0.4;
            w = 0.02;
            h = 0.01;
            colorBackground[] = {0, 0.988, 0.992, 1};
        };
        class TitleAlarmBox: ACME_VentText {
            idc = 87714;
            style = 2;
            x = 0.4;
            y = 0.4;
            w = 0.03;
            h = 0.014;
            colorBackground[] = {0, 0, 0, 0};
        };
        class LblBPM: ACME_VentText {
            idc = 87720;
            text = "BPM";
            x = 0.4;
            y = 0.4;
            w = 0.06;
            h = 0.03;
            colorText[] = {0.9, 0.9, 0.9, 1};
            colorBackground[] = {0, 0, 0, 0};
            sizeEx = 0.028;
        };
        class ValBPM: ACME_VentText {
            idc = 87721;
            text = "12 (11)";
            x = 0.4;
            y = 0.4;
            w = 0.12;
            h = 0.03;
            colorText[] = {1, 1, 1, 1};
            colorBackground[] = {0, 0, 0, 0};
            sizeEx = 0.03;
        };
        class LblMV: ACME_VentText {
            idc = 87722;
            text = "M.V";
            x = 0.4;
            y = 0.4;
            w = 0.06;
            h = 0.03;
            colorText[] = {0.9, 0.9, 0.9, 1};
            colorBackground[] = {0, 0, 0, 0};
            sizeEx = 0.028;
        };
        class ValMV: ACME_VentText {
            idc = 87723;
            text = "07.49";
            x = 0.4;
            y = 0.4;
            w = 0.12;
            h = 0.03;
            colorText[] = {0.56, 0.84, 1, 1};
            colorBackground[] = {0, 0, 0, 0};
            sizeEx = 0.03;
        };
        class LblVT: ACME_VentText {
            idc = 87724;
            text = "VTi";
            x = 0.4;
            y = 0.4;
            w = 0.06;
            h = 0.03;
            colorText[] = {0.9, 0.9, 0.9, 1};
            colorBackground[] = {0, 0, 0, 0};
            sizeEx = 0.028;
        };
        class ValVTBox: ACME_VentText {
            idc = 87725;
            x = 0.4;
            y = 0.4;
            w = 0.12;
            h = 0.03;
            colorBackground[] = {0, 0, 0, 0};
        };
        class ValVT: ACME_VentText {
            idc = 87726;
            text = "0681";
            x = 0.4;
            y = 0.4;
            w = 0.12;
            h = 0.03;
            colorText[] = {1, 1, 1, 1};
            colorBackground[] = {0, 0, 0, 0};
            sizeEx = 0.03;
        };
        class RowParams: ACME_VentText {
            idc = 87727;
            text = "PEEP 5.0        I:E 1:2.0";
            x = 0.4;
            y = 0.4;
            w = 0.2;
            h = 0.025;
            colorText[] = {0.8, 0.8, 0.8, 1};
            colorBackground[] = {0, 0, 0, 0};
            sizeEx = 0.022;
        };
        class RowAutoPeep: ACME_VentText {
            idc = 87767;
            text = "";
            x = 0.4;
            y = 0.4;
            w = 0.1;
            h = 0.03;
            style = 0;
            colorText[] = {0.8, 0.8, 0.8, 1};
            colorBackground[] = {0, 0, 0, 0};
        };
        class RowIE: ACME_VentText {
            idc = 87768;
            text = "";
            x = 0.4;
            y = 0.4;
            w = 0.2;
            h = 0.03;
            style = 0;
            colorText[] = {0.8, 0.8, 0.8, 1};
            colorBackground[] = {0, 0, 0, 0};
        };
        class GaugeFrame: ACME_VentText {
            idc = 87730;
            x = 0.4;
            y = 0.4;
            w = 0.02;
            h = 0.14;
            colorBackground[] = {0.05, 0.06, 0.07, 1};
        };
        class GaugeGreen: ACME_VentText {
            idc = 87731;
            x = 0.4;
            y = 0.4;
            w = 0.02;
            h = 0.05;
            colorBackground[] = {0.23, 0.56, 0.29, 1};
        };
        class GaugeBlue: ACME_VentText {
            idc = 87732;
            x = 0.4;
            y = 0.4;
            w = 0.02;
            h = 0.04;
            colorBackground[] = {0.12, 0.45, 0.75, 1};
        };
        class GaugeLbl50: ACME_VentText {
            idc = 87733;
            x = 0.4;
            y = 0.4;
            w = 0.03;
            h = 0.02;
            colorText[] = {1, 1, 1, 1};
            colorBackground[] = {0, 0, 0, 0};
            style = 1;
            text = "50";
        };
        class GaugeLbl40: GaugeLbl50 {
            idc = 87734;
            text = "40";
        };
        class GaugeLbl30: GaugeLbl50 {
            idc = 87735;
            text = "30";
        };
        class GaugeLbl20: GaugeLbl50 {
            idc = 87736;
            text = "20";
        };
        class GaugeLbl10: GaugeLbl50 {
            idc = 87737;
            text = "10";
        };
        class GaugeLbl0: GaugeLbl50 {
            idc = 87738;
            text = "0";
        };
        class GaugeLbl60: GaugeLbl50 {
            idc = 87769;
            text = "60";
        };
        class GaugeTick50: ACME_VentText {
            idc = 87739;
            x = 0.4;
            y = 0.4;
            w = 0.006;
            h = 0.002;
            colorBackground[] = {1, 1, 1, 1};
        };
        class GaugeTick40: GaugeTick50 {
            idc = 87759;
        };
        class GaugeTick30: GaugeTick50 {
            idc = 87761;
        };
        class GaugeTick20: GaugeTick50 {
            idc = 87762;
        };
        class GaugeTick10: GaugeTick50 {
            idc = 87763;
        };
        class GaugeTick0: GaugeTick50 {
            idc = 87764;
        };
        class GaugeTick60: GaugeTick50 {
            idc = 87774;
        };
        class ACME_VentBtn: RscButton {
            shadow = 0;
            soundEnter[] = {"", 0, 1};
            soundPush[] = {"", 0, 1};
            soundClick[] = {"", 0, 1};
            soundEscape[] = {"", 0, 1};
            colorText[] = {0.92, 0.92, 0.92, 1};
            colorFocused[] = {0, 0, 0, 0};
            colorBackgroundActive[] = {0, 0, 0, 0};
            colorDisabled[] = {0.92, 0.92, 0.92, 1};
            colorBackgroundDisabled[] = {0, 0, 0, 0};
        };
        class BtnAlarm: ACME_VentBtn {
            idc = 87740;
            text = "";
            x = 0.4;
            y = 0.4;
            w = 0.04;
            h = 0.03;
            colorBackground[] = {0, 0, 0, 0};
        };
        class HlAlarm: ACME_VentText {
            idc = 87748;
            text = "";
            x = 0.4;
            y = 0.4;
            w = 0.03;
            h = 0.03;
            colorBackground[] = {0, 0, 0, 0};
        };
        class IcoAlarm: RscPicture {
            idc = 87741;
            text = "\acm_extended\ui\vent\alarm_ca.paa";
            x = 0.4;
            y = 0.4;
            w = 0.03;
            h = 0.03;
            colorText[] = {0.1, 0.1, 0.1, 1};
        };
        class VentStatusBox: ACME_VentText {
            idc = 87766;
            text = "";
            x = 0.4;
            y = 0.4;
            w = 0.03;
            h = 0.03;
            style = 2;
            colorText[] = {1, 1, 1, 1};
            colorBackground[] = {0, 0, 0, 0};
        };
        class TxtAlarmCount: ACME_VentText {
            idc = 87765;
            text = "(0)";
            x = 0.4;
            y = 0.4;
            w = 0.04;
            h = 0.03;
            style = 0;
            colorText[] = {0.1, 0.1, 0.1, 1};
            colorBackground[] = {0, 0, 0, 0};
        };
        class BtnGraph: ACME_VentBtn {
            idc = 87742;
            text = "";
            x = 0.4;
            y = 0.4;
            w = 0.04;
            h = 0.03;
            colorBackground[] = {0, 0, 0, 0};
            colorFocused[] = {0, 0, 0, 0};
        };
        class HlGraph: ACME_VentText {
            idc = 87749;
            text = "";
            x = 0.4;
            y = 0.4;
            w = 0.03;
            h = 0.03;
            colorBackground[] = {0, 0, 0, 0};
        };
        class IcoGraph: RscPicture {
            idc = 87743;
            text = "\acm_extended\ui\vent\graphs_ca.paa";
            x = 0.4;
            y = 0.4;
            w = 0.03;
            h = 0.03;
            colorText[] = {0.1, 0.1, 0.1, 1};
        };
        class BtnBreath: ACME_VentBtn {
            idc = 87744;
            text = "";
            x = 0.4;
            y = 0.4;
            w = 0.04;
            h = 0.03;
            colorBackground[] = {0, 0, 0, 0};
            colorFocused[] = {0, 0, 0, 0};
        };
        class HlBreath: ACME_VentText {
            idc = 87752;
            text = "";
            x = 0.4;
            y = 0.4;
            w = 0.03;
            h = 0.03;
            colorBackground[] = {0, 0, 0, 0};
        };
        class IcoBreath: RscPicture {
            idc = 87745;
            text = "\acm_extended\ui\vent\manual_breath_ca.paa";
            x = 0.4;
            y = 0.4;
            w = 0.03;
            h = 0.03;
            colorText[] = {0.1, 0.1, 0.1, 1};
        };
        class BtnMenu: ACME_VentBtn {
            idc = 87746;
            text = "";
            x = 0.4;
            y = 0.4;
            w = 0.04;
            h = 0.03;
            colorBackground[] = {0, 0, 0, 0};
            colorFocused[] = {0, 0, 0, 0};
        };
        class HlMenu: ACME_VentText {
            idc = 87753;
            text = "";
            x = 0.4;
            y = 0.4;
            w = 0.03;
            h = 0.03;
            colorBackground[] = {0, 0, 0, 0};
        };
        class IcoMenu: RscPicture {
            idc = 87747;
            text = "\acm_extended\ui\vent\main_menu_ca.paa";
            x = 0.4;
            y = 0.4;
            w = 0.03;
            h = 0.03;
            colorText[] = {0.1, 0.1, 0.1, 1};
        };
        class HitBPM: ACME_VentBtn {
            idc = 87750;
            text = "";
            x = 0.4;
            y = 0.4;
            w = 0.18;
            h = 0.03;
            colorBackground[] = {0, 0, 0, 0};
            colorFocused[] = {0, 0, 0, 0};
        };
        class HitVT: ACME_VentBtn {
            idc = 87751;
            text = "";
            x = 0.4;
            y = 0.4;
            w = 0.18;
            h = 0.03;
            colorBackground[] = {0, 0, 0, 0};
            colorFocused[] = {0, 0, 0, 0};
        };
        class BootLogo: RscPictureKeepAspect {
            idc = 87760;
            text = "\acm_extended\ui\vent\sparrow_startup_icon_ca.paa";
            x = 0.4;
            y = 0.4;
            w = 0.1;
            h = 0.1;
            colorText[] = {1, 1, 1, 1};
        };
        class HintScrollIco: RscPictureKeepAspect {
            idc = 87770;
            text = "\z\ace\addons\interaction\UI\mouse_scroll_ca.paa";
            x = 0.4;
            y = 0.4;
            w = 0.03;
            h = 0.03;
            colorText[] = {1, 1, 1, 0.9};
        };
        class HintScrollTxt: ACME_VentText {
            idc = 87771;
            text = "Scroll: Move Selection";
            x = 0.4;
            y = 0.4;
            w = 0.2;
            h = 0.03;
            colorText[] = {0.9, 0.9, 0.9, 1};
            colorBackground[] = {0, 0, 0, 0};
            sizeEx = 0.03;
        };
        class HintSelIco: RscPictureKeepAspect {
            idc = 87772;
            text = "\z\ace\addons\interaction\UI\mouse_scroll_ca.paa";
            x = 0.4;
            y = 0.4;
            w = 0.03;
            h = 0.03;
            colorText[] = {1, 1, 1, 0.9};
        };
        class HintSelTxt: ACME_VentText {
            idc = 87773;
            text = "Middle Click: Select";
            x = 0.4;
            y = 0.4;
            w = 0.2;
            h = 0.03;
            colorText[] = {0.9, 0.9, 0.9, 1};
            colorBackground[] = {0, 0, 0, 0};
            sizeEx = 0.03;
        };
        class HintFlipIco: ACME_VentTextC {
            idc = 87776;
            text = "F";
            x = 0.4;
            y = 0.4;
            w = 0.03;
            h = 0.03;
            colorText[] = {0.95, 0.97, 1, 1};
            colorBackground[] = {1, 1, 1, 0.14};
            sizeEx = 0.026;
        };
        class HintFlipTxt: ACME_VentText {
            idc = 87777;
            text = "Flip Device";
            x = 0.4;
            y = 0.4;
            w = 0.2;
            h = 0.03;
            colorText[] = {0.9, 0.9, 0.9, 1};
            colorBackground[] = {0, 0, 0, 0};
            sizeEx = 0.03;
        };
        class RevBattery: ACME_VentBtn {
            idc = 87778;
            text = "";
            x = 0.4;
            y = 0.4;
            w = 0.1;
            h = 0.05;
            borderSize = 0;
            colorBackground[] = {0, 0, 0, 0};
            colorBackgroundActive[] = {0, 0, 0, 0};
            colorBackgroundDisabled[] = {0, 0, 0, 0};
            colorFocused[] = {0, 0, 0, 0};
            colorBorder[] = {0, 0, 0, 0};
            colorShadow[] = {0, 0, 0, 0};
            colorText[] = {0, 0, 0, 0};
            colorDisabled[] = {0, 0, 0, 0};
        };
        class RevPower: RevBattery {
            idc = 87779;
            w = 0.05;
        };
        class RevTip: ACME_VentTextC {
            idc = 88000;
            text = "";
            x = 0.4;
            y = 0.4;
            w = 0.2;
            h = 0.03;
            colorText[] = {0.95, 0.97, 1, 1};
            colorBackground[] = {0, 0, 0, 0.72};
            sizeEx = 0.03;
        };
        class RevBanner: ACME_VentTextC {
            idc = 88001;
            text = "";
            x = 0.4;
            y = 0.4;
            w = 0.3;
            h = 0.04;
            colorText[] = {0, 0.988, 0.992, 1};
            colorBackground[] = {0, 0, 0, 0.78};
            sizeEx = 0.036;
        };
        class ListTitle: ACME_VentText {
            idc = 87780;
            text = "";
            x = 0.4;
            y = 0.4;
            w = 0.2;
            h = 0.02;
            colorText[] = {0.05, 0.05, 0.05, 1};
            colorBackground[] = {0, 0, 0, 0};
            style = 0;
            sizeEx = 0.023;
        };
        class ListRow0: ACME_VentBtn {
            idc = 87781;
            style = 2;
            text = "";
            x = 0.4;
            y = 0.4;
            w = 0.2;
            h = 0.03;
            colorBackground[] = {0, 0, 0, 0};
            colorText[] = {0.92, 0.92, 0.92, 1};
            colorFocused[] = {0, 0, 0, 0};
            colorBackgroundDisabled[] = {0, 0, 0, 0};
            colorDisabled[] = {0.92, 0.92, 0.92, 1};
        };
        class ListRow1: ACME_VentBtn {
            idc = 87782;
            style = 2;
            text = "";
            x = 0.4;
            y = 0.4;
            w = 0.2;
            h = 0.03;
            colorBackground[] = {0, 0, 0, 0};
            colorText[] = {0.92, 0.92, 0.92, 1};
            colorFocused[] = {0, 0, 0, 0};
            colorBackgroundDisabled[] = {0, 0, 0, 0};
            colorDisabled[] = {0.92, 0.92, 0.92, 1};
        };
        class ListRow2: ACME_VentBtn {
            idc = 87783;
            style = 2;
            text = "";
            x = 0.4;
            y = 0.4;
            w = 0.2;
            h = 0.03;
            colorBackground[] = {0, 0, 0, 0};
            colorText[] = {0.92, 0.92, 0.92, 1};
            colorFocused[] = {0, 0, 0, 0};
            colorBackgroundDisabled[] = {0, 0, 0, 0};
            colorDisabled[] = {0.92, 0.92, 0.92, 1};
        };
        class ListRow3: ACME_VentBtn {
            idc = 87784;
            style = 2;
            text = "";
            x = 0.4;
            y = 0.4;
            w = 0.2;
            h = 0.03;
            colorBackground[] = {0, 0, 0, 0};
            colorText[] = {0.92, 0.92, 0.92, 1};
            colorFocused[] = {0, 0, 0, 0};
            colorBackgroundDisabled[] = {0, 0, 0, 0};
            colorDisabled[] = {0.92, 0.92, 0.92, 1};
        };
        class ListRow4: ACME_VentBtn {
            idc = 87785;
            style = 2;
            text = "";
            x = 0.4;
            y = 0.4;
            w = 0.2;
            h = 0.03;
            colorBackground[] = {0, 0, 0, 0};
            colorText[] = {0.92, 0.92, 0.92, 1};
            colorFocused[] = {0, 0, 0, 0};
            colorBackgroundDisabled[] = {0, 0, 0, 0};
            colorDisabled[] = {0.92, 0.92, 0.92, 1};
        };
        class ListRow5: ACME_VentBtn {
            idc = 87786;
            style = 2;
            text = "";
            x = 0.4;
            y = 0.4;
            w = 0.2;
            h = 0.03;
            colorBackground[] = {0, 0, 0, 0};
            colorText[] = {0.92, 0.92, 0.92, 1};
            colorFocused[] = {0, 0, 0, 0};
            colorBackgroundDisabled[] = {0, 0, 0, 0};
            colorDisabled[] = {0.92, 0.92, 0.92, 1};
        };
        class ListPrompt: ACME_VentStructuredText {
            idc = 87787;
            text = "";
            x = 0.4;
            y = 0.4;
            w = 0.2;
            h = 0.06;
            size = 0.022;
            class Attributes {
                align = "center";
                color = "#EAEAEA";
            };
        };
        class HlNavConfirm: ACME_VentText {
            idc = 87754;
            text = "";
            x = 0.4;
            y = 0.4;
            w = 0.03;
            h = 0.03;
            colorBackground[] = {0, 0, 0, 0};
        };
        class NavConfirm: ACME_VentBtn {
            idc = 87790;
            text = "";
            x = 0.4;
            y = 0.4;
            w = 0.04;
            h = 0.03;
            colorBackground[] = {0, 0, 0, 0};
            colorFocused[] = {0, 0, 0, 0};
            action = "";
        };
        class IcoNavConfirm: RscPicture {
            idc = 87791;
            text = "\acm_extended\ui\vent\confirm_ca.paa";
            x = 0.4;
            y = 0.4;
            w = 0.03;
            h = 0.03;
            colorText[] = {0.1, 0.1, 0.1, 1};
        };
        class HlNavHome: ACME_VentText {
            idc = 87755;
            text = "";
            x = 0.4;
            y = 0.4;
            w = 0.03;
            h = 0.03;
            colorBackground[] = {0, 0, 0, 0};
        };
        class NavHome: ACME_VentBtn {
            idc = 87792;
            text = "";
            x = 0.4;
            y = 0.4;
            w = 0.04;
            h = 0.03;
            colorBackground[] = {0, 0, 0, 0};
            colorFocused[] = {0, 0, 0, 0};
            action = "";
        };
        class IcoNavHome: RscPicture {
            idc = 87793;
            text = "\acm_extended\ui\vent\home_ca.paa";
            x = 0.4;
            y = 0.4;
            w = 0.03;
            h = 0.03;
            colorText[] = {0.1, 0.1, 0.1, 1};
        };
        class HlNavBack: ACME_VentText {
            idc = 87756;
            text = "";
            x = 0.4;
            y = 0.4;
            w = 0.03;
            h = 0.03;
            colorBackground[] = {0, 0, 0, 0};
        };
        class NavBack: ACME_VentBtn {
            idc = 87794;
            text = "";
            x = 0.4;
            y = 0.4;
            w = 0.04;
            h = 0.03;
            colorBackground[] = {0, 0, 0, 0};
            colorFocused[] = {0, 0, 0, 0};
            action = "";
        };
        class IcoNavBack: RscPicture {
            idc = 87795;
            text = "\acm_extended\ui\vent\back_ca.paa";
            x = 0.4;
            y = 0.4;
            w = 0.03;
            h = 0.03;
            colorText[] = {0.1, 0.1, 0.1, 1};
        };
        class HlNavNext: ACME_VentText {
            idc = 87757;
            text = "";
            x = 0.4;
            y = 0.4;
            w = 0.03;
            h = 0.03;
            colorBackground[] = {0, 0, 0, 0};
        };
        class NavNext: ACME_VentBtn {
            idc = 87796;
            text = "";
            x = 0.4;
            y = 0.4;
            w = 0.04;
            h = 0.03;
            colorBackground[] = {0, 0, 0, 0};
            colorFocused[] = {0, 0, 0, 0};
            action = "";
        };
        class IcoNavNext: RscPicture {
            idc = 87797;
            text = "\acm_extended\ui\vent\next_screen_ca.paa";
            x = 0.4;
            y = 0.4;
            w = 0.03;
            h = 0.03;
            colorText[] = {0.1, 0.1, 0.1, 1};
        };
        class GraphTitle: ACME_VentText {
            idc = 87800;
            text = "PRESSURE";
            x = 0.4;
            y = 0.4;
            w = 0.2;
            h = 0.02;
            colorText[] = {0.05, 0.05, 0.05, 1};
            colorBackground[] = {0, 0, 0, 0};
            style = 0;
            sizeEx = 0.02;
        };
        class GraphField: ACME_VentText {
            idc = 87801;
            x = 0.4;
            y = 0.4;
            w = 0.2;
            h = 0.1;
            colorBackground[] = {0.02, 0.03, 0.05, 1};
        };
        class GraphAxis: ACME_VentText {
            idc = 87802;
            x = 0.4;
            y = 0.4;
            w = 0.2;
            h = 0.001;
            colorBackground[] = {0.35, 0.38, 0.42, 1};
        };
        class BtnClose: RscButton {
            shadow = 0;
            idc = 87775;
            text = "Close";
            x = "safezoneX + safezoneW - 0.12";
            y = "safezoneY + 0.02";
            w = 0.1;
            h = 0.035;
            colorBackground[] = {0.15, 0.15, 0.15, 0.9};
            colorBackgroundActive[] = {0.15, 0.15, 0.15, 0.9};
            colorFocused[] = {0.15, 0.15, 0.15, 0.9};
            soundEnter[] = {"", 0, 1};
            soundPush[] = {"", 0, 1};
            soundClick[] = {"", 0, 1};
            soundEscape[] = {"", 0, 1};
            action = "closeDialog 0";
        };
    };
};
class ACME_Laryngoscopy_Dialog {
    idd = 87800;
    movingEnable = 0;
    onLoad = "[_this select 0] call ACME_fnc_minigameInputInstall; _this call ACME_fnc_laryngoInit";
    onUnload = "[] call ACME_fnc_laryngoClose";
    class ControlsBackground {
        class LG_Dim: RscText {
            idc = -1;
            x = "safezoneX";
            y = "safezoneY";
            w = "safezoneW";
            h = "safezoneH";
            colorBackground[] = {0, 0, 0, 0.72};
        };
        class LG_Pharynx: RscPictureKeepAspect {
            idc = 87803;
            x = 0.35;
            y = 0.1;
            w = 0.3;
            h = 0.6;
            text = "\acm_extended\ui\laryngo\cl1_pharynx.paa";
            colorText[] = {1, 1, 1, 1};
        };
        class LG_Larynx: RscPictureKeepAspect {
            idc = 87804;
            x = 0.35;
            y = 0.1;
            w = 0.3;
            h = 0.6;
            text = "\acm_extended\ui\laryngo\cl1_larynx.paa";
            colorText[] = {1, 1, 1, 1};
        };
        class LG_Palate: RscPictureKeepAspect {
            idc = 87805;
            x = 0.35;
            y = 0.1;
            w = 0.3;
            h = 0.6;
            text = "\acm_extended\ui\laryngo\sh_palate.paa";
            colorText[] = {1, 1, 1, 1};
        };
        class LG_Cavity: RscPictureKeepAspect {
            idc = 87806;
            x = 0.35;
            y = 0.1;
            w = 0.3;
            h = 0.6;
            text = "\acm_extended\ui\laryngo\sh_cavity.paa";
            colorText[] = {1, 1, 1, 1};
        };
        class LG_Teeth: RscPictureKeepAspect {
            idc = 87807;
            x = 0.35;
            y = 0.1;
            w = 0.3;
            h = 0.6;
            text = "\acm_extended\ui\laryngo\sh_teeth.paa";
            colorText[] = {1, 1, 1, 1};
        };
        class LG_TeethBroken: RscPictureKeepAspect {
            idc = 87878;
            x = 0.35;
            y = 0.1;
            w = 0.3;
            h = 0.6;
            text = "\acm_extended\ui\laryngo\sh_teeth_fractured.paa";
            colorText[] = {1, 1, 1, 0};
        };
        class LG_Lips: RscPictureKeepAspect {
            idc = 87808;
            x = 0.35;
            y = 0.1;
            w = 0.3;
            h = 0.6;
            text = "\acm_extended\ui\laryngo\sh_lips.paa";
            colorText[] = {1, 1, 1, 1};
        };
        class LG_Tube1: RscPictureKeepAspect {
            idc = 87900;
            x = 0.35;
            y = 0.1;
            w = 0.3;
            h = 0.6;
            text = "\acm_extended\ui\laryngo\ett_f1.paa";
            colorText[] = {1, 1, 1, 0};
        };
        class LG_Tube2: RscPictureKeepAspect {
            idc = 87901;
            x = 0.35;
            y = 0.1;
            w = 0.3;
            h = 0.6;
            text = "\acm_extended\ui\laryngo\ett_f2.paa";
            colorText[] = {1, 1, 1, 0};
        };
        class LG_Tube3: RscPictureKeepAspect {
            idc = 87902;
            x = 0.35;
            y = 0.1;
            w = 0.3;
            h = 0.6;
            text = "\acm_extended\ui\laryngo\ett_f3.paa";
            colorText[] = {1, 1, 1, 0};
        };
        class LG_Tube4: RscPictureKeepAspect {
            idc = 87903;
            x = 0.35;
            y = 0.1;
            w = 0.3;
            h = 0.6;
            text = "\acm_extended\ui\laryngo\ett_f4.paa";
            colorText[] = {1, 1, 1, 0};
        };
        class LG_Tube5: RscPictureKeepAspect {
            idc = 87904;
            x = 0.35;
            y = 0.1;
            w = 0.3;
            h = 0.6;
            text = "\acm_extended\ui\laryngo\ett_f5.paa";
            colorText[] = {1, 1, 1, 0};
        };
        class LG_Tube6: RscPictureKeepAspect {
            idc = 87905;
            x = 0.35;
            y = 0.1;
            w = 0.3;
            h = 0.6;
            text = "\acm_extended\ui\laryngo\ett_f6.paa";
            colorText[] = {1, 1, 1, 0};
        };
        class LG_Tube7: RscPictureKeepAspect {
            idc = 87906;
            x = 0.35;
            y = 0.1;
            w = 0.3;
            h = 0.6;
            text = "\acm_extended\ui\laryngo\ett_f7.paa";
            colorText[] = {1, 1, 1, 0};
        };
        class LG_Tube8: RscPictureKeepAspect {
            idc = 87907;
            x = 0.35;
            y = 0.1;
            w = 0.3;
            h = 0.6;
            text = "\acm_extended\ui\laryngo\ett_f8.paa";
            colorText[] = {1, 1, 1, 0};
        };
        class LG_TubeBlocked: RscPictureKeepAspect {
            idc = 87908;
            x = 0.35;
            y = 0.1;
            w = 0.3;
            h = 0.6;
            text = "\acm_extended\ui\laryngo\ett_blocked.paa";
            colorText[] = {1, 1, 1, 0};
        };
        class LG_FrameA: RscPictureKeepAspect {
            idc = 87801;
            x = 0.35;
            y = 0.1;
            w = 0.3;
            h = 0.6;
            text = "\acm_extended\ui\laryngo\tongue_mp1_1.paa";
            colorText[] = {1, 1, 1, 1};
        };
        class LG_Frame2: RscPictureKeepAspect {
            idc = 87851;
            x = 0.35;
            y = 0.1;
            w = 0.3;
            h = 0.6;
            text = "\acm_extended\ui\laryngo\tongue_mp1_1.paa";
            colorText[] = {1, 1, 1, 0};
        };
        class LG_Frame3: RscPictureKeepAspect {
            idc = 87852;
            x = 0.35;
            y = 0.1;
            w = 0.3;
            h = 0.6;
            text = "\acm_extended\ui\laryngo\tongue_mp1_2.paa";
            colorText[] = {1, 1, 1, 0};
        };
        class LG_Frame4: RscPictureKeepAspect {
            idc = 87853;
            x = 0.35;
            y = 0.1;
            w = 0.3;
            h = 0.6;
            text = "\acm_extended\ui\laryngo\tongue_mp1_3.paa";
            colorText[] = {1, 1, 1, 0};
        };
        class LG_Fluid: RscPictureKeepAspect {
            idc = 87915;
            x = 0.35;
            y = 0.1;
            w = 0.3;
            h = 0.6;
            text = "";
            colorText[] = {1, 1, 1, 0};
        };
        class LG_Blade: RscPictureKeepAspect {
            idc = 87802;
            x = 0.35;
            y = 0.1;
            w = 0.3;
            h = 0.6;
            text = "\acm_extended\ui\laryngo\blade_master.paa";
            colorText[] = {1, 1, 1, 0};
        };
        class LG_BladeFulc1: RscPictureKeepAspect {
            idc = 87811;
            x = 0.35;
            y = 0.1;
            w = 0.3;
            h = 0.6;
            text = "\acm_extended\ui\laryngo\blade_fulc_1.paa";
            colorText[] = {1, 1, 1, 0};
        };
        class LG_BladeFulc2: RscPictureKeepAspect {
            idc = 87812;
            x = 0.35;
            y = 0.1;
            w = 0.3;
            h = 0.6;
            text = "\acm_extended\ui\laryngo\blade_fulc_2.paa";
            colorText[] = {1, 1, 1, 0};
        };
        class LG_BladeFulc3: RscPictureKeepAspect {
            idc = 87911;
            x = 0.35;
            y = 0.1;
            w = 0.3;
            h = 0.6;
            text = "\acm_extended\ui\laryngo\blade_fulc_3.paa";
            colorText[] = {1, 1, 1, 0};
        };
        class LG_BladeFulc4: RscPictureKeepAspect {
            idc = 87912;
            x = 0.35;
            y = 0.1;
            w = 0.3;
            h = 0.6;
            text = "\acm_extended\ui\laryngo\blade_fulc_4.paa";
            colorText[] = {1, 1, 1, 0};
        };
        class LG_BladeFulc5: RscPictureKeepAspect {
            idc = 87913;
            x = 0.35;
            y = 0.1;
            w = 0.3;
            h = 0.6;
            text = "\acm_extended\ui\laryngo\blade_fulc_5.paa";
            colorText[] = {1, 1, 1, 0};
        };
        class LG_Light: RscPictureKeepAspect {
            idc = 87809;
            x = 0.35;
            y = 0.1;
            w = 0.3;
            h = 0.6;
            text = "";
            colorText[] = {1, 1, 1, 0};
        };
        class LG_Collar: RscPictureKeepAspect {
            idc = 87909;
            x = 0.35;
            y = 0.1;
            w = 0.3;
            h = 0.6;
            text = "\acm_extended\ui\laryngo\ett_secured_f1.paa";
            colorText[] = {1, 1, 1, 0};
        };
        class LG_CollarSet: RscPictureKeepAspect {
            idc = 87910;
            x = 0.35;
            y = 0.1;
            w = 0.3;
            h = 0.6;
            text = "\acm_extended\ui\laryngo\ett_secured_f2.paa";
            colorText[] = {1, 1, 1, 0};
        };
        class LG_Syringe: RscPicture {
            idc = 87814;
            x = 0.35;
            y = 0.1;
            w = 0.3;
            h = 0.3;
            text = "\x\ACM\addons\circulation\ui\syringe\syringe_10_backbit_ca.paa";
            colorText[] = {1, 1, 1, 0};
        };
        class LG_SyringePlunger: LG_Syringe {
            idc = 87817;
            text = "\x\ACM\addons\circulation\ui\syringe\syringe_10_plunger_ca.paa";
        };
        class LG_SyringeBarrel: LG_Syringe {
            idc = 87818;
            text = "\acm_extended\ui\syringe\syringe_flush_10_barrel_ca.paa";
        };
        class LG_Suction: RscPictureKeepAspect {
            idc = 87916;
            x = 0.4;
            y = 0.05;
            w = 0.2;
            h = 0.8;
            text = "\acm_extended\ui\laryngo\suction\yank_master.paa";
            colorText[] = {1, 1, 1, 0};
        };
    };
    class Controls {
        class LG_Title: RscText {
            idc = -1;
            style = 2;
            x = "safezoneX";
            y = "safezoneY + safezoneH * 0.035";
            w = "safezoneW";
            h = "safezoneH * 0.05";
            text = "";
            colorText[] = {0.93, 0.89, 0.8, 1};
            colorBackground[] = {0, 0, 0, 0};
            sizeEx = "0.042 * safezoneH";
        };
        class LG_Instruction: RscText {
            idc = 87810;
            style = 2;
            x = "safezoneX";
            y = "safezoneY + safezoneH * 0.09";
            w = "safezoneW";
            h = "safezoneH * 0.04";
            text = "";
            colorText[] = {0.82, 0.82, 0.82, 1};
            colorBackground[] = {0, 0, 0, 0};
            sizeEx = "0.026 * safezoneH";
        };
        class LG_Success: RscText {
            idc = 87816;
            style = 2;
            x = "safezoneX";
            y = "safezoneY + safezoneH * 0.42";
            w = "safezoneW";
            h = "safezoneH * 0.09";
            text = "";
            colorText[] = {0.55, 0.92, 0.6, 1};
            colorBackground[] = {0, 0, 0, 0};
            sizeEx = "0.055 * safezoneH";
        };
        class LG_Surface: RscControlsGroupNoScrollbars {
            idc = 87830;
            x = 0.35;
            y = 0.1;
            w = 0.3;
            h = 0.6;
            colorBackground[] = {0, 0, 0, 0};
            class Controls {};
        };
        class LG_ScopeBG: RscText {
            idc = 87860;
            x = "safezoneX + safezoneW * 0.82";
            y = "safezoneY + safezoneH * 0.30";
            w = "safezoneW * 0.08";
            h = "safezoneH * 0.16";
            colorBackground[] = {0, 0, 0, 0.85};
        };
        class LG_ScopeLogo: RscPictureKeepAspect {
            idc = 87861;
            x = "safezoneX + safezoneW * 0.826";
            y = "safezoneY + safezoneH * 0.31";
            w = "safezoneW * 0.068";
            h = "safezoneH * 0.12";
            text = "\acm_extended\ui\vent\laryngoscope_ca.paa";
        };
        class LG_ScopeCount: RscText {
            idc = 87862;
            x = "safezoneX + safezoneW * 0.82";
            y = "safezoneY + safezoneH * 0.445";
            w = "safezoneW * 0.08";
            h = "safezoneH * 0.03";
            style = 2;
            text = "";
            colorText[] = {0.93, 0.89, 0.8, 1};
            colorBackground[] = {0, 0, 0, 0};
            sizeEx = "0.022 * safezoneH";
        };
        class LG_ScopeClick: RscButton {
            idc = 87863;
            x = "safezoneX + safezoneW * 0.82";
            y = "safezoneY + safezoneH * 0.30";
            w = "safezoneW * 0.08";
            h = "safezoneH * 0.16";
            text = "";
            tooltip = "Pick up / return laryngoscope";
            onButtonClick = "['scope'] call ACME_fnc_laryngoGrab";
            colorText[] = {0, 0, 0, 0};
            colorDisabled[] = {0, 0, 0, 0};
            colorBackground[] = {0, 0, 0, 0};
            colorBackgroundDisabled[] = {0, 0, 0, 0};
            colorBackgroundActive[] = {1, 1, 1, 0.04};
            colorFocused[] = {0, 0, 0, 0};
            colorShadow[] = {0, 0, 0, 0};
            colorBorder[] = {0, 0, 0, 0};
            borderSize = 0;
        };
        class LG_TubeBG: RscText {
            idc = 87864;
            x = "safezoneX + safezoneW * 0.82";
            y = "safezoneY + safezoneH * 0.50";
            w = "safezoneW * 0.08";
            h = "safezoneH * 0.16";
            colorBackground[] = {0, 0, 0, 0.85};
        };
        class LG_TubeLogo: RscPictureKeepAspect {
            idc = 87865;
            x = "safezoneX + safezoneW * 0.826";
            y = "safezoneY + safezoneH * 0.51";
            w = "safezoneW * 0.068";
            h = "safezoneH * 0.12";
            text = "\acm_extended\ui\vent\et_tube_ca.paa";
        };
        class LG_TubeCount: RscText {
            idc = 87866;
            x = "safezoneX + safezoneW * 0.82";
            y = "safezoneY + safezoneH * 0.645";
            w = "safezoneW * 0.08";
            h = "safezoneH * 0.03";
            style = 2;
            text = "";
            colorText[] = {0.93, 0.89, 0.8, 1};
            colorBackground[] = {0, 0, 0, 0};
            sizeEx = "0.022 * safezoneH";
        };
        class LG_TubeClick: RscButton {
            idc = 87867;
            x = "safezoneX + safezoneW * 0.82";
            y = "safezoneY + safezoneH * 0.50";
            w = "safezoneW * 0.08";
            h = "safezoneH * 0.16";
            text = "";
            tooltip = "Pick up / return ET tube";
            onButtonClick = "['tube'] call ACME_fnc_laryngoGrab";
            colorText[] = {0, 0, 0, 0};
            colorDisabled[] = {0, 0, 0, 0};
            colorBackground[] = {0, 0, 0, 0};
            colorBackgroundDisabled[] = {0, 0, 0, 0};
            colorBackgroundActive[] = {1, 1, 1, 0.04};
            colorFocused[] = {0, 0, 0, 0};
            colorShadow[] = {0, 0, 0, 0};
            colorBorder[] = {0, 0, 0, 0};
            borderSize = 0;
        };
        class LG_SyrBG: RscText {
            idc = 87870;
            x = "safezoneX + safezoneW * 0.82";
            y = "safezoneY + safezoneH * 0.70";
            w = "safezoneW * 0.08";
            h = "safezoneH * 0.16";
            colorBackground[] = {0, 0, 0, 0.85};
        };
        class LG_SyrLogo: RscPictureKeepAspect {
            idc = 87871;
            x = "safezoneX + safezoneW * 0.826";
            y = "safezoneY + safezoneH * 0.71";
            w = "safezoneW * 0.068";
            h = "safezoneH * 0.12";
            text = "\acm_extended\ui\laryngo\active_syringe.paa";
        };
        class LG_SyrCount: RscText {
            idc = 87872;
            x = "safezoneX + safezoneW * 0.82";
            y = "safezoneY + safezoneH * 0.845";
            w = "safezoneW * 0.08";
            h = "safezoneH * 0.03";
            style = 2;
            text = "";
            colorText[] = {0.93, 0.89, 0.8, 1};
            colorBackground[] = {0, 0, 0, 0};
            sizeEx = "0.022 * safezoneH";
        };
        class LG_SyrClick: RscButton {
            idc = 87873;
            x = "safezoneX + safezoneW * 0.82";
            y = "safezoneY + safezoneH * 0.70";
            w = "safezoneW * 0.08";
            h = "safezoneH * 0.16";
            text = "";
            tooltip = "Pick up / return cuff syringe";
            onButtonClick = "['syringe'] call ACME_fnc_laryngoGrab";
            colorText[] = {0, 0, 0, 0};
            colorDisabled[] = {0, 0, 0, 0};
            colorBackground[] = {0, 0, 0, 0};
            colorBackgroundDisabled[] = {0, 0, 0, 0};
            colorBackgroundActive[] = {1, 1, 1, 0.04};
            colorFocused[] = {0, 0, 0, 0};
            colorShadow[] = {0, 0, 0, 0};
            colorBorder[] = {0, 0, 0, 0};
            borderSize = 0;
        };
        class LG_ColBG: RscText {
            idc = 87874;
            x = "safezoneX + safezoneW * 0.82";
            y = "safezoneY + safezoneH * 0.86";
            w = "safezoneW * 0.08";
            h = "safezoneH * 0.16";
            colorBackground[] = {0, 0, 0, 0.85};
        };
        class LG_ColLogo: RscPictureKeepAspect {
            idc = 87875;
            x = "safezoneX + safezoneW * 0.826";
            y = "safezoneY + safezoneH * 0.87";
            w = "safezoneW * 0.068";
            h = "safezoneH * 0.12";
            text = "\acm_extended\ui\laryngo\ett_secured_f2.paa";
        };
        class LG_ColCount: RscText {
            idc = 87876;
            x = "safezoneX + safezoneW * 0.82";
            y = "safezoneY + safezoneH * 0.99";
            w = "safezoneW * 0.08";
            h = "safezoneH * 0.03";
            style = 2;
            text = "";
            colorText[] = {0.93, 0.89, 0.8, 1};
            colorBackground[] = {0, 0, 0, 0};
            sizeEx = "0.022 * safezoneH";
        };
        class LG_ColClick: RscButton {
            idc = 87877;
            x = "safezoneX + safezoneW * 0.82";
            y = "safezoneY + safezoneH * 0.86";
            w = "safezoneW * 0.08";
            h = "safezoneH * 0.16";
            text = "";
            tooltip = "Pick up / return securing collar";
            onButtonClick = "['collar'] call ACME_fnc_laryngoGrab";
            colorText[] = {0, 0, 0, 0};
            colorDisabled[] = {0, 0, 0, 0};
            colorBackground[] = {0, 0, 0, 0};
            colorBackgroundDisabled[] = {0, 0, 0, 0};
            colorBackgroundActive[] = {1, 1, 1, 0.04};
            colorFocused[] = {0, 0, 0, 0};
            colorShadow[] = {0, 0, 0, 0};
            colorBorder[] = {0, 0, 0, 0};
            borderSize = 0;
        };
        class LG_SucBG: RscText {
            idc = 87880;
            x = "safezoneX + safezoneW * 0.82";
            y = "safezoneY + safezoneH * 0.86";
            w = "safezoneW * 0.08";
            h = "safezoneH * 0.16";
            colorBackground[] = {0, 0, 0, 0.85};
        };
        class LG_SucLogo: RscPictureKeepAspect {
            idc = 87881;
            x = "safezoneX + safezoneW * 0.826";
            y = "safezoneY + safezoneH * 0.87";
            w = "safezoneW * 0.068";
            h = "safezoneH * 0.12";
            text = "\acm_extended\ui\laryngo\suction\yank_master.paa";
        };
        class LG_SucCount: RscText {
            idc = 87882;
            x = "safezoneX + safezoneW * 0.82";
            y = "safezoneY + safezoneH * 0.99";
            w = "safezoneW * 0.08";
            h = "safezoneH * 0.03";
            style = 2;
            text = "";
            colorText[] = {0.93, 0.89, 0.8, 1};
            colorBackground[] = {0, 0, 0, 0};
            sizeEx = "0.022 * safezoneH";
        };
        class LG_SucClick: RscButton {
            idc = 87883;
            x = "safezoneX + safezoneW * 0.82";
            y = "safezoneY + safezoneH * 0.86";
            w = "safezoneW * 0.08";
            h = "safezoneH * 0.16";
            text = "";
            tooltip = "Pick up / return Yankauer suction";
            onButtonClick = "['suction'] call ACME_fnc_laryngoGrab";
            colorText[] = {0, 0, 0, 0};
            colorDisabled[] = {0, 0, 0, 0};
            colorBackground[] = {0, 0, 0, 0};
            colorBackgroundDisabled[] = {0, 0, 0, 0};
            colorBackgroundActive[] = {1, 1, 1, 0.04};
            colorFocused[] = {0, 0, 0, 0};
            colorShadow[] = {0, 0, 0, 0};
            colorBorder[] = {0, 0, 0, 0};
            borderSize = 0;
        };
        class LG_Cancel: RscButton {
            idc = 87868;
            x = "safezoneX + safezoneW * 0.82";
            y = "safezoneY + safezoneH * 0.82";
            w = "safezoneW * 0.08";
            h = "safezoneH * 0.05";
            text = "Done";
            colorBackground[] = {0.3, 0.1, 0.1, 0.85};
            colorText[] = {0.93, 0.89, 0.8, 1};
            action = "closeDialog 0";
        };
    };
};
class ACME_MC_MenuBtn: RscButton {
    idc = -1;
    colorText[] = {0.92, 0.95, 1, 1};
    colorDisabled[] = {1, 1, 1, 0.25};
    colorBackground[] = {0.1, 0.13, 0.18, 1};
    colorBackgroundDisabled[] = {0.06, 0.07, 0.09, 1};
    colorBackgroundActive[] = {0.16, 0.42, 0.58, 1};
    colorFocused[] = {0.12, 0.16, 0.22, 1};
    colorBorder[] = {0, 0, 0, 0};
    font = "PuristaBold";
    sizeEx = "safeZoneH * 0.022";
    style = 2;
    shadow = 0;
    y = "safeZoneY + safeZoneH*0.075 + safeZoneH*0.85*0.600";
    h = "safeZoneH * 0.045";
    w = "((safeZoneH*0.85*1.61) - 0.028)/9 - 0.004";
};
class ACME_Megacode_Panel {
    idd = 87300;
    movingEnable = 0;
    enableSimulation = 1;
    onLoad = "_this call ACME_fnc_megacodePanelLoad";
    onUnload = "_this call ACME_fnc_megacodeClosePanel";
    class ControlsBackground {
        class MC_Backdrop: RscText {
            idc = -1;
            text = "";
            x = "safeZoneX + (safeZoneW-(safeZoneH*0.85*1.61))/2";
            y = "safeZoneY + safeZoneH * 0.075";
            w = "(safeZoneH*0.85*1.61)";
            h = "safeZoneH * 0.85";
            colorBackground[] = {0.02, 0.03, 0.05, 0.97};
        };
        class MC_TitleBar: RscText {
            idc = -1;
            text = "  MEGACODE KELLY   //   INSTRUCTOR CONTROL PANEL";
            x = "safeZoneX + (safeZoneW-(safeZoneH*0.85*1.61))/2";
            y = "safeZoneY + safeZoneH * 0.075";
            w = "(safeZoneH*0.85*1.61)";
            h = "safeZoneH * 0.045";
            colorBackground[] = {0.07, 0.1, 0.14, 1};
            colorText[] = {0.5, 0.85, 1, 1};
            sizeEx = "safeZoneH * 0.026";
            font = "PuristaBold";
        };
        class MC_WaveBG: RscText {
            idc = -1;
            text = "";
            x = "safeZoneX + (safeZoneW-(safeZoneH*0.85*1.61))/2 + 0.010";
            y = "safeZoneY + safeZoneH*0.075 + safeZoneH*0.050";
            w = "(safeZoneH*0.85*1.61)*0.605";
            h = "safeZoneH*0.85*0.50 + 0.004";
            colorBackground[] = {0, 0, 0, 1};
        };
        class MC_VitalsBG: MC_WaveBG {
            x = "safeZoneX + (safeZoneW-(safeZoneH*0.85*1.61))/2 + (safeZoneH*0.85*1.61)*0.625 - 0.004";
            w = "(safeZoneH*0.85*1.61)*0.36";
            colorBackground[] = {0.015, 0.02, 0.03, 1};
        };
        class MC_ContentBG: MC_WaveBG {
            x = "safeZoneX + (safeZoneW-(safeZoneH*0.85*1.61))/2 + 0.010";
            y = "safeZoneY + safeZoneH*0.075 + safeZoneH*0.85*0.655";
            w = "(safeZoneH*0.85*1.61) - 0.020";
            h = "safeZoneH*0.85*0.330";
            colorBackground[] = {0.04, 0.05, 0.07, 1};
        };
    };
    class Controls {
        class MC_BtnVitals: ACME_MC_MenuBtn {
            text = "VITALS";
            x = "safeZoneX + (safeZoneW-(safeZoneH*0.85*1.61))/2 + 0.014 + ((safeZoneH*0.85*1.61) - 0.028)*(0/9)";
            action = "[87300, 'vitals'] call ACME_fnc_megacodeMenu";
            tooltip = "Heart rate, SpO2, BP, RR, EtCO2, temperature, pulse";
        };
        class MC_BtnRhythm: ACME_MC_MenuBtn {
            text = "RHYTHM";
            x = "safeZoneX + (safeZoneW-(safeZoneH*0.85*1.61))/2 + 0.014 + ((safeZoneH*0.85*1.61) - 0.028)*(1/9)";
            action = "[87300, 'rhythm'] call ACME_fnc_megacodeMenu";
            tooltip = "Cardiac rhythm library (sinus through asystole)";
        };
        class MC_BtnAirway: ACME_MC_MenuBtn {
            text = "AIRWAY";
            x = "safeZoneX + (safeZoneW-(safeZoneH*0.85*1.61))/2 + 0.014 + ((safeZoneH*0.85*1.61) - 0.028)*(2/9)";
            action = "[87300, 'airway'] call ACME_fnc_megacodeMenu";
            tooltip = "Airway / breathing states and tension pneumothorax";
        };
        class MC_BtnWounds: ACME_MC_MenuBtn {
            text = "WOUNDS";
            x = "safeZoneX + (safeZoneW-(safeZoneH*0.85*1.61))/2 + 0.014 + ((safeZoneH*0.85*1.61) - 0.028)*(3/9)";
            action = "[87300, 'wounds'] call ACME_fnc_megacodeMenu";
            tooltip = "Add wounds of any type to any region";
        };
        class MC_BtnNeuro: ACME_MC_MenuBtn {
            text = "NEURO/+";
            x = "safeZoneX + (safeZoneW-(safeZoneH*0.85*1.61))/2 + 0.014 + ((safeZoneH*0.85*1.61) - 0.028)*(4/9)";
            action = "[87300, 'neuro'] call ACME_fnc_megacodeMenu";
            tooltip = "ICP, GCS, herniation, seizure, posturing, pupils";
        };
        class MC_BtnScenario: ACME_MC_MenuBtn {
            text = "SCENARIO";
            x = "safeZoneX + (safeZoneW-(safeZoneH*0.85*1.61))/2 + 0.014 + ((safeZoneH*0.85*1.61) - 0.028)*(5/9)";
            colorBackground[] = {0.2, 0.12, 0.28, 1};
            action = "[87300, 'scenario'] call ACME_fnc_megacodeMenu";
            tooltip = "Run an evolving clinical scenario that deteriorates toward arrest";
        };
        class MC_BtnLog: ACME_MC_MenuBtn {
            text = "LOG";
            x = "safeZoneX + (safeZoneW-(safeZoneH*0.85*1.61))/2 + 0.014 + ((safeZoneH*0.85*1.61) - 0.028)*(6/9)";
            colorBackground[] = {0.1, 0.2, 0.16, 1};
            action = "[87300, 'log'] call ACME_fnc_megacodeMenu";
            tooltip = "Activity log of everything applied to the manikin";
        };
        class MC_BtnReset: ACME_MC_MenuBtn {
            text = "RESET";
            x = "safeZoneX + (safeZoneW-(safeZoneH*0.85*1.61))/2 + 0.014 + ((safeZoneH*0.85*1.61) - 0.028)*(7/9)";
            colorBackground[] = {0.35, 0.2, 0.1, 1};
            action = "call ACME_fnc_megacodeReset";
            tooltip = "Reset the manikin to a clean baseline";
        };
        class MC_BtnDone: ACME_MC_MenuBtn {
            text = "DONE";
            x = "safeZoneX + (safeZoneW-(safeZoneH*0.85*1.61))/2 + 0.014 + ((safeZoneH*0.85*1.61) - 0.028)*(8/9)";
            colorBackground[] = {0.3, 0.1, 0.12, 1};
            action = "closeDialog 0";
            tooltip = "Close the control panel";
        };
    };
};
class ACME_MC_CableTuner {
    idd = 87310;
    movingEnable = 0;
    enableSimulation = 1;
    onLoad = "_this call ACME_fnc_megacodeCableTunerLoad";
    class ControlsBackground {
        class CT_Backdrop: RscText {
            idc = -1;
            text = "";
            x = "safeZoneX + safeZoneW * 0.05";
            y = "safeZoneY + safeZoneH * 0.685";
            w = "safeZoneW * 0.90";
            h = "safeZoneH * 0.300";
            colorBackground[] = {0.02, 0.03, 0.05, 0.97};
        };
        class CT_TitleBar: RscText {
            idc = -1;
            text = "  MEGACODE CABLE TUNER";
            x = "safeZoneX + safeZoneW * 0.05";
            y = "safeZoneY + safeZoneH * 0.685";
            w = "safeZoneW * 0.90";
            h = "safeZoneH * 0.034";
            colorBackground[] = {0.07, 0.1, 0.14, 1};
            colorText[] = {0.5, 0.85, 1, 1};
            sizeEx = "safeZoneH * 0.024";
            font = "PuristaBold";
        };
    };
    class Controls {};
};
class ACME_CoolerManager_Dialog {
    idd = 87400;
    movingEnable = 0;
    enableSimulation = 1;
    onLoad = "[_this select 0] call ACME_fnc_minigameInputInstall; uiNamespace setVariable ['ACME_CLR_DLG', (_this select 0)]; call ACME_fnc_coolerRefresh; [{ if (!isNull (uiNamespace getVariable ['ACME_CLR_DLG', displayNull])) then { call ACME_fnc_coolerRefresh; }; }, []] call CBA_fnc_execNextFrame;";
    onUnload = "uiNamespace setVariable ['ACME_CLR_DLG', displayNull]; call ACME_fnc_coolerClearSlots;";
    class ControlsBackground {
        class ACME_CLR_Backdrop: RscText {
            idc = 87401;
            text = "";
            x = "safeZoneX + (safeZoneW / 2) - (safeZoneW / 5)";
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 2.9)";
            w = "safeZoneW / 2.5";
            h = "safeZoneH / 1.55";
            colorBackground[] = {0.04, 0.06, 0.09, 0.94};
        };
        class ACME_CLR_HeaderRule: RscText {
            idc = 87420;
            text = "";
            x = "safeZoneX + (safeZoneW / 2) - (safeZoneW / 5)";
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 2.9) + (safeZoneH / 13)";
            w = "safeZoneW / 2.5";
            h = "safeZoneH / 240";
            colorBackground[] = {0.74, 0.12, 0.12, 1};
        };
        class ACME_CLR_Title: RscText {
            idc = 87402;
            text = "Blood Cooler";
            x = "safeZoneX + (safeZoneW / 2) - (safeZoneW / 5) + (safeZoneW / 90)";
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 2.9) + (safeZoneH / 90)";
            w = "safeZoneW / 3";
            h = "safeZoneH / 22";
            colorText[] = {0.92, 0.24, 0.24, 1};
            colorBackground[] = {0, 0, 0, 0};
            font = "PuristaBold";
            sizeEx = "safeZoneH * 0.032";
            style = 0;
            shadow = 0;
        };
        class ACME_CLR_CapBadge: RscText {
            idc = 87421;
            text = "";
            x = "safeZoneX + (safeZoneW / 2) + (safeZoneW / 5) - (safeZoneW / 6.5) - (safeZoneW / 90)";
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 2.9) + (safeZoneH / 120)";
            w = "safeZoneW / 6.5";
            h = "safeZoneH / 20";
            colorText[] = {0.55, 0.88, 1, 1};
            colorBackground[] = {0.07, 0.13, 0.18, 0.85};
            font = "PuristaBold";
            sizeEx = "safeZoneH * 0.026";
            style = 2;
            shadow = 0;
        };
        class ACME_CLR_Readout: RscText {
            idc = 87403;
            text = "";
            x = "safeZoneX + (safeZoneW / 2) - (safeZoneW / 5) + (safeZoneW / 90)";
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 2.9) + (safeZoneH / 11.5)";
            w = "safeZoneW / 2.5";
            h = "safeZoneH / 30";
            colorText[] = {0.7, 0.8, 0.9, 1};
            colorBackground[] = {0, 0, 0, 0};
            font = "RobotoCondensed";
            sizeEx = "safeZoneH * 0.022";
            style = 0;
            shadow = 0;
        };
        class ACME_CLR_LabelIn: RscText {
            idc = 87404;
            text = "COOLER BAYS";
            x = "safeZoneX + (safeZoneW * 0.312)";
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 4.1)";
            w = "safeZoneW * 0.2016";
            h = "safeZoneH / 30";
            colorText[] = {0.5, 0.85, 1, 1};
            colorBackground[] = {0, 0, 0, 0};
            font = "PuristaBold";
            sizeEx = "safeZoneH * 0.021";
            shadow = 0;
        };
        class ACME_CLR_LabelOut: RscText {
            idc = 87405;
            text = "INVENTORY (warming)";
            x = "safeZoneX + (safeZoneW * 0.53)";
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 4.1)";
            w = "safeZoneW * 0.158";
            h = "safeZoneH / 30";
            colorText[] = {0.9, 0.7, 0.4, 1};
            colorBackground[] = {0, 0, 0, 0};
            font = "PuristaBold";
            sizeEx = "safeZoneH * 0.021";
            shadow = 0;
        };
    };
    class Controls {
        class ACME_CLR_SlotGroup: RscControlsGroupNoScrollbars {
            idc = 87415;
            x = "safeZoneX + (safeZoneW * 0.312)";
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 4.7)";
            w = "safeZoneW * 0.2016";
            h = "safeZoneH / 2.4";
            class Controls {};
        };
        class ACME_CLR_ListIn: RscListBox {
            idc = 87410;
            x = -1;
            y = -1;
            w = 0.001;
            h = 0.001;
            colorBackground[] = {0, 0, 0, 0};
            sizeEx = "safeZoneH * 0.001";
            font = "RobotoCondensed";
        };
        class ACME_CLR_ListOut: RscListBox {
            idc = 87411;
            x = "safeZoneX + (safeZoneW * 0.53)";
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 4.7)";
            w = "safeZoneW * 0.158";
            h = "safeZoneH / 2.7";
            colorBackground[] = {0.02, 0.04, 0.07, 0.9};
            sizeEx = "safeZoneH * 0.021";
            font = "RobotoCondensed";
        };
        class ACME_CLR_Unload: RscButton {
            idc = 87412;
            text = "Unload selected bay >";
            tooltip = "Take the selected unit out of the cooler (it starts warming).";
            action = "call ACME_fnc_coolerUnload;";
            x = "safeZoneX + (safeZoneW * 0.312)";
            y = "safeZoneY + (safeZoneH / 2) + (safeZoneH / 4.6)";
            w = "safeZoneW * 0.2016";
            h = "safeZoneH / 26";
            colorBackground[] = {0.16, 0.2, 0.24, 1};
            colorText[] = {0.85, 0.95, 1, 1};
            font = "RobotoCondensed";
            sizeEx = "safeZoneH * 0.021";
        };
        class ACME_CLR_Load: RscButton {
            idc = 87413;
            text = "< Load into cooler";
            tooltip = "Put the selected blood bag into the cooler (it stays cold).";
            action = "call ACME_fnc_coolerLoad;";
            x = "safeZoneX + (safeZoneW * 0.53)";
            y = "safeZoneY + (safeZoneH / 2) + (safeZoneH / 4.6)";
            w = "safeZoneW * 0.158";
            h = "safeZoneH / 26";
            colorBackground[] = {0.16, 0.2, 0.24, 1};
            colorText[] = {0.85, 0.95, 1, 1};
            font = "RobotoCondensed";
            sizeEx = "safeZoneH * 0.021";
        };
        class ACME_CLR_Close: RscButton {
            idc = 87414;
            text = "Close";
            action = "closeDialog 0;";
            x = "safeZoneX + (safeZoneW / 2) - (safeZoneW / 5)";
            y = "safeZoneY + (safeZoneH / 2) + (safeZoneH / 2.9) - (safeZoneH / 22)";
            w = "safeZoneW / 2.5";
            h = "safeZoneH / 24";
            colorBackground[] = {0.45, 0.12, 0.12, 1};
            colorText[] = {1, 1, 1, 1};
            font = "PuristaBold";
            sizeEx = "safeZoneH * 0.024";
            style = 2;
        };
    };
};
class CfgSounds {
    class ACME_VentBoot {
        name = "ACME_VentBoot";
        sound[] = {"acm_extended\sound\vent_boot_sfx.ogg", 1, 1};
        titles[] = {};
    };
    class ACME_VentDial {
        name = "ACME_VentDial";
        sound[] = {"acm_extended\sound\vent_rotary_dial_sfx.ogg", 1, 1};
        titles[] = {};
    };
    class ACME_VentClick {
        name = "ACME_VentClick";
        sound[] = {"acm_extended\sound\vent_rotary_dial_click_sfx.ogg", 1, 1};
        titles[] = {};
    };
    class ACME_VentPower {
        name = "ACME_VentPower";
        sound[] = {"acm_extended\sound\vent_power_btn_sfx.ogg", 1, 1};
        titles[] = {};
    };
    class ACME_VentBattSwap {
        name = "ACME_VentBattSwap";
        sound[] = {"acm_extended\sound\vent_battery_swap_sfx.ogg", 1, 1};
        titles[] = {};
    };
    class ACME_KellyCut_1 {
        name = "ACME_KellyCut_1";
        sound[] = {"acm_extended\sound\kelly_clamps_cut1_sfx.ogg", 1, 1};
        titles[] = {};
    };
    class ACME_KellyCut_2: ACME_KellyCut_1 {
        name = "ACME_KellyCut_2";
        sound[] = {"acm_extended\sound\kelly_clamps_cut2_sfx.ogg", 1, 1};
    };
    class ACME_KellyCut_3: ACME_KellyCut_1 {
        name = "ACME_KellyCut_3";
        sound[] = {"acm_extended\sound\kelly_clamps_cut3_sfx.ogg", 1, 1};
    };
    class ACME_KellyCut_4: ACME_KellyCut_1 {
        name = "ACME_KellyCut_4";
        sound[] = {"acm_extended\sound\kelly_clamps_cut4_sfx.ogg", 1, 1};
    };
    class ACME_KellyClose: ACME_KellyCut_1 {
        name = "ACME_KellyClose";
        sound[] = {"acm_extended\sound\kelly_clamps_close_sfx.ogg", 1, 1};
    };
    class ACME_BreathIn_S_1 {
        name = "ACME_BreathIn_S_1";
        sound[] = {
            "acm_extended\sound\breath_in_1_sfx.ogg",
            "db-9",
            1,
            18
        };
        titles[] = {};
    };
    class ACME_BreathIn_S_2: ACME_BreathIn_S_1 {
        name = "ACME_BreathIn_S_2";
        sound[] = {
            "acm_extended\sound\breath_in_2_sfx.ogg",
            "db-9",
            1,
            18
        };
    };
    class ACME_BreathIn_S_3: ACME_BreathIn_S_1 {
        name = "ACME_BreathIn_S_3";
        sound[] = {
            "acm_extended\sound\breath_in_3_sfx.ogg",
            "db-9",
            1,
            18
        };
    };
    class ACME_BreathIn_S_4: ACME_BreathIn_S_1 {
        name = "ACME_BreathIn_S_4";
        sound[] = {
            "acm_extended\sound\breath_in_4_sfx.ogg",
            "db-9",
            1,
            18
        };
    };
    class ACME_BreathIn_S_5: ACME_BreathIn_S_1 {
        name = "ACME_BreathIn_S_5";
        sound[] = {
            "acm_extended\sound\breath_in_5_sfx.ogg",
            "db-9",
            1,
            18
        };
    };
    class ACME_BreathIn_S_6: ACME_BreathIn_S_1 {
        name = "ACME_BreathIn_S_6";
        sound[] = {
            "acm_extended\sound\breath_in_6_sfx.ogg",
            "db-9",
            1,
            18
        };
    };
    class ACME_BreathIn_M_1: ACME_BreathIn_S_1 {
        name = "ACME_BreathIn_M_1";
        sound[] = {
            "acm_extended\sound\breath_in_1_sfx.ogg",
            "db-2",
            1,
            18
        };
    };
    class ACME_BreathIn_M_2: ACME_BreathIn_S_1 {
        name = "ACME_BreathIn_M_2";
        sound[] = {
            "acm_extended\sound\breath_in_2_sfx.ogg",
            "db-2",
            1,
            18
        };
    };
    class ACME_BreathIn_M_3: ACME_BreathIn_S_1 {
        name = "ACME_BreathIn_M_3";
        sound[] = {
            "acm_extended\sound\breath_in_3_sfx.ogg",
            "db-2",
            1,
            18
        };
    };
    class ACME_BreathIn_M_4: ACME_BreathIn_S_1 {
        name = "ACME_BreathIn_M_4";
        sound[] = {
            "acm_extended\sound\breath_in_4_sfx.ogg",
            "db-2",
            1,
            18
        };
    };
    class ACME_BreathIn_M_5: ACME_BreathIn_S_1 {
        name = "ACME_BreathIn_M_5";
        sound[] = {
            "acm_extended\sound\breath_in_5_sfx.ogg",
            "db-2",
            1,
            18
        };
    };
    class ACME_BreathIn_M_6: ACME_BreathIn_S_1 {
        name = "ACME_BreathIn_M_6";
        sound[] = {
            "acm_extended\sound\breath_in_6_sfx.ogg",
            "db-2",
            1,
            18
        };
    };
    class ACME_BreathIn_D_1: ACME_BreathIn_S_1 {
        name = "ACME_BreathIn_D_1";
        sound[] = {
            "acm_extended\sound\breath_in_1_sfx.ogg",
            "db+4",
            1,
            18
        };
    };
    class ACME_BreathIn_D_2: ACME_BreathIn_S_1 {
        name = "ACME_BreathIn_D_2";
        sound[] = {
            "acm_extended\sound\breath_in_2_sfx.ogg",
            "db+4",
            1,
            18
        };
    };
    class ACME_BreathIn_D_3: ACME_BreathIn_S_1 {
        name = "ACME_BreathIn_D_3";
        sound[] = {
            "acm_extended\sound\breath_in_3_sfx.ogg",
            "db+4",
            1,
            18
        };
    };
    class ACME_BreathIn_D_4: ACME_BreathIn_S_1 {
        name = "ACME_BreathIn_D_4";
        sound[] = {
            "acm_extended\sound\breath_in_4_sfx.ogg",
            "db+4",
            1,
            18
        };
    };
    class ACME_BreathIn_D_5: ACME_BreathIn_S_1 {
        name = "ACME_BreathIn_D_5";
        sound[] = {
            "acm_extended\sound\breath_in_5_sfx.ogg",
            "db+4",
            1,
            18
        };
    };
    class ACME_BreathIn_D_6: ACME_BreathIn_S_1 {
        name = "ACME_BreathIn_D_6";
        sound[] = {
            "acm_extended\sound\breath_in_6_sfx.ogg",
            "db+4",
            1,
            18
        };
    };
    class ACME_BreathOut_S_1: ACME_BreathIn_S_1 {
        name = "ACME_BreathOut_S_1";
        sound[] = {
            "acm_extended\sound\breath_out_1_sfx.ogg",
            "db-9",
            1,
            18
        };
    };
    class ACME_BreathOut_S_2: ACME_BreathIn_S_1 {
        name = "ACME_BreathOut_S_2";
        sound[] = {
            "acm_extended\sound\breath_out_2_sfx.ogg",
            "db-9",
            1,
            18
        };
    };
    class ACME_BreathOut_S_3: ACME_BreathIn_S_1 {
        name = "ACME_BreathOut_S_3";
        sound[] = {
            "acm_extended\sound\breath_out_3_sfx.ogg",
            "db-9",
            1,
            18
        };
    };
    class ACME_BreathOut_S_4: ACME_BreathIn_S_1 {
        name = "ACME_BreathOut_S_4";
        sound[] = {
            "acm_extended\sound\breath_out_4_sfx.ogg",
            "db-9",
            1,
            18
        };
    };
    class ACME_BreathOut_S_5: ACME_BreathIn_S_1 {
        name = "ACME_BreathOut_S_5";
        sound[] = {
            "acm_extended\sound\breath_out_5_sfx.ogg",
            "db-9",
            1,
            18
        };
    };
    class ACME_BreathOut_S_6: ACME_BreathIn_S_1 {
        name = "ACME_BreathOut_S_6";
        sound[] = {
            "acm_extended\sound\breath_out_6_sfx.ogg",
            "db-9",
            1,
            18
        };
    };
    class ACME_BreathOut_M_1: ACME_BreathIn_S_1 {
        name = "ACME_BreathOut_M_1";
        sound[] = {
            "acm_extended\sound\breath_out_1_sfx.ogg",
            "db-2",
            1,
            18
        };
    };
    class ACME_BreathOut_M_2: ACME_BreathIn_S_1 {
        name = "ACME_BreathOut_M_2";
        sound[] = {
            "acm_extended\sound\breath_out_2_sfx.ogg",
            "db-2",
            1,
            18
        };
    };
    class ACME_BreathOut_M_3: ACME_BreathIn_S_1 {
        name = "ACME_BreathOut_M_3";
        sound[] = {
            "acm_extended\sound\breath_out_3_sfx.ogg",
            "db-2",
            1,
            18
        };
    };
    class ACME_BreathOut_M_4: ACME_BreathIn_S_1 {
        name = "ACME_BreathOut_M_4";
        sound[] = {
            "acm_extended\sound\breath_out_4_sfx.ogg",
            "db-2",
            1,
            18
        };
    };
    class ACME_BreathOut_M_5: ACME_BreathIn_S_1 {
        name = "ACME_BreathOut_M_5";
        sound[] = {
            "acm_extended\sound\breath_out_5_sfx.ogg",
            "db-2",
            1,
            18
        };
    };
    class ACME_BreathOut_M_6: ACME_BreathIn_S_1 {
        name = "ACME_BreathOut_M_6";
        sound[] = {
            "acm_extended\sound\breath_out_6_sfx.ogg",
            "db-2",
            1,
            18
        };
    };
    class ACME_BreathOut_D_1: ACME_BreathIn_S_1 {
        name = "ACME_BreathOut_D_1";
        sound[] = {
            "acm_extended\sound\breath_out_1_sfx.ogg",
            "db+4",
            1,
            18
        };
    };
    class ACME_BreathOut_D_2: ACME_BreathIn_S_1 {
        name = "ACME_BreathOut_D_2";
        sound[] = {
            "acm_extended\sound\breath_out_2_sfx.ogg",
            "db+4",
            1,
            18
        };
    };
    class ACME_BreathOut_D_3: ACME_BreathIn_S_1 {
        name = "ACME_BreathOut_D_3";
        sound[] = {
            "acm_extended\sound\breath_out_3_sfx.ogg",
            "db+4",
            1,
            18
        };
    };
    class ACME_BreathOut_D_4: ACME_BreathIn_S_1 {
        name = "ACME_BreathOut_D_4";
        sound[] = {
            "acm_extended\sound\breath_out_4_sfx.ogg",
            "db+4",
            1,
            18
        };
    };
    class ACME_BreathOut_D_5: ACME_BreathIn_S_1 {
        name = "ACME_BreathOut_D_5";
        sound[] = {
            "acm_extended\sound\breath_out_5_sfx.ogg",
            "db+4",
            1,
            18
        };
    };
    class ACME_BreathOut_D_6: ACME_BreathIn_S_1 {
        name = "ACME_BreathOut_D_6";
        sound[] = {
            "acm_extended\sound\breath_out_6_sfx.ogg",
            "db+4",
            1,
            18
        };
    };
    class ACME_RoscGasp: ACME_KellyCut_1 {
        name = "ACME_RoscGasp";
        sound[] = {
            "acm_extended\sound\rosc_gasp_sfx.ogg",
            "db+6",
            1,
            25
        };
    };
    class ACME_IVCap {
        name = "ACME_IVCap";
        sound[] = {"acm_extended\sound\iv_cap_sfx.ogg", 1, 1};
        titles[] = {};
    };
    class ACME_IVUncap {
        name = "ACME_IVUncap";
        sound[] = {"acm_extended\sound\iv_uncap_sfx.ogg", 1, 1};
        titles[] = {};
    };
    class ACME_ManualSuction {
        name = "ACME_ManualSuction";
        sound[] = {"\acm_extended\sound\manual_suction_sfx.ogg", 1, 1};
        titles[] = {};
    };
    class ACME_BloodFridgeDoorOpen {
        name = "ACME_BloodFridgeDoorOpen";
        sound[] = {
            "acm_extended\sound\bloodfridge_open.ogg",
            1,
            1,
            30
        };
        titles[] = {};
    };
    class ACME_BloodFridgeDoorClose {
        name = "ACME_BloodFridgeDoorClose";
        sound[] = {
            "acm_extended\sound\bloodfridge_closed.ogg",
            1,
            1,
            30
        };
        titles[] = {};
    };
    class ACME_NarcBoxOpen {
        name = "ACME_NarcBoxOpen";
        sound[] = {"acm_extended\sound\narc_box_open.ogg", 1, 1};
        titles[] = {};
    };
    class ACME_NarcBoxClosed {
        name = "ACME_NarcBoxClosed";
        sound[] = {"acm_extended\sound\narc_box_closed.ogg", 1, 1};
        titles[] = {};
    };
    class ACM_Stethoscope_Breath_Normal_Crackles {
        name = "ACM_Stethoscope_Breath_Normal_Crackles";
        sound[] = {"acm_extended\sound\breathing_normal_crackles.ogg", "db+10", 1};
        titles[] = {};
    };
    class ACM_Stethoscope_Breath_Fast_Crackles {
        name = "ACM_Stethoscope_Breath_Fast_Crackles";
        sound[] = {"acm_extended\sound\breathing_fast_crackles.ogg", "db+10", 1};
        titles[] = {};
    };
    class ACM_Stethoscope_Breath_Slow_Crackles {
        name = "ACM_Stethoscope_Breath_Slow_Crackles";
        sound[] = {"acm_extended\sound\breathing_slow_crackles.ogg", "db+10", 1};
        titles[] = {};
    };
    class ACM_HPMK_Wrap {
        name = "ACM_HPMK_Wrap";
        sound[] = {"acm_extended\sound\HPMK_sfx.ogg", "db+4", 1};
        titles[] = {};
    };
    class ACM_HPMK_Remove {
        name = "ACM_HPMK_Remove";
        sound[] = {"acm_extended\sound\HPMK_remove_sfx.ogg", "db+4", 1};
        titles[] = {};
    };
    class ACM_ChestSeal_Apply {
        name = "ACM_ChestSeal_Apply";
        sound[] = {"acm_extended\sound\chest_seal_sfx.ogg", "db+4", 1};
        titles[] = {};
    };
    class ACME_CS_HoleReveal {
        name = "ACME_CS_HoleReveal";
        sound[] = {"acm_extended\sound\chest_seal_hole_sfx.ogg", "db+2", 1};
        titles[] = {};
    };
    class ACME_NARSPEAR_Open {
        name = "ACME_NARSPEAR_Open";
        sound[] = {"acm_extended\sound\nar_spear_open_sfx.ogg", "db+3", 1};
        titles[] = {};
    };
    class ACME_NARSPEAR_Close {
        name = "ACME_NARSPEAR_Close";
        sound[] = {"acm_extended\sound\nar_spear_close_sfx.ogg", "db+3", 1};
        titles[] = {};
    };
    class ACME_NARSPEAR_Pierce {
        name = "ACME_NARSPEAR_Pierce";
        sound[] = {"acm_extended\sound\nar_spear_pierce_sfx.ogg", "db+4", 1};
        titles[] = {};
    };
    class ACM_Suction_Off {
        name = "ACM_Suction_Off";
        sound[] = {"acm_extended\sound\suction_off_sfx.ogg", "db+2", 1};
        titles[] = {};
    };
    class ACM_Expose_1 {
        name = "ACM_Expose_1";
        sound[] = {"acm_extended\sound\expose1_sfx.ogg", "db+2", 1};
        titles[] = {};
    };
    class ACM_Expose_2 {
        name = "ACM_Expose_2";
        sound[] = {"acm_extended\sound\expose2_sfx.ogg", "db+2", 1};
        titles[] = {};
    };
    class ACM_Expose_3 {
        name = "ACM_Expose_3";
        sound[] = {"acm_extended\sound\expose3_sfx.ogg", "db+2", 1};
        titles[] = {};
    };
    class ACM_Expose_4 {
        name = "ACM_Expose_4";
        sound[] = {"acm_extended\sound\expose4_sfx.ogg", "db+2", 1};
        titles[] = {};
    };
    class ACM_Expose_Chest {
        name = "ACM_Expose_Chest";
        sound[] = {"acm_extended\sound\expose_chest.ogg", "db+2", 1};
        titles[] = {};
    };
    class ACME_SyringeDraw {
        name = "ACME_SyringeDraw";
        sound[] = {"acm_extended\sound\syringe_draw.ogg", "db+3", 1};
        titles[] = {};
    };
    class ACME_SyringePush {
        name = "ACME_SyringePush";
        sound[] = {"acm_extended\sound\syringe_push.ogg", "db+5", 1};
        titles[] = {};
    };
    class ACME_EMMA_Attach {
        name = "ACME_EMMA_Attach";
        sound[] = {"acm_extended\sound\emma_attach_sfx.ogg", "db+3", 1};
        titles[] = {};
    };
    class ACME_EMMA_Detach {
        name = "ACME_EMMA_Detach";
        sound[] = {"acm_extended\sound\emma_detach_sfx.ogg", "db+3", 1};
        titles[] = {};
    };
    class ACME_JunctionalPacking {
        name = "ACME_JunctionalPacking";
        sound[] = {"acm_extended\sound\junctionalwound_packing_sfx.ogg", "db+3", 1};
        titles[] = {};
    };
    class ACME_JunctionalWrapping {
        name = "ACME_JunctionalWrapping";
        sound[] = {"acm_extended\sound\junctionalwound_wrapping_sfx.ogg", "db+3", 1};
        titles[] = {};
    };
    class ACME_JunctionalTie {
        name = "ACME_JunctionalTie";
        sound[] = {"acm_extended\sound\junctionalwound_packing_tie_sfx.ogg", "db+3", 1};
        titles[] = {};
    };
    class ACME_HPMK_Wrap {
        name = "ACME_HPMK_Wrap";
        sound[] = {"acm_extended\sound\HPMK_wrap.ogg", "db+4", 1};
        titles[] = {};
    };
    class ACME_HPMK_Unwrap {
        name = "ACME_HPMK_Unwrap";
        sound[] = {"acm_extended\sound\HPMK_unwrap.ogg", "db+4", 1};
        titles[] = {};
    };
    class ACME_HPMK_Expose {
        name = "ACME_HPMK_Expose";
        sound[] = {"acm_extended\sound\HPMK_expose_sfx.ogg", "db+4", 1};
        titles[] = {};
    };
    class ACME_DirectPressure {
        name = "ACME_DirectPressure";
        sound[] = {"acm_extended\sound\direct_pressure_sfx.ogg", "db+3", 1};
        titles[] = {};
    };
    class ACME_JunctionalLeaking {
        name = "ACME_JunctionalLeaking";
        sound[] = {"acm_extended\sound\junctionalwound_leaking_sfx.ogg", "db+2", 1};
        titles[] = {};
    };
};
class CfgSFX {
    class ACM_NRB_SFX {
        sounds[] = {"nrb"};
        nrb[] = {
            "acm_extended\sound\nrbmask_sfx.ogg",
            1,
            1,
            22,
            1,
            0,
            0,
            0
        };
        empty[] = {"", 0, 0, 0, 0, 0, 0, 0};
    };
    class ACME_SyringeDraw_SFX {
        sounds[] = {"draw"};
        draw[] = {
            "acm_extended\sound\syringe_draw.ogg",
            1.2,
            1,
            18,
            0,
            0,
            0,
            0
        };
        empty[] = {"", 0, 0, 0, 0, 0, 0, 0};
    };
    class ACME_JunctionalPackLoop_SFX {
        sounds[] = {"pack"};
        pack[] = {
            "acm_extended\sound\junctionalwound_packing_sfx.ogg",
            1.3,
            1,
            16,
            1,
            0,
            0,
            0
        };
        empty[] = {"", 0, 0, 0, 0, 0, 0, 0};
    };
    class ACME_JunctionalPack_SFX {
        sounds[] = {"wrap"};
        wrap[] = {
            "acm_extended\sound\junctionalwound_wrapping_sfx.ogg",
            1.3,
            1,
            16,
            1,
            0,
            0,
            0
        };
        empty[] = {"", 0, 0, 0, 0, 0, 0, 0};
    };
    class ACME_JunctionalLeak_SFX {
        sounds[] = {"leak"};
        leak[] = {
            "acm_extended\sound\junctionalwound_leaking_sfx.ogg",
            1.15,
            1,
            16,
            1,
            0,
            0,
            0
        };
        empty[] = {"", 0, 0, 0, 0, 0, 0, 0};
    };
    class ACME_VentRun_SFX {
        sounds[] = {"run"};
        run[] = {
            "acm_extended\sound\ventilator_running_sfx.ogg",
            1.6,
            1,
            30,
            1,
            0,
            0,
            0
        };
        empty[] = {"", 0, 0, 0, 0, 0, 0, 0};
    };
    class ACM_Suction_SFX {
        sounds[] = {"suction"};
        suction[] = {
            "acm_extended\sound\suction.ogg",
            1.3,
            1,
            30,
            1,
            0,
            0,
            0
        };
        empty[] = {"", 0, 0, 0, 0, 0, 0, 0};
    };
};
class CfgFactionClasses {
    class NO_CATEGORY;
    class ACME_Curator_Category: NO_CATEGORY {
        displayName = "ACM Extended";
        priority = 3;
        side = 7;
    };
};
class CfgVehicles {
    class Rope;
    class ACME_IVLine_Rope: Rope {
        scope = 1;
        model = "\acm_extended\models\iv_line_segment.p3d";
        segmentType = "ACME_IVLine_Segment";
        hiddenSelections[] = {"rope"};
        hiddenSelectionsTextures[] = {"#(argb,8,8,3)color(0.64,0.86,0.95,1.0,co)"};
    };
    class ACME_IVLine_Rope_Blood: ACME_IVLine_Rope {
        hiddenSelectionsTextures[] = {"#(argb,8,8,3)color(0.55,0.05,0.05,1.0,co)"};
    };
    class ACME_IVLine_Rope_Plasma: ACME_IVLine_Rope {
        hiddenSelectionsTextures[] = {"#(argb,8,8,3)color(0.86,0.72,0.32,1.0,co)"};
    };
    class ACME_IVLine_BlueHose: Rope {
        scope = 1;
        model = "\z\ace\addons\refuel\data\hose.p3d";
        segmentType = "ace_refuel_fuelHoseSegment";
        hiddenSelections[] = {"rope"};
        hiddenSelectionsTextures[] = {"#(argb,8,8,3)color(0.64,0.86,0.95,1.0,co)"};
    };
    class ThingX;
    class ACME_IVBagObject: ThingX {
        scope = 1;
        scopeCurator = 0;
        displayName = "IV Bag";
        model = "\z\ace\addons\medical_treatment\data\IVBag_500ml.p3d";
        hiddenSelections[] = {"camo"};
        hiddenSelectionsTextures[] = {"\z\ace\addons\medical_treatment\data\IVBag_saline_500ml_ca.paa"};
    };
    class ACME_IVBagObject_250: ACME_IVBagObject {
        model = "\z\ace\addons\medical_treatment\data\IVBag_250ml.p3d";
        hiddenSelectionsTextures[] = {"\z\ace\addons\medical_treatment\data\IVBag_saline_250ml_ca.paa"};
    };
    class ACME_IVBagObject_1000: ACME_IVBagObject {
        model = "\z\ace\addons\medical_treatment\data\IVBag_1000ml.p3d";
        hiddenSelectionsTextures[] = {"\z\ace\addons\medical_treatment\data\IVBag_saline_1000ml_ca.paa"};
    };
    class ACME_RopeHelper: ThingX {
        scope = 1;
        scopeCurator = 0;
        displayName = "IV Line Anchor";
        model = "\A3\Weapons_f\empty";
    };
    class Box_NATO_Ammo_F;
    class Box_NATO_Wps_F;
    class ACME_BloodCoolerBox_CSWB1U: Box_NATO_Ammo_F {
        scope = 2;
        scopeCurator = 2;
        author = "mavis";
        displayName = "Blood Cooler 1U (Box)";
        maximumLoad = 6;
        transportMaxWeapons = 0;
        transportMaxMagazines = 0;
        transportMaxBackpacks = 0;
        hiddenSelections[] = {"camo"};
        hiddenSelectionsTextures[] = {"#(argb,8,8,3)color(0.62,0.10,0.10,1.0,co)"};
        ace_dragging_canDrag = 1;
        ace_dragging_dragPosition[] = {0, 1, 0};
        ace_dragging_dragDirection = 0;
        ace_dragging_canCarry = 1;
        ace_dragging_carryPosition[] = {0, 1, 1};
        ace_dragging_carryDirection = 0;
        class ACE_Actions {
            class ACE_MainActions {
                displayName = "Blood Cooler";
                selection = "";
                distance = 4;
                condition = "true";
                class ACME_PackUpCooler {
                    displayName = "Pick Up Cooler";
                    distance = 4;
                    condition = "true";
                    statement = "[_target] call ACME_fnc_coolerBoxPackUp";
                };
            };
        };
    };
    class ACME_BloodCoolerBox_CSWB2U: Box_NATO_Ammo_F {
        scope = 2;
        scopeCurator = 2;
        author = "mavis";
        displayName = "Blood Cooler 2U (Box)";
        maximumLoad = 11;
        transportMaxWeapons = 0;
        transportMaxMagazines = 0;
        transportMaxBackpacks = 0;
        hiddenSelections[] = {"camo"};
        hiddenSelectionsTextures[] = {"#(argb,8,8,3)color(0.62,0.10,0.10,1.0,co)"};
        ace_dragging_canDrag = 1;
        ace_dragging_dragPosition[] = {0, 1, 0};
        ace_dragging_dragDirection = 0;
        ace_dragging_canCarry = 1;
        ace_dragging_carryPosition[] = {0, 1, 1};
        ace_dragging_carryDirection = 0;
        class ACE_Actions {
            class ACE_MainActions {
                displayName = "Blood Cooler";
                selection = "";
                distance = 4;
                condition = "true";
                class ACME_PackUpCooler {
                    displayName = "Pick Up Cooler";
                    distance = 4;
                    condition = "true";
                    statement = "[_target] call ACME_fnc_coolerBoxPackUp";
                };
            };
        };
    };
    class ACME_BloodCoolerBox_CSWB4U: Box_NATO_Wps_F {
        scope = 2;
        scopeCurator = 2;
        author = "mavis";
        displayName = "Blood Cooler 4U (Box)";
        maximumLoad = 21;
        transportMaxWeapons = 0;
        transportMaxMagazines = 0;
        transportMaxBackpacks = 0;
        hiddenSelections[] = {"camo"};
        hiddenSelectionsTextures[] = {"#(argb,8,8,3)color(0.62,0.10,0.10,1.0,co)"};
        ace_dragging_canDrag = 1;
        ace_dragging_dragPosition[] = {0, 1, 0};
        ace_dragging_dragDirection = 0;
        ace_dragging_canCarry = 1;
        ace_dragging_carryPosition[] = {0, 1, 1};
        ace_dragging_carryDirection = 0;
        class ACE_Actions {
            class ACE_MainActions {
                displayName = "Blood Cooler";
                selection = "";
                distance = 4;
                condition = "true";
                class ACME_PackUpCooler {
                    displayName = "Pick Up Cooler";
                    distance = 4;
                    condition = "true";
                    statement = "[_target] call ACME_fnc_coolerBoxPackUp";
                };
            };
        };
    };
    class Man;
    class CAManBase: Man {
        class ACE_SelfActions {
            class ACE_Equipment {
                class ACE_MapFlashlight {
                    condition = "(ace_map_mapIllumination && visibleMap) && {!(['blocked'] call ACME_fnc_laryngoFlash)}";
                };
            };
            class ACME_MinigameFlashlight {
                displayName = "Flashlights";
                icon = "\a3\ui_f\data\IGUI\Cfg\VehicleToggles\lightsiconon_ca.paa";
                condition = "(missionNamespace getVariable ['ACME_flashlightMenuActive', false]) || (!isNull (uiNamespace getVariable ['ACME_IV_DLG', displayNull])) || (!isNull (uiNamespace getVariable ['ACME_CS_DLG', displayNull])) || (!isNull (uiNamespace getVariable ['ACME_Thora_DLG', displayNull])) || (!isNull (uiNamespace getVariable ['ACME_laryngo_dlg', displayNull])) || (!isNull (uiNamespace getVariable ['ACME_SK_DLG', displayNull]))";
                exceptions[] = {
                    "isNotDragging",
                    "notOnMap",
                    "isNotInside",
                    "isNotSitting"
                };
                insertChildren = "(call ace_map_fnc_compileFlashlightMenu) + ([] call ACME_fnc_lightExtras)";
            };
            class ACM_Action_GetUp {
                condition = "((_player getVariable ['ACM_core_Lying_State', false]) || {_player getVariable ['ACME_headElevated', false]})";
                statement = "[_player, true] call ACM_core_fnc_getUp";
            };
            class ACM_Equipment {
                class ACME_SyringeKit {
                    displayName = "Narc Box";
                    icon = "\acm_extended\ui\items\narc_box_ca.paa";
                    condition = "true";
                    statement = "";
                    exceptions[] = {"isNotInside", "isNotSitting"};
                    showDisabled = 0;
                    class ACME_SyringeKit_Draw {
                        displayName = "Open Narc Box";
                        icon = "\acm_extended\ui\items\narc_box_ca.paa";
                        condition = "!isNil ""ACM_circulation_fnc_Syringe_Draw""";
                        statement = "ACME_infusion_pendingContext = nil; [10] call ACME_fnc_skOpenDraw";
                        exceptions[] = {"isNotInside", "isNotSitting"};
                        showDisabled = 1;
                    };
                    class ACME_SyringeKit_PushEpi {
                        displayName = "Draw Push-Dose Epi (10 mcg/mL)";
                        condition = "(([_player, 'ACM_SalineFlush_10'] call ace_common_fnc_getCountOfItem) > 0) && {([_player, 'EpinephrineCardiac'] call ACME_fnc_infusionVialVolume) >= 1}";
                        statement = "[_player, _player, '', ['pushDoseOneShot']] call ACME_fnc_salineFlush";
                        exceptions[] = {"isNotInside", "isNotSitting"};
                        showDisabled = 1;
                    };
                };
                class ACME_DrawnSyringes {
                    displayName = "Drawn Syringes";
                    icon = "\x\ACM\addons\circulation\ui\syringe_10_ca.paa";
                    condition = "!((_player getVariable ['ACME_narcStore', []]) isEqualTo [])";
                    statement = "";
                    insertChildren = "_this call ACME_fnc_skSyringeSelfMenu";
                    exceptions[] = {"isNotInside", "isNotSitting"};
                    showDisabled = 0;
                };
                class ACME_Take4U {
                    displayName = "Take Golden Hour 4U (overload)";
                    icon = "\acm_extended\ui\items\goldenhour_cswb4u_ca.paa";
                    condition = "(((nearestObjects [_player, ['AllVehicles','ReammoBox_F','WeaponHolderSimulated','GroundWeaponHolder'], 6]) findIf {_x != _player && {'ACME_BloodCooler_CSWB4U' in (itemCargo _x)}}) >= 0)";
                    statement = "call ACME_fnc_take4U";
                    exceptions[] = {"isNotInside", "isNotSitting"};
                    showDisabled = 0;
                };
                class ACME_BloodCooler {
                    displayName = "Blood Cooler";
                    icon = "\acm_extended\ui\items\goldenhour_cswb1u_ca.paa";
                    condition = "({_x in (items _player)} count ['ACME_BloodCooler_CSWB1U','ACME_BloodCooler_CSWB2U','ACME_BloodCooler_CSWB4U']) > 0";
                    statement = "";
                    exceptions[] = {"isNotInside", "isNotSitting"};
                    showDisabled = 0;
                    class ACME_BloodCooler_Open {
                        displayName = "Open Blood Cooler";
                        icon = "\acm_extended\ui\items\goldenhour_cswb1u_ca.paa";
                        condition = "({_x in (items _player)} count ['ACME_BloodCooler_CSWB1U','ACME_BloodCooler_CSWB2U','ACME_BloodCooler_CSWB4U']) > 0";
                        statement = "call ACME_fnc_coolerOpenCarried";
                        exceptions[] = {"isNotInside", "isNotSitting"};
                        showDisabled = 0;
                    };
                    class ACME_BloodCooler_SetDown {
                        displayName = "Set Down as Box";
                        icon = "\acm_extended\ui\items\goldenhour_cswb4u_ca.paa";
                        condition = "({_x in (items _player)} count ['ACME_BloodCooler_CSWB1U','ACME_BloodCooler_CSWB2U','ACME_BloodCooler_CSWB4U']) > 0";
                        statement = "call ACME_fnc_coolerBoxDeploy";
                        exceptions[] = {"isNotInside", "isNotSitting"};
                        showDisabled = 0;
                    };
                };
                class ACME_VentilatorOpen {
                    displayName = "Open Ventilator";
                    icon = "\acm_extended\ui\vent\ventway_sparrow_robust_ca.paa";
                    condition = "([_player, 'ACME_Ventilator'] call ace_common_fnc_getCountOfItem) > 0";
                    statement = "[] call ACME_fnc_ventPanelOpen";
                    exceptions[] = {"isNotInside", "isNotSitting"};
                    showDisabled = 0;
                };
            };
        };
        class ACE_Actions {
            class ACE_MainActions {
                class ACM_LyingState_GetUp {
                    condition = "!(isPlayer _target) && {(_target getVariable ['ACM_core_Lying_State', false]) && {alive _target} && {!(_target getVariable ['ACE_isUnconscious', false])} && {!(_target getVariable ['ace_evacuation_casualtyTicketClaimed', false])} && {!(_target getVariable ['ACME_obtunded', false])}}";
                    statement = "[_target, true] call ACM_core_fnc_getUp";
                };
                class ACME_LyingState_GetUp_Player {
                    displayName = "Get Up";
                    icon = "";
                    condition = "(isPlayer _target) && {_target getVariable ['ACM_core_Lying_State', false]} && {alive _target} && {!(_target getVariable ['ACE_isUnconscious', false])} && {!(_target getVariable ['ace_evacuation_casualtyTicketClaimed', false])}";
                    statement = "[_target, true] call ACM_core_fnc_getUp";
                    exceptions[] = {"isNotInside"};
                    showDisabled = 0;
                };
            };
        };
    };
    class Sound;
    class ACM_NRB_SoundSource: Sound {
        scope = 1;
        sound = "ACM_NRB_SFX";
    };
    class ACME_SyringeDraw_SoundSource: Sound {
        scope = 1;
        sound = "ACME_SyringeDraw_SFX";
    };
    class ACME_JunctionalPackLoop_SoundSource: Sound {
        scope = 1;
        sound = "ACME_JunctionalPackLoop_SFX";
    };
    class ACME_JunctionalPack_SoundSource: Sound {
        scope = 1;
        sound = "ACME_JunctionalPack_SFX";
    };
    class ACME_JunctionalLeak_SoundSource: Sound {
        scope = 1;
        sound = "ACME_JunctionalLeak_SFX";
    };
    class ACM_Suction_SoundSource: Sound {
        scope = 1;
        sound = "ACM_Suction_SFX";
    };
    class ACME_VentRun_SoundSource: Sound {
        scope = 1;
        sound = "ACME_VentRun_SFX";
    };
    class Module_F;
    class ACME_ModuleMegacodeKelly: Module_F {
        scope = 2;
        scopeCurator = 2;
        displayName = "Spawn Megacode Kelly";
        category = "ACME_Curator_Category";
        function = "ACME_fnc_megacodeModuleInit";
        functionPriority = 1;
        isGlobal = 0;
        isTriggerActivated = 0;
        is3DEN = 0;
        curatorCanAttach = 0;
        icon = "\a3\ui_f\data\IGUI\Cfg\Actions\heal_ca.paa";
        portrait = "\a3\ui_f\data\IGUI\Cfg\Actions\heal_ca.paa";
        class Arguments {};
        class ModuleDescription {
            description = "Spawns a controllable Megacode Kelly training manikin: a bare, gearless casualty locked in ACM_LyingState. Interact with it to open the instructor control panel (vitals, rhythms, airway, wounds, neuro/ICP).";
        };
    };
    class ACME_ModuleInflictEdema: Module_F {
        scope = 2;
        scopeCurator = 2;
        displayName = "Inflict Pulmonary Edema";
        category = "ACME_Curator_Category";
        function = "ACME_fnc_zeusInflictEdema";
        functionPriority = 1;
        isGlobal = 0;
        isTriggerActivated = 0;
        isDisposable = 1;
        curatorCanAttach = 1;
        class Arguments {};
        class ModuleDescription {
            description = "Floods the lungs with fluid overload. Recruitable shunt: PEEP treats it, oxygen alone does not.";
        };
    };
    class ACME_ModuleClearEdema: Module_F {
        scope = 2;
        scopeCurator = 2;
        displayName = "Clear Pulmonary Edema";
        category = "ACME_Curator_Category";
        function = "ACME_fnc_zeusClearEdema";
        functionPriority = 1;
        isGlobal = 0;
        isTriggerActivated = 0;
        isDisposable = 1;
        curatorCanAttach = 1;
        class Arguments {};
        class ModuleDescription {
            description = "Drains the fluid overload. The counterpart to Inflict Pulmonary Edema, so the same casualty can be run twice.";
        };
    };
    class ACME_ModuleInflictBlastLung: Module_F {
        scope = 2;
        scopeCurator = 2;
        displayName = "Inflict Blast Lung";
        category = "ACME_Curator_Category";
        function = "ACME_fnc_zeusInflictBlastLung";
        functionPriority = 1;
        isGlobal = 0;
        isTriggerActivated = 0;
        is3DEN = 0;
        curatorCanAttach = 1;
        icon = "\x\acm\addons\breathing\ui\chestseal_ca.paa";
        portrait = "\x\acm\addons\breathing\ui\chestseal_ca.paa";
        class Arguments {};
        class ModuleDescription {
            description = "Inflicts primary blast injury (blast lung) on the targeted casualty. The lung floods and stiffens: gas exchange collapses and they cannot be saved with a bag. They need intubation, high FiO2 and MECHANICAL VENTILATION. Because the lung is stiff, volume control (SIMV VC PS) drives the airway pressure into barotrauma and makes it worse. pressure control (SIMV PC) is the correct mode. Often accompanied by a pneumothorax.";
        };
    };
    class ACME_ModuleInflictJunctional: Module_F {
        scope = 2;
        scopeCurator = 2;
        displayName = "Inflict Junctional Bleed";
        category = "ACME_Curator_Category";
        function = "ACME_fnc_zeusInflictJunctional";
        functionPriority = 1;
        isGlobal = 0;
        isTriggerActivated = 0;
        is3DEN = 0;
        curatorCanAttach = 1;
        icon = "\z\ace\addons\medical_treatment\ui\tourniquet_ca.paa";
        portrait = "\z\ace\addons\medical_treatment\ui\tourniquet_ca.paa";
        class Arguments {};
        class ModuleDescription {
            description = "Places a junctional (axillary/inguinal) arterial hemorrhage on a random uninjured limb of the targeted casualty. Drop again for another limb. Controlled by direct pressure, packing, wraps, or an AAJT-S.";
        };
    };
    class ACME_ModuleInduceObtundation: Module_F {
        scope = 2;
        scopeCurator = 2;
        displayName = "Induce / Clear Obtundation";
        category = "ACME_Curator_Category";
        function = "ACME_fnc_zeusInduceObtundation";
        functionPriority = 1;
        isGlobal = 0;
        isTriggerActivated = 0;
        is3DEN = 0;
        curatorCanAttach = 1;
        icon = "\a3\ui_f\data\IGUI\Cfg\Actions\heal_ca.paa";
        portrait = "\a3\ui_f\data\IGUI\Cfg\Actions\heal_ca.paa";
        class Arguments {};
        class ModuleDescription {
            description = "Toggles the awake-but-down obtunded (back) state on the targeted casualty. Players get the full input-lock and blur experience; AI are placed in the locked back pose. Drop again to clear it.";
        };
    };
    class ACME_ModuleInflictTBI: Module_F {
        scope = 2;
        scopeCurator = 2;
        displayName = "Inflict TBI";
        category = "ACME_Curator_Category";
        function = "ACME_fnc_zeusInflictTBI";
        functionPriority = 1;
        isGlobal = 0;
        isTriggerActivated = 0;
        is3DEN = 0;
        curatorCanAttach = 1;
        icon = "\a3\ui_f\data\IGUI\Cfg\Actions\heal_ca.paa";
        portrait = "\a3\ui_f\data\IGUI\Cfg\Actions\heal_ca.paa";
        class Arguments {};
        class ModuleDescription {
            description = "Opens a dialog to set a traumatic brain injury on the targeted casualty: choose severity and an initial state (Mild / Moderate / Severe / Herniating). Drives the CPP/ICP model.";
        };
    };
    class ACME_ModuleInsertIV: Module_F {
        scope = 2;
        scopeCurator = 2;
        displayName = "Place IV";
        category = "ACME_Curator_Category";
        function = "ACME_fnc_zeusInsertIV";
        functionPriority = 1;
        isGlobal = 0;
        isTriggerActivated = 0;
        is3DEN = 0;
        curatorCanAttach = 1;
        icon = "\a3\ui_f\data\IGUI\Cfg\Actions\heal_ca.paa";
        portrait = "\a3\ui_f\data\IGUI\Cfg\Actions\heal_ca.paa";
        class Arguments {};
        class ModuleDescription {
            description = "Opens a dialog to place an IV on the targeted casualty: choose the limb, the access site and the gauge, 14g, 16g, 18g or 20g. The catheter hub is written to the limb so it can be pulled in the IV screen.";
        };
    };
    class ACME_ModuleClearTBI: Module_F {
        scope = 2;
        scopeCurator = 2;
        displayName = "Clear TBI";
        category = "ACME_Curator_Category";
        function = "ACME_fnc_zeusClearTBI";
        functionPriority = 1;
        isGlobal = 0;
        isTriggerActivated = 0;
        is3DEN = 0;
        curatorCanAttach = 1;
        icon = "\a3\ui_f\data\IGUI\Cfg\Actions\heal_ca.paa";
        portrait = "\a3\ui_f\data\IGUI\Cfg\Actions\heal_ca.paa";
        class Arguments {};
        class ModuleDescription {
            description = "Clears a traumatic brain injury and all ICP state from the targeted casualty (resolves ICP drive, herniation, evac flag and vitals offsets). Reverses Inflict TBI.";
        };
    };
    class Fridge_01_closed_F;
    class Fridge_01_open_F;
    class ACME_BloodFridge_Closed: Fridge_01_closed_F {
        scope = 1;
        scopeCurator = 0;
        displayName = "Blood Fridge (Stocked)";
        author = "PILLAR";
        class ACE_Actions {
            class ACE_MainActions {
                displayName = "Blood Fridge";
                selection = "";
                distance = 4;
                condition = "true";
                class ACME_bf_take {
                    displayName = "Take Blood Unit";
                    icon = "\z\ace\addons\medical_treatment\ui\bloodIV_ca.paa";
                    distance = 4;
                    condition = "true";
                    statement = "";
                    insertChildren = "_this call ACME_fnc_bloodFridgeTakeMenu";
                };
                class ACME_BF_Contents {
                    displayName = "Check Contents";
                    condition = "true";
                    statement = "[_target] call ACME_fnc_bloodFridgeContents";
                    icon = "\z\ace\addons\medical_treatment\ui\bloodIV_ca.paa";
                };
            };
        };
    };
    class ACME_BloodFridge_Open: Fridge_01_open_F {
        scope = 1;
        scopeCurator = 0;
        displayName = "Blood Fridge (Open)";
        author = "PILLAR";
        class ACE_Actions {
            class ACE_MainActions {
                displayName = "Blood Fridge";
                selection = "";
                distance = 4;
                condition = "true";
                class ACME_bf_take {
                    displayName = "Take Blood Unit";
                    icon = "\z\ace\addons\medical_treatment\ui\bloodIV_ca.paa";
                    distance = 4;
                    condition = "true";
                    statement = "";
                    insertChildren = "_this call ACME_fnc_bloodFridgeTakeMenu";
                };
                class ACME_BF_Contents {
                    displayName = "Check Contents";
                    condition = "true";
                    statement = "[_target] call ACME_fnc_bloodFridgeContents";
                    icon = "\z\ace\addons\medical_treatment\ui\bloodIV_ca.paa";
                };
            };
        };
    };
    class ACME_ModuleBloodFridge: Module_F {
        scope = 2;
        scopeCurator = 2;
        displayName = "Place Blood Fridge";
        category = "ACME_Curator_Category";
        function = "ACME_fnc_bloodFridgeModuleInit";
        functionPriority = 1;
        isGlobal = 0;
        isTriggerActivated = 0;
        is3DEN = 0;
        curatorCanAttach = 1;
        icon = "\z\ace\addons\medical_treatment\ui\bloodIV_ca.paa";
        portrait = "\z\ace\addons\medical_treatment\ui\bloodIV_ca.paa";
        class Arguments {
            class ONeg {
                displayName = "O- units";
                description = "500 mL units of O-negative (universal donor).";
                typeName = "NUMBER";
                defaultValue = 2;
            };
            class OPos {
                displayName = "O+ units";
                description = "500 mL units of O-positive.";
                typeName = "NUMBER";
                defaultValue = 6;
            };
            class ANeg {
                displayName = "A- units";
                description = "500 mL units of A-negative.";
                typeName = "NUMBER";
                defaultValue = 0;
            };
            class APos {
                displayName = "A+ units";
                description = "500 mL units of A-positive.";
                typeName = "NUMBER";
                defaultValue = 0;
            };
            class BNeg {
                displayName = "B- units";
                description = "500 mL units of B-negative.";
                typeName = "NUMBER";
                defaultValue = 0;
            };
            class BPos {
                displayName = "B+ units";
                description = "500 mL units of B-positive.";
                typeName = "NUMBER";
                defaultValue = 0;
            };
            class ABNeg {
                displayName = "AB- units";
                description = "500 mL units of AB-negative.";
                typeName = "NUMBER";
                defaultValue = 0;
            };
            class ABPos {
                displayName = "AB+ units";
                description = "500 mL units of AB-positive.";
                typeName = "NUMBER";
                defaultValue = 0;
            };
            class Restock {
                displayName = "Restock periodically";
                description = "If yes, the fridge refills to its configured load every regen interval below.";
                typeName = "BOOL";
                defaultValue = 1;
            };
            class RegenMins {
                displayName = "Regen interval (in-game minutes)";
                description = "In-game minutes between regenerations. 1440 = 24 in-game hours (default). 0 = never regenerate. -1 = use the addon-option interval.";
                typeName = "NUMBER";
                defaultValue = 1440;
            };
        };
        class ModuleDescription {
            description = "Places a stocked blood fridge. Set per-type unit counts (defaults 2x O-, 6x O+) and daily restock. ACE-interact to take units; blood keeps indefinitely while inside and the model opens while anyone is using it.";
        };
    };
};
class ACM_MedicalMenu_ActionButton_None;
class ACM_MedicalMenu_ActionButton_ACM_NRBMask: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\acm_extended\ui\items\nrbmask_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_HPMK: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\acm_extended\ui\items\HPMK_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACME_AAJT: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\acm_extended\ui\items\aajt-s_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACME_Ventilator: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\acm_extended\ui\vent\ventway_sparrow_robust_icon_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_EMMA: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\acm_extended\ui\emma\emma_etco2_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACME_iGel_Remove: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\acm_extended\ui\items\igel_remove_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACME_IV_18g: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\acm_extended\ui\items\iv_18g_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACME_IV_20g: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\acm_extended\ui\items\iv_20g_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACME_NARSPEAR: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\acm_extended\ui\items\nar_spear_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACME_Spray_Esketamine: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\acm_extended\ui\items\esketamine_in_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACME_CombatGauze: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\acm_extended\ui\items\combat_gauze_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACME_XStat: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\acm_extended\ui\items\xstat_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACME_NarcBox: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\acm_extended\ui\items\narc_box_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACME_EstablishIV: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\acm_extended\ui\items\establish_iv_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACE_tourniquet;
class ACM_MedicalMenu_ActionButton_ACE_surgicalKit;
class ACM_MedicalMenu_ActionButton_ACE_personalAidKit;
class ACM_MedicalMenu_ActionButton_ACE_bodyBag;
class ACM_MedicalMenu_ActionButton_ACE_bodyBag_blue;
class ACM_MedicalMenu_ActionButton_ACE_bodyBag_white;
class ACM_MedicalMenu_ActionButton_ACE_adenosine;
class ACM_MedicalMenu_ActionButton_ACE_epinephrine;
class ACM_MedicalMenu_ActionButton_CPR;
class ACM_MedicalMenu_ActionButton_ACE_morphine;
class ACM_MedicalMenu_ActionButton_ACM_OPA;
class ACM_MedicalMenu_ActionButton_ACM_IGel;
class ACM_MedicalMenu_ActionButton_ACM_NPA;
class ACM_MedicalMenu_ActionButton_ACM_SuctionBag;
class ACM_MedicalMenu_ActionButton_ACM_ACCUVAC;
class ACM_MedicalMenu_ActionButton_ACM_CricKit;
class ACM_MedicalMenu_ActionButton_ACM_ChestSeal;
class ACM_MedicalMenu_ActionButton_ACM_PulseOximeter;
class ACM_MedicalMenu_ActionButton_ACM_Stethoscope;
class ACM_MedicalMenu_ActionButton_ACM_NCDKit;
class ACM_MedicalMenu_ActionButton_ACM_ChestTubeKit;
class ACM_MedicalMenu_ActionButton_ACM_ThoracostomyKit;
class ACM_MedicalMenu_ActionButton_ACM_PocketBVM;
class ACM_MedicalMenu_ActionButton_ACM_BVM;
class ACM_MedicalMenu_ActionButton_ACM_AED;
class ACM_MedicalMenu_ActionButton_ACM_PressureCuff;
class ACM_MedicalMenu_ActionButton_ACM_IO_FAST;
class ACM_MedicalMenu_ActionButton_ACM_IO_EZ;
class ACM_MedicalMenu_ActionButton_ACM_Syringe_10;
class ACM_MedicalMenu_ActionButton_ACM_Syringe_5;
class ACM_MedicalMenu_ActionButton_ACM_Syringe_3;
class ACM_MedicalMenu_ActionButton_ACM_Syringe_1;
class ACM_MedicalMenu_ActionButton_ACM_Spray_Naloxone;
class ACM_MedicalMenu_ActionButton_ACM_Paracetamol;
class ACM_MedicalMenu_ActionButton_ACM_AmmoniaInhalant;
class ACM_MedicalMenu_ActionButton_ACM_Inhaler_Penthrox;
class ACM_MedicalMenu_ActionButton_ACM_Lozenge_Fentanyl;
class ACM_MedicalMenu_ActionButton_ACM_PressureBandage;
class ACM_MedicalMenu_ActionButton_ACM_EmergencyTraumaDressing;
class ACM_MedicalMenu_ActionButton_ACM_ElasticWrap;
class ACM_MedicalMenu_ActionButton_ACM_SAMSplint;
class ACM_MedicalMenu_ActionButton_ACM_ATNA_Autoinjector;
class ACM_MedicalMenu_ActionButton_ACM_Midazolam_Autoinjector;
class ACM_MedicalMenu_ActionButton_ACM_IV_16G {
    textureNoShortcut = "\acm_extended\ui\items\iv_16g_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_IV_14G {
    textureNoShortcut = "\acm_extended\ui\items\iv_14g_ca.paa";
};
class ACM_MedicalMenu_ActionButton_L_None: ACM_MedicalMenu_ActionButton_None {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACE_tourniquet: ACM_MedicalMenu_ActionButton_ACE_tourniquet {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACE_surgicalKit: ACM_MedicalMenu_ActionButton_ACE_surgicalKit {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACE_personalAidKit: ACM_MedicalMenu_ActionButton_ACE_personalAidKit {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACE_bodyBag: ACM_MedicalMenu_ActionButton_ACE_bodyBag {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACE_bodyBag_blue: ACM_MedicalMenu_ActionButton_ACE_bodyBag_blue {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACE_bodyBag_white: ACM_MedicalMenu_ActionButton_ACE_bodyBag_white {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACE_adenosine: ACM_MedicalMenu_ActionButton_ACE_adenosine {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACE_epinephrine: ACM_MedicalMenu_ActionButton_ACE_epinephrine {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_CPR: ACM_MedicalMenu_ActionButton_CPR {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACE_morphine: ACM_MedicalMenu_ActionButton_ACE_morphine {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_OPA: ACM_MedicalMenu_ActionButton_ACM_OPA {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_IGel: ACM_MedicalMenu_ActionButton_ACM_IGel {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_NPA: ACM_MedicalMenu_ActionButton_ACM_NPA {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_SuctionBag: ACM_MedicalMenu_ActionButton_ACM_SuctionBag {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_ACCUVAC: ACM_MedicalMenu_ActionButton_ACM_ACCUVAC {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_CricKit: ACM_MedicalMenu_ActionButton_ACM_CricKit {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_ChestSeal: ACM_MedicalMenu_ActionButton_ACM_ChestSeal {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_PulseOximeter: ACM_MedicalMenu_ActionButton_ACM_PulseOximeter {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_Stethoscope: ACM_MedicalMenu_ActionButton_ACM_Stethoscope {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_NCDKit: ACM_MedicalMenu_ActionButton_ACM_NCDKit {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_ChestTubeKit: ACM_MedicalMenu_ActionButton_ACM_ChestTubeKit {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_ThoracostomyKit: ACM_MedicalMenu_ActionButton_ACM_ThoracostomyKit {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_PocketBVM: ACM_MedicalMenu_ActionButton_ACM_PocketBVM {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_BVM: ACM_MedicalMenu_ActionButton_ACM_BVM {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_AED: ACM_MedicalMenu_ActionButton_ACM_AED {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_PressureCuff: ACM_MedicalMenu_ActionButton_ACM_PressureCuff {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_IV_16G: ACM_MedicalMenu_ActionButton_ACM_IV_16G {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_IV_14G: ACM_MedicalMenu_ActionButton_ACM_IV_14G {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_IO_FAST: ACM_MedicalMenu_ActionButton_ACM_IO_FAST {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_IO_EZ: ACM_MedicalMenu_ActionButton_ACM_IO_EZ {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_Syringe_10: ACM_MedicalMenu_ActionButton_ACM_Syringe_10 {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_Syringe_5: ACM_MedicalMenu_ActionButton_ACM_Syringe_5 {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_Syringe_3: ACM_MedicalMenu_ActionButton_ACM_Syringe_3 {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_Syringe_1: ACM_MedicalMenu_ActionButton_ACM_Syringe_1 {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_Spray_Naloxone: ACM_MedicalMenu_ActionButton_ACM_Spray_Naloxone {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_Paracetamol: ACM_MedicalMenu_ActionButton_ACM_Paracetamol {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_AmmoniaInhalant: ACM_MedicalMenu_ActionButton_ACM_AmmoniaInhalant {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_Inhaler_Penthrox: ACM_MedicalMenu_ActionButton_ACM_Inhaler_Penthrox {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_Lozenge_Fentanyl: ACM_MedicalMenu_ActionButton_ACM_Lozenge_Fentanyl {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_PressureBandage: ACM_MedicalMenu_ActionButton_ACM_PressureBandage {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_EmergencyTraumaDressing: ACM_MedicalMenu_ActionButton_ACM_EmergencyTraumaDressing {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_ElasticWrap: ACM_MedicalMenu_ActionButton_ACM_ElasticWrap {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_SAMSplint: ACM_MedicalMenu_ActionButton_ACM_SAMSplint {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_ATNA_Autoinjector: ACM_MedicalMenu_ActionButton_ACM_ATNA_Autoinjector {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_Midazolam_Autoinjector: ACM_MedicalMenu_ActionButton_ACM_Midazolam_Autoinjector {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_NRBMask: ACM_MedicalMenu_ActionButton_ACM_NRBMask {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_HPMK: ACM_MedicalMenu_ActionButton_ACM_HPMK {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACME_AAJT: ACM_MedicalMenu_ActionButton_ACME_AAJT {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACM_EMMA: ACM_MedicalMenu_ActionButton_ACM_EMMA {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACME_iGel_Remove: ACM_MedicalMenu_ActionButton_ACME_iGel_Remove {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACME_IV_18g: ACM_MedicalMenu_ActionButton_ACME_IV_18g {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACME_IV_20g: ACM_MedicalMenu_ActionButton_ACME_IV_20g {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACME_NARSPEAR: ACM_MedicalMenu_ActionButton_ACME_NARSPEAR {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACME_Spray_Esketamine: ACM_MedicalMenu_ActionButton_ACME_Spray_Esketamine {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACME_CombatGauze: ACM_MedicalMenu_ActionButton_ACME_CombatGauze {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACME_XStat: ACM_MedicalMenu_ActionButton_ACME_XStat {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACME_NarcBox: ACM_MedicalMenu_ActionButton_ACME_NarcBox {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACME_EstablishIV: ACM_MedicalMenu_ActionButton_ACME_EstablishIV {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ACM_MedicalMenu_ActionButton_L_ACME_Ventilator: ACM_MedicalMenu_ActionButton_ACME_Ventilator {
    style = 0;
    class Attributes {
        align = "left";
        color = "#E5E5E5";
        font = "RobotoCondensed";
        shadow = "false";
    };
    class TextPos {
        left = "0.013 + 1.35 * (((safezoneW / safezoneH) min 1.2) / 40)";
        top = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) - (((safezoneW / safezoneH) min 1.2) / 40)) / 2";
        right = 0.005;
        bottom = 0;
    };
};
class ace_medical_treatment_actions {
    class CheckPulse;
    class InspectForFracture: CheckPulse {
        callbackSuccess = "ACME_fnc_inspectForFracture";
    };
    class RemoveOPA;
    class RemoveIGel: RemoveOPA {
        icon = "\acm_extended\ui\items\igel_remove_ca.paa";
        ACM_menuIcon = "ACME_iGel_Remove";
    };
    class CheckAirway {
        treatmentTime = "['CheckAirway'] call ACME_fnc_assessmentTime";
        animationMedic = "";
        animationMedicProne = "";
        animationMedicSelf = "";
        animationMedicSelfProne = "";
        condition = "ACM_airway_enable && {!(_patient call ace_common_fnc_isAwake)}";
        callbackStart = "";
        callbackProgress = "_this call ACME_fnc_assessmentProgress";
        callbackSuccess = "_this call ACM_airway_fnc_checkAirway; [_this] call ACME_fnc_assessmentFinish";
        callbackFailure = "[_this] call ACME_fnc_assessmentFinish";
    };
    class RecoveryPosition: CheckAirway {
        displayName = "$STR_ACM_Airway_EstablishRecoveryPosition";
        displayNameProgress = "$STR_ACM_Airway_EstablishRecoveryPosition_Progress";
        icon = "";
        medicRequired = 0;
        treatmentTime = 3;
        allowedSelections[] = {"Body"};
        condition = "alive _patient && {ACM_airway_enable} && {!(_patient call ace_common_fnc_isAwake)} && {(_patient getVariable ['ACM_airway_AirwayItem_Oral','']) != 'SGA'} && {!(_patient getVariable ['ACME_ETT_Inserted',false])} && {!(_patient getVariable ['ACME_vent_driving',false])} && {!(_patient getVariable ['ACM_airway_RecoveryPosition_State',false])} && {isNull objectParent _patient}";
        callbackSuccess = "[_medic,_patient,true] call ACM_airway_fnc_setRecoveryPosition";
        ACM_rollToBack = 0;
    };
    class CheckResponse: CheckPulse {
        displayName = "$STR_ACE_Medical_Treatment_Check_Response";
        displayNameProgress = "$STR_ACE_Medical_Treatment_Check_Response_Content";
        category = "examine";
        allowedSelections[] = {"Head"};
        allowSelfTreatment = 0;
        treatmentTime = 5;
        condition = "true";
        callbackStart = "if (toLower (_this param [3, '']) == 'checkresponse') then {[(_this param [0, objNull]), 'response', 5] call ACME_fnc_treatmentPoseStart}";
        callbackSuccess = "_this call ace_medical_treatment_fnc_checkResponse; [_medic, 'response'] call ACME_fnc_treatmentPoseStop";
        callbackFailure = "[_medic, 'response'] call ACME_fnc_treatmentPoseStop";
        animationMedic = "";
        animationMedicProne = "";
        animationMedicSelf = "";
        animationMedicSelfProne = "";
    };
    class CheckDogTags: CheckResponse {
        condition = "ACME_fnc_canCheckPatientDogtags";
    };
    class ShakeAwake;
    class SlapAwake: ShakeAwake {
        displayName = "$STR_ACM_Disability_SlapAwake";
        displayNameProgress = "$STR_ACM_Disability_SlapAwake_Progress";
        allowedSelections[] = {"Head"};
        treatmentTime = 2;
        condition = "!([_patient] call ace_common_fnc_isAwake)";
        callbackSuccess = "ACM_disability_fnc_slapAwake";
        animationMedic = "AinvPknlMstpSnonWnonDr_medic3";
        ACM_rollToBack = 1;
        ACM_ignoreAnimCoef = 1;
    };
    class CheckBreathing {
        treatmentTime = 2;
        animationMedic = "";
        animationMedicProne = "";
        animationMedicSelf = "";
        animationMedicSelfProne = "";
        callbackStart = "";
        callbackProgress = "_this call ACME_fnc_assessmentProgress";
        callbackSuccess = "_this call ACM_breathing_fnc_checkBreathing; [_this] call ACME_fnc_assessmentFinish";
        callbackFailure = "[_this] call ACME_fnc_assessmentFinish";
        condition = "true";
    };
    class UseStethoscope {
        ACM_rollToBack = 0;
        ACME_neverRollToBack = 1;
        animationMedic = "";
        animationMedicProne = "";
        animationMedicSelf = "";
        animationMedicSelfProne = "";
        callbackStart = "";
        callbackSuccess = "private _a = +_this; private _p = _a param [1,objNull]; private _ready = if (isNull _p) then {-1} else {_p getVariable ['ACME_headElev_suspendReadyAt',-1]}; if (!isNull _p && {_p getVariable ['ACME_headElev_Suspended',false]} && {_ready > CBA_missionTime}) then {[{_this call ACM_breathing_fnc_useStethoscope},_a,((_ready - CBA_missionTime) max 0.05) + 0.05] call CBA_fnc_waitAndExecute} else {_a call ACM_breathing_fnc_useStethoscope}";
    };
    class CheckCapillaryRefill {
        animationMedic = "AmovPknlMstpSrasWpstDnon_AmovPknlMstpSrasWpstDnon_gear";
        animationMedicProne = "AmovPknlMstpSrasWpstDnon_AmovPknlMstpSrasWpstDnon_gear";
    };
    class InsertOPA: CheckAirway {
        callbackStart = "";
        animationMedic = "AinvPknlMstpSnonWnonDr_medic4";
        animationMedicProne = "AinvPknlMstpSnonWnonDr_medic4";
        displayName = "$STR_ACM_Airway_InsertOPA";
        displayNameProgress = "$STR_ACM_Airway_InsertOPA_Progress";
        icon = "";
        medicRequired = "ACM_airway_allowOPA";
        treatmentTime = "ACM_airway_treatmentTimeOPA";
        items[] = {"ACM_OPA"};
        consumeItem = 1;
        condition = "ACM_airway_enable && !(_patient call ace_common_fnc_isAwake) && (_patient getVariable ['ACM_airway_AirwayItem_Oral','']) == '' && !(_patient getVariable ['ACME_ETT_Inserted', false]) && !(_patient getVariable ['ACM_airway_SurgicalAirway_TubeInserted', false])";
        callbackSuccess = "[_medic, _patient, 'OPA'] call ACM_airway_fnc_insertAirwayItem";
        ACM_cancelRecovery = 1;
        ACM_menuIcon = "ACM_OPA";
    };
    class InsertNPA: InsertOPA {
        displayName = "$STR_ACM_Airway_InsertNPA";
        displayNameProgress = "$STR_ACM_Airway_InsertNPA_Progress";
        icon = "";
        medicRequired = "ACM_airway_allowNPA";
        treatmentTime = "ACM_airway_treatmentTimeNPA";
        items[] = {"ACM_NPA"};
        condition = "ACM_airway_enable && !(_patient call ace_common_fnc_isAwake) && (_patient getVariable ['ACM_airway_AirwayItem_Nasal','']) == '' && !(_patient getVariable ['ACME_ETT_Inserted', false]) && !(_patient getVariable ['ACM_airway_SurgicalAirway_TubeInserted', false])";
        callbackSuccess = "[_medic, _patient, 'NPA'] call ACM_airway_fnc_insertAirwayItem";
        ACM_menuIcon = "ACM_NPA";
    };
    class InsertIGel: InsertOPA {
        displayName = "$STR_ACM_Airway_InsertIGel";
        displayNameProgress = "$STR_ACM_Airway_InsertIGel_Progress";
        icon = "";
        medicRequired = "ACM_airway_allowSGA";
        treatmentTime = "ACM_airway_treatmentTimeSGA";
        items[] = {"ACM_IGel"};
        condition = "ACM_airway_enable && !(_patient call ace_common_fnc_isAwake) && (_patient getVariable ['ACM_airway_AirwayItem_Oral','']) == '' && !(_patient getVariable ['ACME_ETT_Inserted', false]) && !(_patient getVariable ['ACM_airway_SurgicalAirway_TubeInserted', false]) && !(_patient getVariable ['ACME_nrb_on', false])";
        callbackSuccess = "[_medic, _patient, 'SGA'] call ACM_airway_fnc_insertAirwayItem";
        ACM_menuIcon = "ACM_IGel";
    };
    class AED_ApplyPads;
    class AED_RemovePads;
    class AED_ViewMonitor: CheckPulse {
        category = "advanced";
    };
    class AED_AnalyzeRhythm: AED_ViewMonitor {
        category = "advanced";
    };
    class AED_MeasureBP: AED_AnalyzeRhythm {
        category = "advanced";
    };
    class AED_ConnectPulseOximeter: AED_ApplyPads {
        category = "advanced";
    };
    class AED_DisconnectPulseOximeter: AED_RemovePads {
        category = "advanced";
    };
    class AED_ConnectPressureCuff: AED_ApplyPads {
        category = "advanced";
    };
    class AED_DisconnectPressureCuff: AED_RemovePads {
        category = "advanced";
    };
    class AED_ConnectCapnograph: AED_ApplyPads {
        category = "advanced";
    };
    class AED_DisconnectCapnograph: AED_RemovePads {
        category = "advanced";
    };
    class CheckBloodPressure;
    class MeasureBloodPressure: CheckBloodPressure {
        callbackSuccess = "[_medic, _patient, _bodyPart, false] call ACME_fnc_measureBPWrap";
    };
    class MeasureBloodPressureStethoscope: MeasureBloodPressure {
        callbackSuccess = "[_medic, _patient, _bodyPart, true] call ACME_fnc_measureBPWrap";
    };
    class InsertIV_16_Upper {
        condition = "false";
    };
    class InsertIV_16_Middle {
        condition = "false";
    };
    class InsertIV_16_Lower {
        condition = "false";
    };
    class InsertIV_14_Upper {
        condition = "false";
    };
    class InsertIV_14_Middle {
        condition = "false";
    };
    class InsertIV_14_Lower {
        condition = "false";
    };
    class InsertIV_18_Upper {
        condition = "false";
    };
    class InsertIV_18_Middle {
        condition = "false";
    };
    class InsertIV_18_Lower {
        condition = "false";
    };
    class RemoveIV_16_Upper {
        condition = "false";
    };
    class RemoveIV_16_Middle {
        condition = "false";
    };
    class RemoveIV_16_Lower {
        condition = "false";
    };
    class RemoveIV_14_Upper {
        condition = "false";
    };
    class RemoveIV_14_Middle {
        condition = "false";
    };
    class RemoveIV_14_Lower {
        condition = "false";
    };
    class RemoveIO_FAST1 {
        condition = "false";
    };
    class RemoveIO_EZ {
        condition = "false";
    };
    class ACME_RemoveIO_FAST1 {
        displayName = "$STR_ACM_Circulation_RemoveIO_FAST1";
        displayNameProgress = "$STR_ACM_Circulation_RemoveIO_FAST1_Progress";
        icon = "";
        category = "advanced";
        treatmentLocations = 0;
        medicRequired = 0;
        treatmentTime = 3.5;
        allowedSelections[] = {"Body"};
        allowSelfTreatment = 0;
        items[] = {};
        consumeItem = 0;
        condition = "[_patient, _bodyPart, 4] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 4, false, false] call ACM_circulation_fnc_setIV";
        ACM_menuIcon = "ACM_IO_FAST";
    };
    class ACME_RemoveIO_EZ: ACME_RemoveIO_FAST1 {
        displayName = "$STR_ACM_Circulation_RemoveIO_EZ";
        displayNameProgress = "$STR_ACM_Circulation_RemoveIO_EZ_Progress";
        allowedSelections[] = {"LeftArm", "RightArm", "LeftLeg", "RightLeg"};
        condition = "[_patient, _bodyPart, 3] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 3, false, false] call ACM_circulation_fnc_setIV";
        ACM_menuIcon = "ACM_IO_EZ";
    };
    class InsertIO_FAST1: InsertIV_16_Upper {
        callbackStart = "_medic setVariable ['ACME_ioSupplySource', [_patient, _bodyPart, _itemUser, _usedItem, if (_createLitter) then {objNull} else {objectParent _itemUser}, _createLitter || {!(_medic isEqualTo player && {_isInZeus}) && {!isNull objectParent _itemUser}}]];";
        callbackFailure = "private _source = _medic getVariable ['ACME_ioSupplySource', []]; if ((_source select [0,4]) isEqualTo [_patient, _bodyPart, _itemUser, _usedItem]) then {_medic setVariable ['ACME_ioSupplySource', nil];};";
        callbackSuccess = "[_medic, _patient, _bodyPart, 4, true, false, -1, [_itemUser, _usedItem]] call ACM_circulation_fnc_setIV;";
    };
    class InsertIO_EZ: InsertIO_FAST1 {
        callbackSuccess = "[_medic, _patient, _bodyPart, 3, true, false, -1, [_itemUser, _usedItem]] call ACM_circulation_fnc_setIV;";
    };
    class Naloxone;
    class ACME_Esketamine_IN: Naloxone {
        displayName = "Use Esketamine (IN)";
        displayNameProgress = "Administering intranasal esketamine...";
        items[] = {"ACME_Spray_Esketamine"};
        treatmentTime = 4;
        medicRequired = 0;
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Esketamine', _itemUser, _usedItem, _createLitter, 1, false] call ace_medical_treatment_fnc_medication";
        ACM_rollToBack = "false";
        sounds[] = {};
        ACM_menuIcon = "ACME_Spray_Esketamine";
    };
    class ACME_ManualRemovePlateCarrier: CheckPulse {
        displayName = "Remove Plate Carrier";
        displayNameProgress = "";
        category = "advanced";
        treatmentLocations[] = {"All"};
        medicRequired = 0;
        allowSelfTreatment = 0;
        treatmentTime = 0.001;
        allowedSelections[] = {"Body"};
        condition = "[_medic, _patient, false] call ACME_fnc_manualPlateCarrierCanToggle";
        callbackStart = "";
        callbackSuccess = "[_patient, 'manualPlateCarrier', [_medic, _patient, false]] call ACME_fnc_ownerDispatch";
        callbackFailure = "";
        callbackProgress = "";
        animationMedic = "";
        animationMedicProne = "";
        animationMedicSelf = "";
        animationMedicSelfProne = "";
        ACM_rollToBack = 0;
        items[] = {};
        consumeItem = 0;
        ACM_menuIcon = "";
    };
    class ACME_ManualReplacePlateCarrier: ACME_ManualRemovePlateCarrier {
        displayName = "Replace Plate Carrier";
        condition = "[_medic, _patient, true] call ACME_fnc_manualPlateCarrierCanToggle";
        callbackSuccess = "[_patient, 'manualPlateCarrier', [_medic, _patient, true]] call ACME_fnc_ownerDispatch";
    };
    class InspectChest {
        condition = "false";
    };
    class ACME_InspectChest: CheckBreathing {
        displayName = "Inspect Chest";
        displayNameProgress = "Inspecting chest...";
        icon = "";
        category = "airway";
        treatmentLocations[] = {"All"};
        medicRequired = "ACM_breathing_allowInspectChest";
        treatmentTime = 6;
        allowedSelections[] = {"Body"};
        allowSelfTreatment = 1;
        condition = "!isNull _patient && {_patient isKindOf 'CAManBase'}";
        callbackStart = "_this call ACME_fnc_inspectChestPoseStart";
        callbackSuccess = "[_medic,_patient] call ACM_breathing_fnc_inspectChest; [_medic] call ACME_fnc_inspectChestPoseStop";
        callbackFailure = "[_medic, true] call ACME_fnc_inspectChestPoseStop";
        callbackProgress = "";
        animationMedic = "";
        animationMedicProne = "";
        animationMedicSelf = "";
        animationMedicSelfProne = "";
        ACM_rollToBack = "false";
        ACM_cancelRecovery = 1;
    };
    class ApplyChestSeal {
        condition = "false";
    };
    class PerformThoracostomy: ApplyChestSeal {
        condition = "false";
    };
    class ACME_PerformThoracostomy: CheckPulse {
        displayName = "Perform Thoracostomy";
        displayNameProgress = "Performing thoracostomy...";
        category = "airway";
        treatmentLocations[] = {"All"};
        medicRequired = "ACM_breathing_allowThoracostomy";
        allowSelfTreatment = 0;
        treatmentTime = 1;
        allowedSelections[] = {"Body"};
        condition = "([_medic, 'ACME_PerformThoracostomy'] call ACME_fnc_procedureActionAllowed) && {!isNull _patient && {_patient isKindOf 'CAManBase'} && {(_patient getVariable ['ACM_breathing_Thoracostomy_State', 0]) < 1} && {([_medic, _patient] call ACME_fnc_thoraKitItem) != ''}}";
        callbackStart = "";
        callbackSuccess = "[_this select 0, _this select 1, _this select 2] call ACME_fnc_thoraOpen";
        callbackFailure = "";
        callbackProgress = "";
        consumeItem = 0;
        items[] = {};
        ACM_menuIcon = "ACM_ThoracostomyKit";
        ACM_cancelRecovery = 1;
    };
    class ACME_AdjustThoracostomy: ACME_PerformThoracostomy {
        displayName = "Adjust Thoracostomy";
        displayNameProgress = "Opening thoracostomy...";
        condition = "([_medic, 'ACME_AdjustThoracostomy'] call ACME_fnc_procedureActionAllowed) && {!isNull _patient && {[_medic, _patient, true] call ACME_fnc_thoraCanOpen}}";
        medicRequired = 0;
    };
    class ACME_InsertChestTube: ACME_PerformThoracostomy {
        displayName = "Insert Chest Tube";
        displayNameProgress = "Opening thoracostomy...";
        items[] = {"ACM_ChestTubeKit"};
        consumeItem = 0;
        condition = "([_medic, 'ACME_InsertChestTube'] call ACME_fnc_procedureActionAllowed) && {!isNull _patient && {(_patient getVariable ['ACM_breathing_Thoracostomy_State', 0]) == 1} && {(((_patient getVariable ['ACME_thora_open_left', '']) == 'finger') && {!(_patient getVariable ['ACME_thora_closed_left', false])} && {!(_patient getVariable ['ACME_thora_sealed_left', false])}) || (((_patient getVariable ['ACME_thora_open_right', '']) == 'finger') && {!(_patient getVariable ['ACME_thora_closed_right', false])} && {!(_patient getVariable ['ACME_thora_sealed_right', false])})}}";
        callbackSuccess = "[_this select 0, _this select 1, _this select 2] call ACME_fnc_thoraOpen";
        ACM_menuIcon = "ACM_ChestTubeKit";
        medicRequired = "ACME_skillChestTube";
    };
    class ACME_DrainFluid_ACCUVAC: ACME_PerformThoracostomy {
        displayName = "Drain Fluid (ACCUVAC)";
        displayNameProgress = "Draining fluid...";
        items[] = {"ACM_ACCUVAC"};
        condition = "([_medic, 'ACME_DrainFluid_ACCUVAC'] call ACME_fnc_procedureActionAllowed) && {!isNull _patient && {(_patient getVariable ['ACM_breathing_Thoracostomy_State', 0]) in [2,3]}}";
        callbackSuccess = "[_this select 0, _this select 1, 'drain', 1] call ACME_fnc_thoraAftercare";
        ACM_menuIcon = "ACM_ACCUVAC";
        medicRequired = "ACM_breathing_allowThoracostomy";
    };
    class ACME_DrainFluid_SuctionBag: ACME_DrainFluid_ACCUVAC {
        displayName = "Drain Fluid (Suction Bag)";
        treatmentTime = 8;
        items[] = {"ACM_SuctionBag"};
        consumeItem = 0;
        callbackSuccess = "[_this select 0, _this select 1, 'drain', 0] call ACME_fnc_thoraAftercare";
        ACM_menuIcon = "ACM_SuctionBag";
        condition = "([_medic, 'ACME_DrainFluid_SuctionBag'] call ACME_fnc_procedureActionAllowed) && {!isNull _patient && {(_patient getVariable ['ACM_breathing_Thoracostomy_State', 0]) in [2,3]}}";
    };
    class ACME_ResealChestTube: ACME_PerformThoracostomy {
        displayName = "Reseal Chest Tube";
        displayNameProgress = "Resealing chest tube...";
        condition = "([_medic, 'ACME_ResealChestTube'] call ACME_fnc_procedureActionAllowed) && {!isNull _patient && {(_patient getVariable ['ACM_breathing_Thoracostomy_State', 0]) == 3}}";
        callbackSuccess = "[_this select 0, _this select 1, 'reseal'] call ACME_fnc_thoraAftercare";
        ACM_menuIcon = "ACM_ChestTubeKit";
        medicRequired = "ACM_breathing_allowThoracostomy";
    };
    class ACME_CloseIncision: ACME_PerformThoracostomy {
        displayName = "Close Incision (Suture)";
        displayNameProgress = "Suturing incision closed...";
        condition = "([_medic, 'ACME_CloseIncision'] call ACME_fnc_procedureActionAllowed) && {!isNull _patient && {(([_medic, _patient, ['ACE_surgicalKit']] call ace_medical_treatment_fnc_hasItem) || {_patient getVariable ['ACM_breathing_Thoracostomy_UsedKit', false]})} && {(_patient getVariable ['ACM_breathing_Thoracostomy_State', 0]) > 0} && {!(_patient getVariable ['ACME_thora_tube_left', false])} && {!(_patient getVariable ['ACME_thora_tube_right', false])} && {!(_patient getVariable ['ACME_thora_closed_left', false])} && {!(_patient getVariable ['ACME_thora_closed_right', false])}}";
        callbackSuccess = "[_this select 0, _this select 1, 'close'] call ACME_fnc_thoraAftercare";
        ACM_menuIcon = "ACE_surgicalKit";
        medicRequired = "ACM_breathing_allowThoracostomy";
    };
    class ACME_SutureChestTube: ACME_PerformThoracostomy {
        displayName = "Suture Chest Tube";
        treatmentTime = 0.001;
        displayNameProgress = "Suturing chest tube in place...";
        condition = "([_medic, 'ACME_SutureChestTube'] call ACME_fnc_procedureActionAllowed) && {!isNull _patient && {(([_medic, _patient, ['ACE_surgicalKit']] call ace_medical_treatment_fnc_hasItem) || {_patient getVariable ['ACM_breathing_Thoracostomy_UsedKit', false]})} && {((_patient getVariable ['ACME_thora_tube_left', false]) && {!(_patient getVariable ['ACME_thora_sealed_left', false])}) || ((_patient getVariable ['ACME_thora_tube_right', false]) && {!(_patient getVariable ['ACME_thora_sealed_right', false])})}}";
        callbackSuccess = "_this call ACME_fnc_thoraSutureTube";
        ACM_menuIcon = "ACE_surgicalKit";
        medicRequired = "ACM_breathing_allowThoracostomy";
    };
    class InsertChestTube {
        condition = "false";
    };
    class ResealChestTube {
        condition = "false";
    };
    class DrainFluid_ACCUVAC {
        condition = "false";
    };
    class DrainFluid_SuctionBag {
        condition = "false";
    };
    class CloseIncision {
        condition = "false";
    };
    class ACME_ApplyChestSeal: CheckPulse {
        displayName = "Apply Chest Seal";
        displayNameProgress = "Applying chest seal...";
        category = "airway";
        treatmentLocations[] = {"All"};
        medicRequired = 0;
        allowSelfTreatment = 1;
        treatmentTime = 0.4;
        allowedSelections[] = {"Body"};
        ACM_rollToBack = "false";
        condition = "[_patient] call ACME_fnc_chestSealCanApply";
        callbackStart = "";
        callbackSuccess = "_this call ACME_fnc_chestSealOpen";
        callbackFailure = "";
        callbackProgress = "";
        animationMedic = "";
        animationMedicProne = "";
        animationMedicSelf = "";
        animationMedicSelfProne = "";
        consumeItem = 0;
        ACM_menuIcon = "ACM_ChestSeal";
        items[] = {"ACM_ChestSeal"};
    };
    class ACME_BurpChestSeal: ACME_ApplyChestSeal {
        displayName = "Burp Chest Seal";
        displayNameProgress = "Burping seal...";
        treatmentTime = 2;
        items[] = {};
        condition = "false";
        callbackSuccess = "_this call ACME_fnc_chestSealBurp";
        callbackFailure = "";
        callbackProgress = "";
        animationMedic = "AmovPknlMstpSrasWpstDnon_AmovPknlMstpSrasWpstDnon_gear";
    };
    class ACME_PerformNARSPEAR: CheckPulse {
        displayName = "Perform NCD (NAR SPEAR)";
        displayNameProgress = "Preparing NAR SPEAR...";
        category = "airway";
        treatmentLocations[] = {"All"};
        medicRequired = "ACM_breathing_allowNCD";
        allowSelfTreatment = 0;
        treatmentTime = 0.4;
        allowedSelections[] = {"Body"};
        condition = "([_medic, 'ACME_PerformNARSPEAR'] call ACME_fnc_procedureActionAllowed) && {[_patient] call ACME_fnc_chestSealCanApply}";
        callbackStart = "";
        callbackSuccess = "[_this select 0, _this select 1, _this select 2, 'spear'] call ACME_fnc_chestSealOpen";
        callbackFailure = "";
        callbackProgress = "";
        consumeItem = 0;
        ACM_menuIcon = "ACME_NARSPEAR";
        items[] = {"ACME_NARSPEAR"};
        ACM_cancelRecovery = 1;
    };
    class ACME_DirectPressure: CheckPulse {
        displayName = "Apply Direct Pressure";
        displayNameProgress = "Getting into position...";
        category = "bandage";
        treatmentLocations[] = {"All"};
        medicRequired = 0;
        treatmentTime = 0.1;
        allowedSelections[] = {
            "Head",
            "Body",
            "LeftArm",
            "RightArm",
            "LeftLeg",
            "RightLeg"
        };
        condition = "(missionNamespace getVariable ['ACME_sys_dp', true]) && {!(_medic getVariable ['ACME_DP_Active', false])} && {(_medic getVariable ['ACME_DP_ClaimPending', []]) isEqualTo []} && {!(_medic getVariable ['ACME_hang_Active', false])} && {(toLower _bodyPart != 'body') || {!(missionNamespace getVariable ['ACM_core_ContinuousAction_Active', false])}}";
        callbackStart = "";
        callbackSuccess = "_this call ACME_fnc_directPressureStart";
        callbackFailure = "";
        callbackProgress = "";
        ACM_menuIcon = "CPR";
        items[] = {};
    };
    class ACME_StopDirectPressure: CheckPulse {
        displayName = "Stop Direct Pressure";
        displayNameProgress = "Releasing pressure...";
        category = "bandage";
        treatmentLocations[] = {"All"};
        medicRequired = 0;
        treatmentTime = 0.1;
        allowedSelections[] = {
            "Head",
            "Body",
            "LeftArm",
            "RightArm",
            "LeftLeg",
            "RightLeg"
        };
        condition = "(_medic getVariable ['ACME_DP_Active', false]) && {(_medic getVariable ['ACME_DP_Patient', objNull]) isEqualTo _patient}";
        callbackStart = "";
        callbackSuccess = "[false, _medic] call ACME_fnc_directPressureStop";
        callbackFailure = "";
        callbackProgress = "";
        ACM_menuIcon = "CPR";
        items[] = {};
    };
    class ACME_MeasureRespirations: CheckPulse {
        displayName = "Measure Respirations";
        displayNameProgress = "";
        category = "examine";
        allowedSelections[] = {"Head", "Body"};
        treatmentLocations[] = {"All"};
        medicRequired = 0;
        allowSelfTreatment = 0;
        treatmentTime = 0.001;
        condition = "true";
        items[] = {};
        consumeItem = 0;
        callbackStart = "";
        callbackProgress = "true";
        callbackSuccess = "ACME_fnc_respirationStart";
        callbackFailure = "";
        animationMedic = "";
        animationMedicProne = "";
        animationMedicSelf = "";
        animationMedicSelfProne = "";
        ACM_rollToBack = 0;
        ACME_neverRollToBack = 1;
    };
    class ACME_AssessPupils: CheckPulse {
        displayName = "Assess Pupils";
        displayNameProgress = "Assessing pupils...";
        category = "examine";
        treatmentLocations[] = {"All"};
        medicRequired = 0;
        treatmentTime = 4;
        allowedSelections[] = {"Head"};
        condition = "true";
        callbackSuccess = "_this call ACME_fnc_tbiAssessPupils";
        callbackFailure = "";
        callbackProgress = "";
        animationMedic = "AinvPknlMstpSnonWnonDr_medic4";
        items[] = {};
    };
    class ACME_CheckTemperature: CheckPulse {
        animationMedic = "AmovPknlMstpSrasWpstDnon_AmovPknlMstpSrasWpstDnon_gear";
        animationMedicProne = "AmovPknlMstpSrasWpstDnon_AmovPknlMstpSrasWpstDnon_gear";
        displayName = "Check Temperature";
        displayNameProgress = "Checking temperature...";
        category = "examine";
        treatmentLocations[] = {"All"};
        medicRequired = 0;
        treatmentTime = 3;
        allowedSelections[] = {"Head", "Body"};
        condition = "([_medic, _patient, 'ACM_Thermometer'] call ACME_fnc_treatmentSupplyCount) > 0";
        callbackSuccess = "_this call ACME_fnc_checkTemperature";
        callbackFailure = "";
        callbackProgress = "";
        items[] = {};
    };
    class ACME_ElevateHead: CheckPulse {
        ACM_rollToBack = 0;
        displayName = "Elevate Head to 30°";
        displayNameProgress = "Elevating head...";
        category = "examine";
        treatmentLocations[] = {"All"};
        medicRequired = 0;
        treatmentTime = 0.5;
        allowedSelections[] = {"Head"};
        condition = "[_patient, _medic] call ACME_fnc_headElevateCanStart";
        callbackSuccess = "_this call ACME_fnc_headElevateStart";
        callbackFailure = "";
        callbackProgress = "";
        animationMedic = "";
        animationMedicProne = "";
        animationMedicSelf = "";
        animationMedicSelfProne = "";
        items[] = {};
    };
    class ACME_LowerHead: CheckPulse {
        ACM_rollToBack = 0;
        displayName = "Lower Head to Flat";
        displayNameProgress = "Lowering head...";
        category = "examine";
        treatmentLocations[] = {"All"};
        medicRequired = 0;
        treatmentTime = 0.5;
        allowedSelections[] = {"Head"};
        condition = "!(_patient isEqualTo _medic) && {_patient getVariable ['ACME_headElevated', false]}";
        callbackSuccess = "[_this select 0, _this select 1] call ACME_fnc_headElevateStop";
        callbackFailure = "";
        callbackProgress = "";
        animationMedic = "";
        animationMedicProne = "";
        animationMedicSelf = "";
        animationMedicSelfProne = "";
        items[] = {};
    };
    class ACME_TuneHeadTilt: CheckPulse {
        displayName = "Tune Head / Plate Carrier";
        displayNameProgress = "Opening tuner...";
        category = "examine";
        treatmentLocations[] = {"All"};
        medicRequired = 0;
        treatmentTime = 0.3;
        allowedSelections[] = {"Head"};
        condition = "([] call ACME_fnc_debugEnabled) && {!(_patient isEqualTo _medic)} && {_patient getVariable ['ACME_headElevated', false]}";
        callbackSuccess = "_this call ACME_fnc_headElevTuneOpen";
        callbackFailure = "";
        callbackProgress = "";
        items[] = {};
    };
    class ACME_PackJunctional: CheckPulse {
        displayName = "Pack Wound (Combat Gauze)";
        ACM_menuIcon = "ACME_CombatGauze";
        displayNameProgress = "Packing junctional wound...";
        category = "bandage";
        treatmentLocations[] = {"All"};
        medicRequired = 0;
        treatmentTime = 10;
        allowedSelections[] = {"LeftArm", "RightArm", "LeftLeg", "RightLeg"};
        condition = "(_patient getVariable [format ['ACME_Junc_%1', toLower _bodyPart], '']) == 'open'";
        callbackStart = "_this call ACME_fnc_junctionalPackSfxStart; [_medic, 'junctional'] call ACME_fnc_treatmentPoseStart";
        callbackSuccess = "_this call ACME_fnc_junctionalPackDone; [_medic, 'junctional'] call ACME_fnc_treatmentPoseStop";
        callbackFailure = "params ['_medic','_patient','_bodyPart']; [_medic] call ACME_fnc_junctionalPackSfxStop; if (!isNull _patient) then {_patient setVariable [format ['ACME_Junc_Packing_%1', toLower _bodyPart], false, true]}; [_medic, 'junctional'] call ACME_fnc_treatmentPoseStop";
        callbackProgress = "";
        animationMedic = "";
        animationMedicProne = "";
        animationMedicSelf = "";
        animationMedicSelfProne = "";
        items[] = {"ACM_CombatGauze"};
        consumeItem = 1;
        icon = "\acm_extended\ui\items\combat_gauze_ca.paa";
    };
    class ACME_WrapJunctional: CheckPulse {
        displayName = "Dress Junctional Wound";
        ACM_menuIcon = "ACM_PressureBandage";
        displayNameProgress = "Dressing junctional wound...";
        category = "bandage";
        treatmentLocations[] = {"All"};
        medicRequired = 0;
        treatmentTime = 10;
        allowedSelections[] = {"LeftArm", "RightArm", "LeftLeg", "RightLeg"};
        condition = "(_patient getVariable [format ['ACME_Junc_%1', toLower _bodyPart], '']) == 'packed'";
        callbackStart = "_this call ACME_fnc_junctionalWrapSfxStart; [_medic, 'junctional'] call ACME_fnc_treatmentPoseStart";
        callbackSuccess = "_this call ACME_fnc_junctionalWrapDone; [_medic, 'junctional'] call ACME_fnc_treatmentPoseStop";
        callbackFailure = "(_this select 0) call ACME_fnc_junctionalWrapSfxStop; [_medic, 'junctional'] call ACME_fnc_treatmentPoseStop";
        callbackProgress = "";
        animationMedic = "";
        animationMedicProne = "";
        animationMedicSelf = "";
        animationMedicSelfProne = "";
        items[] = {"ACM_PressureBandage", "ACM_ElasticWrap"};
        consumeItem = 1;
        icon = "\x\acm\addons\damage\ui\pressurebandage.paa";
    };
    class ACME_InflictJunctional: CheckPulse {
        displayName = "Inflict Junctional Wound [TEST]";
        displayNameProgress = "...";
        category = "advanced";
        treatmentLocations[] = {"All"};
        medicRequired = 0;
        treatmentTime = 0.5;
        allowedSelections[] = {"LeftArm", "RightArm", "LeftLeg", "RightLeg"};
        condition = "([] call ACME_fnc_debugEnabled) && {!((_patient getVariable [format ['ACME_Junc_%1', toLower _bodyPart], '']) in ['open','packed','wrapped'])}";
        callbackSuccess = "[_patient, _bodyPart] call ACME_fnc_junctionalInflict";
        callbackFailure = "";
        callbackProgress = "";
        items[] = {};
    };
    class ACME_AutoBP: CheckPulse {
        displayName = "Auto Blood Pressure (AED)";
        displayNameProgress = "";
        category = "advanced";
        treatmentLocations[] = {"All"};
        medicRequired = 0;
        treatmentTime = 0.01;
        allowedSelections[] = {"LeftArm", "RightArm"};
        allowSelfTreatment = 0;
        condition = "_this call ACME_fnc_autoBPCondition";
        callbackSuccess = "_this call ACME_fnc_toggleAutoBP";
        callbackFailure = "";
        callbackProgress = "";
        animationMedic = "";
        items[] = {};
        ACM_menuIcon = "ACM_AED";
    };
    class ACME_IVMinigameStart: CheckPulse {
        animationMedic = "";
        animationMedicProne = "";
        displayName = "Establish IV";
        displayNameProgress = "...";
        category = "advanced";
        ACM_menuIcon = "ACME_EstablishIV";
        treatmentLocations[] = {"All"};
        medicRequired = 0;
        treatmentTime = 0.1;
        allowedSelections[] = {"LeftArm", "RightArm", "LeftLeg", "RightLeg"};
        items[] = {};
        condition = "true";
        callbackStart = "_this call ACME_fnc_ivMinigamePrepare";
        callbackSuccess = "[_medic, _patient, toLower _bodyPart, 'lower'] call ACME_fnc_ivMinigameOpen";
        callbackFailure = "";
        callbackProgress = "";
    };
    class ACME_SwapVentBattery: CheckPulse {
        displayName = "Replace Ventilator Battery";
        displayNameProgress = "Replacing battery...";
        category = "advanced";
        treatmentTime = 6;
        items[] = {"ACME_VentBattery"};
        condition = "[_patient] call ACME_fnc_canSwapVentBattery";
        callbackSuccess = "[_this select 0, _this select 1] call ACME_fnc_swapVentBattery";
        itemConsumed = 1;
        allowedSelections[] = {"Body"};
    };
    class ACME_IntubateStart: CheckAirway {
        callbackStart = "";
        animationMedic = "AinvPknlMstpSnonWnonDr_medic4";
        animationMedicProne = "AinvPknlMstpSnonWnonDr_medic4";
        displayName = "Intubate (Orotracheal)";
        displayNameProgress = "Intubating...";
        category = "airway";
        treatmentLocations[] = {"All"};
        medicRequired = "ACME_skillIntubation";
        treatmentTime = 0.1;
        allowedSelections[] = {"Head"};
        items[] = {};
        condition = "([_medic, 'ACME_IntubateStart'] call ACME_fnc_procedureActionAllowed) && {([_medic, _patient, 'ACME_Laryngoscope'] call ACME_fnc_treatmentSupplyCount) > 0} && {([_medic, _patient, 'ACME_ETTube'] call ACME_fnc_treatmentSupplyCount) > 0} && {!(_patient getVariable ['ACME_ETT_Inserted', false])} && {!(_patient getVariable ['ACM_airway_RecoveryPosition_State', false])} && {(_patient getVariable ['ACM_airway_AirwayItem_Oral', '']) isEqualTo ''} && {!(_patient getVariable ['ACM_airway_SurgicalAirway_TubeInserted', false])} && {!(_patient getVariable ['ACME_nrb_on', false])}";
        callbackSuccess = "[_medic, _patient, toLower _bodyPart] call ACME_fnc_laryngoOpen";
        callbackFailure = "";
        callbackProgress = "";
    };
    class ACME_Extubate: CheckAirway {
        callbackStart = "";
        animationMedic = "AinvPknlMstpSnonWnonDr_medic4";
        animationMedicProne = "AinvPknlMstpSnonWnonDr_medic4";
        displayName = "Extubate";
        displayNameProgress = "Extubating...";
        category = "airway";
        treatmentLocations[] = {"All"};
        medicRequired = "ACME_skillIntubation";
        treatmentTime = 4;
        allowedSelections[] = {"Head"};
        items[] = {};
        condition = "([_medic, 'ACME_Extubate'] call ACME_fnc_procedureActionAllowed) && {(_patient getVariable ['ACME_ETT_Inserted', false])}";
        callbackSuccess = "[_medic, _patient] call ACME_fnc_laryngoExtubate";
        callbackFailure = "";
        callbackProgress = "";
    };
    class ACME_OpenAirwayView: CheckAirway {
        callbackStart = "";
        animationMedic = "AinvPknlMstpSnonWnonDr_medic4";
        animationMedicProne = "AinvPknlMstpSnonWnonDr_medic4";
        displayName = "Open Airway View";
        displayNameProgress = "Looking...";
        category = "airway";
        treatmentLocations[] = {"All"};
        medicRequired = "ACME_skillIntubation";
        treatmentTime = 0.1;
        allowedSelections[] = {"Head"};
        items[] = {};
        condition = "([_medic, 'ACME_OpenAirwayView'] call ACME_fnc_procedureActionAllowed) && {(_patient getVariable ['ACME_ETT_Inserted', false])}";
        callbackSuccess = "[_medic, _patient, toLower _bodyPart] call ACME_fnc_laryngoOpen";
        callbackFailure = "";
        callbackProgress = "";
    };
    class ACME_ConnectETVent: CheckPulse {
        displayName = "Connect Airway > Ventilator";
        displayNameProgress = "";
        category = "advanced";
        treatmentLocations = 0;
        medicRequired = "ACME_skillVentilator";
        treatmentTime = 0;
        ACM_rollToBack = "false";
        consumeItem = 0;
        allowedSelections[] = {"Head"};
        items[] = {};
        condition = "([_medic, 'ACME_ConnectETVent'] call ACME_fnc_procedureActionAllowed) && {!(_patient getVariable ['ACM_airway_RecoveryPosition_State', false])} && {((_patient getVariable ['ACME_ETT_Inserted', false]) || {(_patient getVariable ['ACM_airway_AirwayItem_Oral', '']) isEqualTo 'SGA'} || {_patient getVariable ['ACM_airway_SurgicalAirway_TubeInserted', false]}) && {!(_patient getVariable ['ACME_vent_circuit', false])} && {!(_patient getVariable ['ACME_vent_onPatient', false])} && {(_patient getVariable ['ACME_vent_custodyId', '']) == ''} && {([_medic, _patient, 'ACME_Ventilator'] call ACME_fnc_treatmentSupplyCount) > 0}}";
        callbackSuccess = "[_medic, _patient] call ACME_fnc_ventConnectPatient";
        ACM_menuIcon = "ACME_Ventilator";
        callbackFailure = "";
        callbackProgress = "";
    };
    class ACME_DisconnectETVent: CheckPulse {
        displayName = "Disconnect Ventilator";
        displayNameProgress = "Disconnecting ventilator...";
        category = "advanced";
        medicRequired = "ACME_skillVentilator";
        treatmentTime = 2;
        allowedSelections[] = {"Head"};
        items[] = {};
        condition = "([_medic, 'ACME_DisconnectETVent'] call ACME_fnc_procedureActionAllowed) && {(_patient getVariable ['ACME_vent_onPatient', false]) && {!(_patient getVariable ['ACME_vent_recovering', false])}}";
        callbackSuccess = "[_medic, _patient] call ACME_fnc_ventDisconnectPatient";
        callbackFailure = "";
        callbackProgress = "";
        ACM_menuIcon = "ACME_Ventilator";
    };
    class ACME_DebugForceShake: CheckPulse {
        displayName = "Force Shake (debug)";
        displayNameProgress = "";
        treatmentTime = 0.01;
        allowedSelections[] = {"Head"};
        condition = "missionNamespace getVariable ['ACME_debug_enabled', false]";
        callbackSuccess = "[] call ACME_fnc_debugForceShake";
        items[] = {};
    };
    class ACME_VentOpenPatient: CheckPulse {
        displayName = "Open Ventilator";
        displayNameProgress = "...";
        category = "advanced";
        treatmentLocations[] = {"All"};
        medicRequired = "ACME_skillVentilator";
        treatmentTime = 0.1;
        allowedSelections[] = {"Head"};
        items[] = {};
        condition = "([_medic, 'ACME_VentOpenPatient'] call ACME_fnc_procedureActionAllowed) && {!(_patient getVariable ['ACME_vent_recovering', false])} && {alive _patient || {_patient getVariable ['ACME_vent_onPatient', false]}} && {((_patient getVariable ['ACME_vent_circuit', false]) || {_patient getVariable ['ACME_vent_configured', false]}) && {(_patient getVariable ['ACME_vent_onPatient', false]) || {([_medic, 'ACME_Ventilator'] call ace_common_fnc_getCountOfItem) > 0}}}";
        callbackSuccess = "[_patient, true] call ACME_fnc_ventPanelOpen";
        ACM_menuIcon = "ACME_Ventilator";
        callbackFailure = "";
        callbackProgress = "";
    };
    class ACME_EstablishEJ: CheckPulse {
        animationMedic = "";
        animationMedicProne = "";
        displayName = "Establish EJ IV";
        displayNameProgress = "...";
        category = "advanced";
        ACM_menuIcon = "ACME_EstablishIV";
        treatmentLocations[] = {"All"};
        medicRequired = 0;
        treatmentTime = 0.1;
        allowedSelections[] = {"Head"};
        items[] = {};
        condition = "!alive _patient || {(_patient getVariable ['ACE_isUnconscious', false]) || {(stance _patient) == 'PRONE'}}";
        callbackStart = "_this call ACME_fnc_ivMinigamePrepare";
        callbackSuccess = "[_medic, _patient, 'ej', 'left'] call ACME_fnc_ivMinigameOpen";
        callbackFailure = "";
        callbackProgress = "";
    };
    class ACME_RemoveEJ: CheckPulse {
        displayName = "Remove EJ IV";
        displayNameProgress = "Removing EJ IV...";
        category = "advanced";
        ACM_menuIcon = "ACME_EstablishIV";
        treatmentLocations[] = {"All"};
        medicRequired = 0;
        treatmentTime = 3;
        allowedSelections[] = {"Head"};
        items[] = {};
        condition = "false";
        callbackSuccess = "[_medic, _patient] call ACME_fnc_removeEJ";
        callbackFailure = "";
        callbackProgress = "";
    };
    class ACME_ApplyAAJT_Inguinal: CheckPulse {
        displayName = "Apply AAJT-S (Inguinal)";
        displayNameProgress = "Applying AAJT-S...";
        category = "bandage";
        treatmentLocations = 0;
        medicRequired = 0;
        treatmentTime = 20;
        allowedSelections[] = {"LeftLeg", "RightLeg"};
        condition = "!(_patient getVariable ['ACME_AAJT_inguinal', false])";
        callbackStart = "[_this select 1, 'aajtApplying', [toLowerANSI (_this select 2), true]] call ACME_fnc_ownerDispatch";
        callbackSuccess = "_this call ACME_fnc_aajtApply";
        callbackFailure = "[_this select 1, 'aajtApplying', ['', false]] call ACME_fnc_ownerDispatch";
        callbackProgress = "";
        animationMedic = "AinvPknlMstpSnonWnonDr_medic4";
        items[] = {"ACME_AAJT_S"};
        consumeItem = 1;
        icon = "\acm_extended\ui\items\aajt-s_ca.paa";
        ACM_menuIcon = "ACME_AAJT";
    };
    class ACME_RemoveAAJT_Inguinal: CheckPulse {
        displayName = "Remove AAJT-S (Inguinal)";
        displayNameProgress = "Removing AAJT-S...";
        category = "bandage";
        treatmentLocations = 0;
        medicRequired = 0;
        treatmentTime = 4;
        allowedSelections[] = {"LeftLeg", "RightLeg"};
        condition = "(_patient getVariable ['ACME_AAJT_inguinal', false]) && {(_patient getVariable ['ACME_AAJT_inguinalSide', '']) == toLowerANSI _bodyPart}";
        callbackSuccess = "_this call ACME_fnc_aajtRemove";
        callbackFailure = "";
        callbackProgress = "";
        animationMedic = "AinvPknlMstpSnonWnonDr_medic4";
        items[] = {};
        icon = "\acm_extended\ui\items\aajt-s_ca.paa";
        ACM_menuIcon = "ACME_AAJT";
    };
    class ACME_ApplyAAJT_Axilla: CheckPulse {
        displayName = "Apply AAJT-S (Axilla)";
        displayNameProgress = "Applying AAJT-S...";
        category = "bandage";
        treatmentLocations = 0;
        medicRequired = 0;
        treatmentTime = 20;
        allowedSelections[] = {"LeftArm", "RightArm"};
        condition = "((toLowerANSI _bodyPart) == 'leftarm' && {!(_patient getVariable ['ACME_AAJT_axillaleft', false])}) || {(toLowerANSI _bodyPart) == 'rightarm' && {!(_patient getVariable ['ACME_AAJT_axillaright', false])}}";
        callbackStart = "[_this select 1, 'aajtApplying', [toLowerANSI (_this select 2), true]] call ACME_fnc_ownerDispatch";
        callbackSuccess = "_this call ACME_fnc_aajtApply";
        callbackFailure = "[_this select 1, 'aajtApplying', ['', false]] call ACME_fnc_ownerDispatch";
        callbackProgress = "";
        animationMedic = "AinvPknlMstpSnonWnonDr_medic4";
        items[] = {"ACME_AAJT_S"};
        consumeItem = 1;
        icon = "\acm_extended\ui\items\aajt-s_ca.paa";
        ACM_menuIcon = "ACME_AAJT";
    };
    class ACME_RemoveAAJT_Axilla: CheckPulse {
        displayName = "Remove AAJT-S (Axilla)";
        displayNameProgress = "Removing AAJT-S...";
        category = "bandage";
        treatmentLocations = 0;
        medicRequired = 0;
        treatmentTime = 4;
        allowedSelections[] = {"LeftArm", "RightArm"};
        condition = "((toLowerANSI _bodyPart) == 'leftarm' && {_patient getVariable ['ACME_AAJT_axillaleft', false]}) || {(toLowerANSI _bodyPart) == 'rightarm' && {_patient getVariable ['ACME_AAJT_axillaright', false]}}";
        callbackSuccess = "_this call ACME_fnc_aajtRemove";
        callbackFailure = "";
        callbackProgress = "";
        animationMedic = "AinvPknlMstpSnonWnonDr_medic4";
        items[] = {};
        icon = "\acm_extended\ui\items\aajt-s_ca.paa";
        ACM_menuIcon = "ACME_AAJT";
    };
    class ACME_ApplyAAJT_Zone3: CheckPulse {
        displayName = "Apply AAJT-S (Zone 3 REBOA)";
        displayNameProgress = "Applying AAJT-S (Zone 3 REBOA)...";
        category = "bandage";
        treatmentLocations = 0;
        medicRequired = 0;
        treatmentTime = 20;
        allowedSelections[] = {"Body"};
        condition = "!(_patient getVariable ['ACME_AAJT_zone3', false])";
        callbackStart = "[_this select 1, 'aajtApplying', ['body', true]] call ACME_fnc_ownerDispatch";
        callbackSuccess = "_this call ACME_fnc_aajtApply";
        callbackFailure = "[_this select 1, 'aajtApplying', ['', false]] call ACME_fnc_ownerDispatch";
        callbackProgress = "";
        animationMedic = "AinvPknlMstpSnonWnonDr_medic4";
        items[] = {"ACME_AAJT_S"};
        consumeItem = 1;
        icon = "\acm_extended\ui\items\aajt-s_zone3_reboa_ca.paa";
        ACM_menuIcon = "ACME_AAJT";
    };
    class ACME_RemoveAAJT_Zone3: CheckPulse {
        displayName = "Remove AAJT-S (Zone 3 REBOA)";
        displayNameProgress = "Removing AAJT-S (Zone 3 REBOA)...";
        category = "bandage";
        treatmentLocations = 0;
        medicRequired = 0;
        treatmentTime = 4;
        allowedSelections[] = {"Body"};
        condition = "_patient getVariable ['ACME_AAJT_zone3', false]";
        callbackSuccess = "_this call ACME_fnc_aajtRemove";
        callbackFailure = "";
        callbackProgress = "";
        animationMedic = "AinvPknlMstpSnonWnonDr_medic4";
        items[] = {};
        icon = "\acm_extended\ui\items\aajt-s_zone3_reboa_ca.paa";
        ACM_menuIcon = "ACME_AAJT";
    };
    class PersonalAidKit {
        condition = "((_patient call ace_medical_status_fnc_isInStableCondition) || {_patient getVariable ['ACME_XStat_needsSurgery', false]}) && {!(_patient getVariable ['ACME_requiresEvac', false]) || {(_patient getVariable ['ACME_evacuated', false]) || {!isNull objectParent _patient}}}";
    };
    class ACME_ApplyXStat: CheckPulse {
        displayName = "Insert XStat 30";
        displayNameProgress = "Inserting XStat...";
        category = "bandage";
        treatmentLocations[] = {"All"};
        medicRequired = 0;
        treatmentTime = 3;
        allowedSelections[] = {"LeftLeg", "RightLeg", "LeftArm", "RightArm"};
        condition = "private _i = ['head','body','leftarm','rightarm','leftleg','rightleg'] find toLowerANSI _bodyPart; ((_patient getVariable [format ['ACME_Junc_%1', toLowerANSI _bodyPart], '']) == 'open') && {_i >= 0} && {!([_patient, _i] call ACME_fnc_aajtOccludes)} && {([_medic, _patient, 'ACME_XStat'] call ACME_fnc_treatmentSupplyCount) > 0}";
        callbackSuccess = "_this call ACME_fnc_xstatApply";
        callbackFailure = "";
        callbackProgress = "";
        animationMedic = "AinvPknlMstpSnonWnonDr_medic4";
        items[] = {"ACME_XStat"};
        consumeItem = 0;
        ACM_menuIcon = "ACME_XStat";
        icon = "\acm_extended\ui\items\xstat_ca.paa";
    };
    class ACME_ApplyNRB: CheckAirway {
        callbackStart = "";
        displayName = "Apply Non-Rebreather Mask";
        displayNameProgress = "Applying NRB...";
        category = "airway";
        treatmentLocations[] = {"All"};
        medicRequired = 0;
        treatmentTime = 1;
        allowedSelections[] = {"Head"};
        condition = "(missionNamespace getVariable ['ACME_sys_nrb', true]) && {[_patient] call ACME_fnc_nrbAirwayCompatible} && {!(_patient getVariable ['ACME_nrb_on', false]) && {([_medic, _patient, 'ACM_NRBMask'] call ACME_fnc_treatmentSupplyCount) > 0}}";
        callbackSuccess = "_this call ACME_fnc_nrbApply";
        callbackFailure = "";
        callbackProgress = "";
        animationMedic = "AinvPknlMstpSnonWnonDr_medic4";
        items[] = {};
        icon = "\acm_extended\ui\items\nrbmask_ca.paa";
        ACM_menuIcon = "ACM_NRBMask";
    };
    class ACME_RemoveNRB: CheckAirway {
        callbackStart = "";
        animationMedic = "AinvPknlMstpSnonWnonDr_medic4";
        animationMedicProne = "AinvPknlMstpSnonWnonDr_medic4";
        displayName = "Remove Non-Rebreather Mask";
        displayNameProgress = "Removing NRB...";
        category = "airway";
        treatmentLocations[] = {"All"};
        medicRequired = 0;
        treatmentTime = 2;
        allowedSelections[] = {"Head"};
        condition = "_patient getVariable ['ACME_nrb_on', false]";
        callbackSuccess = "_this call ACME_fnc_nrbRemove";
        callbackFailure = "";
        callbackProgress = "";
        items[] = {};
        icon = "\acm_extended\ui\items\nrbmask_ca.paa";
        ACM_menuIcon = "ACM_NRBMask";
    };
    class ACME_PrepHPMK: CheckPulse {
        displayName = "Prep HPMK";
        displayNameProgress = "Prepping HPMK...";
        category = "advanced";
        treatmentLocations[] = {"All"};
        medicRequired = 0;
        treatmentTime = 5.699;
        allowedSelections[] = {"Body"};
        condition = "!(_patient isEqualTo _medic) && {(_patient getVariable ['ACE_isUnconscious', false]) || {(stance _patient) == 'PRONE'} || {_patient getVariable ['ACM_core_Lying_State', false]}} && {(missionNamespace getVariable ['ACME_sys_hpmk', true]) && {((_patient getVariable ['ACME_hpmk_state', '']) == '') && {([_medic, _patient, 'ACM_HPMK'] call ACME_fnc_treatmentSupplyCount) > 0}}}";
        callbackStart = "params ['_medic','_patient']; if (!isNull _patient) then {[_patient, 5.699] call ACME_fnc_markImportantSfx}; if (!isNull _medic) then {[_medic, 'ACM_HPMK_Wrap'] call ACME_fnc_worldSfxNearby}";
        callbackSuccess = "_this call ACME_fnc_hpmkPrep";
        callbackFailure = "";
        callbackProgress = "";
        animationMedic = "AinvPknlMstpSnonWnonDr_medic4";
        items[] = {};
        icon = "\acm_extended\ui\items\HPMK_ca.paa";
        ACM_menuIcon = "ACM_HPMK";
    };
    class ACME_WrapHPMK: CheckPulse {
        displayName = "Wrap in HPMK";
        displayNameProgress = "Wrapping in HPMK...";
        category = "advanced";
        treatmentLocations[] = {"All"};
        medicRequired = 0;
        treatmentTime = 1.242;
        allowedSelections[] = {"Body"};
        condition = "!(_patient isEqualTo _medic) && {(_patient getVariable ['ACE_isUnconscious', false]) || {(stance _patient) == 'PRONE'} || {_patient getVariable ['ACM_core_Lying_State', false]}} && {(_patient getVariable ['ACME_hpmk_state', '']) == 'prepped'}";
        callbackStart = "";
        callbackSuccess = "_this call ACME_fnc_hpmkWrap";
        callbackFailure = "";
        callbackProgress = "";
        animationMedic = "AinvPknlMstpSnonWnonDr_medic4";
        items[] = {};
        icon = "\acm_extended\ui\items\HPMK_ca.paa";
        ACM_menuIcon = "ACM_HPMK";
    };
    class ACME_UnwrapHPMK: CheckPulse {
        displayName = "Unwrap HPMK";
        displayNameProgress = "Unwrapping HPMK...";
        category = "advanced";
        treatmentLocations[] = {"All"};
        medicRequired = 0;
        treatmentTime = 1.019;
        allowedSelections[] = {"Body"};
        condition = "!(_patient isEqualTo _medic) && {(_patient getVariable ['ACME_hpmk_state', '']) in ['wrapped', 'exposed']}";
        callbackStart = "params ['_medic','_patient']; if (!isNull _patient) then {[_patient, 1.019] call ACME_fnc_markImportantSfx}; if (!isNull _medic) then {[_medic, 'ACME_HPMK_Unwrap'] call ACME_fnc_worldSfxNearby}";
        callbackSuccess = "_this call ACME_fnc_hpmkUnwrap";
        callbackFailure = "";
        callbackProgress = "";
        animationMedic = "AinvPknlMstpSnonWnonDr_medic4";
        items[] = {};
        icon = "\acm_extended\ui\items\HPMK_ca.paa";
        ACM_menuIcon = "ACM_HPMK";
    };
    class ACME_ExposeChestHPMK: CheckPulse {
        displayName = "Partially Expose Chest";
        displayNameProgress = "Exposing chest...";
        category = "advanced";
        treatmentLocations[] = {"All"};
        medicRequired = 0;
        treatmentTime = 2.377;
        allowedSelections[] = {"Body"};
        condition = "!(_patient isEqualTo _medic) && {(_patient getVariable ['ACME_hpmk_state', '']) == 'wrapped'}";
        callbackStart = "params ['_medic','_patient']; if (!isNull _patient) then {[_patient, 2.377] call ACME_fnc_markImportantSfx}; if (!isNull _medic) then {[_medic, 'ACME_HPMK_Expose'] call ACME_fnc_worldSfxNearby}";
        callbackSuccess = "_this call ACME_fnc_hpmkExposeChest";
        callbackFailure = "";
        callbackProgress = "";
        animationMedic = "AinvPknlMstpSnonWnonDr_medic4";
        items[] = {};
        icon = "\acm_extended\ui\items\HPMK_ca.paa";
        ACM_menuIcon = "ACM_HPMK";
    };
    class ACME_CoverChestHPMK: CheckPulse {
        displayName = "Cover Chest";
        displayNameProgress = "Re-covering chest...";
        category = "advanced";
        treatmentLocations[] = {"All"};
        medicRequired = 0;
        treatmentTime = 2.377;
        allowedSelections[] = {"Body"};
        condition = "!(_patient isEqualTo _medic) && {(_patient getVariable ['ACME_hpmk_state', '']) == 'exposed'}";
        callbackStart = "params ['_medic','_patient']; if (!isNull _patient) then {[_patient, 2.377] call ACME_fnc_markImportantSfx}; if (!isNull _medic) then {[_medic, 'ACME_HPMK_Expose'] call ACME_fnc_worldSfxNearby}";
        callbackSuccess = "_this call ACME_fnc_hpmkCoverChest";
        callbackFailure = "";
        callbackProgress = "";
        animationMedic = "AinvPknlMstpSnonWnonDr_medic4";
        items[] = {};
        icon = "\acm_extended\ui\items\HPMK_ca.paa";
        ACM_menuIcon = "ACM_HPMK";
    };
    class ACME_RemoveHPMK: CheckPulse {
        displayName = "Remove HPMK";
        displayNameProgress = "Removing HPMK...";
        category = "advanced";
        treatmentLocations[] = {"All"};
        medicRequired = 0;
        treatmentTime = 3.924;
        allowedSelections[] = {"Body"};
        condition = "!(_patient isEqualTo _medic) && {(_patient getVariable ['ACME_hpmk_state', '']) == 'prepped'}";
        callbackStart = "params ['_medic','_patient']; if (!isNull _patient) then {[_patient, 3.924] call ACME_fnc_markImportantSfx}; if (!isNull _medic) then {[_medic, 'ACM_HPMK_Remove'] call ACME_fnc_worldSfxNearby}";
        callbackSuccess = "_this call ACME_fnc_hpmkRemove";
        callbackFailure = "";
        callbackProgress = "";
        items[] = {};
        icon = "\acm_extended\ui\items\HPMK_ca.paa";
        ACM_menuIcon = "ACM_HPMK";
    };
    class ACME_AttachEMMA: CheckPulse {
        displayName = "Attach EMMA to My BVM";
        displayNameProgress = "Attaching EMMA...";
        category = "airway";
        treatmentLocations[] = {"All"};
        medicRequired = 0;
        allowSelfTreatment = 1;
        treatmentTime = 0.5;
        allowedSelections[] = {
            "Head",
            "Body",
            "LeftArm",
            "RightArm",
            "LeftLeg",
            "RightLeg"
        };
        condition = "!(_medic getVariable ['ACME_emma_bvmAttached', false]) && {([_medic, _patient, 'ACM_EMMA'] call ACME_fnc_treatmentSupplyCount) > 0}";
        callbackStart = "params ['_medic']; if (!isNull _medic) then {[_medic, 'ACME_EMMA_Attach'] call ACME_fnc_worldSfxNearby}";
        callbackSuccess = "_this call ACME_fnc_emmaAttach";
        callbackFailure = "";
        callbackProgress = "";
        items[] = {};
        icon = "\acm_extended\ui\emma\emma_etco2_ca.paa";
        ACM_menuIcon = "ACM_EMMA";
    };
    class ACME_AttachEMMAETT: CheckPulse {
        displayName = "Attach EMMA to ETT";
        displayNameProgress = "Attaching EMMA...";
        category = "airway";
        treatmentLocations[] = {"All"};
        medicRequired = 0;
        allowSelfTreatment = 0;
        treatmentTime = 0.5;
        allowedSelections[] = {"Head"};
        condition = "[_medic, _patient, 'ett'] call ACME_fnc_emmaCanAttachIGel";
        callbackStart = "params ['_medic']; if (!isNull _medic) then {[_medic, 'ACME_EMMA_Attach'] call ACME_fnc_worldSfxNearby}";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'ett'] call ACME_fnc_emmaAttachIGel";
        callbackFailure = "";
        callbackProgress = "";
        items[] = {};
        icon = "\acm_extended\ui\emma\emma_etco2_ca.paa";
        ACM_menuIcon = "ACM_EMMA";
    };
    class ACME_RemoveEMMAETT: ACME_AttachEMMAETT {
        displayName = "Remove EMMA from ETT";
        displayNameProgress = "Removing EMMA...";
        condition = "(_patient isNotEqualTo _medic) && {_patient getVariable ['ACME_ETT_Inserted', false]} && {[_medic, _patient] call ACME_fnc_emmaCanRemoveIGel}";
        callbackStart = "params ['_medic']; if (!isNull _medic) then {[_medic, 'ACME_EMMA_Detach'] call ACME_fnc_worldSfxNearby}";
        callbackSuccess = "_this call ACME_fnc_emmaRemoveIGel";
    };
    class ACME_AttachEMMAIGel: CheckPulse {
        displayName = "Attach EMMA to their i-gel";
        displayNameProgress = "Attaching EMMA...";
        category = "airway";
        treatmentLocations[] = {"All"};
        medicRequired = 0;
        allowSelfTreatment = 0;
        treatmentTime = 0.5;
        allowedSelections[] = {"Head"};
        condition = "[_medic, _patient, 'igel'] call ACME_fnc_emmaCanAttachIGel";
        callbackStart = "params ['_medic']; if (!isNull _medic) then {[_medic, 'ACME_EMMA_Attach'] call ACME_fnc_worldSfxNearby}";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'igel'] call ACME_fnc_emmaAttachIGel";
        callbackFailure = "";
        callbackProgress = "";
        items[] = {};
        icon = "\acm_extended\ui\emma\emma_etco2_ca.paa";
        ACM_menuIcon = "ACM_EMMA";
    };
    class ACME_RemoveEMMAIGel: CheckPulse {
        displayName = "Remove EMMA from their i-gel";
        displayNameProgress = "Removing EMMA...";
        category = "airway";
        treatmentLocations[] = {"All"};
        medicRequired = 0;
        allowSelfTreatment = 0;
        treatmentTime = 0.5;
        allowedSelections[] = {"Head"};
        condition = "!(_patient getVariable ['ACME_ETT_Inserted', false]) && {[_medic, _patient] call ACME_fnc_emmaCanRemoveIGel}";
        callbackStart = "params ['_medic']; if (!isNull _medic) then {[_medic, 'ACME_EMMA_Detach'] call ACME_fnc_worldSfxNearby}";
        callbackSuccess = "_this call ACME_fnc_emmaRemoveIGel";
        callbackFailure = "";
        callbackProgress = "";
        items[] = {};
        icon = "\acm_extended\ui\emma\emma_etco2_ca.paa";
        ACM_menuIcon = "ACM_EMMA";
    };
    class ACME_RemoveEMMA: CheckPulse {
        displayName = "Remove EMMA from My BVM";
        displayNameProgress = "Removing EMMA...";
        category = "airway";
        treatmentLocations[] = {"All"};
        medicRequired = 0;
        allowSelfTreatment = 1;
        treatmentTime = 0.5;
        allowedSelections[] = {
            "Head",
            "Body",
            "LeftArm",
            "RightArm",
            "LeftLeg",
            "RightLeg"
        };
        condition = "_medic getVariable ['ACME_emma_bvmAttached', false]";
        callbackStart = "params ['_medic']; if (!isNull _medic) then {[_medic, 'ACME_EMMA_Detach'] call ACME_fnc_worldSfxNearby}";
        callbackSuccess = "_this call ACME_fnc_emmaRemove";
        callbackFailure = "";
        callbackProgress = "";
        items[] = {};
        icon = "\acm_extended\ui\emma\emma_etco2_ca.paa";
        ACM_menuIcon = "ACM_EMMA";
    };
    class UseSuctionBag: CheckAirway {
        animationMedic = "AinvPknlMstpSnonWnonDr_medic4";
        animationMedicProne = "AinvPknlMstpSnonWnonDr_medic4";
        treatmentTime = 0.1;
        callbackStart = "";
        consumeItem = 0;
        callbackSuccess = "[_medic, _patient, 0] call ACME_fnc_suctionOpen";
        callbackFailure = "";
    };
    class UseAccuvac: UseSuctionBag {
        treatmentTime = 0.1;
        callbackStart = "";
        callbackSuccess = "[_medic, _patient, 1] call ACME_fnc_suctionOpen";
        callbackFailure = "";
    };
    class ACME_GiveCalcium: CheckPulse {
        displayName = "Administer Calcium Gluconate (1g)";
        displayNameProgress = "Pushing calcium...";
        category = "medication";
        treatmentLocations[] = {"All"};
        medicRequired = 1;
        treatmentTime = 5;
        allowedSelections[] = {
            "Body",
            "LeftArm",
            "RightArm",
            "LeftLeg",
            "RightLeg"
        };
        condition = "false";
        callbackSuccess = "_this call ACME_fnc_administerCalcium";
        callbackFailure = "";
        callbackProgress = "";
        items[] = {"ACM_Vial_CalciumGluconate"};
        animationMedic = "AinvPknlMstpSnonWnonDr_medic4";
    };
    class ACME_GiveMagnesium: CheckPulse {
        displayName = "Administer Magnesium Sulfate (2g)";
        displayNameProgress = "Giving magnesium...";
        category = "medication";
        treatmentLocations[] = {"All"};
        medicRequired = 1;
        treatmentTime = 8;
        allowedSelections[] = {
            "Body",
            "LeftArm",
            "RightArm",
            "LeftLeg",
            "RightLeg"
        };
        condition = "false";
        callbackSuccess = "_this call ACME_fnc_administerMagnesium";
        callbackFailure = "";
        callbackProgress = "";
        items[] = {"ACME_MagnesiumBag"};
        animationMedic = "AinvPknlMstpSnonWnonDr_medic4";
    };
    class ACME_HangBag: CheckPulse {
        displayName = "Hang Bag (raise for high flow)";
        displayNameProgress = "Raising the bag...";
        category = "medication";
        treatmentLocations[] = {"All"};
        medicRequired = 0;
        treatmentTime = 1.5;
        allowedSelections[] = {
            "Body",
            "LeftArm",
            "RightArm",
            "LeftLeg",
            "RightLeg"
        };
        condition = "false";
        callbackStart = "_this call ACME_fnc_hangBagPrep";
        callbackSuccess = "_this call ACME_fnc_hangBagStart";
        callbackFailure = "[_medic] call ACME_fnc_hangBagPrepStop";
        callbackProgress = "";
        items[] = {};
        animationMedic = "";
        animationMedicProne = "";
    };
    class ACME_ReadCoreTemp: CheckPulse {
        displayName = "Measure Core Temperature";
        displayNameProgress = "Taking core temperature...";
        category = "examine";
        treatmentLocations[] = {"All"};
        medicRequired = 0;
        treatmentTime = 8;
        allowedSelections[] = {"Body"};
        condition = "([_medic, _patient, 'ACM_Thermometer'] call ACME_fnc_treatmentSupplyCount) > 0";
        callbackSuccess = "_this call ACME_fnc_readCoreTemp";
        callbackFailure = "";
        callbackProgress = "";
        items[] = {};
        animationMedic = "AmovPknlMstpSrasWpstDnon_AmovPknlMstpSrasWpstDnon_gear";
    };
    class ACME_FeelSkin: CheckPulse {
        displayName = "Feel Skin";
        displayNameProgress = "Feeling skin...";
        category = "examine";
        treatmentLocations[] = {"All"};
        medicRequired = 0;
        treatmentTime = 2;
        allowedSelections[] = {
            "Head",
            "Body",
            "LeftArm",
            "RightArm",
            "LeftLeg",
            "RightLeg"
        };
        condition = "true";
        callbackSuccess = "_this call ACME_fnc_feelSkin";
        callbackFailure = "";
        callbackProgress = "";
        items[] = {};
        animationMedic = "AmovPknlMstpSrasWpstDnon_AmovPknlMstpSrasWpstDnon_gear";
    };
    class ACME_PushDoseEpi: CheckPulse {
        displayName = "Push-Dose Epi (10 mcg IV/IO)";
        displayNameProgress = "Pushing epinephrine...";
        category = "medication";
        treatmentLocations[] = {"All"};
        medicRequired = "ACME_skillMedicationBolus";
        treatmentTime = 2;
        allowedSelections[] = {
            "Head",
            "Body",
            "LeftArm",
            "RightArm",
            "LeftLeg",
            "RightLeg"
        };
        condition = "([_medic, 'ACME_PushDoseEpi'] call ACME_fnc_procedureActionAllowed) && {(((_medic getVariable ['ACME_narcStore', []]) findIf {(_x param [6,'']) == 'epiMixB12'}) >= 0) && {([_patient, _bodyPart, 0] call ACM_circulation_fnc_hasIV) || {[_patient, _bodyPart, 0] call ACM_circulation_fnc_hasIO}}}";
        callbackSuccess = "_this call ACME_fnc_administerPushDoseEpi";
        callbackFailure = "";
        callbackProgress = "";
        items[] = {};
        animationMedic = "AinvPknlMstpSnonWnonDr_medic4";
    };
    class ACME_SyringeKit_DrawPatient: CheckPulse {
        displayName = "Narc Box: Draw + Administer";
        displayNameProgress = "Opening Narc Box...";
        category = "medication";
        treatmentLocations[] = {"All"};
        medicRequired = "ACME_skillMedicationPreparation";
        treatmentTime = 0.01;
        allowedSelections[] = {
            "Head",
            "Body",
            "LeftArm",
            "RightArm",
            "LeftLeg",
            "RightLeg"
        };
        condition = "([_medic, 'ACME_SyringeKit_DrawPatient'] call ACME_fnc_procedureActionAllowed) && {!isNil ""ACM_circulation_fnc_Syringe_Draw""}";
        callbackSuccess = "if ([_medic, 'medicationPreparation'] call ACME_fnc_procedureAllowed) then {ACME_infusion_pendingContext = nil; [10, _this select 1, _this select 2] call ACME_fnc_skOpenDraw;};";
        callbackFailure = "";
        callbackProgress = "";
        items[] = {};
        ACM_menuIcon = "ACME_NarcBox";
    };
    class ACME_ToggleShock: CheckPulse {
        displayName = "Induce/Clear Peri-Arrest Shock";
        displayNameProgress = "";
        category = "advanced";
        treatmentLocations[] = {"All"};
        medicRequired = 1;
        treatmentTime = 0.01;
        allowedSelections[] = {"Head"};
        condition = "[] call ACME_fnc_debugEnabled";
        callbackSuccess = "_this call ACME_fnc_toggleShock";
        callbackFailure = "";
        callbackProgress = "";
        items[] = {};
    };
    class ACME_ToggleOverResus: CheckPulse {
        displayName = "Induce/Clear Over-Resuscitation (debug)";
        displayNameProgress = "";
        category = "advanced";
        treatmentLocations[] = {"All"};
        medicRequired = 1;
        treatmentTime = 0.01;
        allowedSelections[] = {"Head"};
        condition = "[] call ACME_fnc_debugEnabled";
        callbackSuccess = "_this call ACME_fnc_toggleOverResus";
        callbackFailure = "";
        callbackProgress = "";
        items[] = {};
    };
    class ACME_ToggleObtunded: CheckPulse {
        displayName = "Induce/Clear Obtunded Back (debug)";
        displayNameProgress = "";
        category = "advanced";
        treatmentLocations[] = {"All"};
        medicRequired = 1;
        treatmentTime = 0.01;
        allowedSelections[] = {"Head"};
        condition = "[] call ACME_fnc_debugEnabled";
        callbackSuccess = "_this call ACME_fnc_setObtunded";
        callbackFailure = "";
        callbackProgress = "";
        items[] = {};
    };
    class ACME_ToggleObtundedProne: ACME_ToggleObtunded {
        displayName = "Induce/Clear Obtunded Prone (debug)";
        callbackSuccess = "[_this select 0, _this select 1, _this select 2, 'prone'] call ACME_fnc_setObtunded";
    };
    class ACME_DebugObtundedBackPose: ACME_ToggleObtunded {
        displayName = "Obtunded BACK pose only (debug)";
        callbackSuccess = "_this call ACME_fnc_debugObtundedBack";
    };
    class ACME_ToggleHypothermia: CheckPulse {
        displayName = "Step Hypothermia: mild/mod/severe/clear (debug)";
        displayNameProgress = "";
        category = "advanced";
        treatmentLocations[] = {"All"};
        medicRequired = 1;
        treatmentTime = 0.01;
        allowedSelections[] = {"Head"};
        condition = "[] call ACME_fnc_debugEnabled";
        callbackSuccess = "_this call ACME_fnc_toggleHypothermia";
        callbackFailure = "";
        callbackProgress = "";
        items[] = {};
    };
    class ACME_RhythmAFibRVR: CheckPulse {
        displayName = "Rhythm: AFib-RVR on/off (debug)";
        displayNameProgress = "";
        category = "advanced";
        treatmentLocations[] = {"All"};
        medicRequired = 1;
        treatmentTime = 0.01;
        allowedSelections[] = {"Head"};
        condition = "[] call ACME_fnc_debugEnabled";
        callbackSuccess = "_this call ACME_fnc_rhythmAFibRVR";
        callbackFailure = "";
        callbackProgress = "";
        items[] = {};
    };
    class ACME_RhythmAFib: CheckPulse {
        displayName = "Rhythm: Atrial Fibrillation (controlled) on/off (debug)";
        displayNameProgress = "";
        category = "advanced";
        treatmentLocations[] = {"All"};
        medicRequired = 1;
        treatmentTime = 0.01;
        allowedSelections[] = {"Head"};
        condition = "[] call ACME_fnc_debugEnabled";
        callbackSuccess = "_this call ACME_fnc_rhythmAFib";
        callbackFailure = "";
        callbackProgress = "";
        items[] = {};
    };
    class ACME_RhythmAtrialTach: CheckPulse {
        displayName = "Rhythm: Atrial Tachycardia on/off (debug)";
        displayNameProgress = "";
        category = "advanced";
        treatmentLocations[] = {"All"};
        medicRequired = 1;
        treatmentTime = 0.01;
        allowedSelections[] = {"Head"};
        condition = "[] call ACME_fnc_debugEnabled";
        callbackSuccess = "_this call ACME_fnc_rhythmAtrialTach";
        callbackFailure = "";
        callbackProgress = "";
        items[] = {};
    };
    class ACME_RhythmTorsades: CheckPulse {
        displayName = "Rhythm: Torsades / polymorphic VT on/off (debug)";
        displayNameProgress = "";
        category = "advanced";
        treatmentLocations[] = {"All"};
        medicRequired = 1;
        treatmentTime = 0.01;
        allowedSelections[] = {"Head"};
        condition = "[] call ACME_fnc_debugEnabled";
        callbackSuccess = "_this call ACME_fnc_rhythmTorsades";
        callbackFailure = "";
        callbackProgress = "";
        items[] = {};
    };
    class ACME_RhythmSVT: CheckPulse {
        displayName = "Rhythm: SVT on/off (debug)";
        displayNameProgress = "";
        category = "advanced";
        treatmentLocations[] = {"All"};
        medicRequired = 1;
        treatmentTime = 0.01;
        allowedSelections[] = {"Head"};
        condition = "[] call ACME_fnc_debugEnabled";
        callbackSuccess = "_this call ACME_fnc_rhythmSVT";
        callbackFailure = "";
        callbackProgress = "";
        items[] = {};
    };
    class ACME_DebugVFXHypoxia: CheckPulse {
        displayName = "Visual FX: Hypoxia cycle (debug)";
        displayNameProgress = "";
        category = "advanced";
        treatmentLocations[] = {"All"};
        medicRequired = 1;
        treatmentTime = 0.01;
        allowedSelections[] = {"Head"};
        condition = "[] call ACME_fnc_debugEnabled";
        callbackSuccess = "[_this select 0,_this select 1,'hypoxia'] call ACME_fnc_visualFxDebugCycle";
        callbackFailure = "";
        callbackProgress = "";
        items[] = {};
    };
    class ACME_DebugVFXHypotension: ACME_DebugVFXHypoxia {
        displayName = "Visual FX: Hypotension / shock cycle (debug)";
        callbackSuccess = "[_this select 0,_this select 1,'hypotension'] call ACME_fnc_visualFxDebugCycle";
    };
    class ACME_DebugVFXHypercapnia: ACME_DebugVFXHypoxia {
        displayName = "Visual FX: Hypercapnia cycle (debug)";
        callbackSuccess = "[_this select 0,_this select 1,'hypercapnia'] call ACME_fnc_visualFxDebugCycle";
    };
    class ACME_DebugVFXKetamine: ACME_DebugVFXHypoxia {
        displayName = "Visual FX: Ketamine / dissociation cycle (debug)";
        callbackSuccess = "[_this select 0,_this select 1,'ketamine'] call ACME_fnc_visualFxDebugCycle";
    };
    class ACME_DebugVFXSyncope: ACME_DebugVFXHypoxia {
        displayName = "Visual FX: Near-syncope cycle (debug)";
        callbackSuccess = "[_this select 0,_this select 1,'syncope'] call ACME_fnc_visualFxDebugCycle";
    };
    class ACME_DebugVFXClear: ACME_DebugVFXHypoxia {
        displayName = "Visual FX: Clear debug overrides";
        callbackSuccess = "[_this select 0,_this select 1] call ACME_fnc_visualFxDebugClear";
    };
    class ACME_DebugDescriptorSelfTest: CheckPulse {
        displayName = "Descriptor Self-Test (debug)";
        displayNameProgress = "";
        category = "advanced";
        treatmentLocations[] = {"All"};
        medicRequired = 1;
        treatmentTime = 0.01;
        allowedSelections[] = {"Head"};
        condition = "[] call ACME_fnc_debugEnabled";
        callbackSuccess = "_this call ACME_fnc_descriptorSelfTest";
        callbackFailure = "";
        callbackProgress = "";
        items[] = {};
    };
    class ACME_DebugCheyneStokes: CheckPulse {
        displayName = "Respirations: Cheyne-Stokes on/off (debug)";
        displayNameProgress = "";
        category = "advanced";
        treatmentLocations[] = {"All"};
        medicRequired = 1;
        treatmentTime = 0.01;
        allowedSelections[] = {"Head"};
        condition = "[] call ACME_fnc_debugEnabled";
        callbackSuccess = "_this call ACME_fnc_debugCheyneStokes";
        callbackFailure = "";
        callbackProgress = "";
        items[] = {};
    };
    class ACME_DebugInduceSeizure: CheckPulse {
        displayName = "Induce Seizure (debug)";
        displayNameProgress = "";
        category = "advanced";
        treatmentLocations[] = {"All"};
        medicRequired = 0;
        treatmentTime = 0.01;
        allowedSelections[] = {"Head"};
        condition = "([] call ACME_fnc_debugEnabled) && {alive _patient} && {!(_patient getVariable ['ace_medical_inCardiacArrest', false])}";
        callbackSuccess = "_this call ACME_fnc_debugInduceSeizure";
        callbackFailure = "";
        callbackProgress = "";
        animationMedic = "";
        animationMedicProne = "";
        items[] = {};
    };
    class ACME_FlushDrawDirty: ACME_PushDoseEpi {
        medicRequired = 1;
        displayName = "Draw Push-Dose from Running Epi (10mcg)";
        displayNameProgress = "Drawing from dirty-epi bag...";
        category = "medication";
        treatmentTime = 4.946;
        condition = "false";
        callbackStart = "playSound 'ACME_SyringeDraw'";
        callbackSuccess = "[_this select 0, _this select 1, _this select 2, ['drawDirty']] call ACME_fnc_salineFlush";
        items[] = {};
    };
    class ACME_FlushLine: ACME_PushDoseEpi {
        medicRequired = 1;
        displayName = "Flush IV Site (Saline)";
        displayNameProgress = "Flushing IV/IO site...";
        category = "medication";
        treatmentTime = 3;
        condition = "(([_medic, _patient, 'ACM_SalineFlush_10'] call ACME_fnc_treatmentSupplyCount) > 0) && {([_patient, _bodyPart, 0] call ACM_circulation_fnc_hasIV) || {[_patient, _bodyPart, 0] call ACM_circulation_fnc_hasIO}}";
        callbackStart = "playSound 'ACME_SyringeDraw'";
        callbackSuccess = "[_this select 0, _this select 1, _this select 2, ['flushLine']] call ACME_fnc_salineFlush";
        items[] = {};
    };
    class ACME_OsmoBolus_HTS: CheckPulse {
        displayName = "Push 23.4% Hypertonic Saline";
        displayNameProgress = "Pushing hypertonic saline...";
        category = "medication";
        treatmentLocations[] = {"All"};
        medicRequired = "ACME_skillMedicationBolus";
        treatmentTime = 6;
        items[] = {"ACME_HTSBullet"};
        consumeItem = 0;
        allowedSelections[] = {"All"};
        allowSelfTreatment = 0;
        condition = "[_medic, 'ACME_OsmoBolus_HTS'] call ACME_fnc_procedureActionAllowed";
        callbackSuccess = "[_this select 0, _this select 1, _this select 2, ['HTS3', 30, 'ACME_HTSBullet']] call ACME_fnc_tbiOsmoBolus";
        callbackFailure = "";
        callbackProgress = "";
        litter[] = {};
    };
    class ACME_OsmoBolus_Mannitol: ACME_OsmoBolus_HTS {
        displayName = "Push Mannitol 20%";
        displayNameProgress = "Pushing mannitol...";
        items[] = {"ACME_MannitolVial"};
        callbackSuccess = "[_this select 0, _this select 1, _this select 2, ['Mannitol', 50, 'ACME_MannitolVial']] call ACME_fnc_tbiOsmoBolus";
    };
    class ACME_Place18g_Upper: CheckPulse {
        animationMedic = "";
        animationMedicProne = "";
        displayName = "Place 18g IV (Upper)";
        ACM_menuIcon = "ACME_IV_18g";
        displayNameProgress = "Placing 18g IV...";
        category = "advanced";
        treatmentLocations[] = {"All"};
        medicRequired = 1;
        treatmentTime = 5;
        allowedSelections[] = {"LeftArm", "RightArm", "LeftLeg", "RightLeg"};
        condition = "false";
        callbackSuccess = "[_this select 0, _this select 1, _this select 2, [0]] call ACME_fnc_place18g";
        callbackFailure = "";
        callbackProgress = "";
        items[] = {};
    };
    class ACME_Place18g_Middle: ACME_Place18g_Upper {
        displayName = "Place 18g IV (Middle)";
        callbackSuccess = "[_this select 0, _this select 1, _this select 2, [1]] call ACME_fnc_place18g";
    };
    class ACME_Place18g_Lower: ACME_Place18g_Upper {
        displayName = "Place 18g IV (Lower)";
        callbackSuccess = "[_this select 0, _this select 1, _this select 2, [2]] call ACME_fnc_place18g";
    };
    class ACME_Remove18g_Upper: ACME_Place18g_Upper {
        animationMedic = "";
        animationMedicProne = "";
        displayName = "Remove 18g IV (Upper)";
        displayNameProgress = "Removing 18g IV...";
        treatmentTime = 3;
        medicRequired = 0;
        condition = "false";
        callbackSuccess = "[_this select 0, _this select 1, _this select 2, [0]] call ACME_fnc_remove18g";
    };
    class ACME_Remove18g_Middle: ACME_Remove18g_Upper {
        displayName = "Remove 18g IV (Middle)";
        condition = "false";
        callbackSuccess = "[_this select 0, _this select 1, _this select 2, [1]] call ACME_fnc_remove18g";
    };
    class ACME_Remove18g_Lower: ACME_Remove18g_Upper {
        displayName = "Remove 18g IV (Lower)";
        condition = "false";
        callbackSuccess = "[_this select 0, _this select 1, _this select 2, [2]] call ACME_fnc_remove18g";
    };
};
class ACM_Medication {
    class MedicationType {
        class Norepinephrine {
            classnames[] = {"Norepinephrine_IV"};
        };
        class Sugammadex {
            classnames[] = {"Sugammadex_IV"};
        };
        class Magnesium {
            classnames[] = {"Magnesium_IV"};
        };
        class Midazolam {
            classnames[] = {"Midazolam_IV", "Midazolam"};
        };
        class CalciumGluconate {
            classnames[] = {"CalciumGluconate_IV"};
        };
        class Ceftriaxone {
            classnames[] = {"Ceftriaxone_IV", "Ceftriaxone"};
        };
        class Rocuronium {
            classnames[] = {"Rocuronium_IV", "Rocuronium"};
        };
        class Propofol {
            classnames[] = {"Propofol_IV"};
        };
        class Phentolamine {
            classnames[] = {"Phentolamine"};
        };
        class Hyaluronidase {
            classnames[] = {"Hyaluronidase"};
        };
    };
    class Concentration {
        class EpinephrineCardiac {
            concentration = 0.1;
            dose = "1mg/10ml (1:10,000)";
            volume = 10;
        };
        class Fentanyl {
            concentration = 0.05;
            dose = "500mcg/10ml";
            volume = 10;
        };
        class Norepinephrine {
            concentration = 1;
            dose = "4mg/4ml";
            volume = 4;
        };
        class HTS3 {
            concentration = 30;
            dose = "3% NaCl";
            volume = 10;
        };
        class Ceftriaxone {
            concentration = 100;
            dose = "1g/10ml";
            volume = 10;
        };
        class CalciumGluconate {
            concentration = 100;
            dose = "5g/50ml";
            volume = 50;
        };
        class Propofol {
            concentration = 10;
            dose = "500mg/50ml";
            volume = 50;
        };
        class Midazolam {
            concentration = 1;
            dose = "5mg/5ml";
            volume = 5;
        };
        class Rocuronium {
            concentration = 10;
            dose = "100mg/10ml";
            volume = 10;
        };
        class Sugammadex {
            concentration = 100;
            dose = "500mg/5ml";
            volume = 5;
        };
        class Phentolamine {
            concentration = 5;
            dose = "5mg/1ml";
            volume = 1;
        };
        class Hyaluronidase {
            concentration = 150;
            dose = "150U/1ml";
            volume = 1;
        };
    };
    class Medications {
        class ACM_Inhalant_Medication;
        class ACM_IV_Medication;
        class ACM_IM_Medication;
        class Ertapenem_IV;
        class Ertapenem;
        class Midazolam: ACM_IM_Medication {
            timeTillMaxEffect = 900;
            timeInSystem = 3600;
            maxEffectTime = 900;
        };
        class Adenosine_IV: ACM_IV_Medication {
            timeTillMaxEffect = 1;
            maxEffectTime = 1;
            timeInSystem = 15;
            hrIncrease[] = {0, 0};
        };
        class Ketamine: ACM_IM_Medication {
            medicationType = "Ketamine";
            minPainReduce = 0.4;
            painReduce = 0.95;
            maxPainReduce = 1;
            hrIncrease[] = {0, 0};
            timeInSystem = 900;
            timeTillMaxEffect = 20;
            maxEffectTime = 600;
            maxDose = 500;
            maxDoseDeviation = 100;
            minEffectDose = 41.5;
            maxEffectDose = 62.25;
        };
        class Ketamine_IV: ACM_IV_Medication {
            medicationType = "Ketamine";
            minPainReduce = 0.5;
            painReduce = 0.85;
            maxPainReduce = 1;
            hrIncrease[] = {0, 0};
            timeInSystem = 660;
            timeTillMaxEffect = 5;
            maxEffectTime = 540;
            maxDose = 250;
            maxDoseDeviation = 50;
            minEffectDose = 8.3;
            maxEffectDose = 16.6;
        };
        class Phentolamine: ACM_IM_Medication {
            medicationType = "Phentolamine";
            minEffectDose = 5;
            maxEffectDose = 5;
            weightEffect = 0;
            painReduce = 0;
            hrIncrease[] = {0, 0};
            rrAdjust[] = {0, 0};
            maxDose = 0;
        };
        class Hyaluronidase: ACM_IM_Medication {
            medicationType = "Hyaluronidase";
            minEffectDose = 150;
            maxEffectDose = 150;
            weightEffect = 0;
            painReduce = 0;
            hrIncrease[] = {0, 0};
            rrAdjust[] = {0, 0};
            maxDose = 0;
        };
        class Ceftriaxone_IV: Ertapenem_IV {};
        class Ceftriaxone: Ertapenem {};
        class Sugammadex_IV: ACM_IV_Medication {
            medicationType = "Sugammadex";
            minPainReduce = 0;
            painReduce = 0;
            maxPainReduce = 0;
            hrIncrease[] = {0, 0};
            maxHRIncrease = 0;
            rrAdjust[] = {0, 0};
            maxRRAdjust = 0;
            breathingEffectivenessAdjust[] = {0, 0};
            maxBreathingEffectivenessAdjust = 0;
            timeInSystem = 2100;
            timeTillMaxEffect = 150;
            maxEffectTime = 1500;
            maxDose = 0;
            incompatibleMedication[] = {};
            viscosityChange = 0;
            minEffectDose = 100;
            maxEffectDose = 100;
            weightEffect = 0;
            maxDoseDeviation = 0;
        };
        class Rocuronium_IV: ACM_IV_Medication {
            medicationType = "Rocuronium";
            minPainReduce = 0;
            painReduce = 0;
            maxPainReduce = 0;
            hrIncrease[] = {0, 0};
            maxHRIncrease = 0;
            rrAdjust[] = {0, 0};
            maxRRAdjust = 0;
            breathingEffectivenessAdjust[] = {0, 0};
            maxBreathingEffectivenessAdjust = 0;
            timeInSystem = 2400;
            timeTillMaxEffect = 60;
            maxEffectTime = 1800;
            maxDose = 0;
            maxDoseDeviation = 0;
            minEffectDose = 24.9;
            maxEffectDose = 83;
        };
        class Rocuronium: Rocuronium_IV {
            medicationType = "Rocuronium";
            timeTillMaxEffect = 90;
        };
        class CalciumChloride_IV: ACM_IV_Medication {
            hrIncrease[] = {0, 0};
            timeInSystem = 2700;
            timeTillMaxEffect = 300;
            maxEffectTime = 600;
            viscosityChange = -10;
            unstableDose = 4000;
            maxEffectDose = 1000;
            weightEffect = 0;
        };
        class CalciumGluconate_IV: ACM_IV_Medication {
            medicationType = "CalciumGluconate";
            hrIncrease[] = {0, 0};
            timeInSystem = 2700;
            timeTillMaxEffect = 420;
            maxEffectTime = 600;
            viscosityChange = -6;
            unstableDose = 12000;
            maxEffectDose = 3000;
            weightEffect = 0;
        };
        class Amiodarone_IV: ACM_IV_Medication {
            medicationType = "Amiodarone";
            hrIncrease[] = {0, 0};
            timeInSystem = 720;
            timeTillMaxEffect = 10;
            maxEffectTime = 480;
            maxDose = 2200;
            maxDoseDeviation = 200;
            unstableDose = 900;
            maxEffectDose = 150;
            weightEffect = 0;
        };
        class Midazolam_IV: ACM_IV_Medication {
            medicationType = "Midazolam";
            timeInSystem = 2700;
            timeTillMaxEffect = 240;
            maxEffectTime = 600;
            hrIncrease[] = {0, 0};
            rrAdjust[] = {-1, -4};
            maxDose = 30;
            maxDoseDeviation = 10;
            unstableDose = 20;
            maxEffectDose = 5;
            weightEffect = 0;
        };
        class Propofol_IV: ACM_IV_Medication {
            medicationType = "Propofol";
            timeInSystem = 480;
            timeTillMaxEffect = 90;
            maxEffectTime = 180;
            hrIncrease[] = {0, 0};
            rrAdjust[] = {-2, -6};
            painReduce = 0;
            maxDose = 400;
            maxDoseDeviation = 50;
            unstableDose = 200;
            maxEffectDose = 100;
            weightEffect = 1;
        };
        class Norepinephrine_IV: ACM_IV_Medication {
            medicationType = "Norepinephrine";
            timeInSystem = 360;
            timeTillMaxEffect = 30;
            maxEffectTime = 240;
            hrIncrease[] = {0, 0};
            maxDose = 1;
            maxDoseDeviation = 0.5;
            unstableDose = 1;
            maxEffectDose = 0.08;
            weightEffect = 0;
        };
        class Magnesium_IV: ACM_IV_Medication {
            medicationType = "Magnesium";
            timeInSystem = 1800;
            timeTillMaxEffect = 90;
            maxEffectTime = 900;
            hrIncrease[] = {0, 0};
            rrAdjust[] = {0, 0};
            maxDose = 4000;
            maxDoseDeviation = 1000;
            unstableDose = 6000;
            maxEffectDose = 2000;
            weightEffect = 0;
        };
        class Esmolol_IV: ACM_IV_Medication {
            hrIncrease[] = {0, 0};
            timeInSystem = 320;
            timeTillMaxEffect = 20;
            maxEffectTime = 240;
            unstableDose = 45;
            minEffectDose = 20.75;
            maxEffectDose = 41.5;
            weightEffect = 1;
        };
        class Epinephrine_IV: ACM_IV_Medication {
            medicationType = "Epinephrine";
            timeInSystem = 300;
            maxEffectTime = 180;
            hrIncrease[] = {0, 0};
            rrAdjust[] = {0, 0};
            breathingEffectivenessAdjust[] = {0.01, 0.04};
            viscosityChange = 5;
            unstableDose = 4;
            maxEffectDose = 1;
            weightEffect = 0;
        };
        class EpinephrineCardiac_IV: Epinephrine_IV {
            medicationType = "Epinephrine";
        };
        class Lidocaine_IV: ACM_IV_Medication {
            medicationType = "Lidocaine_IV";
            hrIncrease[] = {0, 0};
            timeInSystem = 600;
            maxEffectTime = 360;
            maxDose = 270;
            maxDoseDeviation = 50;
            unstableDose = 240;
            maxEffectDose = 83;
        };
        class Esketamine: ACM_Inhalant_Medication {
            medicationType = "Ketamine";
            minPainReduce = 0.45;
            painReduce = 0.8;
            maxPainReduce = 0.85;
            hrIncrease[] = {0, 0};
            maxHRIncrease = 10;
            rrAdjust[] = {0, 0};
            maxRRAdjust = 0;
            breathingEffectivenessAdjust[] = {0, 0};
            timeInSystem = 3600;
            timeTillMaxEffect = 600;
            maxEffectTime = 600;
            maxDose = 4;
            maxDoseDeviation = 1;
            minEffectDose = 0.5;
            maxEffectDose = 1;
        };
    };
};
class RscTitles {
    class ACME_Respiration_Display {
        idd = 71590;
        movingEnable = 0;
        enableSimulation = 1;
        duration = 100000000000;
        fadeIn = 0;
        fadeOut = 0;
        onLoad = "uiNamespace setVariable ['ACME_RespirationDisplay', (_this select 0)];";
        onUnload = "uiNamespace setVariable ['ACME_RespirationDisplay', displayNull];";
        class Controls {
            class Title: RscText {
                idc = 71591;
                style = 2;
                text = "Measure Respirations";
                x = "safezoneX";
                y = "safezoneY + safezoneH * 0.015";
                w = "safezoneW";
                h = "safezoneH * 0.06";
                sizeEx = "safezoneH * 0.03";
                shadow = 2;
            };
            class Patient: Title {
                idc = 71592;
                text = "";
                y = "safezoneY + safezoneH * 0.07";
                sizeEx = "safezoneH * 0.023";
            };
            class Circle: RscPicture {
                idc = 71593;
                text = "\acm_extended\ui\dot_grad_ca.paa";
                colorText[] = {0.3, 0.55, 1, 0};
                x = "safezoneX + safezoneW/2 - 0.025";
                y = "safezoneY + safezoneH/2 - 0.025";
                w = 0.05;
                h = 0.05;
            };
            class WatchBackground: RscText {
                idc = -1;
                text = "";
                colorBackground[] = {0.015, 0.02, 0.03, 0.82};
                x = "safezoneX + safezoneW * 0.40";
                y = "safezoneY + safezoneH * 0.68";
                w = "safezoneW * 0.20";
                h = "safezoneH * 0.14";
            };
            class WatchLabel: Title {
                idc = -1;
                text = "OBSERVATION WATCH";
                y = "safezoneY + safezoneH * 0.685";
                h = "safezoneH * 0.035";
                sizeEx = "safezoneH * 0.019";
            };
            class WatchSeconds: Title {
                idc = 71594;
                text = "Preparing...";
                y = "safezoneY + safezoneH * 0.72";
                h = "safezoneH * 0.055";
                sizeEx = "safezoneH * 0.036";
            };
            class Instructions: Title {
                idc = 71595;
                text = "15 real seconds | Esc to cancel";
                y = "safezoneY + safezoneH * 0.78";
                h = "safezoneH * 0.03";
                sizeEx = "safezoneH * 0.018";
            };
        };
    };
    class ACME_EMMA_Display {
        idd = 71500;
        movingEnable = 0;
        enableSimulation = 1;
        duration = 100000000000;
        fadeIn = 0;
        fadeOut = 0;
        onLoad = "uiNamespace setVariable ['ACME_EMMA_DLG', (_this select 0)]; (_this select 0) call ACME_fnc_emmaBuildDisplay;";
        onUnload = "uiNamespace setVariable ['ACME_EMMA_DLG', displayNull];";
        class Controls {};
    };
    class ACME_BVMVent_Display {
        idd = 71510;
        movingEnable = 0;
        enableSimulation = 1;
        duration = 100000000000;
        fadeIn = 0;
        fadeOut = 0;
        onLoad = "uiNamespace setVariable ['ACME_BVMVent_DLG', (_this select 0)];";
        onUnload = "uiNamespace setVariable ['ACME_BVMVent_DLG', displayNull];";
        class Controls {
            class ACME_BVMVent_Circle: RscPicture {
                idc = 71511;
                text = "\acm_extended\ui\dot_grad_ca.paa";
                colorText[] = {0.3, 0.55, 1, 0};
                x = "safezoneX + safezoneW/2 - 0.025";
                y = "safezoneY + safezoneH/2 - 0.025";
                w = 0.05;
                h = 0.05;
            };
        };
    };
    class ACME_HCPush_Display {
        idd = 71520;
        movingEnable = 0;
        enableSimulation = 1;
        duration = 100000000000;
        fadeIn = 0;
        fadeOut = 0;
        onLoad = "uiNamespace setVariable ['ACME_HCPush_DLG', (_this select 0)];";
        onUnload = "uiNamespace setVariable ['ACME_HCPush_DLG', displayNull];";
        class Controls {
            class ACME_HCPush_Backbit: RscPicture {
                idc = 71521;
                text = "\acm_extended\ui\syringe\hud\syringe_10_backbit_ca.paa";
                colorText[] = {1, 1, 1, 1};
                x = 0;
                y = 0;
                w = 0.1;
                h = 0.1;
            };
            class ACME_HCPush_Plunger: ACME_HCPush_Backbit {
                idc = 71522;
                text = "\acm_extended\ui\syringe\hud\syringe_10_plunger_ca.paa";
            };
            class ACME_HCPush_Barrel: ACME_HCPush_Backbit {
                idc = 71523;
                text = "\acm_extended\ui\syringe\hud\syringe_10_barrel_ca.paa";
            };
            class ACME_HCPush_Panel: RscText {
                idc = 71524;
                text = "";
                colorText[] = {1, 1, 1, 0};
                colorBackground[] = {0.02, 0.03, 0.06, 0.9};
                x = 0;
                y = 0;
                w = 0.2;
                h = 0.05;
            };
            class ACME_HCPush_Text: RscStructuredText {
                idc = 71525;
                text = "";
                colorText[] = {0.94, 0.91, 0.82, 1};
                colorBackground[] = {0, 0, 0, 0};
                x = 0;
                y = 0;
                w = 0.2;
                h = 0.05;
            };
        };
    };
};
class CfgRemoteExec {
    class Functions {
        class ACM_airway_fnc_remoteSay3D {
            allowedTargets = 0;
        };
        class ACME_fnc_blastLungInflict {
            allowedTargets = 0;
        };
        class ACME_fnc_bloodColdChainNudge {
            allowedTargets = 2;
        };
        class ACME_fnc_bloodFridgeSpawn {
            allowedTargets = 2;
        };
        class ACME_fnc_ccApply {
            allowedTargets = 0;
        };
        class ACME_fnc_coolerBoxApplyScale {
            allowedTargets = 0;
            jip = 1;
        };
        class ACME_fnc_edemaSet {
            allowedTargets = 0;
        };
        class ACME_fnc_forceWalkLocal {
            allowedTargets = 0;
        };
        class ACME_fnc_megacodeArrest {
            allowedTargets = 0;
        };
        class ACME_fnc_megacodeCableApply {
            allowedTargets = 2;
        };
        class ACME_fnc_megacodeChestInjury {
            allowedTargets = 0;
        };
        class ACME_fnc_megacodeClearWounds {
            allowedTargets = 0;
        };
        class ACME_fnc_megacodeLog {
            allowedTargets = 0;
        };
        class ACME_fnc_megacodeMenu {
            allowedTargets = 0;
        };
        class ACME_fnc_megacodePanelRetarget {
            allowedTargets = 0;
        };
        class ACME_fnc_megacodeResetUnit {
            allowedTargets = 0;
        };
        class ACME_fnc_megacodeScenario {
            allowedTargets = 0;
        };
        class ACME_fnc_remoteDeleteVehicle {
            allowedTargets = 2;
        };
        class ACME_fnc_remoteSay3D {
            allowedTargets = 0;
        };
        class ACME_fnc_zeusClearTBILocal {
            allowedTargets = 0;
        };
        class ACME_fnc_zeusInflictJunctionalLocal {
            allowedTargets = 0;
        };
        class ACME_fnc_zeusTBIApplyLocal {
            allowedTargets = 0;
        };
    };
};

class CfgPatches {
    class ACM_core {
        acmeBuildBatch = "B214";
        acmeNetworkProtocol = 1;
        acmeComponent = "core";
        name = "ACM - Core";
        units[] = {"ACM_MedicalSupplyCrate_Basic", "ACM_MedicalSupplyCrate_Advanced"};
        weapons[] = {};
        requiredVersion = 2.18;
        requiredAddons[] = {
            "cba_main",
            "ace_main",
            "ace_advanced_fatigue",
            "ace_common",
            "ace_dogtags",
            "ace_dragging",
            "ace_interact_menu",
            "ace_medical",
            "ace_medical_ai",
            "ace_medical_damage",
            "ace_medical_engine",
            "ace_medical_feedback",
            "ace_medical_statemachine",
            "ace_medical_status",
            "ace_medical_treatment",
            "ace_medical_vitals",
            "ace_zeus"
        };
        author = "Blue";
        version = 1.2;
        versionStr = "1.2.4.1";
        versionAr[] = {1, 2, 4, 1};
    };
};
class ACE_Medical_StateMachine {
    list = "call ace_common_fnc_getLocalUnits";
    skipNull = 1;
    class Default {
        onState = "ace_medical_statemachine_fnc_handleStateDefault";
        class Injury {
            targetState = "Injured";
            events[] = {"ace_medical_injured", "ace_medical_LoweredVitals"};
        };
        class CriticalInjuryOrVitals {
            targetState = "Unconscious";
            events[] = {"ace_medical_CriticalInjury", "ace_medical_CriticalVitals", "ace_medical_knockOut"};
        };
        class FatalVitals {
            targetState = "CardiacArrest";
            events[] = {"ace_medical_FatalVitals", "ace_medical_Bleedout"};
        };
        class FatalInjury {
            targetState = "FatalInjury";
            events[] = {"ace_medical_FatalInjury"};
        };
    };
    class Injured {
        onState = "ace_medical_statemachine_fnc_handleStateInjured";
        class FullHeal {
            targetState = "Default";
            events[] = {"ace_medical_FullHeal"};
        };
        class CriticalInjuryOrVitals {
            targetState = "Unconscious";
            events[] = {"ace_medical_CriticalInjury", "ace_medical_CriticalVitals", "ace_medical_knockOut"};
        };
        class FatalVitals {
            targetState = "CardiacArrest";
            events[] = {"ace_medical_FatalVitals", "ace_medical_Bleedout"};
        };
        class FatalInjury {
            targetState = "FatalInjury";
            events[] = {"ace_medical_FatalInjury"};
        };
    };
    class Unconscious {
        onState = "ace_medical_statemachine_fnc_handleStateUnconscious";
        onStateEntered = "ace_medical_statemachine_fnc_enteredStateUnconscious";
        class DeathAI {
            targetState = "Dead";
            condition = "!(_this getVariable [""ace_medical_statemachine_AIUnconsciousness"", ace_medical_statemachine_AIUnconsciousness]) && {!isPlayer _this}";
        };
        class WakeUp {
            targetState = "Injured";
            condition = "[_this] call ACM_core_fnc_canWake";
            events[] = {"ace_medical_WakeUp"};
            onTransition = "[_this, false] call ace_medical_status_fnc_setUnconsciousState";
        };
        class FatalTransitions {
            targetState = "CardiacArrest";
            events[] = {"ace_medical_FatalVitals", "ace_medical_Bleedout"};
        };
        class FatalInjury {
            targetState = "FatalInjury";
            events[] = {"ace_medical_FatalInjury"};
        };
    };
    class FatalInjury {
        onStateEntered = "ace_medical_statemachine_fnc_enteredStateFatalInjury";
        class SecondChance {
            events[] = {"ace_medical_FatalInjuryInstantTransition"};
            targetState = "CardiacArrest";
            condition = "ace_medical_statemachine_fnc_conditionSecondChance";
            onTransition = "ace_medical_statemachine_fnc_transitionSecondChance";
        };
        class Death {
            events[] = {"ace_medical_FatalInjuryInstantTransition"};
            targetState = "Dead";
        };
    };
    class CardiacArrest {
        onState = "ace_medical_statemachine_fnc_handleStateCardiacArrest";
        onStateEntered = "ace_medical_statemachine_fnc_enteredStateCardiacArrest";
        onStateLeaving = "ace_medical_statemachine_fnc_leftStateCardiacArrest";
        class DeathAI {
            targetState = "Dead";
            condition = "!(_this getVariable [""ace_medical_statemachine_AIUnconsciousness"", ace_medical_statemachine_AIUnconsciousness]) && {!isPlayer _this}";
        };
        class Reanimation {
            targetState = "Unconscious";
            events[] = {"ace_medical_CPRSucceeded"};
        };
        class Execution {
            targetState = "Dead";
            condition = "ace_medical_statemachine_fnc_conditionExecutionDeath";
            events[] = {"ace_medical_FatalInjury"};
        };
        class Bleedout {
            targetState = "Dead";
            condition = "(ace_medical_statemachine_cardiacArrestBleedoutEnabled)";
            events[] = {"ace_medical_Bleedout"};
        };
        delete Timeout;
    };
    class Dead {
        onStateEntered = "ace_medical_statemachine_fnc_enteredStateDeath";
    };
};
class CfgEditorSubcategories {
    class ACM_core_EditorCategory {
        displayName = "ACM Equipment";
    };
};
class CfgFunctions {
    class overwrite_interact_menu {
        tag = "ace_interact_menu";
        class ace_interact_menu {
            class compileMenuSelfAction {
                file = "\x\ACM\addons\core\overrides\fnc_compileMenuSelfAction.sqf";
            };
            class keyDown {
                file = "\x\ACM\addons\core\overrides\fnc_keyDown.sqf";
            };
        };
    };
    class overwrite_ace_common {
        tag = "ace_common";
        class ace_common {
            class displayTextStructured {
                file = "\x\ACM\addons\core\overrides\fnc_displayTextStructured.sqf";
            };
            class progressBar {
                file = "\x\ACM\addons\core\overrides\fnc_progressBar.sqf";
            };
        };
    };
    class overwrite_medical {
        tag = "ace_medical";
        class ace_medical {
            class deserializeState {
                file = "\x\ACM\addons\core\overrides\fnc_deserializeState.sqf";
            };
            class serializeState {
                file = "\x\ACM\addons\core\overrides\fnc_serializeState.sqf";
            };
        };
    };
    class overwrite_medical_vitals {
        tag = "ace_medical_vitals";
        class ace_medical_vitals {
            class handleUnitVitals {
                file = "\x\ACM\addons\core\overrides\fnc_handleUnitVitals.sqf";
            };
            class updatePeripheralResistance {
                file = "\x\ACM\addons\core\overrides\fnc_updatePeripheralResistance.sqf";
            };
            class updateHeartRate {
                file = "\x\ACM\addons\core\overrides\fnc_updateHeartRate.sqf";
            };
            class updateOxygen {
                file = "\x\ACM\addons\core\overrides\fnc_updateOxygen.sqf";
            };
        };
    };
    class overwrite_medical_status {
        tag = "ace_medical_status";
        class ace_medical_status {
            class getBloodPressure {
                file = "\x\ACM\addons\core\overrides\fnc_getBloodPressure.sqf";
            };
            class getCardiacOutput {
                file = "\x\ACM\addons\core\overrides\fnc_getCardiacOutput.sqf";
            };
            class getBloodVolumeChange {
                file = "\x\ACM\addons\core\overrides\fnc_getBloodVolumeChange.sqf";
            };
            class hasStableVitals {
                file = "\x\ACM\addons\core\overrides\fnc_hasStableVitals.sqf";
            };
            class getBloodLoss {
                file = "\x\ACM\addons\core\overrides\fnc_getBloodLoss.sqf";
            };
            class updateWoundBloodLoss {
                file = "\x\ACM\addons\core\overrides\fnc_updateWoundBloodLoss.sqf";
            };
            class addMedicationAdjustment {
                file = "\x\ACM\addons\core\overrides\fnc_addMedicationAdjustment.sqf";
            };
            class getAllMedicationCount {
                file = "\x\ACM\addons\core\overrides\fnc_getAllMedicationCount.sqf";
            };
            class getMedicationCount {
                file = "\x\ACM\addons\core\overrides\fnc_getMedicationCount.sqf";
            };
            class setCardiacArrestState {
                file = "\x\ACM\addons\core\overrides\fnc_setCardiacArrestState.sqf";
            };
        };
    };
    class overwrite_medical_treatment {
        tag = "ace_medical_treatment";
        class ace_medical_treatment {
            class treatment {
                file = "\x\ACM\addons\core\overrides\fnc_treatment.sqf";
            };
            class addToLog {
                file = "\x\ACM\addons\core\overrides\fnc_addToLog.sqf";
            };
            class canTreatCached {
                file = "\x\ACM\addons\core\overrides\fnc_canTreatCached.sqf";
            };
            class canTreat_holsterCheck {
                file = "\x\ACM\addons\core\overrides\fnc_canTreat_holsterCheck.sqf";
            };
            class ivBagLocal {
                file = "\x\ACM\addons\core\overrides\fnc_ivBagLocal.sqf";
            };
            class ivBag {
                file = "\x\ACM\addons\core\overrides\fnc_ivBag.sqf";
            };
            class medication {
                file = "\x\ACM\addons\core\overrides\fnc_medication.sqf";
            };
            class medicationLocal {
                file = "\x\ACM\addons\core\overrides\fnc_medicationLocal.sqf";
            };
            class onMedicationUsage {
                file = "\x\ACM\addons\core\overrides\fnc_onMedicationUsage.sqf";
            };
            class checkPulseLocal {
                file = "\x\ACM\addons\core\overrides\fnc_checkPulseLocal.sqf";
            };
            class tourniquetRemove {
                file = "\x\ACM\addons\core\overrides\fnc_tourniquetRemove.sqf";
            };
            class loadUnit {
                file = "\x\ACM\addons\core\overrides\fnc_loadUnit.sqf";
            };
            class getTriageStatus {
                file = "\x\ACM\addons\core\overrides\fnc_getTriageStatus.sqf";
            };
            class placeInBodyBag {
                file = "\x\ACM\addons\core\overrides\fnc_placeInBodyBag.sqf";
            };
        };
    };
    class overwrite_medical_damage {
        tag = "ace_medical_damage";
        class ace_medical_damage {
            class woundsHandlerBase {
                file = "\x\ACM\addons\core\overrides\fnc_woundsHandlerBase.sqf";
            };
        };
    };
    class overwrite_medical_feedback {
        tag = "ace_medical_feedback";
        class ace_medical_feedback {
            class handleEffects {
                file = "\x\ACM\addons\core\overrides\fnc_handleEffects.sqf";
            };
            class effectHeartBeat {
                file = "\x\ACM\addons\core\overrides\fnc_effectHeartBeat.sqf";
            };
            class effectPain {
                file = "\x\ACM\addons\core\overrides\fnc_effectPain.sqf";
            };
            class initEffects {
                file = "\x\ACM\addons\core\overrides\fnc_initEffects.sqf";
            };
            class effectUnconscious {
                file = "\x\ACM\addons\core\overrides\fnc_effectUnconscious.sqf";
            };
            class playInjuredSound {
                file = "\x\ACM\addons\core\overrides\fnc_playInjuredSound.sqf";
            };
        };
    };
    class overwrite_medical_statemachine {
        tag = "ace_medical_statemachine";
        class ace_medical_statemachine {
            class enteredStateCardiacArrest {
                file = "\x\ACM\addons\core\overrides\fnc_enteredStateCardiacArrest.sqf";
            };
            class handleStateUnconscious {
                file = "\x\ACM\addons\core\overrides\fnc_handleStateUnconscious.sqf";
            };
            class conditionSecondChance {
                file = "\x\ACM\addons\core\overrides\fnc_conditionSecondChance.sqf";
            };
            class conditionExecutionDeath {
                file = "\x\ACM\addons\core\overrides\fnc_conditionExecutionDeath.sqf";
            };
        };
    };
    class overwrite_medical_engine {
        tag = "ace_medical_engine";
        class ace_medical_engine {
            class setUnconsciousAnim {
                file = "\x\ACM\addons\core\overrides\fnc_setUnconsciousAnim.sqf";
            };
            class applyAnimAfterRagdoll {
                file = "\x\ACM\addons\core\overrides\fnc_applyAnimAfterRagdoll.sqf";
            };
            class updateDamageEffects {
                file = "\x\ACM\addons\core\overrides\fnc_updateDamageEffects.sqf";
            };
            class handleDamage {
                file = "\x\ACM\addons\core\overrides\fnc_handleDamage.sqf";
            };
        };
    };
    class overwrite_medical_ai {
        tag = "ace_medical_ai";
        class ace_medical_ai {
            class healingLogic {
                file = "\x\ACM\addons\core\overrides\fnc_healingLogic.sqf";
            };
            class healSelf {
                file = "\x\ACM\addons\core\overrides\fnc_healSelf.sqf";
            };
            class healUnit {
                file = "\x\ACM\addons\core\overrides\fnc_healUnit.sqf";
            };
            class itemCheck {
                file = "\x\ACM\addons\core\overrides\fnc_itemCheck.sqf";
            };
            class playTreatmentAnim {
                file = "\x\ACM\addons\core\overrides\fnc_playTreatmentAnim.sqf";
            };
        };
    };
    class overwrite_ace_dogtags {
        tag = "ace_dogtags";
        class ace_dogtags {
            class getDogtagData {
                file = "\x\ACM\addons\core\overrides\fnc_getDogtagData.sqf";
            };
            class showDogtag {
                file = "\x\ACM\addons\core\overrides\fnc_showDogtag.sqf";
            };
            class checkDogtag {
                file = "\x\ACM\addons\core\overrides\fnc_checkDogtag.sqf";
            };
        };
    };
    class overwrite_ace_advanced_fatigue {
        tag = "ace_advanced_fatigue";
        class ace_advanced_fatigue {
            class handleEffects {
                file = "\x\ACM\addons\core\overrides\fnc_handleEffects_AF.sqf";
            };
        };
    };
    class overwrite_ace_zeus {
        tag = "ace_zeus";
        class ace_zeus {
            class moduleUnconscious {
                file = "\x\ACM\addons\core\overrides\fnc_moduleUnconscious.sqf";
            };
        };
    };
    class overwrite_ace_dragging {
        tag = "ace_dragging";
        class ace_dragging {
            class startCarryLocal {
                file = "\x\ACM\addons\core\overrides\fnc_startCarryLocal.sqf";
            };
            class handleUnconscious {
                file = "\x\ACM\addons\core\overrides\fnc_handleUnconscious.sqf";
            };
            class canDrag {
                file = "\x\ACM\addons\core\overrides\fnc_canDrag.sqf";
            };
            class canCarry {
                file = "\x\ACM\addons\core\overrides\fnc_canCarry.sqf";
            };
        };
    };
};
class Extended_PreStart_EventHandlers {
    class ACM_core {
        init = "call compileScript ['\x\ACM\addons\core\XEH_preStart.sqf']";
    };
};
class Extended_PreInit_EventHandlers {
    class ACM_core {
        init = "call compileScript ['\x\ACM\addons\core\XEH_preInit.sqf']";
    };
};
class Extended_PostInit_EventHandlers {
    class ACM_core {
        init = "call compileScript ['\x\ACM\addons\core\XEH_postInit.sqf']";
    };
};
class Extended_Respawn_EventHandlers {
    class CAManBase {
        class ACM_core {
            respawn = "_this call ACM_core_fnc_handleRespawn";
        };
    };
};
class Extended_Init_EventHandlers {
    class CAManBase {
        class ACM_core {
            init = "[(_this select 0)] call ACM_core_fnc_initUnit";
            exclude[] = {"B_UAV_AI", "O_UAV_AI", "UAV_AI_base_F"};
        };
    };
};
class Extended_InitPost_EventHandlers {
    class LandVehicle {
        class ACM_core {
            init = "_this call ACM_core_fnc_addVehicleCarryLoadActions";
        };
    };
    class Air {
        class ACM_core {
            init = "_this call ACM_core_fnc_addVehicleCarryLoadActions";
        };
    };
    class Ship {
        class ACM_core {
            init = "_this call ACM_core_fnc_addVehicleCarryLoadActions";
        };
    };
};
class ace_Medical_Treatment {
    class Bandaging {
        class FieldDressing;
        class PressureBandage: FieldDressing {
            class Abrasion {
                effectiveness = 4;
                reopeningChance = 0.6;
                reopeningMinDelay = 800;
                reopeningMaxDelay = 1500;
            };
            class AbrasionMinor: Abrasion {};
            class AbrasionMedium: Abrasion {
                effectiveness = 3;
                reopeningChance = 0.9;
            };
            class AbrasionLarge: Abrasion {
                effectiveness = 2.5;
                reopeningChance = 1;
            };
            class Avulsion: Abrasion {
                effectiveness = 2;
                reopeningChance = 0.7;
                reopeningMinDelay = 1000;
                reopeningMaxDelay = 1600;
            };
            class AvulsionMinor: Avulsion {};
            class AvulsionMedium: Avulsion {
                effectiveness = 1.4;
            };
            class AvulsionLarge: Avulsion {
                effectiveness = 1;
            };
            class Contusion: Abrasion {
                effectiveness = 2;
                reopeningChance = 0;
                reopeningMinDelay = 0;
                reopeningMaxDelay = 0;
            };
            class ContusionMinor: Contusion {};
            class ContusionMedium: Contusion {};
            class ContusionLarge: Contusion {};
            class Crush: Abrasion {
                effectiveness = 2;
                reopeningChance = 0.6;
                reopeningMinDelay = 600;
                reopeningMaxDelay = 1000;
            };
            class CrushMinor: Crush {};
            class CrushMedium: Crush {
                effectiveness = 1.7;
                reopeningChance = 0.7;
            };
            class CrushLarge: Crush {
                effectiveness = 1.6;
                reopeningChance = 0.8;
            };
            class Cut: Abrasion {
                effectiveness = 5;
                reopeningChance = 0.6;
                reopeningMinDelay = 700;
                reopeningMaxDelay = 1000;
            };
            class CutMinor: Cut {};
            class CutMedium: Cut {
                effectiveness = 3.5;
                reopeningChance = 0.7;
            };
            class CutLarge: Cut {
                effectiveness = 2;
                reopeningChance = 0.8;
            };
            class Laceration: Abrasion {
                effectiveness = 2;
                reopeningChance = 0.65;
                reopeningMinDelay = 500;
                reopeningMaxDelay = 2000;
            };
            class LacerationMinor: Laceration {};
            class LacerationMedium: Laceration {
                effectiveness = 1.5;
                reopeningChance = 0.8;
            };
            class LacerationLarge: Laceration {
                effectiveness = 1;
                reopeningChance = 0.9;
            };
            class VelocityWound: Abrasion {
                effectiveness = 2.2;
                reopeningChance = 1;
                reopeningMinDelay = 800;
                reopeningMaxDelay = 2000;
            };
            class VelocityWoundMinor: VelocityWound {};
            class VelocityWoundMedium: VelocityWound {
                effectiveness = 1.75;
            };
            class VelocityWoundLarge: VelocityWound {
                effectiveness = 1.5;
            };
            class PunctureWound: Abrasion {
                effectiveness = 2.5;
                reopeningChance = 1;
                reopeningMinDelay = 1000;
                reopeningMaxDelay = 3000;
            };
            class PunctureWoundMinor: PunctureWound {};
            class PunctureWoundMedium: PunctureWound {
                effectiveness = 2;
            };
            class PunctureWoundLarge: PunctureWound {
                effectiveness = 1.5;
            };
        };
        class EmergencyTraumaDressing: PressureBandage {
            class Abrasion {
                effectiveness = 20;
                reopeningChance = 0.48;
                reopeningMinDelay = 800;
                reopeningMaxDelay = 1500;
            };
            class AbrasionMinor: Abrasion {};
            class AbrasionMedium: Abrasion {
                effectiveness = 15;
                reopeningChance = 0.72;
            };
            class AbrasionLarge: Abrasion {
                effectiveness = 12.5;
                reopeningChance = 0.8;
            };
            class Avulsion: Abrasion {
                effectiveness = 10;
                reopeningChance = 0.52;
                reopeningMinDelay = 1000;
                reopeningMaxDelay = 1600;
            };
            class AvulsionMinor: Avulsion {};
            class AvulsionMedium: Avulsion {
                effectiveness = 7;
            };
            class AvulsionLarge: Avulsion {
                effectiveness = 5;
            };
            class Contusion: Abrasion {
                effectiveness = 10;
                reopeningChance = 0;
                reopeningMinDelay = 0;
                reopeningMaxDelay = 0;
            };
            class ContusionMinor: Contusion {};
            class ContusionMedium: Contusion {};
            class ContusionLarge: Contusion {};
            class Crush: Abrasion {
                effectiveness = 10;
                reopeningChance = 0.48;
                reopeningMinDelay = 600;
                reopeningMaxDelay = 1000;
            };
            class CrushMinor: Crush {};
            class CrushMedium: Crush {
                effectiveness = 8.5;
                reopeningChance = 0.52;
            };
            class CrushLarge: Crush {
                effectiveness = 8;
                reopeningChance = 0.64;
            };
            class Cut: Abrasion {
                effectiveness = 25;
                reopeningChance = 0.48;
                reopeningMinDelay = 700;
                reopeningMaxDelay = 1000;
            };
            class CutMinor: Cut {};
            class CutMedium: Cut {
                effectiveness = 17.5;
                reopeningChance = 0.52;
            };
            class CutLarge: Cut {
                effectiveness = 10;
                reopeningChance = 0.64;
            };
            class Laceration: Abrasion {
                effectiveness = 10;
                reopeningChance = 0.52;
                reopeningMinDelay = 500;
                reopeningMaxDelay = 2000;
            };
            class LacerationMinor: Laceration {};
            class LacerationMedium: Laceration {
                effectiveness = 7.5;
                reopeningChance = 0.64;
            };
            class LacerationLarge: Laceration {
                effectiveness = 5;
                reopeningChance = 0.72;
            };
            class VelocityWound: Abrasion {
                effectiveness = 11;
                reopeningChance = 0.8;
                reopeningMinDelay = 800;
                reopeningMaxDelay = 2000;
            };
            class VelocityWoundMinor: VelocityWound {};
            class VelocityWoundMedium: VelocityWound {
                effectiveness = 8.75;
            };
            class VelocityWoundLarge: VelocityWound {
                effectiveness = 7.5;
            };
            class PunctureWound: Abrasion {
                effectiveness = 12.5;
                reopeningChance = 0.8;
                reopeningMinDelay = 1000;
                reopeningMaxDelay = 3000;
            };
            class PunctureWoundMinor: PunctureWound {};
            class PunctureWoundMedium: PunctureWound {
                effectiveness = 10;
            };
            class PunctureWoundLarge: PunctureWound {
                effectiveness = 7.5;
            };
        };
        class ElasticWrap: PressureBandage {
            class Abrasion {
                effectiveness = 0;
            };
            class AbrasionMinor: Abrasion {};
            class AbrasionMedium: Abrasion {};
            class AbrasionLarge: Abrasion {};
            class Avulsion: Abrasion {};
            class AvulsionMinor: Avulsion {};
            class AvulsionMedium: Avulsion {};
            class AvulsionLarge: Avulsion {};
            class Contusion {
                effectiveness = 2;
                reopeningChance = 0;
                reopeningMinDelay = 0;
                reopeningMaxDelay = 0;
            };
            class ContusionMinor: Contusion {
                effectiveness = 3;
            };
            class ContusionMedium: Contusion {};
            class ContusionLarge: Contusion {
                effectiveness = 1;
            };
            class Crush: Abrasion {};
            class CrushMinor: Crush {};
            class CrushMedium: Crush {};
            class CrushLarge: Crush {};
            class Cut: Abrasion {};
            class CutMinor: Cut {};
            class CutMedium: Cut {};
            class CutLarge: Cut {};
            class Laceration: Abrasion {};
            class LacerationMinor: Laceration {};
            class LacerationMedium: Laceration {};
            class LacerationLarge: Laceration {};
            class VelocityWound: Abrasion {};
            class VelocityWoundMinor: VelocityWound {};
            class VelocityWoundMedium: VelocityWound {};
            class VelocityWoundLarge: VelocityWound {};
            class PunctureWound: Abrasion {};
            class PunctureWoundMinor: PunctureWound {};
            class PunctureWoundMedium: PunctureWound {};
            class PunctureWoundLarge: PunctureWound {};
        };
    };
    class IV {
        volume = 1000;
        ratio[] = {};
        type = "Blood";
        class BloodIV {
            volume = 1000;
            ratio[] = {"Plasma", 1};
        };
        class BloodIV_500: BloodIV {
            volume = 500;
        };
        class BloodIV_250: BloodIV {
            volume = 250;
        };
        class PlasmaIV: BloodIV {
            volume = 1000;
            ratio[] = {"Blood", 1};
            type = "Plasma";
        };
        class PlasmaIV_500: PlasmaIV {
            volume = 500;
        };
        class PlasmaIV_250: PlasmaIV {
            volume = 250;
        };
        class SalineIV: BloodIV {
            volume = 1000;
            type = "Saline";
            ratio[] = {};
        };
        class SalineIV_500: SalineIV {
            volume = 500;
        };
        class SalineIV_250: SalineIV {
            volume = 250;
        };
        class FreshBloodBag_500: BloodIV_500 {
            type = "FreshBlood";
        };
        class FreshBloodBag_250: FreshBloodBag_500 {
            volume = 250;
        };
        class BloodBag_O_1000: BloodIV {
            volume = 1000;
            ratio[] = {"Plasma", 1};
            type = "Blood";
            bloodtype = 0;
        };
        class BloodBag_ON_1000: BloodBag_O_1000 {
            bloodtype = 1;
        };
        class BloodBag_A_1000: BloodBag_O_1000 {
            bloodtype = 2;
        };
        class BloodBag_AN_1000: BloodBag_O_1000 {
            bloodtype = 3;
        };
        class BloodBag_B_1000: BloodBag_O_1000 {
            bloodtype = 4;
        };
        class BloodBag_BN_1000: BloodBag_O_1000 {
            bloodtype = 5;
        };
        class BloodBag_AB_1000: BloodBag_O_1000 {
            bloodtype = 6;
        };
        class BloodBag_ABN_1000: BloodBag_O_1000 {
            bloodtype = 7;
        };
        class BloodBag_O_500: BloodBag_O_1000 {
            volume = 500;
        };
        class BloodBag_ON_500: BloodBag_O_500 {
            bloodtype = 1;
        };
        class BloodBag_A_500: BloodBag_O_500 {
            bloodtype = 2;
        };
        class BloodBag_AN_500: BloodBag_O_500 {
            bloodtype = 3;
        };
        class BloodBag_B_500: BloodBag_O_500 {
            bloodtype = 4;
        };
        class BloodBag_BN_500: BloodBag_O_500 {
            bloodtype = 5;
        };
        class BloodBag_AB_500: BloodBag_O_500 {
            bloodtype = 6;
        };
        class BloodBag_ABN_500: BloodBag_O_500 {
            bloodtype = 7;
        };
        class BloodBag_O_250: BloodBag_O_1000 {
            volume = 250;
        };
        class BloodBag_ON_250: BloodBag_O_250 {
            bloodtype = 1;
        };
        class BloodBag_A_250: BloodBag_O_250 {
            bloodtype = 2;
        };
        class BloodBag_AN_250: BloodBag_O_250 {
            bloodtype = 3;
        };
        class BloodBag_B_250: BloodBag_O_250 {
            bloodtype = 4;
        };
        class BloodBag_BN_250: BloodBag_O_250 {
            bloodtype = 5;
        };
        class BloodBag_AB_250: BloodBag_O_250 {
            bloodtype = 6;
        };
        class BloodBag_ABN_250: BloodBag_O_250 {
            bloodtype = 7;
        };
    };
};
class ACM_Medication {
    class Medications {
        maxDoseDeviation = 1;
        hrIncrease[] = {0, 0};
        administrationType = 0;
        medicationType = "Default";
        rrAdjust[] = {0, 0};
        coSensitivityAdjust[] = {0, 0};
        breathingEffectivenessAdjust[] = {0, 0};
        maxEffectTime = 120;
        onOverDose = "";
        minEffectDose = 1;
        maxEffectDose = 1;
        weightEffect = 0;
        absorptionEffect = 0;
        minPainReduce = 0;
        maxPainReduce = 1;
        class ACM_PO_Medication {
            painReduce = 0;
            timeInSystem = 3000;
            timeTillMaxEffect = 240;
            maxEffectTime = 900;
            maxDose = 0;
            maxDoseDeviation = 0;
            incompatibleMedication[] = {};
            administrationType = 2;
            medicationType = "Default";
            maxPainReduce = 1;
            viscosityChange = 0;
            weightEffect = 1;
        };
        class Paracetamol: ACM_PO_Medication {
            minPainReduce = 0.35;
            painReduce = 0.35;
            maxPainReduce = 0.45;
        };
        class ACM_Inhalant_Medication {
            painReduce = 0;
            timeInSystem = 40;
            timeTillMaxEffect = 3;
            maxEffectTime = 6;
            maxDose = 0;
            maxDoseDeviation = 0;
            incompatibleMedication[] = {};
            administrationType = 3;
            medicationType = "Default";
            maxPainReduce = 1;
            viscosityChange = 0;
        };
        class AmmoniaInhalant: ACM_Inhalant_Medication {
            hrIncrease[] = {5, 25};
            maxHRIncrease = 25;
            rrAdjust[] = {3, 3};
            maxRRAdjust = 4;
        };
        class Penthrox: ACM_Inhalant_Medication {
            minPainReduce = 0.5;
            painReduce = 0.5;
            maxPainReduce = 0.7;
            hrIncrease[] = {-0.1, -0.5};
            timeInSystem = 240;
            maxEffectTime = 90;
            maxDose = 5;
            maxDoseDeviation = 1;
            breathingEffectivenessAdjust[] = {-0.001, -0.01};
        };
        class Naloxone: ACM_Inhalant_Medication {
            timeInSystem = 360;
            maxEffectTime = 120;
        };
        class ACM_IV_Medication {
            painReduce = 0;
            timeInSystem = 360;
            timeTillMaxEffect = 5;
            maxEffectTime = 240;
            maxDose = 0;
            maxDoseDeviation = 0;
            incompatibleMedication[] = {};
            administrationType = 1;
            medicationType = "Default";
            maxPainReduce = 1;
            viscosityChange = 0;
            weightEffect = 1;
        };
        class Epinephrine_IV: ACM_IV_Medication {
            medicationType = "Epinephrine";
            timeInSystem = 300;
            maxEffectTime = 180;
            hrIncrease[] = {10, 20};
            rrAdjust[] = {2, 8};
            breathingEffectivenessAdjust[] = {0.01, 0.04};
            viscosityChange = 5;
            unstableDose = 4;
            maxEffectDose = 1;
            weightEffect = 0;
        };
        class Adenosine_IV: ACM_IV_Medication {
            timeInSystem = 100;
            timeTillMaxEffect = 60;
            maxEffectTime = 25;
            hrIncrease[] = {-5, -24};
            unstableDose = 2;
            maxEffectDose = 6;
            weightEffect = 0;
        };
        class Morphine_IV: ACM_IV_Medication {
            medicationType = "Opioid";
            minPainReduce = 0.6;
            painReduce = 0.85;
            maxPainReduce = 1;
            hrIncrease[] = {-4, -10};
            timeInSystem = 1300;
            timeTillMaxEffect = 25;
            maxEffectTime = 900;
            coSensitivityAdjust[] = {-0.04, -0.08};
            viscosityChange = 10;
            maxDose = 12;
            maxDoseDeviation = 3;
            unstableDose = 10;
            minEffectDose = 4.15;
            maxEffectDose = 8.3;
            weightEffect = 2;
        };
        class Amiodarone_IV: ACM_IV_Medication {
            medicationType = "Amiodarone";
            hrIncrease[] = {-5, -10};
            timeInSystem = 720;
            timeTillMaxEffect = 10;
            maxEffectTime = 480;
            maxDose = 2200;
            maxDoseDeviation = 200;
            unstableDose = 900;
            maxEffectDose = 150;
            weightEffect = 0;
        };
        class Atropine_IV: ACM_IV_Medication {
            medicationType = "Atropine";
            hrIncrease[] = {10, 30};
            timeInSystem = 900;
            maxEffectTime = 600;
            rrAdjust[] = {2, 8};
            breathingEffectivenessAdjust[] = {0.01, 0.04};
            maxDose = 20;
            maxDoseDeviation = 2;
            unstableDose = 10;
            maxEffectDose = 1;
            weightEffect = 0;
        };
        class Atropine_IV_L: Atropine_IV {
            hrIncrease[] = {-18, 0};
        };
        class Lidocaine_IV: ACM_IV_Medication {
            medicationType = "Lidocaine_IV";
            hrIncrease[] = {-2, -10};
            timeInSystem = 600;
            maxEffectTime = 360;
            maxDose = 270;
            maxDoseDeviation = 50;
            unstableDose = 240;
            maxEffectDose = 83;
        };
        class TXA_IV: ACM_IV_Medication {
            medicationType = "TXA";
            timeInSystem = 900;
            timeTillMaxEffect = 15;
            maxEffectTime = 600;
            viscosityChange = -10;
            maxEffectDose = 1000;
            weightEffect = 0;
        };
        class Ketamine_IV: ACM_IV_Medication {
            medicationType = "Ketamine";
            minPainReduce = 0.5;
            painReduce = 0.85;
            maxPainReduce = 1;
            hrIncrease[] = {-0.1, -0.5};
            timeInSystem = 660;
            maxEffectTime = 540;
            maxDose = 250;
            maxDoseDeviation = 50;
            minEffectDose = 8.3;
            maxEffectDose = 16.6;
        };
        class Fentanyl_IV: ACM_IV_Medication {
            medicationType = "Opioid";
            minPainReduce = 0.6;
            painReduce = 1;
            hrIncrease[] = {-2, -5};
            timeInSystem = 960;
            timeTillMaxEffect = 10;
            maxEffectTime = 840;
            coSensitivityAdjust[] = {-0.06, -0.07};
            breathingEffectivenessAdjust[] = {-0.01, -0.04};
            viscosityChange = 10;
            maxDose = 0.15;
            maxDoseDeviation = 0.05;
            unstableDose = 0.11;
            minEffectDose = 0.0415;
            maxEffectDose = 0.083;
            weightEffect = 2;
        };
        class Ondansetron_IV: ACM_IV_Medication {
            hrIncrease[] = {-0.5, -2};
            timeInSystem = 720;
            timeTillMaxEffect = 15;
            maxEffectTime = 600;
            viscosityChange = 20;
            maxDose = 8;
            maxDoseDeviation = 8;
            unstableDose = 8;
            maxEffectDose = 4;
            weightEffect = 0;
        };
        class CalciumChloride_IV: ACM_IV_Medication {
            hrIncrease[] = {1, 10};
            timeInSystem = 600;
            timeTillMaxEffect = 15;
            maxEffectTime = 300;
            viscosityChange = -10;
            unstableDose = 4000;
            maxEffectDose = 1000;
            weightEffect = 0;
        };
        class Ertapenem_IV: ACM_IV_Medication {
            medicationType = "Ertapenem";
            timeInSystem = 900;
            timeTillMaxEffect = 5;
            maxEffectTime = 600;
            maxEffectDose = 1000;
            weightEffect = 0;
        };
        class Esmolol_IV: ACM_IV_Medication {
            hrIncrease[] = {-10, -25};
            timeInSystem = 320;
            timeTillMaxEffect = 20;
            maxEffectTime = 240;
            unstableDose = 45;
            minEffectDose = 20.75;
            maxEffectDose = 41.5;
            weightEffect = 1;
        };
        class ACM_IM_Medication {
            painReduce = 0;
            timeInSystem = 400;
            timeTillMaxEffect = 30;
            maxEffectTime = 240;
            maxDose = 0;
            maxDoseDeviation = 0;
            incompatibleMedication[] = {};
            administrationType = 0;
            medicationType = "Default";
            maxPainReduce = 1;
            viscosityChange = 0;
            weightEffect = 1;
            bloodlossEffect = 1;
        };
        class Morphine: ACM_IM_Medication {
            medicationType = "Opioid";
            minPainReduce = 0.5;
            painReduce = 0.9;
            maxPainReduce = 0.95;
            hrIncrease[] = {-2, -6};
            timeInSystem = 1800;
            timeTillMaxEffect = 100;
            maxEffectTime = 1200;
            coSensitivityAdjust[] = {-0.06, -0.07};
            viscosityChange = 8;
            maxDose = 14;
            maxDoseDeviation = 3;
            unstableDose = 15;
            minEffectDose = 5.83;
            maxEffectDose = 8.3;
            weightEffect = 2;
        };
        class Epinephrine: ACM_IM_Medication {
            medicationType = "Epinephrine";
            timeInSystem = 360;
            hrIncrease[] = {2, 10};
            rrAdjust[] = {1, 6};
            breathingEffectivenessAdjust[] = {0, 0.01};
            unstableDose = 6;
            maxEffectDose = 0.3;
            weightEffect = 0;
        };
        class Adenosine: ACM_IM_Medication {
            medicationType = "Adenosine";
        };
        class Amiodarone: ACM_IM_Medication {
            weightEffect = 0;
        };
        class Atropine: ACM_IM_Medication {
            medicationType = "Atropine";
            timeInSystem = 900;
            timeTillMaxEffect = 30;
            maxEffectTime = 600;
            hrIncrease[] = {8, 15};
            rrAdjust[] = {1, 4};
            breathingEffectivenessAdjust[] = {0, 0.01};
            maxDose = 20;
            maxDoseDeviation = 2;
            unstableDose = 12;
            maxEffectDose = 2;
            weightEffect = 0;
        };
        class Atropine_L: Atropine {
            hrIncrease[] = {-10, 0};
        };
        class Lidocaine: ACM_IM_Medication {
            timeInSystem = 600;
            timeTillMaxEffect = 10;
            maxEffectTime = 240;
            maxDose = 200;
            maxDoseDeviation = 50;
            maxEffectDose = 100;
            weightEffect = 0;
        };
        class Ketamine: ACM_IM_Medication {
            medicationType = "Ketamine";
            minPainReduce = 0.4;
            painReduce = 0.95;
            timeInSystem = 900;
            timeTillMaxEffect = 20;
            maxEffectTime = 600;
            maxDose = 500;
            maxDoseDeviation = 100;
            minEffectDose = 41.5;
            maxEffectDose = 62.25;
        };
        class Fentanyl: ACM_IM_Medication {
            medicationType = "Opioid";
            minPainReduce = 0.5;
            painReduce = 0.99;
            hrIncrease[] = {-0.5, -3};
            timeInSystem = 1200;
            timeTillMaxEffect = 30;
            maxEffectTime = 900;
            coSensitivityAdjust[] = {-0.05, -0.06};
            breathingEffectivenessAdjust[] = {-0.01, -0.02};
            viscosityChange = 6;
            maxDose = 0.18;
            maxDoseDeviation = 0.075;
            unstableDose = 0.13;
            minEffectDose = 0.0581;
            maxEffectDose = 0.083;
            weightEffect = 2;
        };
        class Ondansetron: ACM_IM_Medication {
            timeInSystem = 900;
            timeTillMaxEffect = 45;
            maxEffectTime = 720;
            hrIncrease[] = {-0.1, -2};
            maxDose = 8;
            maxDoseDeviation = 8;
            unstableDose = 8;
            maxEffectDose = 4;
            weightEffect = 0;
        };
        class Ertapenem: ACM_IM_Medication {
            medicationType = "Ertapenem";
            timeInSystem = 1200;
            timeTillMaxEffect = 30;
            maxEffectTime = 900;
            maxEffectDose = 1000;
            weightEffect = 0;
        };
        class Midazolam: ACM_IM_Medication {
            timeInSystem = 1200;
            maxEffectTime = 900;
            hrIncrease[] = {-1, -5};
            rrAdjust[] = {-1, -4};
            maxDose = 30;
            maxDoseDeviation = 10;
            unstableDose = 30;
            maxEffectDose = 10;
            weightEffect = 0;
        };
        class Dimercaprol: ACM_IM_Medication {
            timeInSystem = 1800;
            timeTillMaxEffect = 30;
            maxEffectTime = 900;
            hrIncrease[] = {10, 20};
            maxDose = 600;
            maxDoseDeviation = 50;
            unstableDose = 500;
            maxEffectDose = 249;
            viscosityChange = -5;
        };
        class ACM_BUC_Medication {
            painReduce = 0;
            timeInSystem = 900;
            timeTillMaxEffect = 90;
            maxEffectTime = 600;
            maxDose = 0;
            maxDoseDeviation = 0;
            incompatibleMedication[] = {};
            administrationType = 0;
            medicationType = "Default";
            maxPainReduce = 1;
            viscosityChange = 0;
            weightEffect = 0;
        };
        class Fentanyl_BUC: ACM_BUC_Medication {
            medicationType = "Opioid";
            minPainReduce = 0.25;
            painReduce = 0.95;
            hrIncrease[] = {-0.5, -2};
            coSensitivityAdjust[] = {-0.05, -0.06};
            breathingEffectivenessAdjust[] = {-0.01, -0.02};
            viscosityChange = 8;
            maxDose = 2;
            maxDoseDeviation = 1;
            unstableDose = 2;
        };
    };
    class MedicationType {
        class Default {};
        class Epinephrine {
            classnames[] = {"Epinephrine_IV", "Epinephrine"};
        };
        class Opioid {
            classnames[] = {
                "Morphine_IV",
                "Morphine",
                "Fentanyl_IV",
                "Fentanyl",
                "Fentanyl_BUC"
            };
        };
        class Ketamine {
            classnames[] = {"Ketamine_IV", "Ketamine"};
        };
        class TXA {
            classnames[] = {"TXA_IV"};
        };
        class Amiodarone {
            classnames[] = {"Amiodarone_IV"};
        };
        class Atropine {
            classnames[] = {"Atropine_IV", "Atropine"};
        };
        class Lidocaine {
            classnames[] = {"Lidocaine_IV"};
        };
        class Ertapenem {
            classnames[] = {"Ertapenem_IV", "Ertapenem"};
        };
    };
    class Concentration {
        class Naloxone {
            concentration = 4;
            dose = "4mg/0.1ml";
            volume = 0.1;
        };
        class Amiodarone {
            concentration = 50;
            dose = "150mg/3ml";
            volume = 3;
        };
        class Atropine {
            concentration = 1;
            dose = "1mg/1ml";
            volume = 1;
        };
        class TXA {
            concentration = 100;
            dose = "1g/10ml";
            volume = 10;
        };
        class Morphine {
            concentration = 5;
            dose = "10mg/2ml";
            volume = 2;
        };
        class Fentanyl {
            concentration = 0.05;
            dose = "100mcg/2ml";
            volume = 2;
        };
        class Epinephrine {
            concentration = 1;
            dose = "1mg/1ml";
            volume = 1;
        };
        class Adenosine {
            concentration = 3;
            dose = "12mg/4ml";
            volume = 4;
        };
        class Lidocaine {
            concentration = 20;
            dose = "100mg/5ml";
            volume = 5;
        };
        class Ketamine {
            concentration = 50;
            dose = "500mg/10ml";
            volume = 10;
        };
        class Ondansetron {
            concentration = 2;
            dose = "4mg/2ml";
            volume = 2;
        };
        class CalciumChloride {
            concentration = 100;
            dose = "1g/10ml";
            volume = 10;
        };
        class Ertapenem {
            concentration = 312.5;
            dose = "1g/3.2ml";
            volume = 3.2;
        };
        class Esmolol {
            concentration = 10;
            dose = "100mg/10ml";
            volume = 10;
        };
        class Dimercaprol {
            concentration = 100;
            dose = "300mg/3ml";
            volume = 3;
        };
    };
};
class ace_medical_treatment_actions {
    class BasicBandage;
    class BodyBag: BasicBandage {
        ACM_menuIcon = "ACE_bodyBag";
    };
    class BodyBagBlue: BodyBag {
        ACM_menuIcon = "ACE_bodyBag_blue";
    };
    class BodyBagWhite: BodyBag {
        ACM_menuIcon = "ACE_bodyBag_white";
    };
    class Splint: BasicBandage {
        ACM_menuIcon = "ACE_splint";
    };
    class FieldDressing;
    class Morphine: FieldDressing {
        displayName = "$STR_ACM_core_MorphineAutoinjector";
        displayNameProgress = "$STR_ACM_core_MorphineAutoinjector_Progress";
        ACM_menuIcon = "ACE_morphine";
    };
    class Adenosine: Morphine {
        displayName = "$STR_ACM_core_AdenosineAutoinjector";
        displayNameProgress = "$STR_ACM_core_AdenosineAutoinjector_Progress";
        ACM_menuIcon = "ACE_adenosine";
    };
    class Epinephrine: Morphine {
        displayName = "$STR_ACM_core_EpinephrineAutoinjector";
        displayNameProgress = "$STR_ACM_core_EpinephrineAutoinjector_Progress";
        ACM_menuIcon = "ACE_epinephrine";
    };
    class ATNA_Autoinjector: Morphine {
        displayName = "$STR_ACM_CBRN_ATNAAutoinjector";
        displayNameProgress = "$STR_ACM_CBRN_ATNAAutoinjector_Progress";
        medicRequired = "ACM_core_allowATNAAutoinjector";
        items[] = {"ACM_Autoinjector_ATNA"};
        treatmentLocations = 0;
        litter[] = {{"ACE_MedicalLitter_atropine"}};
        ACM_menuIcon = "ACM_ATNA_Autoinjector";
    };
    class Midazolam_Autoinjector: ATNA_Autoinjector {
        displayName = "$STR_ACM_CBRN_MidazolamAutoinjector";
        displayNameProgress = "$STR_ACM_CBRN_MidazolamAutoinjector_Progress";
        medicRequired = "ACM_core_allowMidazolamAutoinjector";
        items[] = {"ACM_Autoinjector_Midazolam"};
        ACM_menuIcon = "ACM_Midazolam_Autoinjector";
    };
    class CheckPulse;
    class CheckResponse: CheckPulse {
        treatmentTime = 2.5;
    };
    class CheckBloodPressure: CheckPulse {
        displayName = "$STR_ACM_circulation_CheckCapillaryRefill";
        displayNameProgress = "$STR_ACM_circulation_CheckCapillaryRefill_Progress";
        allowedSelections[] = {"Body", "LeftArm", "RightArm"};
        treatmentTime = 4;
        callbackSuccess = "ACM_circulation_fnc_checkCapillaryRefill";
    };
    class MeasureBloodPressure: CheckBloodPressure {
        displayName = "$STR_ACM_circulation_PressureCuff_Measure";
        displayNameProgress = "";
        allowedSelections[] = {"LeftArm", "RightArm"};
        treatmentTime = 0.01;
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasPressureCuff";
        callbackSuccess = "[_medic, _patient, _bodyPart, false] call ACM_circulation_fnc_measureBP";
        ACM_menuIcon = "ACM_PressureCuff";
    };
    class MeasureBloodPressureStethoscope: MeasureBloodPressure {
        displayName = "$STR_ACM_circulation_PressureCuff_Measure_Stethoscope";
        items[] = {"ACM_Stethoscope"};
        consumeItem = 0;
        callbackSuccess = "[_medic, _patient, _bodyPart, true] call ACM_circulation_fnc_measureBP";
        ACM_menuIcon = "ACM_Stethoscope";
    };
    class CheckDogTags: CheckResponse {
        displayName = "$STR_ace_dogtags_checkItem";
        displayNameProgress = "";
        icon = "\z\ace\addons\dogtags\data\dogtag_icon_ca.paa";
        treatmentTime = 2;
        allowSelfTreatment = 1;
        condition = "ACM_core_fnc_canCheckDogtag";
        callbackSuccess = "ace_dogtags_fnc_checkDogtag";
        ACM_rollToBack = 1;
    };
    class PressureBandage: BasicBandage {
        displayName = "$STR_ACM_damage_PressureBandage";
        displayNameProgress = "$STR_ace_medical_treatment_Bandaging";
        icon = "\z\ace\addons\medical_gui\ui\bandage.paa";
        category = "bandage";
        consumeItem = 1;
        items[] = {"ACM_PressureBandage"};
        medicRequired = 0;
        allowSelfTreatment = 1;
        allowedSelections[] = {"All"};
        treatmentLocations = 0;
        treatmentTime = "ACM_damage_fnc_getBandageTime";
        callbackStart = "";
        callbackProgress = "";
        callbackSuccess = "ace_medical_treatment_fnc_bandage";
        callbackFailure = "";
        animationMedic = "AinvPknlMstpSlayW[wpn]Dnon_medicOther";
        animationMedicProne = "AinvPpneMstpSlayW[wpn]Dnon_medicOther";
        animationMedicSelf = "AinvPknlMstpSlayW[wpn]Dnon_medic";
        animationMedicSelfProne = "AinvPpneMstpSlayW[wpn]Dnon_medic";
        ACM_menuIcon = "ACM_PressureBandage";
    };
    class EmergencyTraumaDressing: PressureBandage {
        displayName = "$STR_ACM_damage_EmergencyTraumaDressing";
        items[] = {"ACM_EmergencyTraumaDressing"};
        allowSelfTreatment = 0;
        ACM_menuIcon = "ACM_EmergencyTraumaDressing";
    };
    class ElasticWrap: PressureBandage {
        displayName = "$STR_ACM_damage_ElasticWrap_Bruises";
        displayNameProgress = "$STR_ACM_damage_ElasticWrap_Progress";
        items[] = {"ACM_ElasticWrap"};
        medicRequired = "ACM_core_allowWrap";
        condition = "[_medic, _patient, _bodyPart, 2] call ACM_damage_fnc_canWrap";
        treatmentTime = "ACM_damage_fnc_getBruiseWrapTime";
        callbackSuccess = "ACM_damage_fnc_wrapBruises";
        ACM_menuIcon = "ACM_ElasticWrap";
    };
    class ElasticWrapBandages: ElasticWrap {
        displayName = "$STR_ACM_damage_ElasticWrap_Bandages";
        condition = "[_medic, _patient, _bodyPart] call ACM_damage_fnc_canWrap";
        treatmentTime = "[_medic, _patient, _bodyPart, 0] call ACM_damage_fnc_getWrapTime";
        callbackSuccess = "[_medic, _patient, _bodyPart, 0] call ACM_damage_fnc_wrapBodypart";
    };
    class ElasticWrapClots: ElasticWrap {
        displayName = "$STR_ACM_damage_ElasticWrap_Clots";
        condition = "[_medic, _patient, _bodyPart, 1] call ACM_damage_fnc_canWrap";
        treatmentTime = "[_medic, _patient, _bodyPart, 1] call ACM_damage_fnc_getWrapTime";
        callbackSuccess = "[_medic, _patient, _bodyPart, 1] call ACM_damage_fnc_wrapBodypart";
    };
    class ElasticWrapSplint: ElasticWrap {
        displayName = "$STR_ACM_disability_ElasticWrap_Splint";
        allowedSelections[] = {"LeftArm", "RightArm", "LeftLeg", "RightLeg"};
        condition = "ACM_disability_fnc_canWrapSplint";
        treatmentTime = "ACM_disability_fnc_getSplintWrapTime";
        callbackSuccess = "ACM_disability_fnc_wrapSplint";
    };
    class StitchAirwayIncision: FieldDressing {
        displayName = "$STR_ACM_airway_SurgicalAirwayStitch";
        displayNameProgress = "$STR_ace_medical_treatment_Stitching";
        icon = "\z\ace\addons\medical_gui\ui\surgical_kit.paa";
        category = "airway";
        items[] = {"ACE_surgicalKit"};
        treatmentLocations = "ace_medical_treatment_locationSurgicalKit";
        allowSelfTreatment = 0;
        medicRequired = "ace_medical_treatment_medicSurgicalKit";
        treatmentTime = "[_medic, _patient] call ACM_airway_fnc_getStitchAirwayIncisionTime";
        allowedSelections[] = {"Head"};
        condition = "[_medic, _patient] call ACM_airway_fnc_canStitchAirwayIncision";
        callbackSuccess = "[_medic, _patient] call ACM_airway_fnc_stitchAirwayIncision";
        callbackStart = "";
        callbackProgress = "";
        consumeItem = "ace_medical_treatment_consumeSurgicalKit";
        animationMedic = "AinvPknlMstpSnonWnonDnon_medic1";
        litter[] = {{"ACE_MedicalLitter_gloves"}};
        ACM_rollToBack = 1;
        ACM_menuIcon = "ACE_surgicalKit";
    };
    class StitchAirwayIncision_Suture: StitchAirwayIncision {
        displayName = "$STR_ACM_airway_SurgicalAirwayStitch_Suture";
        displayNameProgress = "$STR_ACM_damage_SurgicalKit_Suture_Progress";
        treatmentTime = "[_medic, _patient, true] call ACM_airway_fnc_getStitchAirwayIncisionTime";
        condition = "[_medic, _patient, true] call ACM_airway_fnc_canStitchAirwayIncision";
        callbackSuccess = "[_medic, _patient] call ACM_airway_fnc_stitchAirwayIncision";
    };
    class SurgicalAirway_SecureStrap: StitchAirwayIncision {
        displayName = "$STR_ACM_airway_SurgicalAirwayStrap_Action";
        displayNameProgress = "$STR_ACM_airway_SurgicalAirwayStrap_Progress";
        icon = "";
        items[] = {};
        consumeItem = 0;
        treatmentLocations = 0;
        medicRequired = 0;
        treatmentTime = 5;
        condition = "[_medic, _patient] call ACM_airway_fnc_canSecureSurgicalAirway";
        callbackSuccess = "[_medic, _patient] call ACM_airway_fnc_secureSurgicalAirway";
        animationMedic = "";
        litter[] = {};
        ACM_menuIcon = "";
    };
    class InspectForFracture: CheckPulse {
        displayName = "$STR_ACM_disability_InspectForFracture";
        displayNameProgress = "$STR_ACM_disability_InspectForFracture_Progress";
        icon = "";
        medicRequired = "ACM_disability_allowInspectForFracture";
        treatmentLocations = 0;
        treatmentTime = 6;
        allowedSelections[] = {"LeftArm", "RightArm", "LeftLeg", "RightLeg"};
        animationMedic = "";
        condition = "ACM_disability_fnc_canInspectForFracture";
        callbackSuccess = "ACM_disability_fnc_inspectForFracture";
    };
    class FractureRealignment: Splint {
        displayName = "$STR_ACM_disability_FractureRealignment";
        displayNameProgress = "$STR_ACM_disability_FractureRealignment_Progress";
        icon = "";
        medicRequired = "ACM_disability_allowFractureRealignment";
        consumeItem = 0;
        items[] = {};
        treatmentLocations = 0;
        treatmentTime = 3;
        callbackSuccess = "ACM_disability_fnc_performFractureRealignment";
        condition = "ACM_disability_fnc_canPerformFractureRealignment";
        litter[] = {};
        ACM_rollToBack = 1;
        ACM_menuIcon = "";
    };
    class ApplySAMSplint: Splint {
        displayName = "$STR_ACM_disability_ApplySAMSplint";
        displayNameProgress = "$STR_ACM_disability_ApplySAMSplint_Progress";
        items[] = {"ACM_SAMSplint"};
        allowedSelections[] = {"LeftArm", "RightArm", "LeftLeg", "RightLeg"};
        condition = "ACM_disability_fnc_canApplySplint";
        treatmentTime = "ACM_disability_treatmentTimeSAMSplint";
        callbackSuccess = "ACM_disability_fnc_splint";
        ACM_menuIcon = "ACM_SAMSplint";
    };
    class RemoveSAMSplint: Splint {
        displayName = "$STR_ACM_disability_RemoveSAMSplint";
        displayNameProgress = "$STR_ACM_disability_RemoveSAMSplint_Progress";
        allowedSelections[] = {"LeftArm", "RightArm", "LeftLeg", "RightLeg"};
        items[] = {};
        condition = "ACM_disability_fnc_canRemoveSplint";
        treatmentTime = 3;
        callbackSuccess = "ACM_disability_fnc_removeSplint";
        litter[] = {};
        ACM_menuIcon = "ACM_SAMSplint";
    };
    class SurgicalKit: FieldDressing {
        ACM_menuIcon = "ACE_surgicalKit";
        callbackFailure = "[_medic, _patient] call ACM_damage_fnc_surgicalKitCancel";
    };
    class SurgicalKit_Suture: SurgicalKit {
        displayName = "$STR_ACM_damage_SurgicalKit_Suture";
        displayNameProgress = "$STR_ACM_damage_SurgicalKit_Suture_Progress";
        treatmentTime = "[_patient, _bodyPart, 0, true] call ACM_damage_fnc_getStitchTime";
        condition = "[_medic, _patient, _bodyPart, 0, true] call ACM_damage_fnc_canStitch";
        callbackProgress = "[_args, _elapsedTime, _totalTime, 0, true] call ACM_damage_fnc_surgicalKitProgress";
        callbackStart = "[_medic, _patient, true] call ACM_damage_fnc_surgicalKitStart";
        callbackFailure = "[_medic, _patient, true] call ACM_damage_fnc_surgicalKitCancel";
    };
    class StitchWrappedWounds: SurgicalKit {
        displayName = "$STR_ACM_damage_SurgicalKit_Wrapped";
        treatmentTime = "[_patient, _bodyPart, 1] call ACM_damage_fnc_getStitchTime";
        condition = "[_medic, _patient, _bodyPart, 1] call ACM_damage_fnc_canStitch";
        callbackProgress = "[_args, _elapsedTime, _totalTime, 1] call ACM_damage_fnc_surgicalKitProgress";
        callbackFailure = "[_medic, _patient] call ACM_damage_fnc_surgicalKitCancel";
    };
    class StitchWrappedWounds_Suture: SurgicalKit_Suture {
        displayName = "$STR_ACM_damage_SurgicalKit_Wrapped_Suture";
        treatmentTime = "[_patient, _bodyPart, 1, true] call ACM_damage_fnc_getStitchTime";
        condition = "[_medic, _patient, _bodyPart, 1, true] call ACM_damage_fnc_canStitch";
        callbackProgress = "[_args, _elapsedTime, _totalTime, 1, true] call ACM_damage_fnc_surgicalKitProgress";
        callbackFailure = "[_medic, _patient, true] call ACM_damage_fnc_surgicalKitCancel";
    };
    class StitchClottedWounds: SurgicalKit {
        displayName = "$STR_ACM_damage_SurgicalKit_Clotted";
        treatmentTime = "[_patient, _bodyPart, 2] call ACM_damage_fnc_getStitchTime";
        condition = "[_medic, _patient, _bodyPart, 2] call ACM_damage_fnc_canStitch";
        callbackProgress = "[_args, _elapsedTime, _totalTime, 2] call ACM_damage_fnc_surgicalKitProgress";
        callbackFailure = "[_medic, _patient] call ACM_damage_fnc_surgicalKitCancel";
    };
    class StitchClottedWounds_Suture: SurgicalKit_Suture {
        displayName = "$STR_ACM_damage_SurgicalKit_Clotted_Suture";
        treatmentTime = "[_patient, _bodyPart, 2, true] call ACM_damage_fnc_getStitchTime";
        condition = "[_medic, _patient, _bodyPart, 2, true] call ACM_damage_fnc_canStitch";
        callbackProgress = "[_args, _elapsedTime, _totalTime, 2, true] call ACM_damage_fnc_surgicalKitProgress";
        callbackFailure = "[_medic, _patient, true] call ACM_damage_fnc_surgicalKitCancel";
    };
    class ApplyTourniquet: BasicBandage {
        sounds[] = {{"\x\ACM\addons\core\sound\tourniquet_apply.wav", 10, 1, 30}};
        ACM_menuIcon = "ACE_tourniquet";
    };
    class RemoveTourniquet: ApplyTourniquet {
        treatmentTime = "ACM_core_treatmentTimeTakeOffTourniquet";
        sounds[] = {{"\x\ACM\addons\core\sound\tourniquet_remove.wav", 10, 1, 30}};
    };
    class OpenTransfusionMenu: CheckPulse {
        displayName = "$STR_ACM_circulation_OpenTransfusionMenu";
        displayNameProgress = "";
        icon = "";
        category = "advanced";
        treatmentLocations = 0;
        medicRequired = 0;
        allowedSelections[] = {"All"};
        allowSelfTreatment = 1;
        items[] = {};
        consumeItem = 0;
        animationMedic = "";
        condition = "[_patient, _bodyPart, 0, -1] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart, 0] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart] call ACM_circulation_fnc_openTransfusionMenu";
    };
    class InspectIV_Upper: CheckPulse {
        displayName = "$STR_ACM_circulation_InspectIV_Upper";
        displayNameProgress = "$STR_ACM_circulation_InspectIV_Progress";
        icon = "";
        category = "examine";
        treatmentLocations = 0;
        medicRequired = "ACM_circulation_allowIV";
        treatmentTime = 4;
        allowedSelections[] = {"LeftArm", "RightArm", "LeftLeg", "RightLeg"};
        allowSelfTreatment = 1;
        condition = "([_patient, _bodyPart, 0, 0] call ACM_circulation_fnc_hasIV)";
        callbackSuccess = "[_medic, _patient, _bodyPart, 0] call ACM_circulation_fnc_inspectIV";
    };
    class InspectIV_Middle: InspectIV_Upper {
        displayName = "$STR_ACM_circulation_InspectIV_Middle";
        condition = "([_patient, _bodyPart, 0, 1] call ACM_circulation_fnc_hasIV)";
        callbackSuccess = "[_medic, _patient, _bodyPart, 1] call ACM_circulation_fnc_inspectIV";
    };
    class InspectIV_Lower: InspectIV_Upper {
        displayName = "$STR_ACM_circulation_InspectIV_Lower";
        condition = "([_patient, _bodyPart, 0, 2] call ACM_circulation_fnc_hasIV)";
        callbackSuccess = "[_medic, _patient, _bodyPart, 2] call ACM_circulation_fnc_inspectIV";
    };
    class InsertIV_16_Upper: CheckPulse {
        displayName = "$STR_ACM_circulation_InsertIV_16_Upper";
        displayNameProgress = "$STR_ACM_circulation_InsertIV_16_Progress";
        icon = "";
        category = "advanced";
        treatmentLocations = 0;
        medicRequired = "ACM_circulation_allowIV";
        treatmentTime = "ACM_circulation_treatmentTimeIV_16";
        allowedSelections[] = {"LeftArm", "RightArm", "LeftLeg", "RightLeg"};
        allowSelfTreatment = "ACM_circulation_selfIV";
        items[] = {"ACM_IV_16g"};
        consumeItem = 1;
        condition = "[_patient, _bodyPart, 0, 0] call ACM_circulation_fnc_canInsertIV";
        callbackSuccess = "[_medic, _patient, _bodyPart, 1, true, true, 0] call ACM_circulation_fnc_setIV";
        ACM_rollToBack = 1;
        ACM_menuIcon = "ACM_IV_16g";
    };
    class RemoveIV_16_Upper: InsertIV_16_Upper {
        displayName = "$STR_ACM_circulation_RemoveIV_16_Upper";
        displayNameProgress = "$STR_ACM_circulation_RemoveIV_16_Progress";
        icon = "";
        treatmentLocations = 0;
        medicRequired = 0;
        treatmentTime = 3;
        allowSelfTreatment = 1;
        items[] = {};
        consumeItem = 0;
        condition = "[_patient, _bodyPart, 1, 0] call ACM_circulation_fnc_hasIV";
        callbackSuccess = "[_medic, _patient, _bodyPart, 1, false, true, 0] call ACM_circulation_fnc_setIV";
    };
    class InsertIV_16_Middle: InsertIV_16_Upper {
        displayName = "$STR_ACM_circulation_InsertIV_16_Middle";
        condition = "[_patient, _bodyPart, 0, 1] call ACM_circulation_fnc_canInsertIV";
        callbackSuccess = "[_medic, _patient, _bodyPart, 1, true, true, 1] call ACM_circulation_fnc_setIV";
    };
    class RemoveIV_16_Middle: RemoveIV_16_Upper {
        displayName = "$STR_ACM_circulation_RemoveIV_16_Middle";
        condition = "[_patient, _bodyPart, 1, 1] call ACM_circulation_fnc_hasIV";
        callbackSuccess = "[_medic, _patient, _bodyPart, 1, false, true, 1] call ACM_circulation_fnc_setIV";
    };
    class InsertIV_16_Lower: InsertIV_16_Upper {
        displayName = "$STR_ACM_circulation_InsertIV_16_Lower";
        condition = "[_patient, _bodyPart, 0, 2] call ACM_circulation_fnc_canInsertIV";
        callbackSuccess = "[_medic, _patient, _bodyPart, 1, true, true, 2] call ACM_circulation_fnc_setIV";
    };
    class RemoveIV_16_Lower: RemoveIV_16_Upper {
        displayName = "$STR_ACM_circulation_RemoveIV_16_Lower";
        condition = "[_patient, _bodyPart, 1, 2] call ACM_circulation_fnc_hasIV";
        callbackSuccess = "[_medic, _patient, _bodyPart, 1, false, true, 2] call ACM_circulation_fnc_setIV";
    };
    class InsertIV_14_Upper: InsertIV_16_Upper {
        displayName = "$STR_ACM_circulation_InsertIV_14_Upper";
        displayNameProgress = "$STR_ACM_circulation_InsertIV_14_Progress";
        icon = "";
        treatmentTime = "ACM_circulation_treatmentTimeIV_14";
        items[] = {"ACM_IV_14g"};
        callbackSuccess = "[_medic, _patient, _bodyPart, 2, true, true, 0] call ACM_circulation_fnc_setIV";
        ACM_menuIcon = "ACM_IV_14g";
    };
    class RemoveIV_14_Upper: RemoveIV_16_Upper {
        displayName = "$STR_ACM_circulation_RemoveIV_14_Upper";
        displayNameProgress = "$STR_ACM_circulation_RemoveIV_14_Progress";
        icon = "";
        allowSelfTreatment = 0;
        condition = "[_patient, _bodyPart, 2, 0] call ACM_circulation_fnc_hasIV";
        callbackSuccess = "[_medic, _patient, _bodyPart, 2, false, true, 0] call ACM_circulation_fnc_setIV";
        ACM_menuIcon = "ACM_IV_14g";
    };
    class InsertIV_14_Middle: InsertIV_14_Upper {
        displayName = "$STR_ACM_circulation_InsertIV_14_Middle";
        condition = "[_patient, _bodyPart, 0, 1] call ACM_circulation_fnc_canInsertIV";
        callbackSuccess = "[_medic, _patient, _bodyPart, 2, true, true, 1] call ACM_circulation_fnc_setIV";
    };
    class RemoveIV_14_Middle: RemoveIV_14_Upper {
        displayName = "$STR_ACM_circulation_RemoveIV_14_Middle";
        condition = "[_patient, _bodyPart, 2, 1] call ACM_circulation_fnc_hasIV";
        callbackSuccess = "[_medic, _patient, _bodyPart, 2, false, true, 1] call ACM_circulation_fnc_setIV";
    };
    class InsertIV_14_Lower: InsertIV_14_Upper {
        displayName = "$STR_ACM_circulation_InsertIV_14_Lower";
        condition = "[_patient, _bodyPart, 0, 2] call ACM_circulation_fnc_canInsertIV";
        callbackSuccess = "[_medic, _patient, _bodyPart, 2, true, true, 2] call ACM_circulation_fnc_setIV";
    };
    class RemoveIV_14_Lower: RemoveIV_14_Upper {
        displayName = "$STR_ACM_circulation_RemoveIV_14_Lower";
        condition = "[_patient, _bodyPart, 2, 2] call ACM_circulation_fnc_hasIV";
        callbackSuccess = "[_medic, _patient, _bodyPart, 2, false, true, 2] call ACM_circulation_fnc_setIV";
    };
    class InsertIO_FAST1: InsertIV_16_Upper {
        displayName = "$STR_ACM_circulation_InsertIO_FAST1";
        displayNameProgress = "$STR_ACM_circulation_InsertIO_FAST1_Progress";
        icon = "";
        medicRequired = "ACM_circulation_allowIO";
        treatmentTime = "ACM_circulation_treatmentTimeIO_FAST1";
        allowedSelections[] = {"Body"};
        allowSelfTreatment = "ACM_circulation_selfIO";
        items[] = {"ACM_IO_FAST"};
        condition = "!([_patient, _bodyPart] call ACM_circulation_fnc_hasIO)";
        callbackSuccess = "[_medic, _patient, _bodyPart, 4, true, false] call ACM_circulation_fnc_setIV";
        ACM_cancelRecovery = 1;
        ACM_menuIcon = "ACM_IO_FAST";
    };
    class RemoveIO_FAST1: RemoveIV_16_Upper {
        displayName = "$STR_ACM_circulation_RemoveIO_FAST1";
        displayNameProgress = "$STR_ACM_circulation_RemoveIO_FAST1_Progress";
        icon = "";
        allowedSelections[] = {"Body"};
        treatmentTime = 3.5;
        allowSelfTreatment = 0;
        condition = "[_patient, _bodyPart, 4] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 4, false, false] call ACM_circulation_fnc_setIV";
        ACM_menuIcon = "ACM_IO_FAST";
    };
    class InsertIO_EZ: InsertIO_FAST1 {
        displayName = "$STR_ACM_circulation_InsertIO_EZ";
        displayNameProgress = "$STR_ACM_circulation_InsertIO_EZ_Progress";
        icon = "";
        treatmentTime = "ACM_circulation_treatmentTimeIO_EZ";
        allowedSelections[] = {"LeftArm", "RightArm", "LeftLeg", "RightLeg"};
        items[] = {"ACM_IO_EZ"};
        condition = "!([_patient, _bodyPart] call ACM_circulation_fnc_hasIO)";
        callbackSuccess = "[_medic, _patient, _bodyPart, 3, true, false] call ACM_circulation_fnc_setIV";
        ACM_cancelRecovery = 0;
        sounds[] = {{"\x\ACM\addons\circulation\sound\io_drill.wav", 10, 1, 30}};
        ACM_menuIcon = "ACM_IO_EZ";
    };
    class RemoveIO_EZ: RemoveIO_FAST1 {
        displayName = "$STR_ACM_circulation_RemoveIO_EZ";
        displayNameProgress = "$STR_ACM_circulation_RemoveIO_EZ_Progress";
        icon = "";
        allowedSelections[] = {"LeftArm", "RightArm", "LeftLeg", "RightLeg"};
        condition = "[_patient, _bodyPart, 3] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 3, false, false] call ACM_circulation_fnc_setIV";
        ACM_menuIcon = "ACM_IO_EZ";
    };
    class Paracetamol: Morphine {
        displayName = "$STR_ACM_circulation_UseParacetamol";
        displayNameProgress = "$STR_ACM_circulation_UseParacetamol_Progress";
        allowedSelections[] = {"Head"};
        items[] = {"ACM_Paracetamol_SinglePack", "ACM_Paracetamol_DoublePack", "ACM_Paracetamol"};
        medicRequired = 0;
        treatmentTime = 4;
        condition = "[_patient] call ace_common_fnc_isAwake";
        sounds[] = {{"\x\ACM\addons\circulation\sound\paracetamol.wav", 10, 1, 30}};
        litter[] = {};
        ACM_menuIcon = "ACM_Paracetamol";
    };
    class Penthrox: Paracetamol {
        displayName = "$STR_ACM_circulation_UsePenthroxInhaler";
        displayNameProgress = "$STR_ACM_circulation_UsePenthroxInhaler_Progress";
        items[] = {"ACM_Inhaler_Penthrox"};
        treatmentTime = 4;
        animationMedic = "";
        sounds[] = {};
        ACM_menuIcon = "ACM_Inhaler_Penthrox";
    };
    class AmmoniaInhalant: Paracetamol {
        displayName = "$STR_ACM_circulation_UseAmmoniaInhalant";
        displayNameProgress = "$STR_ACM_circulation_UseAmmoniaInhalant_Progress";
        items[] = {"ACM_AmmoniaInhalant"};
        medicRequired = "ACM_circulation_allowAmmoniaInhalant";
        treatmentTime = 3;
        condition = "true";
        ACM_rollToBack = 1;
        ACM_menuIcon = "ACM_AmmoniaInhalant";
    };
    class Naloxone: Paracetamol {
        displayName = "$STR_ACM_circulation_UseNaloxoneSpray";
        displayNameProgress = "$STR_ACM_circulation_UseNaloxoneSpray_Progress";
        items[] = {"ACM_Spray_Naloxone"};
        treatmentTime = 4;
        condition = "true";
        ACM_rollToBack = 0;
        ACME_neverRollToBack = 1;
        sounds[] = {};
        ACM_menuIcon = "ACM_Spray_Naloxone";
    };
    class FentanylLozenge: Paracetamol {
        displayName = "$STR_ACM_circulation_GiveFentanylLozenge";
        displayNameProgress = "$STR_ACM_circulation_GiveFentanylLozenge_Progress";
        items[] = {"ACM_Lozenge_Fentanyl"};
        medicRequired = "ACM_circulation_allowFentanylLozenge";
        allowSelfTreatment = 0;
        treatmentTime = 4;
        condition = "_patient call ace_common_fnc_isAwake && ((_patient getVariable [""ACM_circulation_LozengeItem"", '']) == '') && ((_patient getVariable [""ACM_core_Lying_State"", false]) || (_patient getVariable [""ACM_core_Sitting_State"", false]))";
        callbackSuccess = "[_medic, _patient, 'Fentanyl'] call ACM_circulation_fnc_setLozenge";
        ACM_rollToBack = 1;
        sounds[] = {};
        ACM_menuIcon = "ACM_Lozenge_Fentanyl";
    };
    class RemoveFentanylLozenge: FentanylLozenge {
        displayName = "$STR_ACM_circulation_RemoveFentanylLozenge";
        displayNameProgress = "$STR_ACM_circulation_RemoveFentanylLozenge_Progress";
        items[] = {};
        consumeItem = 0;
        medicRequired = 0;
        allowSelfTreatment = 1;
        treatmentTime = 2;
        condition = "(_patient getVariable [""ACM_circulation_LozengeItem"", '']) == 'Fentanyl'";
        callbackSuccess = "[_medic, _patient] call ACM_circulation_fnc_setLozenge";
    };
    class ShakeAwake: CheckResponse {
        displayName = "$STR_ACM_disability_ShakeAwake";
        displayNameProgress = "$STR_ACM_disability_ShakeAwake_Progress";
        category = "medication";
        medicRequired = 0;
        allowedSelections[] = {"Body", "LeftArm", "RightArm"};
        treatmentTime = 1.5;
        condition = "!([_patient] call ace_common_fnc_isAwake)";
        callbackSuccess = "ACM_disability_fnc_shakeAwake";
    };
    class SlapAwake: ShakeAwake {
        displayName = "$STR_ACM_disability_SlapAwake";
        displayNameProgress = "$STR_ACM_disability_SlapAwake_Progress";
        allowedSelections[] = {"Head"};
        treatmentTime = 3;
        condition = "!([_patient] call ace_common_fnc_isAwake)";
        callbackSuccess = "ACM_disability_fnc_slapAwake";
        animationMedic = "AinvPknlMstpSnonWnonDr_medic3";
        ACM_rollToBack = 1;
        ACM_ignoreAnimCoef = 1;
    };
    class UseSyringe_10: OpenTransfusionMenu {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_UseSyringe', 10]");
        displayNameProgress = "";
        category = "medication";
        medicRequired = "ACM_circulation_allowSyringe";
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_10_ca.paa";
        allowedSelections[] = {
            "Body",
            "LeftArm",
            "RightArm",
            "LeftLeg",
            "RightLeg"
        };
        treatmentTime = 0.01;
        condition = "([_medic, 'ACM_Syringe_10'] call ACME_fnc_itemCount) > 0";
        callbackSuccess = "[_medic, _patient, _bodyPart, 10] call ACM_circulation_fnc_Syringe_Draw";
        ACM_menuIcon = "ACM_Syringe_10";
    };
    class UseSyringe_5: UseSyringe_10 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_UseSyringe', 5]");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_5_ca.paa";
        condition = "([_medic, 'ACM_Syringe_5'] call ACME_fnc_itemCount) > 0";
        callbackSuccess = "[_medic, _patient, _bodyPart, 5] call ACM_circulation_fnc_Syringe_Draw";
        ACM_menuIcon = "ACM_Syringe_5";
    };
    class UseSyringe_3: UseSyringe_10 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_UseSyringe', 3]");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_3_ca.paa";
        condition = "([_medic, 'ACM_Syringe_3'] call ACME_fnc_itemCount) > 0";
        callbackSuccess = "[_medic, _patient, _bodyPart, 3] call ACM_circulation_fnc_Syringe_Draw";
        ACM_menuIcon = "ACM_Syringe_3";
    };
    class UseSyringe_1: UseSyringe_10 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_UseSyringe', 1]");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_1_ca.paa";
        condition = "([_medic, 'ACM_Syringe_1'] call ACME_fnc_itemCount) > 0";
        callbackSuccess = "[_medic, _patient, _bodyPart, 1] call ACM_circulation_fnc_Syringe_Draw";
        ACM_menuIcon = "ACM_Syringe_1";
    };
    class Epinephrine_10_IV: Morphine {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Epinephrine', 10, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Epinephrine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_10_ca.paa";
        allowedSelections[] = {
            "Body",
            "LeftArm",
            "RightArm",
            "LeftLeg",
            "RightLeg"
        };
        items[] = {"ACM_Syringe_10_Epinephrine"};
        consumeItem = 0;
        medicRequired = "ACM_circulation_allowSyringe";
        treatmentTime = 2;
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Epinephrine', 10, true, true] call ACM_circulation_fnc_Syringe_Inject";
        sounds[] = {};
        litter[] = {};
        ACM_menuIcon = "ACM_Syringe_10";
    };
    class Epinephrine_5_IV: Epinephrine_10_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Epinephrine', 5, localize 'STR_ACM_Circulation_Intravenous_Short']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_5_ca.paa";
        items[] = {"ACM_Syringe_5_Epinephrine"};
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Epinephrine', 5, true, true] call ACM_circulation_fnc_Syringe_Inject";
        ACM_menuIcon = "ACM_Syringe_5";
    };
    class Epinephrine_3_IV: Epinephrine_10_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Epinephrine', 3, localize 'STR_ACM_Circulation_Intravenous_Short']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_3_ca.paa";
        items[] = {"ACM_Syringe_3_Epinephrine"};
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Epinephrine', 3, true, true] call ACM_circulation_fnc_Syringe_Inject";
        ACM_menuIcon = "ACM_Syringe_3";
    };
    class Epinephrine_1_IV: Epinephrine_10_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Epinephrine', 1, localize 'STR_ACM_Circulation_Intravenous_Short']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_1_ca.paa";
        items[] = {"ACM_Syringe_1_Epinephrine"};
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Epinephrine', 1, true, true] call ACM_circulation_fnc_Syringe_Inject";
        ACM_menuIcon = "ACM_Syringe_1";
    };
    class Amiodarone_10_IV: Epinephrine_10_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Amiodarone', 10, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Amiodarone']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_10_ca.paa";
        items[] = {"ACM_Syringe_10_Amiodarone"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Amiodarone', 10, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Amiodarone_5_IV: Epinephrine_5_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Amiodarone', 5, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Amiodarone']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_5_ca.paa";
        items[] = {"ACM_Syringe_5_Amiodarone"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Amiodarone', 5, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Amiodarone_3_IV: Epinephrine_3_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Amiodarone', 3, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Amiodarone']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_3_ca.paa";
        items[] = {"ACM_Syringe_3_Amiodarone"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Amiodarone', 3, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Amiodarone_1_IV: Epinephrine_1_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Amiodarone', 1, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Amiodarone']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_1_ca.paa";
        items[] = {"ACM_Syringe_1_Amiodarone"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Amiodarone', 1, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Atropine_10_IV: Epinephrine_10_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Atropine', 10, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Atropine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_10_ca.paa";
        items[] = {"ACM_Syringe_10_Atropine"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Atropine', 10, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Atropine_5_IV: Epinephrine_5_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Atropine', 5, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Atropine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_5_ca.paa";
        items[] = {"ACM_Syringe_5_Atropine"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Atropine', 5, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Atropine_3_IV: Epinephrine_3_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Atropine', 3, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Atropine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_3_ca.paa";
        items[] = {"ACM_Syringe_3_Atropine"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Atropine', 3, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Atropine_1_IV: Epinephrine_1_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Atropine', 1, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Atropine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_1_ca.paa";
        items[] = {"ACM_Syringe_1_Atropine"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Atropine', 1, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Morphine_10_IV: Epinephrine_10_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Morphine', 10, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Morphine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_10_ca.paa";
        items[] = {"ACM_Syringe_10_Morphine"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Morphine', 10, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Morphine_5_IV: Epinephrine_5_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Morphine', 5, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Morphine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_5_ca.paa";
        items[] = {"ACM_Syringe_5_Morphine"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Morphine', 5, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Morphine_3_IV: Epinephrine_3_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Morphine', 3, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Morphine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_3_ca.paa";
        items[] = {"ACM_Syringe_3_Morphine"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Morphine', 3, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Morphine_1_IV: Epinephrine_1_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Morphine', 1, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Morphine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_1_ca.paa";
        items[] = {"ACM_Syringe_1_Morphine"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Morphine', 1, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Ketamine_10_IV: Epinephrine_10_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Ketamine', 10, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Ketamine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_10_ca.paa";
        items[] = {"ACM_Syringe_10_Ketamine"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Ketamine', 10, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Ketamine_5_IV: Epinephrine_5_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Ketamine', 5, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Ketamine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_5_ca.paa";
        items[] = {"ACM_Syringe_5_Ketamine"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Ketamine', 5, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Ketamine_3_IV: Epinephrine_3_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Ketamine', 3, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Ketamine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_3_ca.paa";
        items[] = {"ACM_Syringe_3_Ketamine"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Ketamine', 3, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Ketamine_1_IV: Epinephrine_1_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Ketamine', 1, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Ketamine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_1_ca.paa";
        items[] = {"ACM_Syringe_1_Ketamine"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Ketamine', 1, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Fentanyl_10_IV: Epinephrine_10_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Fentanyl', 10, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Fentanyl']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_10_ca.paa";
        items[] = {"ACM_Syringe_10_Fentanyl"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Fentanyl', 10, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Fentanyl_5_IV: Epinephrine_5_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Fentanyl', 5, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Fentanyl']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_5_ca.paa";
        items[] = {"ACM_Syringe_5_Fentanyl"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Fentanyl', 5, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Fentanyl_3_IV: Epinephrine_3_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Fentanyl', 3, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Fentanyl']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_3_ca.paa";
        items[] = {"ACM_Syringe_3_Fentanyl"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Fentanyl', 3, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Fentanyl_1_IV: Epinephrine_1_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Fentanyl', 1, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Fentanyl']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_1_ca.paa";
        items[] = {"ACM_Syringe_1_Fentanyl"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Fentanyl', 1, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class TXA_10_IV: Epinephrine_10_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_TXA', 10, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_TXA']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_10_ca.paa";
        items[] = {"ACM_Syringe_10_TXA"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'TXA', 10, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class TXA_5_IV: Epinephrine_5_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_TXA', 5, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_TXA']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_5_ca.paa";
        items[] = {"ACM_Syringe_5_TXA"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'TXA', 5, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class TXA_3_IV: Epinephrine_3_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_TXA', 3, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_TXA']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_3_ca.paa";
        items[] = {"ACM_Syringe_3_TXA"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'TXA', 3, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class TXA_1_IV: Epinephrine_1_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_TXA', 1, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_TXA']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_1_ca.paa";
        items[] = {"ACM_Syringe_1_TXA"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'TXA', 1, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Adenosine_10_IV: Epinephrine_10_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Adenosine', 10, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Adenosine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_10_ca.paa";
        items[] = {"ACM_Syringe_10_Adenosine"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Adenosine', 10, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Adenosine_5_IV: Epinephrine_5_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Adenosine', 5, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Adenosine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_5_ca.paa";
        items[] = {"ACM_Syringe_5_Adenosine"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Adenosine', 5, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Adenosine_3_IV: Epinephrine_3_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Adenosine', 3, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Adenosine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_3_ca.paa";
        items[] = {"ACM_Syringe_3_Adenosine"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Adenosine', 3, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Adenosine_1_IV: Epinephrine_1_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Adenosine', 1, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Adenosine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_1_ca.paa";
        items[] = {"ACM_Syringe_1_Adenosine"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Adenosine', 1, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Lidocaine_10_IV: Epinephrine_10_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Lidocaine', 10, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Lidocaine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_10_ca.paa";
        items[] = {"ACM_Syringe_10_Lidocaine"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Lidocaine', 10, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Lidocaine_5_IV: Epinephrine_5_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Lidocaine', 5, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Lidocaine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_5_ca.paa";
        items[] = {"ACM_Syringe_5_Lidocaine"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Lidocaine', 5, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Lidocaine_3_IV: Epinephrine_3_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Lidocaine', 3, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Lidocaine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_3_ca.paa";
        items[] = {"ACM_Syringe_3_Lidocaine"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Lidocaine', 3, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Lidocaine_1_IV: Epinephrine_1_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Lidocaine', 1, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Lidocaine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_1_ca.paa";
        items[] = {"ACM_Syringe_1_Lidocaine"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Lidocaine', 1, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Ondansetron_10_IV: Epinephrine_10_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Ondansetron', 10, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Ondansetron']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_10_ca.paa";
        items[] = {"ACM_Syringe_10_Ondansetron"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Ondansetron', 10, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Ondansetron_5_IV: Epinephrine_5_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Ondansetron', 5, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Ondansetron']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_5_ca.paa";
        items[] = {"ACM_Syringe_5_Ondansetron"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Ondansetron', 5, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Ondansetron_3_IV: Epinephrine_3_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Ondansetron', 3, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Ondansetron']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_3_ca.paa";
        items[] = {"ACM_Syringe_3_Ondansetron"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Ondansetron', 3, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Ondansetron_1_IV: Epinephrine_1_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Ondansetron', 1, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Ondansetron']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_1_ca.paa";
        items[] = {"ACM_Syringe_1_Ondansetron"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Ondansetron', 1, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class CalciumChloride_10_IV: Epinephrine_10_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_CalciumChloride', 10, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_CalciumChloride']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_10_ca.paa";
        items[] = {"ACM_Syringe_10_CalciumChloride"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'CalciumChloride', 10, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class CalciumChloride_5_IV: Epinephrine_5_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_CalciumChloride', 5, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_CalciumChloride']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_5_ca.paa";
        items[] = {"ACM_Syringe_5_CalciumChloride"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'CalciumChloride', 5, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class CalciumChloride_3_IV: Epinephrine_3_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_CalciumChloride', 3, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_CalciumChloride']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_3_ca.paa";
        items[] = {"ACM_Syringe_3_CalciumChloride"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'CalciumChloride', 3, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class CalciumChloride_1_IV: Epinephrine_1_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_CalciumChloride', 1, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_CalciumChloride']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_1_ca.paa";
        items[] = {"ACM_Syringe_1_CalciumChloride"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'CalciumChloride', 1, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Ertapenem_10_IV: Epinephrine_10_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Ertapenem', 10, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Ertapenem']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_10_ca.paa";
        items[] = {"ACM_Syringe_10_Ertapenem"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Ertapenem', 10, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Ertapenem_5_IV: Epinephrine_5_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Ertapenem', 5, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Ertapenem']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_5_ca.paa";
        items[] = {"ACM_Syringe_5_Ertapenem"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Ertapenem', 5, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Ertapenem_3_IV: Epinephrine_3_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Ertapenem', 3, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Ertapenem']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_3_ca.paa";
        items[] = {"ACM_Syringe_3_Ertapenem"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Ertapenem', 3, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Ertapenem_1_IV: Epinephrine_1_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Ertapenem', 1, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Ertapenem']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_1_ca.paa";
        items[] = {"ACM_Syringe_1_Ertapenem"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Ertapenem', 1, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Esmolol_10_IV: Epinephrine_10_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Esmolol', 10, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Esmolol']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_10_ca.paa";
        items[] = {"ACM_Syringe_10_Esmolol"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Esmolol', 10, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Esmolol_5_IV: Epinephrine_5_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Esmolol', 5, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Esmolol']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_5_ca.paa";
        items[] = {"ACM_Syringe_5_Esmolol"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Esmolol', 5, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Esmolol_3_IV: Epinephrine_3_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Esmolol', 3, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Esmolol']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_3_ca.paa";
        items[] = {"ACM_Syringe_3_Esmolol"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Esmolol', 3, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Esmolol_1_IV: Epinephrine_1_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Esmolol', 1, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Esmolol']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_1_ca.paa";
        items[] = {"ACM_Syringe_1_Esmolol"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Esmolol', 1, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Dimercaprol_10_IV: Epinephrine_10_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Dimercaprol', 10, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Dimercaprol']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_10_ca.paa";
        items[] = {"ACM_Syringe_10_Dimercaprol"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Dimercaprol', 10, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Dimercaprol_5_IV: Epinephrine_5_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Dimercaprol', 5, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Dimercaprol']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_5_ca.paa";
        items[] = {"ACM_Syringe_5_Dimercaprol"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Dimercaprol', 5, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Dimercaprol_3_IV: Epinephrine_3_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Dimercaprol', 3, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Dimercaprol']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_3_ca.paa";
        items[] = {"ACM_Syringe_3_Dimercaprol"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Dimercaprol', 3, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Dimercaprol_1_IV: Epinephrine_1_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Push', localize 'STR_ACM_Circulation_Medication_Dimercaprol', 1, localize 'STR_ACM_Circulation_Intravenous_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Pushing', localize 'STR_ACM_Circulation_Medication_Dimercaprol']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_1_ca.paa";
        items[] = {"ACM_Syringe_1_Dimercaprol"};
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasIV || [_patient, _bodyPart] call ACM_circulation_fnc_hasIO";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Dimercaprol', 1, true, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Epinephrine_10_IM: Epinephrine_10_IV {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Epinephrine', 10, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Epinephrine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_10_ca.paa";
        allowedSelections[] = {
            "Body",
            "LeftArm",
            "RightArm",
            "LeftLeg",
            "RightLeg"
        };
        items[] = {"ACM_Syringe_10_Epinephrine"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Epinephrine', 10, false, true] call ACM_circulation_fnc_Syringe_Inject";
        sounds[] = {};
        litter[] = {};
    };
    class Epinephrine_5_IM: Epinephrine_10_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Epinephrine', 5, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_5_ca.paa";
        items[] = {"ACM_Syringe_5_Epinephrine"};
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Epinephrine', 5, false, true] call ACM_circulation_fnc_Syringe_Inject";
        ACM_menuIcon = "ACM_Syringe_5";
    };
    class Epinephrine_3_IM: Epinephrine_10_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Epinephrine', 3, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_3_ca.paa";
        items[] = {"ACM_Syringe_3_Epinephrine"};
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Epinephrine', 3, false, true] call ACM_circulation_fnc_Syringe_Inject";
        ACM_menuIcon = "ACM_Syringe_3";
    };
    class Epinephrine_1_IM: Epinephrine_10_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Epinephrine', 1, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_1_ca.paa";
        items[] = {"ACM_Syringe_1_Epinephrine"};
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Epinephrine', 1, false, true] call ACM_circulation_fnc_Syringe_Inject";
        ACM_menuIcon = "ACM_Syringe_1";
    };
    class Morphine_10_IM: Epinephrine_10_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Morphine', 10, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Morphine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_10_ca.paa";
        items[] = {"ACM_Syringe_10_Morphine"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Morphine', 10, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Morphine_5_IM: Epinephrine_5_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Morphine', 5, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Morphine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_5_ca.paa";
        items[] = {"ACM_Syringe_5_Morphine"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Morphine', 5, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Morphine_3_IM: Epinephrine_3_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Morphine', 3, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Morphine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_3_ca.paa";
        items[] = {"ACM_Syringe_3_Morphine"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Morphine', 3, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Morphine_1_IM: Epinephrine_1_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Morphine', 1, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Morphine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_1_ca.paa";
        items[] = {"ACM_Syringe_1_Morphine"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Morphine', 1, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Ketamine_10_IM: Epinephrine_10_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Ketamine', 10, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Ketamine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_10_ca.paa";
        items[] = {"ACM_Syringe_10_Ketamine"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Ketamine', 10, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Ketamine_5_IM: Epinephrine_5_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Ketamine', 5, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Ketamine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_5_ca.paa";
        items[] = {"ACM_Syringe_5_Ketamine"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Ketamine', 5, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Ketamine_3_IM: Epinephrine_3_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Ketamine', 3, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Ketamine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_3_ca.paa";
        items[] = {"ACM_Syringe_3_Ketamine"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Ketamine', 3, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Ketamine_1_IM: Epinephrine_1_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Ketamine', 1, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Ketamine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_1_ca.paa";
        items[] = {"ACM_Syringe_1_Ketamine"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Ketamine', 1, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class TXA_10_IM: Epinephrine_10_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_TXA', 10, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_TXA']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_10_ca.paa";
        items[] = {"ACM_Syringe_10_TXA"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'TXA', 10, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class TXA_5_IM: Epinephrine_5_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_TXA', 5, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_TXA']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_5_ca.paa";
        items[] = {"ACM_Syringe_5_TXA"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'TXA', 5, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class TXA_3_IM: Epinephrine_3_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_TXA', 3, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_TXA']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_3_ca.paa";
        items[] = {"ACM_Syringe_3_TXA"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'TXA', 3, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class TXA_1_IM: Epinephrine_1_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_TXA', 1, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_TXA']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_1_ca.paa";
        items[] = {"ACM_Syringe_1_TXA"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'TXA', 1, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Fentanyl_10_IM: Epinephrine_10_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Fentanyl', 10, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Fentanyl']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_10_ca.paa";
        items[] = {"ACM_Syringe_10_Fentanyl"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Fentanyl', 10, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Fentanyl_5_IM: Epinephrine_5_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Fentanyl', 5, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Fentanyl']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_5_ca.paa";
        items[] = {"ACM_Syringe_5_Fentanyl"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Fentanyl', 5, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Fentanyl_3_IM: Epinephrine_3_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Fentanyl', 3, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Fentanyl']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_3_ca.paa";
        items[] = {"ACM_Syringe_3_Fentanyl"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Fentanyl', 3, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Fentanyl_1_IM: Epinephrine_1_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Fentanyl', 1, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Fentanyl']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_1_ca.paa";
        items[] = {"ACM_Syringe_1_Fentanyl"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Fentanyl', 1, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Lidocaine_10_IM: Epinephrine_10_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Lidocaine', 10, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Lidocaine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_10_ca.paa";
        items[] = {"ACM_Syringe_10_Lidocaine"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Lidocaine', 10, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Lidocaine_5_IM: Epinephrine_5_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Lidocaine', 5, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Lidocaine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_5_ca.paa";
        items[] = {"ACM_Syringe_5_Lidocaine"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Lidocaine', 5, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Lidocaine_3_IM: Epinephrine_3_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Lidocaine', 3, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Lidocaine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_3_ca.paa";
        items[] = {"ACM_Syringe_3_Lidocaine"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Lidocaine', 3, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Lidocaine_1_IM: Epinephrine_1_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Lidocaine', 1, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Lidocaine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_1_ca.paa";
        items[] = {"ACM_Syringe_1_Lidocaine"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Lidocaine', 1, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Amiodarone_10_IM: Epinephrine_10_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Amiodarone', 10, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Amiodarone']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_10_ca.paa";
        items[] = {"ACM_Syringe_10_Amiodarone"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Amiodarone', 10, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Amiodarone_5_IM: Epinephrine_5_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Amiodarone', 5, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Amiodarone']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_5_ca.paa";
        items[] = {"ACM_Syringe_5_Amiodarone"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Amiodarone', 5, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Amiodarone_3_IM: Epinephrine_3_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Amiodarone', 3, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Amiodarone']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_3_ca.paa";
        items[] = {"ACM_Syringe_3_Amiodarone"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Amiodarone', 3, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Amiodarone_1_IM: Epinephrine_1_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Amiodarone', 1, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Amiodarone']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_1_ca.paa";
        items[] = {"ACM_Syringe_1_Amiodarone"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Amiodarone', 1, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Atropine_10_IM: Epinephrine_10_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Atropine', 10, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Atropine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_10_ca.paa";
        items[] = {"ACM_Syringe_10_Atropine"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Atropine', 10, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Atropine_5_IM: Epinephrine_5_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Atropine', 5, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Atropine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_5_ca.paa";
        items[] = {"ACM_Syringe_5_Atropine"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Atropine', 5, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Atropine_3_IM: Epinephrine_3_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Atropine', 3, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Atropine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_3_ca.paa";
        items[] = {"ACM_Syringe_3_Atropine"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Atropine', 3, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Atropine_1_IM: Epinephrine_1_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Atropine', 1, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Atropine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_1_ca.paa";
        items[] = {"ACM_Syringe_1_Atropine"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Atropine', 1, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Adenosine_10_IM: Epinephrine_10_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Adenosine', 10, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Adenosine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_10_ca.paa";
        items[] = {"ACM_Syringe_10_Adenosine"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Adenosine', 10, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Adenosine_5_IM: Epinephrine_5_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Adenosine', 5, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Adenosine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_5_ca.paa";
        items[] = {"ACM_Syringe_5_Adenosine"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Adenosine', 5, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Adenosine_3_IM: Epinephrine_3_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Adenosine', 3, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Adenosine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_3_ca.paa";
        items[] = {"ACM_Syringe_3_Adenosine"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Adenosine', 3, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Adenosine_1_IM: Epinephrine_1_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Adenosine', 1, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Adenosine']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_1_ca.paa";
        items[] = {"ACM_Syringe_1_Adenosine"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Adenosine', 1, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Ondansetron_10_IM: Epinephrine_10_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Ondansetron', 10, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Ondansetron']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_10_ca.paa";
        items[] = {"ACM_Syringe_10_Ondansetron"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Ondansetron', 10, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Ondansetron_5_IM: Epinephrine_5_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Ondansetron', 5, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Ondansetron']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_5_ca.paa";
        items[] = {"ACM_Syringe_5_Ondansetron"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Ondansetron', 5, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Ondansetron_3_IM: Epinephrine_3_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Ondansetron', 3, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Ondansetron']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_3_ca.paa";
        items[] = {"ACM_Syringe_3_Ondansetron"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Ondansetron', 3, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Ondansetron_1_IM: Epinephrine_1_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Ondansetron', 1, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Ondansetron']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_1_ca.paa";
        items[] = {"ACM_Syringe_1_Ondansetron"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Ondansetron', 1, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class CalciumChloride_10_IM: Epinephrine_10_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_CalciumChloride', 10, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_CalciumChloride']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_10_ca.paa";
        items[] = {"ACM_Syringe_10_CalciumChloride"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'CalciumChloride', 10, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class CalciumChloride_5_IM: Epinephrine_5_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_CalciumChloride', 5, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_CalciumChloride']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_5_ca.paa";
        items[] = {"ACM_Syringe_5_CalciumChloride"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'CalciumChloride', 5, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class CalciumChloride_3_IM: Epinephrine_3_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_CalciumChloride', 3, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_CalciumChloride']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_3_ca.paa";
        items[] = {"ACM_Syringe_3_CalciumChloride"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'CalciumChloride', 3, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class CalciumChloride_1_IM: Epinephrine_1_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_CalciumChloride', 1, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_CalciumChloride']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_1_ca.paa";
        items[] = {"ACM_Syringe_1_CalciumChloride"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'CalciumChloride', 1, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Ertapenem_10_IM: Epinephrine_10_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Ertapenem', 10, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Ertapenem']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_10_ca.paa";
        items[] = {"ACM_Syringe_10_Ertapenem"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Ertapenem', 10, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Ertapenem_5_IM: Epinephrine_5_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Ertapenem', 5, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Ertapenem']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_5_ca.paa";
        items[] = {"ACM_Syringe_5_Ertapenem"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Ertapenem', 5, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Ertapenem_3_IM: Epinephrine_3_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Ertapenem', 3, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Ertapenem']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_3_ca.paa";
        items[] = {"ACM_Syringe_3_Ertapenem"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Ertapenem', 3, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Ertapenem_1_IM: Epinephrine_1_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Ertapenem', 1, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Ertapenem']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_1_ca.paa";
        items[] = {"ACM_Syringe_1_Ertapenem"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Ertapenem', 1, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Esmolol_10_IM: Epinephrine_10_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Esmolol', 10, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Esmolol']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_10_ca.paa";
        items[] = {"ACM_Syringe_10_Esmolol"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Esmolol', 10, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Esmolol_5_IM: Epinephrine_5_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Esmolol', 5, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Esmolol']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_5_ca.paa";
        items[] = {"ACM_Syringe_5_Esmolol"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Esmolol', 5, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Esmolol_3_IM: Epinephrine_3_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Esmolol', 3, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Esmolol']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_3_ca.paa";
        items[] = {"ACM_Syringe_3_Esmolol"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Esmolol', 3, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Esmolol_1_IM: Epinephrine_1_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Esmolol', 1, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Esmolol']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_1_ca.paa";
        items[] = {"ACM_Syringe_1_Esmolol"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Esmolol', 1, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Dimercaprol_10_IM: Epinephrine_10_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Dimercaprol', 10, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Dimercaprol']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_10_ca.paa";
        items[] = {"ACM_Syringe_10_Dimercaprol"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Dimercaprol', 10, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Dimercaprol_5_IM: Epinephrine_5_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Dimercaprol', 5, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Dimercaprol']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_5_ca.paa";
        items[] = {"ACM_Syringe_5_Dimercaprol"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Dimercaprol', 5, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Dimercaprol_3_IM: Epinephrine_3_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Dimercaprol', 3, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Dimercaprol']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_3_ca.paa";
        items[] = {"ACM_Syringe_3_Dimercaprol"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Dimercaprol', 3, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class Dimercaprol_1_IM: Epinephrine_1_IM {
        displayName = __EVAL(call compile "format ['%1 %2 (%3ml) (%4)', localize 'STR_ACM_Circulation_Inject', localize 'STR_ACM_Circulation_Medication_Dimercaprol', 1, localize 'STR_ACM_Circulation_Intramuscular_Short']");
        displayNameProgress = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Injecting', localize 'STR_ACM_Circulation_Medication_Dimercaprol']");
        icon = "\x\ACM\addons\circulation\ui\icon_syringe_1_ca.paa";
        items[] = {"ACM_Syringe_1_Dimercaprol"};
        condition = "true";
        callbackSuccess = "[_medic, _patient, _bodyPart, 'Dimercaprol', 1, false, true] call ACM_circulation_fnc_Syringe_Inject";
    };
    class WashEyes: CheckPulse {
        displayName = "$STR_ACM_CBRN_WashEyes";
        displayNameProgress = "$STR_ACM_CBRN_WashEyes_Progress";
        icon = "";
        category = "medication";
        treatmentLocations = 0;
        medicRequired = 0;
        treatmentTime = 3;
        allowedSelections[] = {"Head"};
        allowSelfTreatment = 1;
        items[] = {
            "ACE_WaterBottle",
            "ACE_WaterBottle_Half",
            "ACE_Canteen",
            "ACE_Canteen_Half"
        };
        consumeItem = 1;
        condition = "_patient call ACM_CBRN_fnc_canWashEyes";
        callbackSuccess = "[_medic, _patient, _usedItem] call ACM_CBRN_fnc_washEyes";
        animationMedicSelf = "";
        ACM_rollToBack = 1;
    };
};
class CfgMovesBasic {
    class Default;
};
class CfgMovesMaleSdr: CfgMovesBasic {
    class States {
        class ACM_GenericContinuous: Default {
            file = "\a3\anims_f\data\anim\sdr\idl\knl\stp\non\non\AidlPknlMstpSnonWnonDnon_G02.rtm";
            speed = -100;
            looped = 1;
            disableWeapons = 1;
            disableWeaponsLong = 1;
            showWeaponAim = 0;
            canPullTrigger = 0;
            duty = 0.2;
            limitGunMovement = 0;
            aiming = "empty";
            aimingBody = "empty";
            ConnectTo[] = {"AmovPknlMstpSnonWnonDnon", 0.1};
            forceAim = 1;
            InterpolateFrom[] = {"AmovPknlMstpSnonWnonDnon", 0.2};
            InterpolateTo[] = {
                "AmovPknlMstpSnonWnonDnon",
                0.1,
                "Unconscious",
                0.02
            };
        };
        class ACM_ProneContinuous: ACM_GenericContinuous {
            InterpolateFrom[] = {"AmovPpneMstpSnonWnonDnon", 0.2};
            file = "\a3\anims_f\data\anim\sdr\idl\pne\stp\non\non\AidlPpneMstpSnonWnonDnon_G02.rtm";
            ConnectTo[] = {"AmovPpneMstpSnonWnonDnon", 0.1};
            InterpolateTo[] = {
                "AmovPpneMstpSnonWnonDnon",
                0.1,
                "Unconscious",
                0.02
            };
        };
        class ainjppnemstpsnonwrfldnon;
        class ACM_LyingState: ainjppnemstpsnonwrfldnon {
            file = "\x\ACM\addons\core\anim\ACM_LyingState.rtm";
            speed = -100;
            looped = 1;
            disableWeapons = 1;
            disableWeaponsLong = 1;
            showWeaponAim = 0;
            canPullTrigger = 0;
            duty = 0.2;
            limitGunMovement = 0;
            aiming = "aimingNo";
            aimingBody = "aimingUpNo";
            head = "headNo";
            ConnectTo[] = {};
            forceAim = 1;
            InterpolateTo[] = {};
        };
    };
};
class CfgSounds {
    class ACM_wakeUp_1 {
        name = "ACM_wakeUp_1";
        sound[] = {"A3\sounds_f\characters\human-sfx\other\vzkriseni_01.wss", "db+8", 1};
        titles[] = {};
    };
    class ACM_wakeUp_2: ACM_wakeUp_1 {
        name = "ACM_wakeUp_2";
        sound[] = {"A3\sounds_f\characters\human-sfx\other\vzkriseni_02.wss", "db+8", 1};
    };
    class ACM_wakeUp_3: ACM_wakeUp_1 {
        name = "ACM_wakeUp_3";
        sound[] = {"A3\sounds_f\characters\human-sfx\other\vzkriseni_03.wss", "db+8", 1};
    };
    class ACM_wakeUp_4: ACM_wakeUp_1 {
        name = "ACM_wakeUp_4";
        sound[] = {"A3\sounds_f\characters\human-sfx\other\vzkriseni_04.wss", "db+8", 1};
    };
};
class ace_medical_replacementItems {
    ItemType_401[] = {
        {"ACM_PressureBandage", 2},
        {"ACE_tourniquet", 1},
        {"ACM_ChestSeal", 1},
        {"ACM_NPA", 1},
        {"ACM_Paracetamol", 1}
    };
    ItemType_619[] = {
        {"ACM_PressureBandage", 3},
        {"ACM_ElasticWrap", 5},
        {"ACM_Vial_Morphine", 1},
        {"ACM_Syringe_5", 1},
        {"ACE_salineIV_250", 1},
        {"ACE_tourniquet", 1},
        {"ACM_SAMSplint", 2},
        {"ACM_ChestSeal", 1},
        {"ACM_NPA", 1},
        {"ACM_NCDKit", 1},
        {"ACM_SuctionBag", 1},
        {"ACM_IV_16g", 1}
    };
};
class CfgVehicles {
    class ACE_medicalSupplyCrate;
    class ACM_MedicalSupplyCrate_Basic: ACE_medicalSupplyCrate {
        displayName = "$STR_ACM_core_MedicalSupplyCrate_Basic_Display";
        author = "Blue";
        editorCategory = "EdCat_Supplies";
        editorSubcategory = "ACM_core_EditorCategory";
        class TransportMagazines {
            class _xx_ACM_Paracetamol {
                magazine = "ACM_Paracetamol";
                count = 4;
            };
            class _xx_ACM_AmmoniaInhalant {
                magazine = "ACM_AmmoniaInhalant";
                count = 4;
            };
            class _xx_ACM_Inhaler_Penthrox {
                magazine = "ACM_Inhaler_Penthrox";
                count = 5;
            };
        };
        class TransportItems {
            class _xx_ACM_PressureBandage {
                name = "ACM_PressureBandage";
                count = 50;
            };
            class _xx_ACM_EmergencyTraumaDressing {
                name = "ACM_EmergencyTraumaDressing";
                count = 20;
            };
            class _xx_ACM_ElasticWrap {
                name = "ACM_ElasticWrap";
                count = 40;
            };
            class _xx_ACE_tourniquet {
                name = "ACE_tourniquet";
                count = 24;
            };
            class _xx_ACM_OPA {
                name = "ACM_OPA";
                count = 10;
            };
            class _xx_ACM_NPA {
                name = "ACM_NPA";
                count = 10;
            };
            class _xx_ACM_SuctionBag {
                name = "ACM_SuctionBag";
                count = 5;
            };
            class _xx_ACM_ChestSeal {
                name = "ACM_ChestSeal";
                count = 10;
            };
            class _xx_ACM_PocketBVM {
                name = "ACM_PocketBVM";
                count = 2;
            };
            class _xx_ACM_NCDKit {
                name = "ACM_NCDKit";
                count = 5;
            };
            class _xx_ACE_morphine {
                name = "ACE_morphine";
                count = 10;
            };
            class _xx_ACM_SAMSplint {
                name = "ACM_SAMSplint";
                count = 10;
            };
            class _xx_ACM_Spray_Naloxone {
                name = "ACM_Spray_Naloxone";
                count = 10;
            };
        };
    };
    class ACM_MedicalSupplyCrate_Advanced: ACM_MedicalSupplyCrate_Basic {
        displayName = "$STR_ACM_core_MedicalSupplyCrate_Advanced_Display";
        class TransportMagazines {
            class _xx_ACM_Paracetamol {
                magazine = "ACM_Paracetamol";
                count = 8;
            };
            class _xx_ACM_AmmoniaInhalant {
                magazine = "ACM_AmmoniaInhalant";
                count = 8;
            };
            class _xx_ACM_Inhaler_Penthrox {
                magazine = "ACM_Inhaler_Penthrox";
                count = 8;
            };
            class _xx_ACM_OxygenTank_425 {
                magazine = "ACM_OxygenTank_425";
                count = 2;
            };
        };
        class TransportItems {
            class _xx_ACM_PressureBandage {
                name = "ACM_PressureBandage";
                count = 60;
            };
            class _xx_ACM_EmergencyTraumaDressing {
                name = "ACM_EmergencyTraumaDressing";
                count = 30;
            };
            class _xx_ACM_ElasticWrap {
                name = "ACM_ElasticWrap";
                count = 60;
            };
            class _xx_ACE_tourniquet {
                name = "ACE_tourniquet";
                count = 16;
            };
            class _xx_ACM_IGel {
                name = "ACM_IGel";
                count = 20;
            };
            class _xx_ACM_ACCUVAC {
                name = "ACM_ACCUVAC";
                count = 5;
            };
            class _xx_ACM_OPA {
                name = "ACM_OPA";
                count = 10;
            };
            class _xx_ACM_NPA {
                name = "ACM_NPA";
                count = 10;
            };
            class _xx_ACM_SuctionBag {
                name = "ACM_SuctionBag";
                count = 10;
            };
            class _xx_ACM_CricKit {
                name = "ACM_CricKit";
                count = 10;
            };
            class _xx_ACM_Stethoscope {
                name = "ACM_Stethoscope";
                count = 4;
            };
            class _xx_ACM_ChestSeal {
                name = "ACM_ChestSeal";
                count = 20;
            };
            class _xx_ACM_BVM {
                name = "ACM_BVM";
                count = 4;
            };
            class _xx_ACM_NCDKit {
                name = "ACM_NCDKit";
                count = 10;
            };
            class _xx_ACM_PulseOximeter {
                name = "ACM_PulseOximeter";
                count = 5;
            };
            class _xx_ACM_ThoracostomyKit {
                name = "ACM_ThoracostomyKit";
                count = 5;
            };
            class _xx_ACM_ChestTubeKit {
                name = "ACM_ChestTubeKit";
                count = 5;
            };
            class _xx_ACM_AED {
                name = "ACM_AED";
                count = 3;
            };
            class _xx_ACM_PressureCuff {
                name = "ACM_PressureCuff";
                count = 3;
            };
            class _xx_ACM_IV_16g {
                name = "ACM_IV_16g";
                count = 25;
            };
            class _xx_ACM_IV_14g {
                name = "ACM_IV_14g";
                count = 15;
            };
            class _xx_ACM_Syringe_1 {
                name = "ACM_Syringe_1";
                count = 5;
            };
            class _xx_ACM_Syringe_3 {
                name = "ACM_Syringe_3";
                count = 5;
            };
            class _xx_ACM_Syringe_5 {
                name = "ACM_Syringe_5";
                count = 5;
            };
            class _xx_ACM_Syringe_10 {
                name = "ACM_Syringe_10";
                count = 2;
            };
            class _xx_ACM_IO_FAST {
                name = "ACM_IO_FAST";
                count = 15;
            };
            class _xx_ACM_IO_EZ {
                name = "ACM_IO_EZ";
                count = 15;
            };
            class _xx_ACM_Vial_Epinephrine {
                name = "ACM_Vial_Epinephrine";
                count = 10;
            };
            class _xx_ACM_Vial_Esmolol {
                name = "ACM_Vial_Esmolol";
                count = 10;
            };
            class _xx_ACM_Vial_TXA {
                name = "ACM_Vial_TXA";
                count = 10;
            };
            class _xx_ACM_Vial_Amiodarone {
                name = "ACM_Vial_Amiodarone";
                count = 10;
            };
            class _xx_ACM_Vial_Atropine {
                name = "ACM_Vial_Atropine";
                count = 10;
            };
            class _xx_ACM_BloodBag_ON_1000 {
                name = "ACM_BloodBag_ON_1000";
                count = 10;
            };
            class _xx_ACM_BloodBag_ON_500 {
                name = "ACM_BloodBag_ON_500";
                count = 10;
            };
            class _xx_ACM_BloodBag_ON_250 {
                name = "ACM_BloodBag_ON_250";
                count = 10;
            };
            class _xx_ACE_plasmaIV {
                name = "ACE_plasmaIV";
                count = 10;
            };
            class _xx_ACE_plasmaIV_500 {
                name = "ACE_plasmaIV_500";
                count = 10;
            };
            class _xx_ACE_plasmaIV_250 {
                name = "ACE_plasmaIV_250";
                count = 10;
            };
            class _xx_ACE_salineIV {
                name = "ACE_salineIV";
                count = 10;
            };
            class _xx_ACE_salineIV_500 {
                name = "ACE_salineIV_500";
                count = 10;
            };
            class _xx_ACE_salineIV_250 {
                name = "ACE_salineIV_250";
                count = 10;
            };
            class _xx_ACM_FieldBloodTransfusionKit_250 {
                name = "ACM_FieldBloodTransfusionKit_250";
                count = 5;
            };
            class _xx_ACM_FieldBloodTransfusionKit_500 {
                name = "ACM_FieldBloodTransfusionKit_500";
                count = 5;
            };
            class _xx_ACM_Vial_CalciumChloride {
                name = "ACM_Vial_CalciumChloride";
                count = 10;
            };
            class _xx_ACE_morphine {
                name = "ACE_morphine";
                count = 5;
            };
            class _xx_ACM_Vial_Morphine {
                name = "ACM_Vial_Morphine";
                count = 10;
            };
            class _xx_ACM_Vial_Ketamine {
                name = "ACM_Vial_Ketamine";
                count = 10;
            };
            class _xx_ACM_Vial_Fentanyl {
                name = "ACM_Vial_Fentanyl";
                count = 10;
            };
            class _xx_ACM_Vial_Lidocaine {
                name = "ACM_Vial_Lidocaine";
                count = 10;
            };
            class _xx_ACM_Vial_Ondansetron {
                name = "ACM_Vial_Ondansetron";
                count = 10;
            };
            class _xx_ACM_Lozenge_Fentanyl {
                name = "ACM_Lozenge_Fentanyl";
                count = 10;
            };
            class _xx_ACM_SAMSplint {
                name = "ACM_SAMSplint";
                count = 10;
            };
            class _xx_ACM_Spray_Naloxone {
                name = "ACM_Spray_Naloxone";
                count = 10;
            };
            class _xx_ACE_personalAidKit {
                name = "ACE_personalAidKit";
                count = 1;
            };
            class _xx_ACE_surgicalKit {
                name = "ACE_surgicalKit";
                count = 2;
            };
            class _xx_ACE_bodyBag {
                name = "ACE_bodyBag";
                count = 5;
            };
            class _xx_ACE_suture {
                name = "ACE_suture";
                count = 60;
            };
            class _xx_ACM_Vial_Ertapenem {
                name = "ACM_Vial_Ertapenem";
                count = 10;
            };
        };
    };
    class ACM_CBRN_SupplyCrate: ACE_medicalSupplyCrate {
        displayName = "$STR_ACM_CBRN_SupplyCrate_Display";
        author = "Blue";
        editorCategory = "EdCat_Supplies";
        editorSubcategory = "ACM_core_EditorCategory";
        class TransportMagazines {};
        class TransportItems {
            class _xx_ACM_Autoinjector_ATNA {
                name = "ACM_Autoinjector_ATNA";
                count = 30;
            };
            class _xx_ACM_Autoinjector_Midazolam {
                name = "ACM_Autoinjector_Midazolam";
                count = 10;
            };
            class _xx_ACM_GasMaskFilter {
                name = "ACM_GasMaskFilter";
                count = 30;
            };
        };
    };
    class ACM_CBRN_PPE_SupplyCrate: ACM_CBRN_SupplyCrate {
        displayName = "$STR_ACM_CBRN_SupplyCrate_PPE_Display";
        class TransportItems {
            class _xx_U_C_CBRN_Suit_01_Blue_F {
                name = "U_C_CBRN_Suit_01_Blue_F";
                count = 10;
            };
            class _xx_G_AirPurifyingRespirator_02_black_F {
                name = "G_AirPurifyingRespirator_02_black_F";
                count = 10;
            };
            class _xx_ChemicalDetector_01_watch_F {
                name = "ChemicalDetector_01_watch_F";
                count = 2;
            };
            class _xx_ACM_GasMaskFilter {
                name = "ACM_GasMaskFilter";
                count = 10;
            };
        };
    };
    class Man;
    class CAManBase: Man {
        class ACE_Actions {
            class ACE_MainActions {
                class ACM_LyingState_GetUp {
                    displayName = "$STR_ACM_core_LyingState_GetUp";
                    icon = "";
                    condition = "!(isPlayer _target) && {(_target getVariable [""ACM_core_Lying_State"", false]) && alive _target && !(_target getVariable ['ACE_isUnconscious', false]) && !(_target getVariable [""ACM_evacuation_casualtyTicketClaimed"", false])}";
                    statement = "[_target] call ACM_core_fnc_getUp";
                    exceptions[] = {"isNotInside"};
                    showDisabled = 0;
                };
            };
        };
        class ACE_SelfActions {
            class ACM_Action_GetUp {
                displayName = "$STR_ACM_core_LyingState_GetUp";
                icon = "";
                condition = "_player getVariable [""ACM_core_Lying_State"", false]";
                statement = "[_player] call ACM_core_fnc_getUp";
                exceptions[] = {"isNotInside", "isNotInLyingState"};
                showDisabled = 0;
            };
            class ACM_Equipment {
                displayName = "$STR_ACM_core_MedicalEquipment";
                icon = "\x\ACM\addons\main\logo_empty.paa";
                exceptions[] = {"isNotInside", "isNotSitting"};
                class ACM_AED_Interactions {
                    displayName = "$STR_ACM_circulation_AED_Short";
                    condition = "([_player, 'ACM_AED'] call ACME_fnc_itemCount) > 0";
                    statement = "";
                    exceptions[] = {"isNotInside", "isNotSitting"};
                    showDisabled = 0;
                    class ACM_AED_ViewMonitor {
                        displayName = "$STR_ACM_circulation_ViewMonitor";
                        condition = "true";
                        statement = "[_player, _player] call ACM_circulation_fnc_displayAEDMonitor";
                        exceptions[] = {"isNotInside", "isNotSitting"};
                        showDisabled = 0;
                    };
                };
                class ACM_Action_SplitMedicationPack {
                    displayName = "$STR_ACM_core_SplitMedicationPack";
                    condition = "true";
                    statement = "";
                    showDisabled = 0;
                    exceptions[] = {"isNotInside", "isNotSitting"};
                    icon = "";
                    insertChildren = "[_player] call ACM_core_fnc_splitMedicationPack_childActions";
                };
            };
        };
    };
    class LandVehicle;
    class Car: LandVehicle {
        class ACE_Actions {
            class ACE_MainActions {
                class ACM_Action_UnloadAndCarryPatient {
                    displayName = "$STR_ACM_core_CarryPatient";
                    condition = "alive _target";
                    exceptions[] = {"isNotDragging", "isNotCarrying", "isNotInside"};
                    statement = "";
                    insertChildren = "call ACM_core_fnc_addVehicleUnloadCarryPatientActions";
                    icon = "\z\ace\addons\dragging\ui\icons\person_carry.paa";
                };
                class ACM_Action_Refill_PortableOxygenTank_425 {
                    displayName = "$STR_ACM_breathing_RefillOxygenTank";
                    condition = "[_player, _target] call ACM_breathing_fnc_canRefillOxygenTank";
                    exceptions[] = {"isNotInside"};
                    statement = "[_player] call ACM_breathing_fnc_refillOxygenTank";
                    icon = "\x\ACM\addons\breathing\ui\icon_oxygentank_ca.paa";
                };
            };
        };
        class ACE_SelfActions {
            class ACM_Action_PatientsList {
                displayName = "$STR_ACM_core_VehiclePatients";
                condition = "count (fullCrew [_target, '']) > 0";
                exceptions[] = {"isNotInside"};
                statement = "";
                insertChildren = "call ACM_core_fnc_addVehiclePatientActions";
                icon = "\x\ACM\addons\main\logo_empty.paa";
            };
        };
    };
    class Car_F: Car {};
    class Quadbike_01_base_F: Car_F {
        class ACE_Actions: ACE_Actions {
            class ACE_MainActions: ACE_MainActions {
                class ACM_Action_UnloadAndCarryPatient {
                    displayName = "$STR_ACM_core_CarryPatient";
                    condition = "alive _target";
                    exceptions[] = {"isNotDragging", "isNotCarrying", "isNotInside"};
                    statement = "";
                    insertChildren = "call ACM_core_fnc_addVehicleUnloadCarryPatientActions";
                    icon = "\z\ace\addons\dragging\ui\icons\person_carry.paa";
                };
            };
        };
        class ACE_SelfActions {
            class ACM_Action_PatientsList {
                displayName = "$STR_ACM_core_VehiclePatients";
                condition = "count (fullCrew [_target, '']) > 0";
                exceptions[] = {"isNotInside"};
                statement = "";
                insertChildren = "call ACM_core_fnc_addVehiclePatientActions";
                icon = "\x\ACM\addons\main\logo_empty.paa";
            };
        };
    };
    class Kart_01_Base_F: Car_F {
        class ACE_Actions: ACE_Actions {
            class ACE_MainActions: ACE_MainActions {
                class ACM_Action_UnloadAndCarryPatient {
                    displayName = "$STR_ACM_core_CarryPatient";
                    condition = "alive _target";
                    exceptions[] = {"isNotDragging", "isNotCarrying", "isNotInside"};
                    statement = "";
                    insertChildren = "call ACM_core_fnc_addVehicleUnloadCarryPatientActions";
                    icon = "\z\ace\addons\dragging\ui\icons\person_carry.paa";
                };
            };
        };
        class ACE_SelfActions {
            class ACM_Action_PatientsList {
                displayName = "$STR_ACM_core_VehiclePatients";
                condition = "count (fullCrew [_target, '']) > 0";
                exceptions[] = {"isNotInside"};
                statement = "";
                insertChildren = "call ACM_core_fnc_addVehiclePatientActions";
                icon = "\x\ACM\addons\main\logo_empty.paa";
            };
        };
    };
    class Tank: LandVehicle {
        class ACE_Actions {
            class ACE_MainActions {
                class ACM_Action_UnloadAndCarryPatient {
                    displayName = "$STR_ACM_core_CarryPatient";
                    condition = "alive _target";
                    exceptions[] = {"isNotDragging", "isNotCarrying", "isNotInside"};
                    statement = "";
                    insertChildren = "call ACM_core_fnc_addVehicleUnloadCarryPatientActions";
                    icon = "\z\ace\addons\dragging\ui\icons\person_carry.paa";
                };
            };
        };
        class ACE_SelfActions {
            class ACM_Action_PatientsList {
                displayName = "$STR_ACM_core_VehiclePatients";
                condition = "count (fullCrew [_target, '']) > 0";
                exceptions[] = {"isNotInside"};
                statement = "";
                insertChildren = "call ACM_core_fnc_addVehiclePatientActions";
                icon = "\x\ACM\addons\main\logo_empty.paa";
            };
        };
    };
    class Motorcycle: LandVehicle {
        class ACE_Actions {
            class ACE_MainActions {
                class ACM_Action_UnloadAndCarryPatient {
                    displayName = "$STR_ACM_core_CarryPatient";
                    condition = "alive _target";
                    exceptions[] = {"isNotDragging", "isNotCarrying", "isNotInside"};
                    statement = "";
                    insertChildren = "call ACM_core_fnc_addVehicleUnloadCarryPatientActions";
                    icon = "\z\ace\addons\dragging\ui\icons\person_carry.paa";
                };
            };
        };
        class ACE_SelfActions {
            class ACM_Action_PatientsList {
                displayName = "$STR_ACM_core_VehiclePatients";
                condition = "count (fullCrew [_target, '']) > 0";
                exceptions[] = {"isNotInside"};
                statement = "";
                insertChildren = "call ACM_core_fnc_addVehiclePatientActions";
                icon = "\x\ACM\addons\main\logo_empty.paa";
            };
        };
    };
    class Air;
    class Helicopter: Air {
        class ACE_Actions {
            class ACE_MainActions {
                class ACM_Action_UnloadAndCarryPatient {
                    displayName = "$STR_ACM_core_CarryPatient";
                    condition = "alive _target";
                    exceptions[] = {"isNotDragging", "isNotCarrying", "isNotInside"};
                    statement = "";
                    insertChildren = "call ACM_core_fnc_addVehicleUnloadCarryPatientActions";
                    icon = "\z\ace\addons\dragging\ui\icons\person_carry.paa";
                };
            };
        };
        class ACE_SelfActions {
            class ACM_Action_PatientsList {
                displayName = "$STR_ACM_core_VehiclePatients";
                condition = "count (fullCrew [_target, '']) > 0";
                exceptions[] = {"isNotInside"};
                statement = "";
                insertChildren = "call ACM_core_fnc_addVehiclePatientActions";
                icon = "\x\ACM\addons\main\logo_empty.paa";
            };
        };
    };
    class Plane: Air {
        class ACE_Actions {
            class ACE_MainActions {
                class ACM_Action_UnloadAndCarryPatient {
                    displayName = "$STR_ACM_core_CarryPatient";
                    condition = "alive _target";
                    exceptions[] = {"isNotDragging", "isNotCarrying", "isNotInside"};
                    statement = "";
                    insertChildren = "call ACM_core_fnc_addVehicleUnloadCarryPatientActions";
                    icon = "\z\ace\addons\dragging\ui\icons\person_carry.paa";
                };
            };
        };
        class ACE_SelfActions {
            class ACM_Action_PatientsList {
                displayName = "$STR_ACM_core_VehiclePatients";
                condition = "count (fullCrew [_target, '']) > 0";
                exceptions[] = {"isNotInside"};
                statement = "";
                insertChildren = "call ACM_core_fnc_addVehiclePatientActions";
                icon = "\x\ACM\addons\main\logo_empty.paa";
            };
        };
    };
    class Ship;
    class Ship_F: Ship {
        class ACE_Actions {
            class ACE_MainActions {
                class ACM_Action_UnloadAndCarryPatient {
                    displayName = "$STR_ACM_core_CarryPatient";
                    condition = "alive _target";
                    exceptions[] = {"isNotDragging", "isNotCarrying", "isNotInside"};
                    statement = "";
                    insertChildren = "call ACM_core_fnc_addVehicleUnloadCarryPatientActions";
                    icon = "\z\ace\addons\dragging\ui\icons\person_carry.paa";
                };
            };
        };
        class ACE_SelfActions {
            class ACM_Action_PatientsList {
                displayName = "$STR_ACM_core_VehiclePatients";
                condition = "count (fullCrew [_target, '']) > 0";
                exceptions[] = {"isNotInside"};
                statement = "";
                insertChildren = "call ACM_core_fnc_addVehiclePatientActions";
                icon = "\x\ACM\addons\main\logo_empty.paa";
            };
        };
    };
};
class RscText;
class RscPicture;
class RscStructuredText;
class RscTitles {
    class RscTreatmentText {
        idd = 100000;
        fadein = 0;
        fadeout = 0;
        duration = 100000000000;
        onLoad = "uiNamespace setVariable ['ACM_TreatmentText', (_this select 0)];";
        onUnLoad = "uiNamespace setVariable ['ACM_TreatmentText', nil];";
        class Controls {
            class Text: RscText {
                idc = 100001;
                style = 2;
                font = "RobotoCondensed";
                x = "safeZoneX";
                y = "safeZoneY";
                w = "safeZoneW";
                h = "safeZoneH * 1.5";
                colorText[] = {1, 1, 1, 1};
                colorBackground[] = {0, 0, 0, 0};
                text = "";
                lineSpacing = 0;
                sizeEx = "((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) * 1 * (0.55 / (getResolution select 5))";
                fixedWidth = 0;
                deletable = 0;
                fade = 0;
                access = 0;
                type = 0;
                shadow = 1;
                colorShadow[] = {0, 0, 0, 0.5};
            };
        };
    };
    class RscContinuousActionText {
        idd = 110000;
        fadein = 0;
        fadeout = 0;
        duration = 100000000000;
        onLoad = "uiNamespace setVariable ['ACM_ContinuousActionText', (_this select 0)];";
        onUnLoad = "uiNamespace setVariable ['ACM_ContinuousActionText', nil];";
        class Controls {
            class TopText: RscText {
                idc = 110001;
                style = 2;
                font = "RobotoCondensed";
                x = "safeZoneX";
                y = "safeZoneY";
                w = "safeZoneW";
                h = "safeZoneH / 10";
                colorText[] = {1, 1, 1, 1};
                colorBackground[] = {0, 0, 0, 0};
                text = "";
                lineSpacing = 0;
                sizeEx = "((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) * 1.4 * (0.55 / (getResolution select 5))";
                fixedWidth = 0;
                deletable = 0;
                fade = 0;
                access = 0;
                type = 0;
                shadow = 1;
                colorShadow[] = {0, 0, 0, 0.5};
            };
            class BottomText: TopText {
                idc = 110002;
                h = "safeZoneH / 6";
                text = "";
            };
        };
    };
    class ACM_core_singleTag {
        idd = -1;
        onLoad = "uiNamespace setVariable [""ace_dogtags_tag"", _this select 0]";
        onUnload = "uiNamespace setVariable [""ace_dogtags_tag"", nil]";
        fadeIn = 0.2;
        fadeOut = 0.2;
        duration = 5;
        movingEnable = 0;
        class controls {
            class background: RscPicture {
                idc = 1000;
                x = "profileNamespace getVariable ['IGUI_ace_dogtags_grid_X', (safeZoneX + safeZoneW) - 12.9 * (((safeZoneW / safeZoneH) min 1.2) / 40)]";
                y = "profileNamespace getVariable ['IGUI_ace_dogtags_grid_Y', safeZoneY + 0.175 * safeZoneH]";
                w = "8 * (((safeZoneW / safeZoneH) min 1.2) / 40)";
                h = "8 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25)";
                text = "\z\ace\addons\dogtags\data\dogtagSingle.paa";
                colorText[] = {1, 1, 1, 1};
            };
            class nickname: RscStructuredText {
                idc = 1001;
                text = "";
                sizeEx = "((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25)";
                colorText[] = {1, 1, 1, 1};
                colorBackground[] = {0, 0, 0, 0};
                x = "1.4 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (profileNamespace getVariable ['IGUI_ace_dogtags_grid_X', (safeZoneX + safeZoneW) - 12.9 * (((safeZoneW / safeZoneH) min 1.2) / 40)])";
                y = "0.052 * safeZoneH + ((profileNamespace getVariable ['IGUI_ace_dogtags_grid_Y', (safeZoneY + 0.175 * safeZoneH)]) / ((0.55 / (getResolution select 5)) min 1))";
                w = "5.9 * (((safeZoneW / safeZoneH) min 1.2) / 40)";
                h = "3.2 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25)";
                font = "RobotoCondensed";
                class Attributes {
                    font = "RobotoCondensed";
                    color = "#FFFFFF";
                    align = "left";
                    valign = "middle";
                    shadow = 2;
                    shadowColor = "#3f4345";
                    size = "0.7 * (0.55 / (getResolution select 5))";
                };
            };
        };
    };
    class ACM_core_doubleTag: ACM_core_singleTag {
        class controls: controls {
            class background: background {
                text = "\z\ace\addons\dogtags\data\dogtagDouble.paa";
            };
            class nickname: nickname {
                class Attributes: Attributes {
                    font = "RobotoCondensed";
                    color = "#FFFFFF";
                    align = "left";
                    valign = "middle";
                    shadow = 2;
                    shadowColor = "#3f4345";
                    size = "0.7 * (0.55 / (getResolution select 5))";
                };
            };
        };
    };
};

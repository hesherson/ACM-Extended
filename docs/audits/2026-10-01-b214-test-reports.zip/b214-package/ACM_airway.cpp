class CfgPatches {
    class ACM_airway {
        acmeBuildBatch = "B214";
        acmeNetworkProtocol = 1;
        acmeComponent = "airway";
        name = "ACM - Airway";
        units[] = {};
        weapons[] = {
            "ACM_OPA",
            "ACM_IGel",
            "ACM_NPA",
            "ACM_SuctionBag",
            "ACM_ACCUVAC",
            "ACM_CricKit"
        };
        requiredVersion = 2.18;
        requiredAddons[] = {"cba_main", "ace_main", "ace_medical_treatment"};
        author = "Blue";
        version = 1.2;
        versionStr = "1.2.4.1";
        versionAr[] = {1, 2, 4, 1};
    };
};
class Extended_PreInit_EventHandlers {
    class ACM_airway {
        init = "call compileScript ['\x\ACM\addons\airway\XEH_preInit.sqf']";
    };
};
class Extended_PostInit_EventHandlers {
    class ACM_airway {
        init = "call compileScript ['\x\ACM\addons\airway\XEH_postInit.sqf']";
    };
};
class CfgMovesBasic {
    class Default;
};
class CfgMovesMaleSdr: CfgMovesBasic {
    class States {
        class DeadState;
        class ACM_RecoveryPosition: DeadState {
            aiming = "aimingNo";
            aimingBody = "aimingUpNo";
            head = "headNo";
            speed = 100;
            file = "\x\ACM\addons\airway\anim\ACM_RecoveryPosition.rtm";
        };
    };
};
class CfgWeapons {
    class ACE_ItemCore;
    class CBA_MiscItem_ItemInfo;
    class ACM_OPA: ACE_ItemCore {
        scope = 2;
        author = "Blue";
        picture = "\x\ACM\addons\airway\ui\opa_ca.paa";
        displayName = "$STR_ACM_airway_OPA";
        descriptionShort = "$STR_ACM_airway_OPA_Desc";
        ACE_isMedicalItem = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 1;
        };
    };
    class ACM_IGel: ACM_OPA {
        picture = "\x\ACM\addons\airway\ui\igel_ca.paa";
        displayName = "$STR_ACM_airway_IGel";
        descriptionShort = "$STR_ACM_airway_IGel_Desc";
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 2;
        };
    };
    class ACM_NPA: ACM_OPA {
        picture = "\x\ACM\addons\airway\ui\npa_ca.paa";
        displayName = "$STR_ACM_airway_NPA";
        descriptionShort = "$STR_ACM_airway_NPA_Desc";
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 1.4;
        };
    };
    class ACM_SuctionBag: ACM_OPA {
        picture = "\x\ACM\addons\airway\ui\suctionbag_ca.paa";
        displayName = "$STR_ACM_airway_SuctionBag";
        descriptionShort = "$STR_ACM_airway_SuctionBag_Desc";
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 2;
        };
    };
    class ACM_ACCUVAC: ACM_SuctionBag {
        picture = "\x\ACM\addons\airway\ui\accuvac_ca.paa";
        displayName = "$STR_ACM_airway_ACCUVAC";
        descriptionShort = "$STR_ACM_airway_ACCUVAC_Desc";
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 20;
        };
    };
    class ACM_CricKit: ACM_OPA {
        picture = "\x\ACM\addons\airway\ui\crickit_ca.paa";
        displayName = "$STR_ACM_airway_CricKit";
        descriptionShort = "$STR_ACM_airway_CricKit_Desc";
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 2.5;
        };
    };
};
class ace_medical_treatment_actions {
    class CheckPulse;
    class CheckAirway: CheckPulse {
        displayName = "$STR_ACM_airway_CheckAirway";
        displayNameProgress = "$STR_ACM_airway_CheckAirway_Progress";
        icon = "";
        category = "airway";
        treatmentLocations = 0;
        medicRequired = 0;
        treatmentTime = 2.5;
        allowedSelections[] = {"Head"};
        allowSelfTreatment = 0;
        condition = "ACM_airway_enable && !(_patient call ace_common_fnc_isAwake)";
        callbackSuccess = "ACM_airway_fnc_checkAirway";
        ACM_rollToBack = 1;
    };
    class HeadTurn: CheckAirway {
        displayName = "$STR_ACM_airway_PerformHeadTurning";
        displayNameProgress = "$STR_ACM_airway_PerformHeadTurning_Progress";
        icon = "";
        medicRequired = 0;
        treatmentTime = 5;
        condition = "ACM_airway_enable && !(_patient call ace_common_fnc_isAwake) && (_patient getVariable [""ACM_airway_AirwayItem_Oral"", ''] == '')";
        callbackSuccess = "ACM_airway_fnc_performHeadTurn";
        ACM_cancelRecovery = 1;
    };
    class BeginHeadTiltChinLift: CheckAirway {
        displayName = "$STR_ACM_airway_PerformHeadTiltChinLift";
        displayNameProgress = "";
        icon = "";
        medicRequired = 0;
        treatmentTime = 0.001;
        condition = "ACM_airway_enable && !(_patient call ace_common_fnc_isAwake) && !(_patient getVariable [""ACM_airway_HeadTilt_State"", false]) && (_patient getVariable [""ACM_airway_AirwayItem_Oral"", ''] != 'SGA')";
        callbackSuccess = "[_medic, _patient] call ACM_airway_fnc_beginHeadTiltChinLift";
        ACM_rollToBack = 0;
        ACM_cancelRecovery = 1;
    };
    class RecoveryPosition: CheckAirway {
        displayName = "$STR_ACM_airway_EstablishRecoveryPosition";
        displayNameProgress = "$STR_ACM_airway_EstablishRecoveryPosition_Progress";
        icon = "";
        medicRequired = 0;
        treatmentTime = 3;
        allowedSelections[] = {"Body"};
        condition = "ACM_airway_enable && !(_patient call ace_common_fnc_isAwake) && (_patient getVariable [""ACM_airway_AirwayItem_Oral"", ''] != 'SGA') && !((_patient getVariable [""ACM_airway_RecoveryPosition_State"", false])) && (isNull objectParent _patient)";
        callbackSuccess = "[_medic, _patient, true] call ACM_airway_fnc_setRecoveryPosition";
        ACM_rollToBack = 0;
    };
    class CancelRecoveryPosition: RecoveryPosition {
        displayName = "$STR_ACM_airway_CancelRecoveryPosition";
        displayNameProgress = "$STR_ACM_airway_CancelRecoveryPosition_Progress";
        icon = "";
        medicRequired = 0;
        treatmentTime = 1;
        condition = "ACM_airway_enable && !(_patient call ace_common_fnc_isAwake) && (_patient getVariable [""ACM_airway_RecoveryPosition_State"", false])";
        callbackSuccess = "[_medic, _patient, false] call ACM_airway_fnc_setRecoveryPosition";
        ACM_rollToBack = 1;
        ACM_cancelRecovery = 1;
    };
    class UseSuctionBag: CheckAirway {
        displayName = "$STR_ACM_airway_UseSuctionBag";
        displayNameProgress = "$STR_ACM_airway_UseSuctionBag_Progress";
        icon = "";
        medicRequired = "ACM_airway_allowSuctionBag";
        treatmentTime = "[_patient] call ACM_airway_fnc_getSuctionTime";
        items[] = {"ACM_SuctionBag"};
        consumeItem = 1;
        condition = "ACM_airway_enable && !(_patient call ace_common_fnc_isAwake)";
        callbackSuccess = "[_medic, _patient, 0] call ACM_airway_fnc_handleSuction";
        ACM_cancelRecovery = 1;
        ACM_menuIcon = "ACM_SuctionBag";
    };
    class UseAccuvac: UseSuctionBag {
        displayName = "$STR_ACM_airway_UseACCUVAC";
        displayNameProgress = "$STR_ACM_airway_UseACCUVAC_Progress";
        icon = "";
        medicRequired = "ACM_airway_allowACCUVAC";
        treatmentTime = "[_patient] call ACM_airway_fnc_getSuctionTime";
        items[] = {"ACM_ACCUVAC"};
        consumeItem = 0;
        callbackSuccess = "[_medic, _patient, 1] call ACM_airway_fnc_handleSuction";
        ACM_menuIcon = "ACM_ACCUVAC";
    };
    class InsertOPA: CheckAirway {
        displayName = "$STR_ACM_airway_InsertOPA";
        displayNameProgress = "$STR_ACM_airway_InsertOPA_Progress";
        icon = "";
        medicRequired = "ACM_airway_allowOPA";
        treatmentTime = "ACM_airway_treatmentTimeOPA";
        items[] = {"ACM_OPA"};
        consumeItem = 1;
        condition = "ACM_airway_enable && !(_patient call ace_common_fnc_isAwake) && (_patient getVariable [""ACM_airway_AirwayItem_Oral"", ''] == '')";
        callbackSuccess = "[_medic, _patient, 'OPA'] call ACM_airway_fnc_insertAirwayItem";
        ACM_cancelRecovery = 1;
        ACM_menuIcon = "ACM_OPA";
    };
    class InsertNPA: InsertOPA {
        displayName = "$STR_ACM_airway_InsertNPA";
        displayNameProgress = "$STR_ACM_airway_InsertNPA_Progress";
        icon = "";
        medicRequired = "ACM_airway_allowNPA";
        treatmentTime = "ACM_airway_treatmentTimeNPA";
        items[] = {"ACM_NPA"};
        condition = "ACM_airway_enable && !(_patient call ace_common_fnc_isAwake) && (_patient getVariable [""ACM_airway_AirwayItem_Nasal"", ''] == '')";
        callbackSuccess = "[_medic, _patient, 'NPA'] call ACM_airway_fnc_insertAirwayItem";
        ACM_menuIcon = "ACM_NPA";
    };
    class InsertIGel: InsertOPA {
        displayName = "$STR_ACM_airway_InsertIGel";
        displayNameProgress = "$STR_ACM_airway_InsertIGel_Progress";
        icon = "";
        medicRequired = "ACM_airway_allowSGA";
        treatmentTime = "ACM_airway_treatmentTimeSGA";
        items[] = {"ACM_IGel"};
        callbackSuccess = "[_medic, _patient, 'SGA'] call ACM_airway_fnc_insertAirwayItem";
        ACM_menuIcon = "ACM_IGel";
    };
    class RemoveOPA: CheckAirway {
        displayName = "$STR_ACM_airway_RemoveOPA";
        displayNameProgress = "$STR_ACM_airway_RemoveOPA_Progress";
        icon = "";
        medicRequired = 0;
        treatmentTime = 1.5;
        condition = "ACM_airway_enable && (_patient getVariable [""ACM_airway_AirwayItem_Oral"", ''] == 'OPA')";
        callbackSuccess = "[_medic, _patient, false] call ACM_airway_fnc_removeAirwayItem";
    };
    class RemoveNPA: RemoveOPA {
        displayName = "$STR_ACM_airway_RemoveNPA";
        displayNameProgress = "$STR_ACM_airway_RemoveNPA_Progress";
        icon = "";
        condition = "ACM_airway_enable && (_patient getVariable [""ACM_airway_AirwayItem_Nasal"", ''] == 'NPA')";
        callbackSuccess = "[_medic, _patient, true] call ACM_airway_fnc_removeAirwayItem";
    };
    class RemoveIGel: RemoveOPA {
        displayName = "$STR_ACM_airway_RemoveIGel";
        displayNameProgress = "$STR_ACM_airway_RemoveIGel_Progress";
        icon = "";
        treatmentTime = 2;
        condition = "ACM_airway_enable && (_patient getVariable [""ACM_airway_AirwayItem_Oral"", ''] == 'SGA')";
    };
    class EstablishSurgicalAirway: CheckAirway {
        displayName = "$STR_ACM_airway_SurgicalAirway_Action";
        displayNameProgress = "";
        treatmentLocations = 0;
        medicRequired = "ACM_airway_allowSurgicalAirway";
        treatmentTime = 0.001;
        items[] = {"ACM_CricKit"};
        consumeItem = 1;
        condition = "ACM_airway_enable && [_medic, _patient] call ACM_airway_fnc_canEstablishSurgicalAirway";
        callbackSuccess = "ACM_airway_fnc_establishSurgicalAirway";
        ACM_cancelRecovery = 1;
        ACM_menuIcon = "ACM_CricKit";
    };
};
class RscText;
class RscPicture;
class RscButton;
class RscButtonMenu;
class RscControlsGroupNoScrollbars;
class RscTitles {
    class RscHeadTilt {
        idd = 85000;
        fadein = 0;
        fadeout = 0;
        duration = 100000000000;
        onLoad = "uiNamespace setVariable ['ACM_HeadTilt', (_this select 0)];";
        onUnLoad = "uiNamespace setVariable ['ACM_HeadTilt', nil];";
        class Controls {
            class TopText: RscText {
                idc = 85001;
                style = 2;
                font = "RobotoCondensed";
                x = "safeZoneX";
                y = "safeZoneY";
                w = "safeZoneW";
                h = "safeZoneH / 10";
                colorText[] = {1, 1, 1, 1};
                colorBackground[] = {0, 0, 0, 0};
                text = "$STR_ACM_airway_HeadTiltChinLift_ActionInProgress";
                lineSpacing = 0;
                sizeEx = "((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) * 1.4 * (0.55 / (getResolution select 5))";
                fixedWidth = 0;
                deletable = 0;
                fade = 0;
                access = 0;
                type = 0;
                shadow = 1;
                colorShadow[] = {0, 0, 0, 0.5};
            };
            class BottomText: TopText {
                idc = 85002;
                h = "safeZoneH / 6";
                text = "";
            };
        };
    };
};
class ACM_airway_SurgicalAirway_Dialog {
    idd = 87000;
    movingEnable = 0;
    onLoad = "";
    onUnload = "uiNamespace setVariable [""ACM_airway_SurgicalAirway_DLG"", nil]";
    objects[] = {};
    class ControlsBackground {
        class BodyBackground: RscPicture {
            idc = -1;
            x = "((20 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2)) - ((100 * (((safeZoneW / safeZoneH) min 1.2) / 40)) / 2))";
            y = "((10 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2)) - ((75 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25)) / 2))";
            w = "(100 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(75 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            type = 0;
            size = 0;
            text = "\x\ACM\addons\airway\ui\surgical_airway\body_background.paa";
        };
        class Visual_IncisionGroup: RscControlsGroupNoScrollbars {
            idc = 87026;
            x = "0";
            y = "0";
        };
        class Visual_Incision: RscPicture {
            idc = 87027;
            x = "(0 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            y = "(7.65 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
            w = "(6.3 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(4.725 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            type = 0;
            size = 0;
            text = "\x\ACM\addons\airway\ui\surgical_airway\incision_0_0.paa";
            show = 0;
        };
        class Visual_PlacedHook: RscPicture {
            idc = 87024;
            x = "(0 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            y = "(0.6 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
            w = "(25.2 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(18.9 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            type = 0;
            size = 0;
            text = "\x\ACM\addons\airway\ui\surgical_airway\placed_hook.paa";
            show = 0;
        };
        class Visual_PlacedTube: Visual_PlacedHook {
            idc = 87025;
            x = "(-5.55 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            y = "(-9.25 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
            w = "(51.2 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(38.4 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            text = "\x\ACM\addons\airway\ui\surgical_airway\placed_tube_0.paa";
        };
    };
    class Controls {
        class TopText: RscText {
            idc = -1;
            style = 2;
            font = "RobotoCondensed";
            x = "safeZoneX";
            y = "safeZoneY";
            w = "safeZoneW";
            h = "safeZoneH / 10";
            colorText[] = {1, 1, 1, 1};
            colorBackground[] = {0, 0, 0, 0};
            text = "$STR_ACM_airway_SurgicalAirway_ActionProgress";
            lineSpacing = 0;
            sizeEx = "((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) * 1.4 * (0.55 / (getResolution select 5))";
            fixedWidth = 0;
            deletable = 0;
            fade = 0;
            access = 0;
            type = 0;
            shadow = 1;
            colorShadow[] = {0, 0, 0, 0.5};
        };
        class BottomText: TopText {
            idc = 87001;
            h = "safeZoneH / 6";
            text = "";
        };
        class Space_ActionArea: RscText {
            idc = 87003;
            x = "(10 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            y = "(4 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
            w = "(20 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(14 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            colorBackground[] = {0.9, 0.9, 0.3, 0.5};
            show = 0;
        };
        class Space_Landmark_Shape: Space_ActionArea {
            idc = 87004;
            x = "(18.1 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            y = "(7.1 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
            w = "(5 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(3.9 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            colorBackground[] = {0.4, 0.1, 0.2, 1};
        };
        class Space_Landmark_Shape2: Space_Landmark_Shape {
            idc = 87005;
            x = "(18.8 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            y = "(10.8 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
            w = "(3.5 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(7 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            colorBackground[] = {0.3, 0, 0.1, 1};
        };
        class Space_Landmark_Upper: Space_ActionArea {
            idc = 87006;
            x = "(17.8 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            y = "(7.7 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
            w = "(5.5 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(2 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            colorBackground[] = {0.7, 0.1, 0.1, 1};
        };
        class Space_Landmark_UpperMiddle: Space_Landmark_Upper {
            idc = 87007;
            x = "(20.35 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            y = "(7.4 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
            w = "(0.5 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(2.3 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            colorBackground[] = {0.8, 0.7, 0.7, 1};
        };
        class Space_Landmark_Lower: Space_Landmark_Upper {
            idc = 87008;
            x = "(18.5 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            y = "(10.2 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
            w = "(4.2 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(1.4 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
        };
        class Space_Landmark_EntryArea: Space_Landmark_Upper {
            idc = 87010;
            x = "(18.4 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            y = "(9.5 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
            w = "(4.4 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(1 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            colorBackground[] = {0.7, 0.5, 0.5, 1};
        };
        class Space_Landmark_Entry: Space_Landmark_Upper {
            idc = 87009;
            x = "(19.5 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            y = "(9.7 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
            w = "(2.2 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(0.7 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            colorBackground[] = {0.6, 0, 0, 1};
        };
        class Space_Incision_Vertical: RscText {
            idc = 87012;
            x = "(20.35 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            y = "(9.1 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
            w = "(0.5 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(1.9 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            colorBackground[] = {0.6, 0.6, 0, 1};
            show = 0;
        };
        class Space_Incision_Horizontal: Space_Incision_Vertical {
            idc = 87013;
            x = "(20 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            y = "(9.7 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
            w = "(1.2 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(0.7 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            colorBackground[] = {0.9, 0.7, 0.3, 1};
        };
        class Space_CricEntry: Space_Incision_Vertical {
            idc = 87014;
            x = "(19.6 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            y = "(9 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
            w = "(2 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(2 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            colorBackground[] = {0.8, 0.8, 0.2, 1};
        };
        class Space_Incision: RscText {
            idc = 87011;
            x = "0";
            y = "0";
            w = "(0.1 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(0.1 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            colorBackground[] = {1, 0.6, 0.6, 0.5};
            show = 0;
        };
        class Inventory_Scalpel_ImageBG: RscText {
            idc = -1;
            x = "(1.285 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55)) / 2))";
            y = "(0.26 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3)) / 2))";
            w = "(0.115 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55))";
            h = "(0.115 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3))";
            colorBackground[] = {0, 0, 0, 0.7};
        };
        class Inventory_Hook_ImageBG: Inventory_Scalpel_ImageBG {
            y = "(0.39 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3)) / 2))";
        };
        class Inventory_Tube_ImageBG: Inventory_Scalpel_ImageBG {
            y = "(0.52 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3)) / 2))";
        };
        class Inventory_Syringe_ImageBG: Inventory_Scalpel_ImageBG {
            y = "(0.65 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3)) / 2))";
        };
        class Inventory_Strap_ImageBG: Inventory_Scalpel_ImageBG {
            y = "(0.78 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3)) / 2))";
        };
        class Inventory_Scalpel_Image: RscPicture {
            idc = 87029;
            x = "(1.285 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55)) / 2))";
            y = "(0.26 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3)) / 2))";
            w = "(0.115 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55))";
            h = "(0.115 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3))";
            type = 0;
            size = 0;
            text = "\x\ACM\addons\airway\ui\surgical_airway\inv_scalpel.paa";
        };
        class Inventory_Hook_Image: Inventory_Scalpel_Image {
            idc = 87031;
            y = "(0.39 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3)) / 2))";
            text = "\x\ACM\addons\airway\ui\surgical_airway\inv_hook.paa";
        };
        class Inventory_Tube_Image: Inventory_Scalpel_Image {
            idc = 87033;
            y = "(0.52 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3)) / 2))";
            text = "\x\ACM\addons\airway\ui\surgical_airway\inv_tube.paa";
        };
        class Inventory_Syringe_Image: Inventory_Scalpel_Image {
            idc = 87035;
            y = "(0.65 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3)) / 2))";
            text = "\x\ACM\addons\airway\ui\surgical_airway\inv_syringe.paa";
        };
        class Inventory_Strap_Image: Inventory_Scalpel_Image {
            idc = 87037;
            y = "(0.78 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3)) / 2))";
            text = "\x\ACM\addons\airway\ui\surgical_airway\inv_strap.paa";
        };
        class Inventory_Scalpel: RscButton {
            idc = 87028;
            x = "(1.285 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55)) / 2))";
            y = "(0.26 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3)) / 2))";
            w = "(0.115 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55))";
            h = "(0.115 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3))";
            colorText[] = {0, 0, 0, 0};
            colorDisabled[] = {0, 0, 0, 0};
            colorBackground[] = {0, 0, 0, 0};
            colorBackgroundDisabled[] = {0, 0, 0, 0};
            colorBackgroundActive[] = {0, 0, 0, 0};
            colorFocused[] = {0, 0, 0, 0};
            colorBorder[] = {0, 0, 0, 0};
            soundEnter[] = {};
            soundPush[] = {};
            soundEscape[] = {};
            style = 0;
            shadow = 0;
            font = "RobotoCondensed";
            sizeEx = "0";
            onButtonClick = "[0] call ACM_airway_fnc_SurgicalAirway_select";
            tooltip = "$STR_ACM_airway_SurgicalAirway_Scalpel";
            text = "";
        };
        class Inventory_Hook: Inventory_Scalpel {
            idc = 87030;
            y = "(0.39 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3)) / 2))";
            tooltip = "$STR_ACM_airway_SurgicalAirway_Hook";
            onButtonClick = "[1] call ACM_airway_fnc_SurgicalAirway_select";
        };
        class Inventory_Tube: Inventory_Scalpel {
            idc = 87032;
            y = "(0.52 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3)) / 2))";
            tooltip = "$STR_ACM_airway_SurgicalAirway_Tube";
            onButtonClick = "[2] call ACM_airway_fnc_SurgicalAirway_select";
        };
        class Inventory_Syringe: Inventory_Scalpel {
            idc = 87034;
            y = "(0.65 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3)) / 2))";
            tooltip = "$STR_ACM_airway_SurgicalAirway_Syringe";
            onButtonClick = "[3] call ACM_airway_fnc_SurgicalAirway_select";
        };
        class Inventory_Strap: Inventory_Scalpel {
            idc = 87036;
            y = "(0.78 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3)) / 2))";
            tooltip = "$STR_ACM_airway_SurgicalAirway_Strap";
            onButtonClick = "[4] call ACM_airway_fnc_SurgicalAirway_select";
        };
        class Feedback_Palpate: RscPicture {
            idc = 87002;
            x = "0";
            y = "0";
            w = "(0.6 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(0.6 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            type = 0;
            size = 0;
            text = "\x\ACM\addons\airway\ui\surgical_airway\feedback_marker.paa";
            colorText[] = {1, 0, 0, 0.7};
            show = 0;
        };
        class Visual_ActiveItem: RscPicture {
            idc = 87023;
            x = "(0 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            y = "(0 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
            w = "(25 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(25 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            type = 0;
            size = 0;
            text = "";
            show = 0;
        };
        class Action_LiftIncision: RscButton {
            idc = 87016;
            x = "(19.6 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            y = "(9 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
            w = "(2 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(2 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            colorText[] = {0, 0, 0, 0};
            colorDisabled[] = {0, 0, 0, 0};
            colorBackground[] = {0, 0, 0, 0};
            colorBackgroundDisabled[] = {0, 0, 0, 0};
            colorBackgroundActive[] = {0, 0, 0, 0};
            colorFocused[] = {0, 0, 0, 0};
            colorBorder[] = {0, 0, 0, 0};
            soundClick[] = {};
            soundEnter[] = {};
            soundPush[] = {};
            soundEscape[] = {};
            style = 0;
            shadow = 0;
            sizeEx = "0";
            onButtonClick = "[1] call ACM_airway_fnc_SurgicalAirway_action";
            tooltip = "$STR_ACM_airway_SurgicalAirway_LiftIncision";
            text = "";
            show = 0;
        };
        class Action_RemoveHook: Action_LiftIncision {
            idc = 87017;
            x = "(20.2 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            y = "(10 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
            w = "(5.5 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(8.5 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            onButtonClick = "[3] call ACM_airway_fnc_SurgicalAirway_action";
            tooltip = "$STR_ACM_airway_SurgicalAirway_RemoveHook";
        };
        class Action_InsertTube: Action_LiftIncision {
            idc = 87018;
            onButtonClick = "[2] call ACM_airway_fnc_SurgicalAirway_action";
            tooltip = "$STR_ACM_airway_SurgicalAirway_InsertTube";
        };
        class Action_InflateCuff: Action_LiftIncision {
            idc = 87019;
            x = "(3.5 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            y = "(17.6 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
            w = "(6 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(2 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            onButtonClick = "[4] call ACM_airway_fnc_SurgicalAirway_action";
            tooltip = "$STR_ACM_airway_SurgicalAirway_InflateTubeCuff";
        };
        class Action_RemoveStylet: Action_LiftIncision {
            idc = 87020;
            x = "(18.6 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            y = "(8.8 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
            w = "(3 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(3 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            onButtonClick = "[5] call ACM_airway_fnc_SurgicalAirway_action";
            tooltip = "$STR_ACM_airway_SurgicalAirway_RemoveTubeStylet";
        };
        class Action_ConnectStrap: Action_LiftIncision {
            idc = 87021;
            x = "(12.7 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            y = "(9 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
            w = "(5.4 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(2.5 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            onButtonClick = "[6] call ACM_airway_fnc_SurgicalAirway_action";
            tooltip = "$STR_ACM_airway_SurgicalAirway_ConnectStrap";
        };
        class Action_SecureStrap: Action_ConnectStrap {
            idc = 87022;
            x = "(22 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            onButtonClick = "[7] call ACM_airway_fnc_SurgicalAirway_action";
            tooltip = "$STR_ACM_airway_SurgicalAirway_SecureStrap";
        };
    };
};
class ACM_SurgicalAirway_VisualIncision: RscPicture {
    idc = -1;
    x = "(0 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
    y = "(0 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
    w = "(6.3 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
    h = "(4.725 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
    type = 0;
    size = 0;
    text = "\x\ACM\addons\airway\ui\surgical_airway\incision_vertical.paa";
    show = 1;
};

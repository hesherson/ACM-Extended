class CfgPatches {
    class ACM_itemtext {
        acmeBuildBatch = "B214";
        acmeNetworkProtocol = 1;
        acmeComponent = "itemtext";
        version = "1.2.4.1";
        name = "ACM Extended Late Config Patches";
        units[] = {};
        weapons[] = {};
        requiredVersion = 2.18;
        requiredAddons[] = {"ACM_Extended"};
        author = "mavis";
    };
};
class ace_medical_treatment_actions {
    class ACME_DirectPressure {
        animationMedic = "";
        animationMedicProne = "";
        animationMedicSelf = "";
        animationMedicSelfProne = "";
    };
};

class CfgPatches {
    class ACM_zeus {
        acmeBuildBatch = "B215";
        acmeNetworkProtocol = 1;
        acmeComponent = "zeus";
        name = "ACM - Zeus";
        units[] = {
            "ACM_zeus_forceWakeUp",
            "ACM_zeus_inflictCardiacArrest",
            "ACM_zeus_inflictChestInjury",
            "ACM_zeus_setBloodVolume",
            "ACM_zeus_unCardiacArrest",
            "ACM_zeus_givePain",
            "ACM_zeus_setOxygen",
            "ACM_zeus_setBloodType",
            "ACM_zeus_togglePlotArmor",
            "ACM_zeus_assignFullHealFacility"
        };
        weapons[] = {};
        requiredVersion = 2.18;
        requiredAddons[] = {
            "cba_main",
            "ace_main",
            "ace_medical_treatment",
            "ACM_main"
        };
        author = "Blue";
        version = 1.2;
        versionStr = "1.2.4.1";
        versionAr[] = {1, 2, 4, 1};
    };
};
class Extended_PreStart_EventHandlers {
    class ACM_zeus {
        init = "call compileScript ['\x\ACM\addons\zeus\XEH_preStart.sqf']";
    };
};
class Extended_PreInit_EventHandlers {
    class ACM_zeus {
        init = "call compileScript ['\x\ACM\addons\zeus\XEH_preInit.sqf']";
    };
};
class Extended_PostInit_EventHandlers {
    class ACM_zeus {
        init = "call compileScript ['\x\ACM\addons\zeus\XEH_postInit.sqf']";
    };
};
class CfgFactionClasses {
    class ACM_zeus_Modules {
        displayName = "ACM Modules";
        priority = 3;
        side = 7;
    };
};
class CfgVehicles {
    class Module_F;
    class ACM_zeus_moduleBase: Module_F {
        curatorCanAttach = 1;
        category = "ACM_zeus_Modules";
        displayName = "Module";
        icon = "\z\ace\addons\zeus\ui\Icon_Module_Zeus_Heal_ca.paa";
        functionPriority = 1;
        isGlobal = 1;
        isTriggerActivated = 0;
        scope = 1;
        scopeCurator = 2;
    };
    class ACM_zeus_unCardiacArrest: ACM_zeus_moduleBase {
        displayName = "$STR_ACM_zeus_Module_UnCardiacArrest";
        function = "ACM_zeus_fnc_unCardiacArrest";
    };
    class ACM_zeus_forceWakeUp: ACM_zeus_moduleBase {
        displayName = "$STR_ACM_zeus_Module_ForceWakeUp";
        function = "ACM_zeus_fnc_forceWakeUp";
        icon = "\z\ace\addons\zeus\ui\Icon_Module_Zeus_Heal_ca.paa";
    };
    class ACM_zeus_setBloodVolume: ACM_zeus_moduleBase {
        displayName = "$STR_ACM_zeus_Module_SetBloodVolume";
        icon = "\x\ACM\addons\zeus\ui\Icon_Module_BloodVolume_ca.paa";
        curatorInfoType = "ACM_zeus_RscSetBloodVolume";
    };
    class ACM_zeus_inflictCardiacArrest: ACM_zeus_moduleBase {
        displayName = "$STR_ACM_zeus_Module_InflictCardiacArrest";
        icon = "\x\ACM\addons\zeus\ui\Icon_Module_CardiacArrest_ca.paa";
        curatorInfoType = "ACM_zeus_RscInflictCardiacArrest";
    };
    class ACM_zeus_inflictChestInjury: ACM_zeus_moduleBase {
        displayName = "$STR_ACM_zeus_Module_InflictChestInjury";
        icon = "\x\ACM\addons\zeus\ui\Icon_Module_ChestInjury_ca.paa";
        curatorInfoType = "ACM_zeus_RscInflictChestInjury";
    };
    class ACM_zeus_givePain: ACM_zeus_moduleBase {
        displayName = "$STR_ACM_zeus_Module_GivePain";
        icon = "\x\ACM\addons\zeus\ui\Icon_Module_GivePain_ca.paa";
        curatorInfoType = "ACM_zeus_RscGivePain";
    };
    class ACM_zeus_setOxygen: ACM_zeus_moduleBase {
        displayName = "$STR_ACM_zeus_Module_SetOxygen";
        icon = "\x\ACM\addons\zeus\ui\Icon_Module_SetOxygen_ca.paa";
        curatorInfoType = "ACM_zeus_RscSetOxygen";
    };
    class ACM_zeus_setBloodType: ACM_zeus_moduleBase {
        displayName = "$STR_ACM_zeus_Module_SetBloodType";
        icon = "\x\ACM\addons\zeus\ui\Icon_Module_SetBloodType_ca.paa";
        curatorInfoType = "ACM_zeus_RscSetBloodType";
    };
    class ACM_zeus_togglePlotArmor: ACM_zeus_moduleBase {
        displayName = "$STR_ACM_zeus_Module_PlotArmor";
        function = "ACM_zeus_fnc_togglePlotArmor";
        icon = "\x\ACM\addons\zeus\ui\Icon_Module_PlotArmor_ca.paa";
    };
    class ACM_zeus_assignFullHealFacility: ACM_zeus_moduleBase {
        displayName = "$STR_ACM_zeus_Module_AssignFullHealFacility";
        function = "ACM_zeus_fnc_assignFullHealFacility";
        icon = "\x\ACM\addons\mission\ui\Icon_Module_FullHealFacility_ca.paa";
    };
};
class RscControlsGroup;
class RscControlsGroupNoScrollbars;
class RscText;
class RscListBox;
class RscCombo;
class RscEdit;
class RscXSliderH;
class RscCheckBox;
class RscActivePicture;
class RscMapControl;
class RscPicture;
class ctrlToolbox;
class RscButton;
class RscDisplayAttributes {
    class Controls {
        class Background;
        class Title;
        class Content: RscControlsGroup {
            class Controls;
        };
        class ButtonOK;
        class ButtonCancel;
    };
};
class ACM_zeus_RscSetBloodVolume: RscDisplayAttributes {
    onLoad = "['onLoad', _this, ""ACM_zeus_RscSetBloodVolume""] call ace_zeus_fnc_zeusAttributes";
    onUnload = "['onUnload', _this, ""ACM_zeus_RscSetBloodVolume""] call ace_zeus_fnc_zeusAttributes";
    class Controls: Controls {
        class Background: Background {};
        class Title: Title {};
        class Content: Content {
            class Controls {
                class SetBloodVolumeTab: RscControlsGroupNoScrollbars {
                    onSetFocus = "_this call ACM_zeus_fnc_setBloodVolume";
                    idc = 90000;
                    x = 0;
                    y = 0;
                    w = "(26 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                    h = "(3.5 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                    class Controls {
                        class Title_BloodVolume: RscText {
                            idc = -1;
                            text = "$STR_ACM_zeus_Module_SetBloodVolume_BloodVolume";
                            x = 0;
                            y = 0;
                            w = "(10 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            h = "(1 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            colorBackground[] = {0, 0, 0, 0.5};
                        };
                        class Slider_BloodVolume: RscXSliderH {
                            idc = 90001;
                            x = "(10.1 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            y = 0;
                            w = "(15.9 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            h = "(1 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            sliderStep = 0.1;
                            sliderRange[] = {0, 6};
                            sliderPosition = 6;
                        };
                        class Title_PlasmaVolume: Title_BloodVolume {
                            text = "$STR_ACM_zeus_Module_SetBloodVolume_PlasmaVolume";
                            y = "(1.1 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                        };
                        class Slider_PlasmaVolume: Slider_BloodVolume {
                            idc = 90002;
                            y = "(1.1 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            sliderPosition = 0;
                        };
                        class Title_SalineVolume: Title_BloodVolume {
                            text = "$STR_ACM_zeus_Module_SetBloodVolume_SalineVolume";
                            y = "(2.2 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                        };
                        class Slider_SalineVolume: Slider_BloodVolume {
                            idc = 90003;
                            y = "(2.2 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            sliderPosition = 0;
                        };
                    };
                };
            };
        };
        class ButtonOK: ButtonOK {};
        class ButtonCancel: ButtonCancel {};
    };
};
class ACM_zeus_RscInflictCardiacArrest: RscDisplayAttributes {
    onLoad = "['onLoad', _this, ""ACM_zeus_RscInflictCardiacArrest""] call ace_zeus_fnc_zeusAttributes";
    onUnload = "['onUnload', _this, ""ACM_zeus_RscInflictCardiacArrest""] call ace_zeus_fnc_zeusAttributes";
    class Controls: Controls {
        class Background: Background {};
        class Title: Title {};
        class Content: Content {
            class Controls {
                class InflictCardiacArrestTab: RscControlsGroupNoScrollbars {
                    onSetFocus = "_this call ACM_zeus_fnc_inflictCardiacArrest";
                    idc = 90004;
                    x = 0;
                    y = 0;
                    w = "(26 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                    h = "(3 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                    class Controls {
                        class Title_TargetRhythm: RscText {
                            idc = -1;
                            text = "$STR_ACM_zeus_Module_InflictCardiacArrest_TargetRhythm";
                            x = 0;
                            y = 0;
                            w = "(10 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            h = "(3 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            colorBackground[] = {0, 0, 0, 0.5};
                        };
                        class List_TargetRhythm: ctrlToolbox {
                            idc = 90005;
                            x = "(10.1 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            y = 0;
                            w = "(15.9 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            h = "(3 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            rows = 2;
                            columns = 2;
                            strings[] = {
                                "$STR_ACM_zeus_Module_InflictCardiacArrest_TargetRhythm_Sinus",
                                "$STR_ACM_zeus_Module_InflictCardiacArrest_TargetRhythm_Asystole",
                                "$STR_ACM_zeus_Module_InflictCardiacArrest_TargetRhythm_VF",
                                "$STR_ACM_zeus_Module_InflictCardiacArrest_TargetRhythm_PVT",
                                "$STR_ACM_zeus_Module_InflictCardiacArrest_TargetRhythm_Random"
                            };
                        };
                    };
                };
            };
        };
        class ButtonOK: ButtonOK {};
        class ButtonCancel: ButtonCancel {};
    };
};
class ACM_zeus_RscInflictChestInjury: RscDisplayAttributes {
    onLoad = "['onLoad', _this, ""ACM_zeus_RscInflictChestInjury""] call ace_zeus_fnc_zeusAttributes";
    onUnload = "['onUnload', _this, ""ACM_zeus_RscInflictChestInjury""] call ace_zeus_fnc_zeusAttributes";
    class Controls: Controls {
        class Background: Background {};
        class Title: Title {};
        class Content: Content {
            class Controls {
                class InflictChestInjuryTab: RscControlsGroupNoScrollbars {
                    onSetFocus = "_this call ACM_zeus_fnc_inflictChestInjury";
                    idc = 90006;
                    x = 0;
                    y = 0;
                    w = "(26 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                    h = "(3 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                    class Controls {
                        class Title_InjuryType: RscText {
                            idc = -1;
                            text = "$STR_ACM_zeus_Module_InflictChestInjury_InjuryType";
                            x = 0;
                            y = 0;
                            w = "(10 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            h = "(3 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            colorBackground[] = {0, 0, 0, 0.5};
                        };
                        class List_InjuryType: ctrlToolbox {
                            idc = 90007;
                            x = "(10.1 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            y = 0;
                            w = "(15.9 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            h = "(3 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            rows = 2;
                            columns = 2;
                            strings[] = {
                                "$STR_ACM_zeus_Module_InflictChestInjury_Pneumothorax",
                                "$STR_ACM_zeus_Module_InflictChestInjury_TensionPneumothorax",
                                "$STR_ACM_zeus_Module_InflictChestInjury_Hemothorax",
                                "$STR_ACM_zeus_Module_InflictChestInjury_TensionHemothorax"
                            };
                        };
                    };
                };
            };
        };
        class ButtonOK: ButtonOK {};
        class ButtonCancel: ButtonCancel {};
    };
};
class ACM_zeus_RscGivePain: RscDisplayAttributes {
    onLoad = "['onLoad', _this, ""ACM_zeus_RscGivePain""] call ace_zeus_fnc_zeusAttributes";
    onUnload = "['onUnload', _this, ""ACM_zeus_RscGivePain""] call ace_zeus_fnc_zeusAttributes";
    class Controls: Controls {
        class Background: Background {};
        class Title: Title {};
        class Content: Content {
            class Controls {
                class GivePainTab: RscControlsGroupNoScrollbars {
                    onSetFocus = "_this call ACM_zeus_fnc_givePain";
                    idc = 90008;
                    x = 0;
                    y = 0;
                    w = "(26 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                    h = "(1.1 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                    class Controls {
                        class Title_PainAmount: RscText {
                            idc = -1;
                            text = "$STR_ACM_zeus_Module_GivePain_PainAmount";
                            x = 0;
                            y = 0;
                            w = "(10 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            h = "(1 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            colorBackground[] = {0, 0, 0, 0.5};
                        };
                        class Slider_PainAmount: RscXSliderH {
                            idc = 90009;
                            x = "(10.1 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            y = 0;
                            w = "(15.9 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            h = "(1 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            sliderStep = 0.01;
                            sliderRange[] = {0, 1};
                            sliderPosition = 0;
                        };
                    };
                };
            };
        };
        class ButtonOK: ButtonOK {};
        class ButtonCancel: ButtonCancel {};
    };
};
class ACM_zeus_RscSetOxygen: RscDisplayAttributes {
    onLoad = "['onLoad', _this, ""ACM_zeus_RscSetOxygen""] call ace_zeus_fnc_zeusAttributes";
    onUnload = "['onUnload', _this, ""ACM_zeus_RscSetOxygen""] call ace_zeus_fnc_zeusAttributes";
    class Controls: Controls {
        class Background: Background {};
        class Title: Title {};
        class Content: Content {
            class Controls {
                class SetOxygenTab: RscControlsGroupNoScrollbars {
                    onSetFocus = "_this call ACM_zeus_fnc_setOxygen";
                    idc = 90010;
                    x = 0;
                    y = 0;
                    w = "(26 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                    h = "(1.1 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                    class Controls {
                        class Title_SetOxygen: RscText {
                            idc = -1;
                            text = "$STR_ACM_zeus_Module_SetOxygen_OxygenLevel";
                            x = 0;
                            y = 0;
                            w = "(10 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            h = "(1 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            colorBackground[] = {0, 0, 0, 0.5};
                        };
                        class Slider_OxygenSaturation: RscXSliderH {
                            idc = 90011;
                            x = "(10.1 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            y = 0;
                            w = "(15.9 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            h = "(1 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            sliderStep = 0.01;
                            sliderRange[] = {0, 100};
                            sliderPosition = 0;
                        };
                    };
                };
            };
        };
        class ButtonOK: ButtonOK {};
        class ButtonCancel: ButtonCancel {};
    };
};
class ACM_zeus_RscSetBloodType: RscDisplayAttributes {
    onLoad = "['onLoad', _this, ""ACM_zeus_RscSetBloodType""] call ace_zeus_fnc_zeusAttributes";
    onUnload = "['onUnload', _this, ""ACM_zeus_RscSetBloodType""] call ace_zeus_fnc_zeusAttributes";
    class Controls: Controls {
        class Background: Background {};
        class Title: Title {};
        class Content: Content {
            class Controls {
                class SetBloodTypeTab: RscControlsGroupNoScrollbars {
                    onSetFocus = "_this call ACM_zeus_fnc_setBloodType";
                    idc = 90012;
                    x = 0;
                    y = 0;
                    w = "(26 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                    h = "(5 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                    class Controls {
                        class Title_SetBloodType: RscText {
                            idc = -1;
                            text = "$STR_ACM_zeus_Module_SetBloodType";
                            x = 0;
                            y = 0;
                            w = "(10 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            h = "(5 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            colorBackground[] = {0, 0, 0, 0.5};
                        };
                        class List_BloodType: ctrlToolbox {
                            idc = 90013;
                            x = "(10.1 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            y = 0;
                            w = "(15.9 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            h = "(5 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            rows = 4;
                            columns = 2;
                            strings[] = {"O+", "O-", "A+", "A-", "B+", "B-", "AB+", "AB-"};
                        };
                    };
                };
            };
        };
        class ButtonOK: ButtonOK {};
        class ButtonCancel: ButtonCancel {};
    };
};

class CfgPatches {
    class ACM_evacuation {
        acmeBuildBatch = "B215";
        acmeNetworkProtocol = 1;
        acmeComponent = "evacuation";
        name = "ACM - Evacuation";
        units[] = {"ACM_evacuation_EvacuationPoint", "ACM_evacuation_ReinforcePoint"};
        weapons[] = {};
        requiredVersion = 2.18;
        requiredAddons[] = {"cba_main", "ace_main", "ace_medical_treatment"};
        author = "Blue";
        version = 1.2;
        versionStr = "1.2.4.1";
        versionAr[] = {1, 2, 4, 1};
    };
};
class Extended_PreInit_EventHandlers {
    class ACM_evacuation {
        init = "call compileScript ['\x\ACM\addons\evacuation\XEH_preInit.sqf']";
    };
};
class Extended_PostInit_EventHandlers {
    class ACM_evacuation {
        init = "call compileScript ['\x\ACM\addons\evacuation\XEH_postInit.sqf']";
    };
};
class Extended_Respawn_EventHandlers {
    class CAManBase {
        class ACM_evacuation {
            respawn = "_this call ACM_evacuation_fnc_onRespawn";
        };
    };
};
class Extended_Init_EventHandlers {
    class CAManBase {
        class ACM_evacuation {
            init = "[(_this select 0)] call ACM_evacuation_fnc_initUnit";
            exclude[] = {"B_UAV_AI", "O_UAV_AI", "UAV_AI_base_F"};
        };
    };
};
class CfgVehicles {
    class Logic;
    class Module_F: Logic {
        class AttributesBase {
            class Default;
            class Combo;
            class Edit;
            class Checkbox;
            class ModuleDescription;
        };
    };
    class ACM_evacuation_EvacuationPoint: Module_F {
        scope = 2;
        displayName = "$STR_ACM_evacuation_Module_EvacuationPoint";
        icon = "\x\ACM\addons\evacuation\ui\Icon_Evacuation_ca.paa";
        portrait = "\x\ACM\addons\evacuation\ui\Icon_Evacuation_ca.paa";
        category = "ACM_evacuation_Category_Evacuation";
        function = "ACM_evacuation_fnc_moduleCreateEvacuationPoint";
        functionPriority = 1;
        isGlobal = 1;
        isTriggerActivated = 0;
        author = "Blue";
        class Attributes: AttributesBase {
            class Side: Combo {
                property = "ACM_evacuation_Eden_EvacuationPoint_Side";
                displayName = "$STR_ACM_evacuation_Module_PlayerFaction";
                typeName = "NUMBER";
                defaultValue = 0;
                class values {
                    class Side_BLUFOR {
                        name = "BLUFOR";
                        value = 0;
                    };
                    class Side_REDFOR {
                        name = "REDFOR";
                        value = 1;
                    };
                    class Side_GREENFOR {
                        name = "GREENFOR";
                        value = 2;
                    };
                };
            };
            class InteractionDistance: Edit {
                property = "ACM_evacuation_Eden_EvacuationPoint_InteractionDistance";
                displayName = "$STR_ACM_core_Common_Module_InteractionDistance";
                typeName = "NUMBER";
                defaultValue = 5;
            };
            class InteractionPosition: Edit {
                property = "ACM_evacuation_Eden_EvacuationPoint_InteractionPosition";
                displayName = "$STR_ACM_core_Common_Module_InteractionPosition";
                tooltip = "$STR_ACM_core_Common_Module_InteractionPosition_Tooltip";
                typeName = "STRING";
                defaultValue = "[0,0,0]";
            };
        };
    };
    class ACM_evacuation_ReinforcePoint: Module_F {
        scope = 2;
        displayName = "$STR_ACM_evacuation_Module_ReinforcePoint";
        icon = "\x\ACM\addons\evacuation\ui\Icon_Evacuation_ca.paa";
        portrait = "\x\ACM\addons\evacuation\ui\Icon_Evacuation_ca.paa";
        category = "ACM_evacuation_Category_Evacuation";
        function = "ACM_evacuation_fnc_moduleCreateReinforcePoint";
        functionPriority = 1;
        isGlobal = 1;
        isTriggerActivated = 0;
        author = "Blue";
        class Attributes: AttributesBase {
            class Side: Combo {
                property = "ACM_evacuation_Eden_ReinforcePoint_Side";
                displayName = "$STR_ACM_evacuation_Module_PlayerFaction";
                typeName = "NUMBER";
                defaultValue = 0;
                class values {
                    class Side_BLUFOR {
                        name = "BLUFOR";
                        value = 0;
                    };
                    class Side_REDFOR {
                        name = "REDFOR";
                        value = 1;
                    };
                    class Side_GREENFOR {
                        name = "GREENFOR";
                        value = 2;
                    };
                };
            };
        };
    };
    class Man;
    class CAManBase: Man {
        class ACE_Actions {
            class ACE_MainActions {
                class ACM_ConvertCasualty {
                    displayName = "$STR_ACM_evacuation_ConvertCasualty";
                    icon = "";
                    condition = "[_player, _target] call ACM_evacuation_fnc_canConvert";
                    statement = "[_player, _target] call ACM_evacuation_fnc_convertCasualtyAction";
                    exceptions[] = {"isNotInside"};
                    showDisabled = 0;
                };
            };
        };
    };
};
class CfgFactionClasses {
    class ACM_evacuation_Category_Evacuation {
        displayName = "ACM Evacuation";
        priority = 2;
        side = 7;
    };
};

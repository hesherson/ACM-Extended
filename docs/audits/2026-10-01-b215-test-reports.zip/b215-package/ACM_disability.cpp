class CfgPatches {
    class ACM_disability {
        acmeBuildBatch = "B215";
        acmeNetworkProtocol = 1;
        acmeComponent = "disability";
        name = "ACM - Disability";
        units[] = {};
        weapons[] = {"ACM_SAMSplint"};
        requiredVersion = 2.18;
        requiredAddons[] = {"cba_main", "ace_main", "ace_medical_treatment"};
        author = "Blue";
        version = 1.2;
        versionStr = "1.2.4.1";
        versionAr[] = {1, 2, 4, 1};
    };
};
class Extended_PreInit_EventHandlers {
    class ACM_disability {
        init = "call compileScript ['\x\ACM\addons\disability\XEH_preInit.sqf']";
    };
};
class Extended_PostInit_EventHandlers {
    class ACM_disability {
        init = "call compileScript ['\x\ACM\addons\disability\XEH_postInit.sqf']";
    };
};
class CfgWeapons {
    class ACE_ItemCore;
    class CBA_MiscItem_ItemInfo;
    class ACE_splint: ACE_ItemCore {
        displayName = "$STR_ACM_disability_UniversalSplint";
        descriptionShort = "$STR_ACM_disability_UniversalSplint_Desc";
        scope = 1;
    };
    class ACM_SAMSplint: ACE_splint {
        scope = 2;
        author = "Blue";
        picture = "\x\ACM\addons\disability\ui\samsplint.paa";
        displayName = "$STR_ACM_disability_SAMSplint";
        descriptionShort = "$STR_ACM_disability_SAMSplint_Desc";
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 0.5;
        };
    };
};

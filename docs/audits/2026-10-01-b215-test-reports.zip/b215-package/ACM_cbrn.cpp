class CfgPatches {
    class ACM_cbrn {
        acmeBuildBatch = "B215";
        acmeNetworkProtocol = 1;
        acmeComponent = "cbrn";
        name = "ACM - CBRN";
        units[] = {
            "ACM_HazardObject",
            "ACM_cbrn_moduleCreateHazardZone",
            "ACM_cbrn_moduleCreateChemicalDevice",
            "ACM_cbrn_Eden_HazardZone",
            "ACM_cbrn_Eden_ChemicalDevice"
        };
        weapons[] = {"ACM_GasMaskFilter", "ACM_Autoinjector_ATNA", "ACM_Autoinjector_Midazolam"};
        magazines[] = {"ACM_Mortar_Shell_8Rnd_CS", "ACM_Mortar_Shell_8Rnd_Chlorine"};
        requiredVersion = 2.18;
        requiredAddons[] = {
            "cba_main",
            "ace_main",
            "ace_medical_treatment",
            "ACM_main"
        };
        author = "Blue";
        version = 1.2;
        versionStr = "1.2.4.1";
        versionAr[] = {1, 2, 4, 1};
    };
};
class CfgSounds {
    class ACM_CBRN_Cough_1 {
        name = "ACM_CBRN_Cough_1";
        sound[] = {"x\ACM\addons\cbrn\sound\cough1.wav", "db+16", 1};
        titles[] = {};
    };
    class ACM_CBRN_Cough_2: ACM_CBRN_Cough_1 {
        name = "ACM_CBRN_Cough_2";
        sound[] = {"x\ACM\addons\cbrn\sound\cough2.wav", "db+16", 1};
    };
    class ACM_CBRN_Cough_3: ACM_CBRN_Cough_1 {
        name = "ACM_CBRN_Cough_3";
        sound[] = {"x\ACM\addons\cbrn\sound\cough3.wav", "db+16", 1};
    };
    class ACM_CBRN_Cough_4: ACM_CBRN_Cough_1 {
        name = "ACM_CBRN_Cough_4";
        sound[] = {"x\ACM\addons\cbrn\sound\cough3.wav", "db+16", 1};
    };
    class ACM_CBRN_Inhale_1: ACM_CBRN_Cough_1 {
        name = "ACM_CBRN_Inhale_1";
        sound[] = {"x\ACM\addons\cbrn\sound\inhale1.wav", "db+16", 1};
    };
    class ACM_CBRN_Inhale_2: ACM_CBRN_Cough_1 {
        name = "ACM_CBRN_Inhale_2";
        sound[] = {"x\ACM\addons\cbrn\sound\inhale2.wav", "db+16", 1};
    };
};
class CfgCloudlets {
    class BombSmk2;
    class ACM_ChemicalDevice_Chlorine: BombSmk2 {
        lifeTime = 30;
        circleRadius = 1;
        particleFSNtieth = 16;
        particleFSIndex = 12;
        particleFSFrameCount = 8;
        particleFSLoop = 0;
        weight = 1.4;
        rubbing = 1.1;
        size[] = {3, 5};
        color[] = {
            {0.6, 0.63, 0, 0.4},
            {0.6, 0.63, 0, 0.22},
            {0.5, 0.53, 0, 0.09},
            {0.5, 0.53, 0, 0.01}
        };
        animationSpeed[] = {1, 0.5, 0.25, 0.25};
        colorVar[] = {0, 0, 0, 0};
    };
    class ACM_ChemicalDevice_Chlorine_Small: ACM_ChemicalDevice_Chlorine {
        lifeTime = 20;
        size[] = {0.7, 1.2};
        circleRadius = 0.1;
    };
    class ACM_ChemicalDevice_Sarin: ACM_ChemicalDevice_Chlorine {
        color[] = {
            {0.8, 0.8, 0.8, 0.01},
            {0.8, 0.8, 0.8, 0.0025},
            {0.8, 0.8, 0.8, 0.0009},
            {0.8, 0.8, 0.8, 0.0001}
        };
    };
    class ACM_ChemicalDevice_Sarin_Small: ACM_ChemicalDevice_Sarin {
        lifeTime = 20;
        size[] = {0.7, 1.2};
        circleRadius = 0.1;
    };
    class ACM_ChemicalDevice_Lewisite: ACM_ChemicalDevice_Sarin {};
    class ACM_ChemicalDevice_Lewisite_Small: ACM_ChemicalDevice_Sarin_Small {};
    class SmokeShellWhiteSmall;
    class ACM_Mortar_Shell_CS_Effect: SmokeShellWhiteSmall {
        lifeTime = 20;
        weight = 1.3;
        position[] = {0, 0.2, 0};
        color[] = {{0.8, 0.8, 0.8, 0.2}, {0.8, 0.8, 0.8, 0.1}, {0.8, 0.8, 0.8, 0}};
        rotationVelocityVar = 12;
        moveVelocity[] = {0, 0.05, 0};
        moveVelocityVar[] = {0.5, 0.1, 0.5};
    };
    class ACM_Mortar_Shell_Chlorine_Effect: ACM_Mortar_Shell_CS_Effect {
        color[] = {{0.6, 0.63, 0, 0.4}, {0.6, 0.63, 0, 0.25}, {0.6, 0.63, 0, 0}};
    };
    class ACM_Mortar_Shell_Sarin_Effect: ACM_Mortar_Shell_CS_Effect {
        color[] = {{0.8, 0.8, 0.8, 0.015}, {0.8, 0.8, 0.8, 0.001}, {0.8, 0.8, 0.8, 0}};
    };
    class ACM_Mortar_Shell_Lewisite_Effect: ACM_Mortar_Shell_Sarin_Effect {};
};
class SmokeShellWhiteSmall;
class SmokeShellWhite;
class ACM_Mortar_Shell_CS_Effect: SmokeShellWhiteSmall {
    class SmokeShellWhite: SmokeShellWhite {
        simulation = "particles";
        type = "ACM_Mortar_Shell_CS_Effect";
        position[] = {0, 0, 0};
        intensity = 1;
        interval = 1;
    };
};
class ACM_Mortar_Shell_Chlorine_Effect: ACM_Mortar_Shell_CS_Effect {
    class SmokeShellWhite: SmokeShellWhite {
        simulation = "particles";
        type = "ACM_Mortar_Shell_Chlorine_Effect";
        position[] = {0, 0, 0};
        intensity = 1;
        interval = 1;
    };
};
class ACM_Mortar_Shell_Sarin_Effect: ACM_Mortar_Shell_CS_Effect {
    class SmokeShellWhite: SmokeShellWhite {
        simulation = "particles";
        type = "ACM_Mortar_Shell_Sarin_Effect";
        position[] = {0, 0, 0};
        intensity = 1;
        interval = 1;
    };
};
class ACM_Mortar_Shell_Lewisite_Effect: ACM_Mortar_Shell_CS_Effect {
    class SmokeShellWhite: SmokeShellWhite {
        simulation = "particles";
        type = "ACM_Mortar_Shell_Lewisite_Effect";
        position[] = {0, 0, 0};
        intensity = 1;
        interval = 1;
    };
};
class CfgAmmo {
    class SmokeShell;
    class ACM_Grenade_CS_A: SmokeShell {
        timeToLive = 40;
        smokeColor[] = {1, 1, 1, 0.15};
        cost = 1000;
        aiAmmoUsageFlags = "64";
        model = "\x\ACM\addons\cbrn\model\grenade_cs_throw.p3d";
    };
    class G_40mm_Smoke;
    class ACM_Grenade_Shell_CS_A: G_40mm_Smoke {
        timeToLive = 40;
        smokeColor[] = {1, 1, 1, 0.15};
        cost = 1000;
        aiAmmoUsageFlags = "64";
    };
    class SmokeShellArty;
    class ACM_Mortar_Shell_CS_Smoke: SmokeShellArty {
        effectsSmoke = "ACM_Mortar_Shell_CS_Effect";
    };
    class ACM_Mortar_Shell_Chlorine_Smoke: ACM_Mortar_Shell_CS_Smoke {
        effectsSmoke = "ACM_Mortar_Shell_Chlorine_Effect";
    };
    class ACM_Mortar_Shell_Sarin_Smoke: ACM_Mortar_Shell_CS_Smoke {
        effectsSmoke = "ACM_Mortar_Shell_Sarin_Effect";
    };
    class ACM_Mortar_Shell_Lewisite_Smoke: ACM_Mortar_Shell_CS_Smoke {
        effectsSmoke = "ACM_Mortar_Shell_Lewisite_Effect";
    };
    class Smoke_82mm_AMOS_White;
    class ACM_Mortar_Shell_CS_A: Smoke_82mm_AMOS_White {
        timeToLive = 50;
        submunitionAmmo = "ACM_Mortar_Shell_CS_Smoke";
    };
    class ACM_Mortar_Shell_Chlorine_A: Smoke_82mm_AMOS_White {
        timeToLive = 50;
        submunitionAmmo = "ACM_Mortar_Shell_Chlorine_Smoke";
    };
    class ACM_Mortar_Shell_Sarin_A: Smoke_82mm_AMOS_White {
        timeToLive = 30;
        submunitionAmmo = "ACM_Mortar_Shell_Sarin_Smoke";
    };
    class ACM_Mortar_Shell_Lewisite_A: Smoke_82mm_AMOS_White {
        timeToLive = 30;
        submunitionAmmo = "ACM_Mortar_Shell_Lewisite_Smoke";
    };
};
class CfgWeapons {
    class GrenadeLauncher;
    class Throw: GrenadeLauncher {
        muzzles[] += {"ACM_Grenade_CS_Muzzle"};
        class ThrowMuzzle;
        class ACM_Grenade_CS_Muzzle: ThrowMuzzle {
            magazines[] = {"ACM_Grenade_CS"};
        };
    };
    class CannonCore;
    class mortar_82mm: CannonCore {
        magazines[] += {
            "ACM_Mortar_Shell_8Rnd_CS",
            "ACM_Mortar_Shell_8Rnd_Chlorine",
            "ACM_Mortar_Shell_8Rnd_Sarin",
            "ACM_Mortar_Shell_8Rnd_Lewisite"
        };
    };
    class ACE_ItemCore;
    class CBA_MiscItem_ItemInfo;
    class ACM_GasMaskFilter: ACE_ItemCore {
        scope = 2;
        author = "Blue";
        picture = "\x\ACM\addons\cbrn\ui\gasMaskFilter_ca.paa";
        displayName = "$STR_ACM_cbrn_GasMaskFilter";
        descriptionShort = "$STR_ACM_cbrn_GasMaskFilter_Desc";
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 3;
        };
    };
    class ACM_Autoinjector_ATNA: ACE_ItemCore {
        scope = 2;
        author = "Blue";
        picture = "\x\ACM\addons\cbrn\ui\autoinjector_ATNA_ca.paa";
        displayName = "$STR_ACM_cbrn_Autoinjector_ATNA";
        descriptionShort = "$STR_ACM_cbrn_Autoinjector_ATNA_Desc";
        ACE_isMedicalItem = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 1;
        };
    };
    class ACM_Autoinjector_Midazolam: ACM_Autoinjector_ATNA {
        picture = "\x\ACM\addons\cbrn\ui\autoinjector_midazolam_ca.paa";
        displayName = "$STR_ACM_cbrn_Autoinjector_Midazolam";
        descriptionShort = "$STR_ACM_cbrn_Autoinjector_Midazolam_Desc";
    };
};
class CfgMagazines {
    class SmokeShell;
    class ACM_Grenade_CS: SmokeShell {
        author = "Blue";
        displayName = "$STR_ACM_cbrn_CS_Grenade";
        displayNameShort = "$STR_ACM_cbrn_CS_Grenade";
        picture = "\x\ACM\addons\cbrn\ui\grenade_cs_ca.paa";
        model = "\x\ACM\addons\cbrn\model\grenade_cs.p3d";
        ammo = "ACM_Grenade_CS_A";
        descriptionShort = "$STR_ACM_cbrn_CS_Grenade_Desc";
        mass = 4;
    };
    class 1Rnd_Smoke_Grenade_shell;
    class ACM_Grenade_Shell_CS: 1Rnd_Smoke_Grenade_shell {
        author = "Blue";
        displayName = "$STR_ACM_cbrn_CS_Shell_40mm";
        displayNameShort = "$STR_ACM_cbrn_CS_Shell_40mm";
        picture = "\x\ACM\addons\cbrn\ui\40mm_cs_ca.paa";
        ammo = "ACM_Grenade_Shell_CS_A";
        descriptionShort = "$STR_ACM_cbrn_CS_Shell_40mm_Desc";
        mass = 4;
    };
    class 8Rnd_82mm_Mo_Smoke_white;
    class ACM_Mortar_Shell_8Rnd_CS: 8Rnd_82mm_Mo_Smoke_white {
        author = "Blue";
        displayName = "$STR_ACM_cbrn_CS_Shell_82mm";
        displayNameShort = "$STR_ACM_cbrn_CS_Shell_82mm_Short";
        ammo = "ACM_Mortar_Shell_CS_A";
    };
    class ACM_Mortar_Shell_8Rnd_Chlorine: ACM_Mortar_Shell_8Rnd_CS {
        displayName = "$STR_ACM_cbrn_Chlorine_Shell_82mm";
        displayNameShort = "$STR_ACM_cbrn_Chlorine_Shell_82mm_Short";
        ammo = "ACM_Mortar_Shell_Chlorine_A";
    };
    class ACM_Mortar_Shell_8Rnd_Sarin: ACM_Mortar_Shell_8Rnd_CS {
        displayName = "$STR_ACM_cbrn_Sarin_Shell_82mm";
        displayNameShort = "$STR_ACM_cbrn_Sarin_Shell_82mm_Short";
        ammo = "ACM_Mortar_Shell_Sarin_A";
    };
    class ACM_Mortar_Shell_8Rnd_Lewisite: ACM_Mortar_Shell_8Rnd_CS {
        displayName = "$STR_ACM_cbrn_Lewisite_Shell_82mm";
        displayNameShort = "$STR_ACM_cbrn_Lewisite_Shell_82mm_Short";
        ammo = "ACM_Mortar_Shell_Lewisite_A";
    };
};
class CfgMagazineWells {
    class CBA_40mm_M203 {
        ACM_cbrn[] = {"ACM_Grenade_Shell_CS"};
    };
    class UGL_40x36 {
        ACM_cbrn[] = {"ACM_Grenade_Shell_CS"};
    };
};
class CfgVehicles {
    class Logic;
    class Module_F: Logic {
        class AttributesBase {
            class Default;
            class Combo;
            class Edit;
            class Checkbox;
            class ModuleDescription;
        };
    };
    class ACM_cbrn_Eden_HazardZone: Module_F {
        scope = 2;
        displayName = "$STR_ACM_cbrn_Module_HazardZone";
        icon = "\x\ACM\addons\cbrn\ui\Icon_ChemicalHazard_ca.paa";
        category = "ACM_cbrn_CBRN";
        function = "ACM_cbrn_fnc_moduleCreateHazardZone_Eden";
        functionPriority = 1;
        isGlobal = 1;
        isTriggerActivated = 0;
        author = "Blue";
        class AttributeValues {
            size3[] = {5, 5, 2.5};
            isRectangle = 0;
        };
        class Attributes: AttributesBase {
            class HazardType: Combo {
                property = "ACM_cbrn_Eden_HazardZone_HazardType";
                displayName = "$STR_ACM_cbrn_Module_Generic_HazardType";
                typeName = "NUMBER";
                defaultValue = 0;
                class values {
                    class Chemical_Placebo {
                        name = "$STR_ACM_cbrn_Chemical_Placebo";
                        value = 0;
                    };
                    class Chemical_CS {
                        name = "$STR_ACM_cbrn_Chemical_CS";
                        value = 1;
                    };
                    class Chemical_Chlorine {
                        name = "$STR_ACM_cbrn_Chemical_Chlorine";
                        value = 2;
                    };
                    class Chemical_Sarin {
                        name = "$STR_ACM_cbrn_Chemical_Sarin";
                        value = 3;
                    };
                    class Chemical_Lewisite {
                        name = "$STR_ACM_cbrn_Chemical_Lewisite";
                        value = 4;
                    };
                };
            };
            class ZoneRadius: Edit {
                property = "ACM_cbrn_Eden_HazardZone_ZoneRadius";
                displayName = "$STR_ACM_cbrn_Module_Generic_ZoneRadius";
                typeName = "NUMBER";
                defaultValue = 5;
            };
            class EffectTime: Edit {
                property = "ACM_cbrn_Eden_HazardZone_EffectTime";
                displayName = "$STR_ACM_cbrn_Module_Generic_EffectTime";
                tooltip = "$STR_ACM_cbrn_Module_Generic_EffectTime_Tooltip";
                typeName = "NUMBER";
                defaultValue = 0;
            };
            class AttachToObject: Checkbox {
                property = "ACM_cbrn_Eden_HazardZone_AttachToObject";
                displayName = "$STR_ACM_cbrn_Module_Generic_AttachToObject";
                tooltip = "$STR_ACM_cbrn_Module_Generic_AttachToObject_TooltipEden";
                typeName = "BOOL";
            };
            class ShowMist: Checkbox {
                property = "ACM_cbrn_Eden_HazardZone_ShowMist";
                displayName = "$STR_ACM_cbrn_Module_Generic_ShowMist";
                tooltip = "$STR_ACM_cbrn_Module_Generic_ShowMist_Tooltip";
                typeName = "BOOL";
                defaultValue = 1;
            };
            class AffectAI: Checkbox {
                property = "ACM_cbrn_Eden_HazardZone_AffectAI";
                displayName = "$STR_ACM_cbrn_Module_Generic_AffectAI";
                typeName = "BOOL";
                defaultValue = 1;
            };
        };
    };
    class ACM_cbrn_Eden_ChemicalDevice: Module_F {
        scope = 2;
        displayName = "$STR_ACM_cbrn_Module_ChemicalDevice";
        icon = "\x\ACM\addons\cbrn\ui\Icon_ChemicalHazard_ca.paa";
        category = "ACM_cbrn_CBRN";
        function = "ACM_cbrn_fnc_moduleCreateChemicalDevice_Eden";
        functionPriority = 1;
        isGlobal = 1;
        isTriggerActivated = 0;
        author = "Blue";
        class AttributeValues {
            size3[] = {5, 5, 2.5};
            isRectangle = 0;
        };
        class Attributes: AttributesBase {
            class HazardType: Combo {
                property = "ACM_cbrn_Eden_ChemicalDevice_HazardType";
                displayName = "$STR_ACM_cbrn_Module_Generic_HazardType";
                typeName = "NUMBER";
                defaultValue = 0;
                class values {
                    class Chemical_Chlorine {
                        name = "$STR_ACM_cbrn_Chemical_Chlorine";
                        value = 0;
                    };
                    class Chemical_Sarin {
                        name = "$STR_ACM_cbrn_Chemical_Sarin";
                        value = 1;
                    };
                    class Chemical_Lewisite {
                        name = "$STR_ACM_cbrn_Chemical_Lewisite";
                        value = 2;
                    };
                };
            };
            class ExplosionCloudSize: Combo {
                property = "ACM_cbrn_Eden_ChemicalDevice_ExplosionCloudSize";
                displayName = "$STR_ACM_cbrn_Module_CreateChemicalDevice_CloudSize";
                typeName = "NUMBER";
                defaultValue = 0;
                class values {
                    class CloudSize_None {
                        name = "$STR_ACM_cbrn_Module_CreateChemicalDevice_CloudSize_None";
                        value = 0;
                    };
                    class CloudSize_Small {
                        name = "$STR_ACM_cbrn_Module_CreateChemicalDevice_CloudSize_Small";
                        value = 1;
                    };
                    class CloudSize_Large {
                        name = "$STR_ACM_cbrn_Module_CreateChemicalDevice_CloudSize_Large";
                        value = 2;
                    };
                };
            };
            class ZoneRadius: Edit {
                property = "ACM_cbrn_Eden_ChemicalDevice_ZoneRadius";
                displayName = "$STR_ACM_cbrn_Module_Generic_ZoneRadius";
                typeName = "NUMBER";
                defaultValue = 5;
            };
            class PermanentHazard: Checkbox {
                property = "ACM_cbrn_Eden_ChemicalDevice_PermanentHazard";
                displayName = "$STR_ACM_cbrn_Module_CreateChemicalDevice_PermanentHazard";
                tooltip = "$STR_ACM_cbrn_Module_CreateChemicalDevice_PermanentHazard_Tooltip";
                typeName = "BOOL";
                defaultValue = 0;
            };
            class AffectAI: Checkbox {
                property = "ACM_cbrn_Eden_ChemicalDevice_AffectAI";
                displayName = "$STR_ACM_cbrn_Module_Generic_AffectAI";
                typeName = "BOOL";
                defaultValue = 1;
            };
        };
    };
    class ACM_cbrn_moduleBase: Module_F {
        curatorCanAttach = 1;
        category = "ACM_cbrn_CBRN";
        displayName = "Module";
        functionPriority = 1;
        isGlobal = 1;
        isTriggerActivated = 0;
        scope = 1;
        scopeCurator = 2;
        author = "Blue";
    };
    class ACM_cbrn_moduleCreateHazardZone: ACM_cbrn_moduleBase {
        displayName = "$STR_ACM_cbrn_Module_CreateHazardZone";
        icon = "\x\ACM\addons\cbrn\ui\Icon_ChemicalHazard_ca.paa";
        curatorInfoType = "ACM_cbrn_RscCreateHazardZone";
    };
    class ACM_cbrn_moduleCreateChemicalDevice: ACM_cbrn_moduleBase {
        displayName = "$STR_ACM_cbrn_Module_CreateChemicalDevice";
        icon = "\x\ACM\addons\cbrn\ui\Icon_ChemicalHazard_ca.paa";
        curatorInfoType = "ACM_cbrn_RscCreateChemicalDevice";
    };
    class ACE_LogicDummy;
    class ACM_HazardObject: ACE_LogicDummy {
        author = "Blue";
        displayName = "Hazard Origin";
        scopeCurator = 1;
        scopeArsenal = 0;
        model = "\x\cba\addons\ai\InvisibleTarget.p3d";
        icon = "\x\ACM\addons\cbrn\ui\Icon_ChemicalHazard_ca.paa";
    };
    class Man;
    class CAManBase: Man {
        class ACE_Actions {
            class ACM_Action_GasMask_Other {
                displayName = "$STR_ACM_cbrn_GasMask";
                icon = "\x\ACM\addons\cbrn\ui\Icon_Gasmask_ca.paa";
                exceptions[] = {"isNotInside", "isNotSitting"};
                distance = 1.75;
                selection = "head";
                class ACM_Action_PutOnGasMask_Other {
                    displayName = "$STR_ACM_cbrn_GasMask_PutOn";
                    icon = "\x\ACM\addons\cbrn\ui\Icon_Gasmask_ca.paa";
                    condition = "!(_target call ace_common_fnc_isAwake) && !([_target] call ACM_cbrn_fnc_isWearingGasMask) && {([_target] call ACM_cbrn_fnc_hasGasMask || [_player] call ACM_cbrn_fnc_hasGasMask)}";
                    statement = "[_target, _player] call ACM_cbrn_fnc_putOnGasMask";
                    exceptions[] = {"isNotInside", "isNotSitting"};
                    showDisabled = 0;
                };
                class ACM_Action_TakeOffGasMask_Other: ACM_Action_PutOnGasMask_Other {
                    displayName = "$STR_ACM_cbrn_GasMask_TakeOff";
                    condition = "[_target] call ACM_cbrn_fnc_canTakeOffGasMask";
                    statement = "[_target, _player] call ACM_cbrn_fnc_takeOffGasMask";
                };
                class ACM_Action_ReplaceGasMaskFilter_Other: ACM_Action_PutOnGasMask_Other {
                    displayName = "$STR_ACM_cbrn_GasMask_ReplaceFilter";
                    condition = "[_target] call ACM_cbrn_fnc_isWearingGasMask && {([_target] call ACM_cbrn_fnc_hasFilter || [_player] call ACM_cbrn_fnc_hasFilter)}";
                    statement = "[_player] call ACM_cbrn_fnc_replaceFilter";
                };
            };
        };
        class ACE_SelfActions {
            class ACE_Equipment {
                class ACM_Action_GasMask {
                    displayName = "$STR_ACM_cbrn_GasMask";
                    icon = "\x\ACM\addons\cbrn\ui\Icon_Gasmask_ca.paa";
                    exceptions[] = {"isNotInside", "isNotSitting"};
                    class ACM_Action_PutOnGasMask {
                        displayName = "$STR_ACM_cbrn_GasMask_PutOn";
                        condition = "[_player] call ACM_cbrn_fnc_canPutOnGasMask";
                        statement = "[_player] call ACM_cbrn_fnc_putOnGasMask";
                        showDisabled = 0;
                        exceptions[] = {"isNotInside", "isNotSitting"};
                    };
                    class ACM_Action_TakeOffGasMask: ACM_Action_PutOnGasMask {
                        displayName = "$STR_ACM_cbrn_GasMask_TakeOff";
                        condition = "[_player] call ACM_cbrn_fnc_canTakeOffGasMask";
                        statement = "[_player] call ACM_cbrn_fnc_takeOffGasMask";
                    };
                    class ACM_Action_ReplaceGasMaskFilter: ACM_Action_PutOnGasMask {
                        displayName = "$STR_ACM_cbrn_GasMask_ReplaceFilter";
                        condition = "[_player] call ACM_cbrn_fnc_canReplaceFilter";
                        statement = "[_player] call ACM_cbrn_fnc_replaceFilter";
                    };
                };
                class ACM_Action_ChemicalDetector {
                    displayName = "$STR_ACM_cbrn_ChemicalDetector";
                    condition = "(_player getSlotItemName 610) == 'ChemicalDetector_01_watch_F'";
                    exceptions[] = {"isNotInside", "isNotSitting"};
                    icon = "";
                    class ACM_Action_TurnOnDetector {
                        displayName = "$STR_ACM_cbrn_ChemicalDetector_TurnOn";
                        condition = "!(_player getVariable [""ACM_cbrn_Detector_State"", false])";
                        statement = "[_player, true] call ACM_cbrn_fnc_detector_toggle";
                        showDisabled = 0;
                        exceptions[] = {"isNotInside", "isNotSitting"};
                    };
                    class ACM_Action_TurnOffDetector: ACM_Action_TurnOnDetector {
                        displayName = "$STR_ACM_cbrn_ChemicalDetector_TurnOff";
                        condition = "_player getVariable [""ACM_cbrn_Detector_State"", false]";
                        statement = "[_player, false] call ACM_cbrn_fnc_detector_toggle";
                    };
                    class ACM_Action_EnableDetectorAlarm: ACM_Action_TurnOnDetector {
                        displayName = "$STR_ACM_cbrn_ChemicalDetector_EnableAlarm";
                        condition = "!(_player getVariable [""ACM_cbrn_Detector_Alarm_State"", false])";
                        statement = "[_player, true] call ACM_cbrn_fnc_detector_setAlarm";
                    };
                    class ACM_Action_DisableDetectorAlarm: ACM_Action_TurnOnDetector {
                        displayName = "$STR_ACM_cbrn_ChemicalDetector_DisableAlarm";
                        condition = "_player getVariable [""ACM_cbrn_Detector_Alarm_State"", false]";
                        statement = "[_player, false] call ACM_cbrn_fnc_detector_setAlarm";
                    };
                    class ACM_Action_ResetDetector: ACM_Action_TurnOnDetector {
                        displayName = "$STR_ACM_cbrn_ChemicalDetector_Reset";
                        condition = "_player getVariable [""ACM_cbrn_Detector_State"", false]";
                        statement = "[_player] call ACM_cbrn_fnc_detector_reset";
                    };
                };
            };
        };
    };
};
class CfgFactionClasses {
    class ACM_cbrn_CBRN {
        displayName = "ACM CBRN";
        priority = 2;
        side = 7;
    };
};
class Extended_PreInit_EventHandlers {
    class ACM_cbrn {
        init = "call compile preprocessFileLineNumbers '\x\ACM\addons\cbrn\XEH_preInit.sqf'";
    };
};
class Extended_PostInit_EventHandlers {
    class ACM_cbrn {
        init = "call compile preprocessFileLineNumbers '\x\ACM\addons\cbrn\XEH_postInit.sqf'";
    };
};
class Extended_Init_EventHandlers {
    class CAManBase {
        class ACM_cbrn {
            init = "[(_this select 0)] call ACM_cbrn_fnc_initUnit";
            exclude[] = {"B_UAV_AI", "O_UAV_AI", "UAV_AI_base_F"};
        };
    };
};
class ACM_CBRN_Hazards {
    class Chemical {
        class CS {
            thresholds[] = {0, 50};
            threshold_positiveRate[] = {1, 0.5};
            threshold_negativeRate[] = {1, 1};
            absorption_rate = 1;
            inhalation_rate = 0.5;
            elimination_rate = -0.5;
            thresholdFunction = "ACM_cbrn_fnc_effectCS";
            absorbant_skin = 0;
        };
        class Chlorine {
            thresholds[] = {0, 25, 50, 70};
            threshold_positiveRate[] = {1, 1, 1, 0.5};
            threshold_negativeRate[] = {1, 0.5, 0.3, 0.2};
            absorption_rate = 0.35;
            inhalation_rate = 1;
            elimination_rate = -0.25;
            thresholdFunction = "ACM_cbrn_fnc_effectChlorine";
        };
        class Sarin {
            thresholds[] = {0, 25, 50, 70};
            threshold_positiveRate[] = {1, 1, 1, 0.5};
            threshold_negativeRate[] = {1, 0.5, 0.25, 0.1};
            absorption_rate = 0.5;
            inhalation_rate = 1.5;
            elimination_rate = -0.15;
            thresholdFunction = "ACM_cbrn_fnc_effectSarin";
        };
        class Lewisite {
            thresholds[] = {0, 25, 70};
            threshold_positiveRate[] = {1, 1, 0.5};
            threshold_negativeRate[] = {1, 0.5, 0.3};
            absorption_rate = 1.5;
            inhalation_rate = 1;
            elimination_rate = -0.15;
            thresholdFunction = "ACM_cbrn_fnc_effectLewisite";
        };
    };
};
class RscControlsGroup;
class RscControlsGroupNoScrollbars;
class RscText;
class RscListBox;
class RscCombo;
class RscEdit;
class RscXSliderH;
class RscCheckBox;
class RscActivePicture;
class RscMapControl;
class RscPicture;
class ctrlToolbox;
class RscButton;
class RscDisplayAttributes {
    class Controls {
        class Background;
        class Title;
        class Content: RscControlsGroup {
            class Controls;
        };
        class ButtonOK;
        class ButtonCancel;
    };
};
class ACM_cbrn_RscCreateHazardZone: RscDisplayAttributes {
    onLoad = "['onLoad', _this, ""ACM_cbrn_RscCreateHazardZone""] call ace_zeus_fnc_zeusAttributes";
    onUnload = "['onUnload', _this, ""ACM_cbrn_RscCreateHazardZone""] call ace_zeus_fnc_zeusAttributes";
    class Controls: Controls {
        class Background: Background {};
        class Title: Title {};
        class Content: Content {
            class Controls {
                class Tab: RscControlsGroupNoScrollbars {
                    onSetFocus = "_this call ACM_cbrn_fnc_moduleCreateHazardZone";
                    idc = 100000;
                    x = 0;
                    y = 0;
                    w = "(26 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                    h = "(8 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                    class Controls {
                        class Title_HazardType: RscText {
                            idc = -1;
                            text = "$STR_ACM_cbrn_Module_Generic_HazardType";
                            x = 0;
                            y = 0;
                            w = "(10 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            h = "(1 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            colorBackground[] = {0, 0, 0, 0.5};
                        };
                        class List_HazardType: RscCombo {
                            idc = 100001;
                            x = "(10.1 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            y = "0";
                            w = "(16 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            h = "(1 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            colorBackground[] = {0, 0, 0, 0.5};
                            class Items {
                                class Chemical_Placebo {
                                    text = "$STR_ACM_cbrn_Chemical_Placebo";
                                    default = 1;
                                };
                                class Chemical_CS {
                                    text = "$STR_ACM_cbrn_Chemical_CS";
                                };
                                class Chemical_Chlorine {
                                    text = "$STR_ACM_cbrn_Chemical_Chlorine";
                                };
                                class Chemical_Sarin {
                                    text = "$STR_ACM_cbrn_Chemical_Sarin";
                                };
                                class Chemical_Lewisite {
                                    text = "$STR_ACM_cbrn_Chemical_Lewisite";
                                };
                            };
                        };
                        class Title_Radius: Title_HazardType {
                            text = "$STR_ACM_cbrn_Module_Generic_ZoneRadius";
                            y = "(1.1 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            w = "(10 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                        };
                        class Slider_Radius: RscXSliderH {
                            idc = 100002;
                            x = "(10.1 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            y = "(1.1 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            w = "(15.9 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            h = "(1 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            sliderStep = 1;
                            sliderRange[] = {1, 30};
                            sliderPosition = 5;
                        };
                        class Title_EffectTime: Title_HazardType {
                            text = "$STR_ACM_cbrn_Module_Generic_EffectTime";
                            y = "(2.2 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            w = "(10 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            tooltip = "$STR_ACM_cbrn_Module_Generic_EffectTime_Tooltip";
                        };
                        class Slider_EffectTime: Slider_Radius {
                            idc = 100005;
                            y = "(2.2 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            sliderRange[] = {0, 60};
                            sliderPosition = 0;
                        };
                        class Title_Attach: Title_HazardType {
                            text = "$STR_ACM_cbrn_Module_Generic_AttachToObject";
                            y = "(3.3 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            w = "(10 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                        };
                        class Checkbox_Attach: RscCheckBox {
                            idc = 100004;
                            x = "(10.1 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            y = "(3.3 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            w = "(1 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            h = "(1 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            checked = 0;
                        };
                        class Title_ShowMist: Title_HazardType {
                            text = "$STR_ACM_cbrn_Module_Generic_ShowMist";
                            y = "(4.4 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            w = "(10 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            tooltip = "$STR_ACM_cbrn_Module_Generic_ShowMist_Tooltip";
                        };
                        class Checkbox_ShowMist: Checkbox_Attach {
                            idc = 100003;
                            y = "(4.4 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            checked = 1;
                        };
                        class Title_AffectAI: Title_HazardType {
                            text = "$STR_ACM_cbrn_Module_Generic_AffectAI";
                            y = "(5.5 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            w = "(10 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                        };
                        class Checkbox_AffectAI: Checkbox_Attach {
                            idc = 100006;
                            y = "(5.5 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            checked = 1;
                        };
                    };
                };
            };
        };
        class ButtonOK: ButtonOK {};
        class ButtonCancel: ButtonCancel {};
    };
};
class ACM_cbrn_RscCreateChemicalDevice: RscDisplayAttributes {
    onLoad = "['onLoad', _this, ""ACM_cbrn_RscCreateChemicalDevice""] call ace_zeus_fnc_zeusAttributes";
    onUnload = "['onUnload', _this, ""ACM_cbrn_RscCreateChemicalDevice""] call ace_zeus_fnc_zeusAttributes";
    class Controls: Controls {
        class Background: Background {};
        class Title: Title {};
        class Content: Content {
            class Controls {
                class Tab: RscControlsGroupNoScrollbars {
                    onSetFocus = "_this call ACM_cbrn_fnc_moduleCreateChemicalDevice";
                    idc = 100010;
                    x = 0;
                    y = 0;
                    w = "(26 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                    h = "(6 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                    class Controls {
                        class Title_HazardType: RscText {
                            idc = -1;
                            text = "$STR_ACM_cbrn_Module_Generic_HazardType";
                            x = 0;
                            y = 0;
                            w = "(10 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            h = "(1 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            colorBackground[] = {0, 0, 0, 0.5};
                        };
                        class List_HazardType: RscCombo {
                            idc = 100011;
                            x = "(10.1 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            y = "0";
                            w = "(16 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            h = "(1 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            colorBackground[] = {0, 0, 0, 0.5};
                            class Items {
                                class Chemical_Chlorine {
                                    text = "$STR_ACM_cbrn_Chemical_Chlorine";
                                    default = 1;
                                };
                                class Chemical_Sarin {
                                    text = "$STR_ACM_cbrn_Chemical_Sarin";
                                };
                                class Chemical_Lewisite {
                                    text = "$STR_ACM_cbrn_Chemical_Lewisite";
                                };
                            };
                        };
                        class Title_ExplosionCloud: Title_HazardType {
                            text = "$STR_ACM_cbrn_Module_CreateChemicalDevice_CloudSize";
                            y = "(1.1 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            w = "(10 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                        };
                        class List_ExplosionCloud: ctrlToolbox {
                            idc = 100016;
                            x = "(10.1 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            y = "(1.1 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            w = "(15.9 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            h = "(1 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            rows = 1;
                            columns = 3;
                            strings[] = {"$STR_ACM_cbrn_Module_CreateChemicalDevice_CloudSize_None", "$STR_ACM_cbrn_Module_CreateChemicalDevice_CloudSize_Small", "$STR_ACM_cbrn_Module_CreateChemicalDevice_CloudSize_Large"};
                        };
                        class Title_Radius: Title_HazardType {
                            text = "$STR_ACM_cbrn_Module_Generic_ZoneRadius";
                            y = "(2.2 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            w = "(10 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                        };
                        class Slider_Radius: RscXSliderH {
                            idc = 100012;
                            x = "(10.1 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            y = "(2.2 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            w = "(15.9 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            h = "(1 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            sliderStep = 1;
                            sliderRange[] = {1, 15};
                            sliderPosition = 5;
                        };
                        class Title_PermanentHazard: Title_HazardType {
                            text = "$STR_ACM_cbrn_Module_CreateChemicalDevice_PermanentHazard";
                            y = "(3.3 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            w = "(10 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            tooltip = "$STR_ACM_cbrn_Module_CreateChemicalDevice_PermanentHazard_Tooltip";
                        };
                        class Checkbox_PermanentHazard: RscCheckBox {
                            idc = 100013;
                            x = "(10.1 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            y = "(3.3 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            w = "(1 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                            h = "(1 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            checked = 0;
                        };
                        class Title_AffectAI: Title_HazardType {
                            text = "$STR_ACM_cbrn_Module_Generic_AffectAI";
                            y = "(4.4 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            w = "(10 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                        };
                        class Checkbox_AffectAI: Checkbox_PermanentHazard {
                            idc = 100015;
                            y = "(4.4 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                            checked = 1;
                        };
                    };
                };
            };
        };
        class ButtonOK: ButtonOK {};
        class ButtonCancel: ButtonCancel {};
    };
};

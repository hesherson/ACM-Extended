class CfgPatches {
    class ACM_breathing {
        acmeBuildBatch = "B215";
        acmeNetworkProtocol = 1;
        acmeComponent = "breathing";
        name = "ACM - Breathing";
        units[] = {};
        weapons[] = {
            "ACM_ChestSeal",
            "ACM_PulseOximeter",
            "ACM_Stethoscope",
            "ACM_NCDKit",
            "ACM_ChestTubeKit",
            "ACM_ThoracostomyKit",
            "ACM_PocketBVM",
            "ACM_BVM"
        };
        requiredVersion = 2.18;
        requiredAddons[] = {"cba_main", "ace_main", "ace_medical_treatment"};
        author = "Blue";
        version = 1.2;
        versionStr = "1.2.4.1";
        versionAr[] = {1, 2, 4, 1};
    };
};
class Extended_PreInit_EventHandlers {
    class ACM_breathing {
        init = "call compileScript ['\x\ACM\addons\breathing\XEH_preInit.sqf']";
    };
};
class Extended_PostInit_EventHandlers {
    class ACM_breathing {
        init = "call compileScript ['\x\ACM\addons\breathing\XEH_postInit.sqf']";
    };
};
class CfgMagazines {
    class CA_Magazine;
    class ACM_OxygenTank_425: CA_Magazine {
        scope = 2;
        author = "Blue";
        picture = "\x\ACM\addons\breathing\ui\oxygentank_ca.paa";
        displayName = "$STR_ACM_breathing_OxygenTank_425";
        descriptionShort = "$STR_ACM_breathing_OxygenTank_425_Desc";
        ACE_isMedicalItem = 1;
        ACE_asItem = 1;
        count = 283;
        mass = 20;
    };
};
class CfgWeapons {
    class ACE_ItemCore;
    class CBA_MiscItem_ItemInfo;
    class ACM_ChestSeal: ACE_ItemCore {
        scope = 2;
        author = "Blue";
        picture = "\x\ACM\addons\breathing\ui\chestseal_ca.paa";
        displayName = "$STR_ACM_breathing_ChestSeal";
        descriptionShort = "$STR_ACM_breathing_ChestSeal_Desc";
        ACE_isMedicalItem = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 2;
        };
    };
    class ACM_PulseOximeter: ACM_ChestSeal {
        picture = "\x\ACM\addons\breathing\ui\pulseoximeter_ca.paa";
        displayName = "$STR_ACM_breathing_PulseOximeter";
        descriptionShort = "$STR_ACM_breathing_PulseOximeter_Desc";
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 1;
        };
    };
    class ACM_Stethoscope: ACM_ChestSeal {
        picture = "\x\ACM\addons\breathing\ui\stethoscope_ca.paa";
        displayName = "$STR_ACM_breathing_Stethoscope";
        descriptionShort = "$STR_ACM_breathing_Stethoscope_Desc";
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 2;
        };
    };
    class ACM_NCDKit: ACM_ChestSeal {
        picture = "\x\ACM\addons\breathing\ui\ncdkit_ca.paa";
        displayName = "$STR_ACM_breathing_NCDKit";
        descriptionShort = "$STR_ACM_breathing_NCDKit_Desc";
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 1;
        };
    };
    class ACM_ChestTubeKit: ACM_ChestSeal {
        picture = "\x\ACM\addons\breathing\ui\chestTubeKit_ca.paa";
        displayName = "$STR_ACM_breathing_ChestTubeKit";
        descriptionShort = "$STR_ACM_breathing_ChestTubeKit_Desc";
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 4;
        };
    };
    class ACM_ThoracostomyKit: ACM_ChestSeal {
        picture = "\x\ACM\addons\breathing\ui\thoracostomyKit_ca.paa";
        displayName = "$STR_ACM_breathing_ThoracostomyKit";
        descriptionShort = "$STR_ACM_breathing_ThoracostomyKit_Desc";
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 4;
        };
    };
    class ACM_PocketBVM: ACM_ChestSeal {
        picture = "\x\ACM\addons\breathing\ui\pocketBVM_ca.paa";
        displayName = "$STR_ACM_breathing_PocketBVM";
        descriptionShort = "$STR_ACM_breathing_PocketBVM_Desc";
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 5;
        };
    };
    class ACM_BVM: ACM_PocketBVM {
        picture = "\x\ACM\addons\breathing\ui\bvm_ca.paa";
        displayName = "$STR_ACM_breathing_BVM";
        descriptionShort = "$STR_ACM_breathing_BVM_Desc";
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 12;
        };
    };
    class ACM_OxygenTank_425_Empty: ACM_ChestSeal {
        scope = 1;
        picture = "\x\ACM\addons\breathing\ui\oxygentank_ca.paa";
        displayName = "$STR_ACM_breathing_OxygenTank_425_Empty";
        descriptionShort = "$STR_ACM_breathing_OxygenTank_425_Desc";
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 20;
        };
    };
};
class CfgSounds {
    class ACM_Stethoscope_HeartBeat_Normal_1 {
        name = "ACM_Stethoscope_HeartBeat_Normal_1";
        sound[] = {"\x\ACM\addons\breathing\sound\heartbeat_normal_1.wav", "db+16", 1};
        titles[] = {};
    };
    class ACM_Stethoscope_HeartBeat_Normal_2: ACM_Stethoscope_HeartBeat_Normal_1 {
        name = "ACM_Stethoscope_HeartBeat_Normal_2";
        sound[] = {"\x\ACM\addons\breathing\sound\heartbeat_normal_2.wav", "db+16", 1};
    };
    class ACM_Stethoscope_HeartBeat_Normal_3: ACM_Stethoscope_HeartBeat_Normal_1 {
        name = "ACM_Stethoscope_HeartBeat_Normal_3";
        sound[] = {"\x\ACM\addons\breathing\sound\heartbeat_normal_3.wav", "db+16", 1};
    };
    class ACM_Stethoscope_HeartBeat_Fast_1: ACM_Stethoscope_HeartBeat_Normal_1 {
        name = "ACM_Stethoscope_HeartBeat_Fast_1";
        sound[] = {"\x\ACM\addons\breathing\sound\heartbeat_fast_1.wav", "db+16", 1};
    };
    class ACM_Stethoscope_HeartBeat_Fast_2: ACM_Stethoscope_HeartBeat_Normal_1 {
        name = "ACM_Stethoscope_HeartBeat_Fast_2";
        sound[] = {"\x\ACM\addons\breathing\sound\heartbeat_fast_2.wav", "db+16", 1};
    };
    class ACM_Stethoscope_HeartBeat_Fast_3: ACM_Stethoscope_HeartBeat_Normal_1 {
        name = "ACM_Stethoscope_HeartBeat_Fast_3";
        sound[] = {"\x\ACM\addons\breathing\sound\heartbeat_fast_3.wav", "db+16", 1};
    };
    class ACM_Stethoscope_HeartBeat_Slow_1: ACM_Stethoscope_HeartBeat_Normal_1 {
        name = "ACM_Stethoscope_HeartBeat_Slow_1";
        sound[] = {"\x\ACM\addons\breathing\sound\heartbeat_slow_1.wav", "db+16", 1};
    };
    class ACM_Stethoscope_HeartBeat_Slow_2: ACM_Stethoscope_HeartBeat_Normal_1 {
        name = "ACM_Stethoscope_HeartBeat_Slow_2";
        sound[] = {"\x\ACM\addons\breathing\sound\heartbeat_slow_2.wav", "db+16", 1};
    };
    class ACM_Stethoscope_HeartBeat_Slow_3: ACM_Stethoscope_HeartBeat_Normal_1 {
        name = "ACM_Stethoscope_HeartBeat_Slow_3";
        sound[] = {"\x\ACM\addons\breathing\sound\heartbeat_slow_3.wav", "db+16", 1};
    };
    class ACM_Stethoscope_Breath_Normal_Normal: ACM_Stethoscope_HeartBeat_Normal_1 {
        name = "ACM_Stethoscope_Breath_Normal_Normal";
        sound[] = {"\x\ACM\addons\breathing\sound\breath_normal.wav", "db+16", 1};
    };
    class ACM_Stethoscope_Breath_Fast_Normal: ACM_Stethoscope_Breath_Normal_Normal {
        name = "ACM_Stethoscope_Breath_Fast_Normal";
        sound[] = {"\x\ACM\addons\breathing\sound\breath_fast.wav", "db+16", 1};
    };
    class ACM_Stethoscope_Breath_Slow_Normal: ACM_Stethoscope_Breath_Normal_Normal {
        name = "ACM_Stethoscope_Breath_Slow_Normal";
        sound[] = {"\x\ACM\addons\breathing\sound\breath_slow.wav", "db+16", 1};
    };
    class ACM_Stethoscope_Breath_Normal_Shallow: ACM_Stethoscope_Breath_Normal_Normal {
        name = "ACM_Stethoscope_Breath_Normal_Shallow";
        sound[] = {"\x\ACM\addons\breathing\sound\breath_normal_shallow.wav", "db+16", 1};
    };
    class ACM_Stethoscope_Breath_Fast_Shallow: ACM_Stethoscope_Breath_Normal_Shallow {
        name = "ACM_Stethoscope_Breath_Fast_Shallow";
        sound[] = {"\x\ACM\addons\breathing\sound\breath_fast_shallow.wav", "db+16", 1};
    };
    class ACM_Stethoscope_Breath_Slow_Shallow: ACM_Stethoscope_Breath_Normal_Shallow {
        name = "ACM_Stethoscope_Breath_Slow_Shallow";
        sound[] = {"\x\ACM\addons\breathing\sound\breath_slow_shallow.wav", "db+16", 1};
    };
    class ACM_Stethoscope_Breath_Normal_Dull: ACM_Stethoscope_Breath_Normal_Normal {
        name = "ACM_Stethoscope_Breath_Normal_Dull";
        sound[] = {"\x\ACM\addons\breathing\sound\breath_normal_dull.wav", "db+16", 1};
    };
    class ACM_Stethoscope_Breath_Fast_Dull: ACM_Stethoscope_Breath_Normal_Dull {
        name = "ACM_Stethoscope_Breath_Fast_Dull";
        sound[] = {"\x\ACM\addons\breathing\sound\breath_fast_dull.wav", "db+16", 1};
    };
    class ACM_Stethoscope_Breath_Slow_Dull: ACM_Stethoscope_Breath_Normal_Dull {
        name = "ACM_Stethoscope_Breath_Slow_Dull";
        sound[] = {"\x\ACM\addons\breathing\sound\breath_slow_dull.wav", "db+16", 1};
    };
};
class ace_medical_treatment_actions {
    class CheckPulse;
    class CheckBreathing: CheckPulse {
        displayName = "$STR_ACM_breathing_CheckBreathing";
        displayNameProgress = "$STR_ACM_breathing_CheckBreathing_Progress";
        icon = "";
        category = "airway";
        treatmentLocations = 0;
        medicRequired = 0;
        treatmentTime = 3;
        allowedSelections[] = {"Head"};
        allowSelfTreatment = 0;
        condition = "true";
        callbackSuccess = "ACM_breathing_fnc_checkBreathing";
        ACM_rollToBack = 1;
    };
    class InspectChest: CheckBreathing {
        displayName = "$STR_ACM_breathing_InspectChest";
        displayNameProgress = "$STR_ACM_breathing_InspectChest_Progress";
        icon = "";
        medicRequired = "ACM_breathing_allowInspectChest";
        treatmentTime = "ACM_breathing_treatmentTimeInspectChest";
        allowedSelections[] = {"Body"};
        condition = "ACM_breathing_pneumothoraxEnabled && !(_patient call ace_common_fnc_isAwake) && (isNull objectParent _patient)";
        callbackSuccess = "ACM_breathing_fnc_inspectChest";
        animationMedic = "AinvPknlMstpSnonWnonDr_medic4";
        ACM_cancelRecovery = 1;
    };
    class UseStethoscope: CheckBreathing {
        displayName = "$STR_ACM_breathing_UseStethoscope";
        displayNameProgress = "";
        icon = "";
        medicRequired = 0;
        treatmentTime = 0.001;
        allowedSelections[] = {"Body"};
        allowSelfTreatment = 0;
        items[] = {"ACM_Stethoscope"};
        consumeItem = 0;
        condition = "true";
        callbackSuccess = "ACM_breathing_fnc_useStethoscope";
        ACME_neverRollToBack = 1;
        ACME_suppressNativeTreatmentAnim = 1;
        ACM_menuIcon = "ACM_Stethoscope";
    };
    class UseBVM: UseStethoscope {
        displayName = "$STR_ACM_breathing_UseBVM";
        icon = "";
        allowedSelections[] = {"Head"};
        items[] = {"ACM_BVM", "ACM_PocketBVM"};
        condition = "[_medic, _patient] call ACM_breathing_fnc_canUseBVM";
        callbackSuccess = "[_medic, _patient, false] call ACM_breathing_fnc_useBVM";
        ACME_neverRollToBack = 0;
        ACME_suppressNativeTreatmentAnim = 0;
        ACM_cancelRecovery = 1;
        ACM_menuIcon = "ACM_BVM";
    };
    class UseBVM_Oxygen: UseBVM {
        displayName = "$STR_ACM_breathing_UseBVM_Oxygen";
        treatmentLocations = 2;
        items[] = {"ACM_BVM"};
        condition = "[_medic, _patient] call ACM_breathing_fnc_canUseBVM";
        callbackSuccess = "[_medic, _patient, true] call ACM_breathing_fnc_useBVM";
        ACM_menuIcon = "ACM_BVM";
    };
    class UseBVM_VehicleOxygen: UseBVM_Oxygen {
        displayName = "$STR_ACM_breathing_UseBVM_VehicleOxygen";
        treatmentLocations = 1;
    };
    class UseBVM_PortableOxygen: UseBVM_Oxygen {
        displayName = "$STR_ACM_breathing_UseBVM_PortableOxygen";
        treatmentLocations = 0;
        items[] = {"ACM_BVM"};
        condition = "[_medic, _patient] call ACM_breathing_fnc_canUseBVM && (([_medic, 'ACM_OxygenTank_425'] call ACME_fnc_itemCount) > 0)";
        callbackSuccess = "[_medic, _patient, true, true] call ACM_breathing_fnc_useBVM";
    };
    class ApplyChestSeal: CheckBreathing {
        displayName = "$STR_ACM_breathing_ApplyChestSeal";
        displayNameProgress = "$STR_ACM_breathing_ApplyChestSeal_Progress";
        icon = "";
        treatmentLocations = 0;
        medicRequired = 0;
        treatmentTime = 5;
        allowedSelections[] = {"Body"};
        allowSelfTreatment = 1;
        items[] = {"ACM_ChestSeal"};
        consumeItem = 1;
        condition = "ACM_breathing_pneumothoraxEnabled && !(_patient getVariable [""ACM_breathing_ChestSeal_State"", false]) && _patient getVariable [""ACM_breathing_ChestInjury_State"", false]";
        callbackSuccess = "ACM_breathing_fnc_applyChestSeal";
        ACM_cancelRecovery = 1;
        ACM_menuIcon = "ACM_ChestSeal";
    };
    class PerformNCD: ApplyChestSeal {
        displayName = "$STR_ACM_breathing_PerformNCD";
        displayNameProgress = "$STR_ACM_breathing_PerformNCD_Progress";
        icon = "";
        treatmentLocations = 0;
        medicRequired = "ACM_breathing_allowNCD";
        treatmentTime = 5;
        allowSelfTreatment = 0;
        items[] = {"ACM_NCDKit"};
        consumeItem = 1;
        condition = "ACM_breathing_pneumothoraxEnabled && _patient getVariable [""ACM_breathing_ChestInjury_State"", false]";
        callbackSuccess = "ACM_breathing_fnc_performNCD";
        ACM_cancelRecovery = 1;
        ACM_menuIcon = "ACM_NCDKit";
    };
    class PerformThoracostomy: ApplyChestSeal {
        displayName = "$STR_ACM_breathing_PerformThoracostomy";
        displayNameProgress = "$STR_ACM_breathing_PerformThoracostomy_Progress";
        icon = "";
        treatmentLocations = "ACM_breathing_locationThoracostomy";
        medicRequired = "ACM_breathing_allowThoracostomy";
        treatmentTime = 5;
        allowSelfTreatment = 0;
        items[] = {"ACE_surgicalKit"};
        consumeItem = 0;
        condition = "ACM_breathing_pneumothoraxEnabled && (_patient getVariable [""ACM_breathing_ChestInjury_State"", false]) && (_patient getVariable [""ACM_breathing_Thoracostomy_State"", 0]) < 1";
        callbackSuccess = "[_medic, _patient, false] call ACM_breathing_fnc_Thoracostomy_start";
        ACM_cancelRecovery = 1;
        ACM_menuIcon = "ACE_surgicalKit";
    };
    class PerformThoracostomy_Kit: PerformThoracostomy {
        displayName = "$STR_ACM_breathing_PerformThoracostomy_Kit";
        items[] = {"ACM_ThoracostomyKit"};
        consumeItem = 1;
        callbackSuccess = "[_medic, _patient, true] call ACM_breathing_fnc_Thoracostomy_start";
        ACM_menuIcon = "ACM_ThoracostomyKit";
    };
    class InsertChestTube: PerformThoracostomy {
        displayName = "$STR_ACM_breathing_InsertChestTube";
        displayNameProgress = "$STR_ACM_breathing_InsertChestTube_Progress";
        icon = "";
        treatmentTime = 5;
        allowSelfTreatment = 0;
        items[] = {"ACM_ChestTubeKit"};
        consumeItem = 1;
        condition = "ACM_breathing_pneumothoraxEnabled && (_patient getVariable [""ACM_breathing_Thoracostomy_State"", 0]) == 1";
        callbackSuccess = "ACM_breathing_fnc_Thoracostomy_insertChestTube";
        ACM_menuIcon = "ACM_ChestTubeKit";
    };
    class ResealChestTube: InsertChestTube {
        displayName = "$STR_ACM_breathing_ResealChestTube";
        displayNameProgress = "$STR_ACM_breathing_ResealChestTube_Progress";
        items[] = {};
        consumeItem = 0;
        condition = "ACM_breathing_pneumothoraxEnabled && (_patient getVariable [""ACM_breathing_Thoracostomy_State"", 0]) == 3";
        callbackSuccess = "ACM_breathing_fnc_Thoracostomy_resealChestTube";
        ACM_menuIcon = "";
    };
    class DrainFluid_ACCUVAC: PerformThoracostomy {
        displayName = "$STR_ACM_breathing_DrainFluid_ACCUVAC";
        displayNameProgress = "$STR_ACM_breathing_DrainFluid_Suction_Progress";
        icon = "";
        treatmentTime = 5;
        allowSelfTreatment = 0;
        items[] = {"ACM_ACCUVAC"};
        consumeItem = 0;
        condition = "ACM_breathing_pneumothoraxEnabled && (_patient getVariable [""ACM_breathing_Thoracostomy_State"", 0]) in [2, 3]";
        callbackSuccess = "[_medic, _patient] call ACM_breathing_fnc_Thoracostomy_drain";
        ACM_menuIcon = "ACM_ACCUVAC";
    };
    class DrainFluid_SuctionBag: DrainFluid_ACCUVAC {
        displayName = "$STR_ACM_breathing_DrainFluid_SuctionBag";
        icon = "";
        treatmentTime = 8;
        items[] = {"ACM_SuctionBag"};
        consumeItem = 1;
        callbackSuccess = "[_medic, _patient, 0] call ACM_breathing_fnc_Thoracostomy_drain";
        ACM_menuIcon = "ACM_SuctionBag";
    };
    class CloseIncision: PerformThoracostomy {
        displayName = "$STR_ACM_breathing_CloseIncision";
        displayNameProgress = "$STR_ACM_breathing_CloseIncision_Progress";
        icon = "";
        treatmentLocations = 0;
        treatmentTime = 5;
        items[] = {};
        condition = "([_medic, _patient, ['ACE_surgicalKit']] call ace_medical_treatment_fnc_hasItem || (_patient getVariable [""ACM_breathing_Thoracostomy_UsedKit"", false])) && (_patient getVariable [""ACM_breathing_Thoracostomy_State"", 0]) > 0";
        callbackSuccess = "ACM_breathing_fnc_Thoracostomy_close";
        ACM_menuIcon = "";
    };
    class PlacePulseOximeter: CheckPulse {
        displayName = "$STR_ACM_breathing_PlacePulseOximeter";
        displayNameProgress = "$STR_ACM_breathing_PlacePulseOximeter_Progress";
        icon = "";
        category = "examine";
        treatmentLocations = 0;
        medicRequired = 0;
        treatmentTime = 2;
        allowedSelections[] = {"LeftArm", "RightArm"};
        items[] = {"ACM_PulseOximeter"};
        consumeItem = 1;
        condition = "ACM_breathing_fnc_canPlacePulseOximeter";
        callbackSuccess = "[_medic, _patient, _bodyPart] call ACM_breathing_fnc_setPulseOximeter";
        ACM_menuIcon = "ACM_PulseOximeter";
    };
    class RemovePulseOximeter: PlacePulseOximeter {
        displayName = "$STR_ACM_breathing_RemovePulseOximeter";
        displayNameProgress = "$STR_ACM_breathing_RemovePulseOximeter_Progress";
        icon = "";
        medicRequired = 0;
        treatmentTime = 1;
        items[] = {};
        consumeItem = 0;
        callbackSuccess = "[_medic, _patient, _bodyPart, false] call ACM_breathing_fnc_setPulseOximeter";
    };
};
class RscText;
class RscLine;
class RscStructuredText;
class RscButtonMenu;
class RscButton;
class RscPicture;
class ACM_breathing_Stethoscope_Dialog {
    idd = 81000;
    movingEnable = 0;
    onLoad = "";
    onUnload = "_this call ACME_fnc_stethoscopeClose;";
    objects[] = {};
    class ControlsBackground {
        class BodyBackground: RscPicture {
            idc = 81005;
            x = "((20 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2)) - ((180 * (((safeZoneW / safeZoneH) min 1.2) / 40)) / 2))";
            y = "((36 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2)) - ((135 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25)) / 2))";
            w = "(180 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(135 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            type = 0;
            size = 0;
            text = "\x\ACM\addons\gui\ui\body_background.paa";
        };
        class RightLung_Space: RscText {
            idc = 81010;
            x = "(12.5 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            y = "(-1.5 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
            w = "(5.8 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(10 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            colorBackground[] = {1, 1, 1, 0.5};
            show = 0;
        };
        class RightLung_Space_2: RightLung_Space {
            idc = 81011;
            x = "(10 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            y = "(3 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
            w = "(5 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(8 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
        };
        class LeftLung_Space: RightLung_Space {
            idc = 81012;
            x = "(22 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
        };
        class LeftLung_Space_2: RightLung_Space_2 {
            idc = 81013;
            x = "(25.5 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
        };
        class RightSide: RightLung_Space {
            idc = 81003;
            x = "(8.5 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            y = "(-5.3 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
            w = "(11.5 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(22 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            colorBackground[] = {0, 1, 0, 0.5};
            show = 0;
        };
        class LeftSide: RightSide {
            idc = 81004;
            x = "(20 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
        };
        class Bone_Sternum: RightLung_Space {
            idc = 81040;
            x = "(18 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            y = "(-1.5 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
            w = "(4 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(9 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            colorBackground[] = {1, 1, 0.5, 0.5};
        };
        class RightLung_Bronchial: RightLung_Space {
            idc = 81014;
            x = "(14.3 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            y = "(-5.2 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
            w = "(3 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(3 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            colorBackground[] = {0, 1, 0, 0.5};
        };
        class RightLung_BronchoVesticular: RightLung_Bronchial {
            idc = 81015;
            x = "(14 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            y = "(-0.2 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
        };
        class RightLung_Vesticular_Middle: RightLung_Bronchial {
            idc = 81016;
            x = "(11.5 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            y = "(4.8 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
        };
        class RightLung_Vesticular_Lower: RightLung_Bronchial {
            idc = 81017;
            x = "(10.6 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            y = "(9.8 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
        };
        class LeftLung_Bronchial: RightLung_Bronchial {
            idc = 81019;
            x = "(23 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
        };
        class LeftLung_BronchoVesticular: RightLung_BronchoVesticular {
            idc = 81020;
            x = "(23 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
        };
        class LeftLung_Vesticular_Middle: RightLung_Vesticular_Middle {
            idc = 81021;
            x = "(26.2 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
        };
        class LeftLung_Vesticular_Lower: RightLung_Vesticular_Lower {
            idc = 81022;
            x = "(27.4 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
        };
        class Heart_1: RightLung_Space {
            idc = 81030;
            x = "(16.6 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            y = "(0.3 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
            w = "(2 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(2 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            colorBackground[] = {1, 0, 0, 0.5};
        };
        class Heart_2: Heart_1 {
            idc = 81031;
            x = "(21.5 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
        };
        class Heart_3: Heart_1 {
            idc = 81032;
            x = "(21.7 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            y = "(2.4 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
        };
        class Heart_4: Heart_1 {
            idc = 81033;
            x = "(21.9 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            y = "(4.6 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
        };
        class Heart_Center: Heart_1 {
            idc = 81034;
            x = "(20 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            y = "(1 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
            w = "(1 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(1 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
        };
    };
    class Controls {
        class TopText: RscText {
            idc = -1;
            style = 2;
            font = "RobotoCondensed";
            x = "safeZoneX";
            y = "safeZoneY";
            w = "safeZoneW";
            h = "safeZoneH / 10";
            colorText[] = {1, 1, 1, 1};
            colorBackground[] = {0, 0, 0, 0};
            text = "Hold left mouse to listen and drag. Release to lift the bell.";
            lineSpacing = 0;
            sizeEx = "((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) * 1.4 * (0.55 / (getResolution select 5))";
            fixedWidth = 0;
            deletable = 0;
            fade = 0;
            access = 0;
            type = 0;
            shadow = 1;
            colorShadow[] = {0, 0, 0, 0.5};
        };
        class BottomText: TopText {
            idc = 81001;
            h = "safeZoneH / 6";
            text = "";
        };
        class ViewLabel: TopText {
            idc = 81007;
            x = 0;
            y = 0;
            w = 0;
            h = 0;
            sizeEx = "((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) * 0.8 * (0.55 / (getResolution select 5))";
            text = "";
        };
        class ChangeView: RscButton {
            idc = 81006;
            x = "safeZoneX + safeZoneW * 0.4625";
            y = "safeZoneY + safeZoneH * 0.92";
            w = "safeZoneW * 0.075";
            h = "safeZoneH * 0.045";
            text = "Flip Side";
            tooltip = "Turn the patient over (front / back)";
            onButtonClick = "[] call ACME_fnc_stethoscopeFlip;";
            colorBackground[] = {0.14, 0.2, 0.3, 0.9};
            colorText[] = {0.93, 0.89, 0.8, 1};
        };
        class Bell: RscPicture {
            idc = 81002;
            x = "(960 / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55)) / 2))";
            y = "(800 / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3)) / 2))";
            w = "(152 / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55))";
            h = "(152 / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3))";
            shadow = 0;
            text = "\x\ACM\addons\breathing\ui\stethoscope_bell.paa";
        };
    };
};
class RscTitles {
    class RscUseBVM {
        idd = 83000;
        fadein = 0;
        fadeout = 0;
        duration = 100000000000;
        onLoad = "uiNamespace setVariable ['ACM_UseBVM', (_this select 0)];";
        onUnLoad = "uiNamespace setVariable ['ACM_UseBVM', nil];";
        class Controls {
            class TopText: RscText {
                idc = 81001;
                style = 2;
                font = "RobotoCondensed";
                x = "safeZoneX";
                y = "safeZoneY";
                w = "safeZoneW";
                h = "safeZoneH / 10";
                colorText[] = {1, 1, 1, 1};
                colorBackground[] = {0, 0, 0, 0};
                text = "$STR_ACM_breathing_BVM_UsingBVM";
                lineSpacing = 0;
                sizeEx = "((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) * 1.4 * (0.55 / (getResolution select 5))";
                fixedWidth = 0;
                deletable = 0;
                fade = 0;
                access = 0;
                type = 0;
                shadow = 1;
                colorShadow[] = {0, 0, 0, 0.5};
            };
            class BottomText: TopText {
                idc = 81002;
                h = "safeZoneH / 6";
                text = "";
            };
        };
    };
};

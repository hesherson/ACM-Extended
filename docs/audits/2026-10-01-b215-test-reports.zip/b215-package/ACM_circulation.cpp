class CfgPatches {
    class ACM_circulation {
        acmeBuildBatch = "B215";
        acmeNetworkProtocol = 1;
        acmeComponent = "circulation";
        name = "ACM - Circulation";
        units[] = {};
        weapons[] = {
            "ACM_AED",
            "ACM_PressureCuff",
            "ACM_IV_16g",
            "ACM_IV_14g",
            "ACM_IO_FAST",
            "ACM_IO_EZ",
            "ACM_Syringe_10",
            "ACM_Syringe_5",
            "ACM_Syringe_3",
            "ACM_Syringe_1",
            "ACM_Vial_Epinephrine",
            "ACM_Vial_Adenosine",
            "ACM_Vial_Morphine",
            "ACM_Vial_Ketamine",
            "ACM_Vial_Lidocaine",
            "ACM_Vial_TXA",
            "ACM_Vial_Amiodarone",
            "ACM_Vial_Atropine",
            "ACM_Vial_Fentanyl",
            "ACM_Vial_Ondansetron",
            "ACM_Vial_CalciumChloride",
            "ACM_Vial_Ertapenem",
            "ACM_Vial_Esmolol",
            "ACM_Spray_Naloxone",
            "ACM_Lozenge_Fentanyl",
            "ACM_FieldBloodTransfusionKit_500",
            "ACM_FieldBloodTransfusionKit_250",
            "ACM_BloodBag_O_1000",
            "ACM_BloodBag_ON_1000",
            "ACM_BloodBag_A_1000",
            "ACM_BloodBag_AN_1000",
            "ACM_BloodBag_B_1000",
            "ACM_BloodBag_BN_1000",
            "ACM_BloodBag_AB_1000",
            "ACM_BloodBag_ABN_1000",
            "ACM_BloodBag_O_500",
            "ACM_BloodBag_ON_500",
            "ACM_BloodBag_A_500",
            "ACM_BloodBag_AN_500",
            "ACM_BloodBag_B_500",
            "ACM_BloodBag_BN_500",
            "ACM_BloodBag_AB_500",
            "ACM_BloodBag_ABN_500",
            "ACM_BloodBag_O_250",
            "ACM_BloodBag_ON_250",
            "ACM_BloodBag_A_250",
            "ACM_BloodBag_AN_250",
            "ACM_BloodBag_B_250",
            "ACM_BloodBag_BN_250",
            "ACM_BloodBag_AB_250",
            "ACM_BloodBag_ABN_250"
        };
        requiredVersion = 2.18;
        requiredAddons[] = {
            "cba_main",
            "ace_main",
            "ace_medical_treatment",
            "ACM_core"
        };
        author = "Blue";
        version = 1.2;
        versionStr = "1.2.4.1";
        versionAr[] = {1, 2, 4, 1};
    };
};
class Extended_PreInit_EventHandlers {
    class ACM_circulation {
        init = "call compileScript ['\x\ACM\addons\circulation\XEH_preInit.sqf']";
    };
};
class Extended_PostInit_EventHandlers {
    class ACM_circulation {
        init = "call compileScript ['\x\ACM\addons\circulation\XEH_postInit.sqf']";
    };
};
class CfgMagazines {
    class CA_Magazine;
    class ACE_painkillers: CA_Magazine {
        scope = 1;
    };
    class ACM_Paracetamol: CA_Magazine {
        scope = 2;
        author = "Blue";
        picture = "\x\ACM\addons\circulation\ui\paracetamol_ca.paa";
        displayName = "$STR_ACM_circulation_Paracetamol";
        descriptionShort = "$STR_ACM_circulation_Paracetamol_Desc";
        ACE_isMedicalItem = 1;
        ACE_asItem = 1;
        count = 10;
        mass = 0.3;
    };
    class ACM_Paracetamol_DoublePack: ACM_Paracetamol {
        scope = 1;
        picture = "\x\ACM\addons\circulation\ui\paracetamol_doublepack_ca.paa";
        displayName = "$STR_ACM_circulation_Paracetamol_DoublePack";
        count = 2;
        mass = 0.06;
    };
    class ACM_AmmoniaInhalant: ACM_Paracetamol {
        picture = "\x\ACM\addons\circulation\ui\inhalant_ammonia_ca.paa";
        displayName = "$STR_ACM_circulation_AmmoniaInhalant";
        descriptionShort = "$STR_ACM_circulation_AmmoniaInhalant_Desc";
        count = 8;
    };
    class ACM_Inhaler_Penthrox: ACM_Paracetamol {
        picture = "\x\ACM\addons\circulation\ui\inhaler_penthrox_ca.paa";
        displayName = "$STR_ACM_circulation_Inhaler_Penthrox";
        descriptionShort = "$STR_ACM_circulation_Inhaler_Penthrox_Desc";
        count = 8;
    };
    class ACM_Syringe_10_Epinephrine: ACM_Paracetamol {
        scope = 1;
        picture = "\x\ACM\addons\circulation\ui\syringe_10_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 10, localize 'STR_ACM_Circulation_Medication_Epinephrine']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 10, localize 'STR_ACM_Circulation_Medication_Epinephrine']");
        ACE_isMedicalItem = 1;
        ACE_asItem = 1;
        count = 1000;
        mass = 0.9;
        ACM_isSyringe = 1;
    };
    class ACM_Syringe_5_Epinephrine: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_5_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 5, localize 'STR_ACM_Circulation_Medication_Epinephrine']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 5, localize 'STR_ACM_Circulation_Medication_Epinephrine']");
        count = 500;
        mass = 0.7;
    };
    class ACM_Syringe_3_Epinephrine: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_3_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 3, localize 'STR_ACM_Circulation_Medication_Epinephrine']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 3, localize 'STR_ACM_Circulation_Medication_Epinephrine']");
        count = 300;
        mass = 0.6;
    };
    class ACM_Syringe_1_Epinephrine: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_1_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 1, localize 'STR_ACM_Circulation_Medication_Epinephrine']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 1, localize 'STR_ACM_Circulation_Medication_Epinephrine']");
        count = 100;
        mass = 0.5;
    };
    class ACM_Syringe_10_Morphine: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_10_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 10, localize 'STR_ACM_Circulation_Medication_Morphine']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 10, localize 'STR_ACM_Circulation_Medication_Morphine']");
        count = 1000;
        mass = 0.9;
    };
    class ACM_Syringe_5_Morphine: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_5_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 5, localize 'STR_ACM_Circulation_Medication_Morphine']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 5, localize 'STR_ACM_Circulation_Medication_Morphine']");
        count = 500;
        mass = 0.7;
    };
    class ACM_Syringe_3_Morphine: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_3_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 3, localize 'STR_ACM_Circulation_Medication_Morphine']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 3, localize 'STR_ACM_Circulation_Medication_Morphine']");
        count = 300;
        mass = 0.6;
    };
    class ACM_Syringe_1_Morphine: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_1_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 1, localize 'STR_ACM_Circulation_Medication_Morphine']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 1, localize 'STR_ACM_Circulation_Medication_Morphine']");
        count = 100;
        mass = 0.5;
    };
    class ACM_Syringe_10_Ketamine: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_10_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 10, localize 'STR_ACM_Circulation_Medication_Ketamine']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 10, localize 'STR_ACM_Circulation_Medication_Ketamine']");
        count = 1000;
        mass = 0.9;
    };
    class ACM_Syringe_5_Ketamine: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_5_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 5, localize 'STR_ACM_Circulation_Medication_Ketamine']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 5, localize 'STR_ACM_Circulation_Medication_Ketamine']");
        count = 500;
        mass = 0.7;
    };
    class ACM_Syringe_3_Ketamine: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_3_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 3, localize 'STR_ACM_Circulation_Medication_Ketamine']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 3, localize 'STR_ACM_Circulation_Medication_Ketamine']");
        count = 300;
        mass = 0.6;
    };
    class ACM_Syringe_1_Ketamine: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_1_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 1, localize 'STR_ACM_Circulation_Medication_Ketamine']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 1, localize 'STR_ACM_Circulation_Medication_Ketamine']");
        count = 100;
        mass = 0.5;
    };
    class ACM_Syringe_10_Adenosine: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_10_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 10, localize 'STR_ACM_Circulation_Medication_Adenosine']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 10, localize 'STR_ACM_Circulation_Medication_Adenosine']");
        count = 1000;
        mass = 0.9;
    };
    class ACM_Syringe_5_Adenosine: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_5_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 5, localize 'STR_ACM_Circulation_Medication_Adenosine']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 5, localize 'STR_ACM_Circulation_Medication_Adenosine']");
        count = 500;
        mass = 0.7;
    };
    class ACM_Syringe_3_Adenosine: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_3_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 3, localize 'STR_ACM_Circulation_Medication_Adenosine']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 3, localize 'STR_ACM_Circulation_Medication_Adenosine']");
        count = 300;
        mass = 0.6;
    };
    class ACM_Syringe_1_Adenosine: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_1_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 1, localize 'STR_ACM_Circulation_Medication_Adenosine']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 1, localize 'STR_ACM_Circulation_Medication_Adenosine']");
        count = 100;
        mass = 0.5;
    };
    class ACM_Syringe_10_Amiodarone: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_10_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 10, localize 'STR_ACM_Circulation_Medication_Amiodarone']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 10, localize 'STR_ACM_Circulation_Medication_Amiodarone']");
        count = 1000;
        mass = 0.9;
    };
    class ACM_Syringe_5_Amiodarone: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_5_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 5, localize 'STR_ACM_Circulation_Medication_Amiodarone']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 5, localize 'STR_ACM_Circulation_Medication_Amiodarone']");
        count = 500;
        mass = 0.7;
    };
    class ACM_Syringe_3_Amiodarone: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_3_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 3, localize 'STR_ACM_Circulation_Medication_Amiodarone']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 3, localize 'STR_ACM_Circulation_Medication_Amiodarone']");
        count = 300;
        mass = 0.6;
    };
    class ACM_Syringe_1_Amiodarone: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_1_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 1, localize 'STR_ACM_Circulation_Medication_Amiodarone']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 1, localize 'STR_ACM_Circulation_Medication_Amiodarone']");
        count = 100;
        mass = 0.5;
    };
    class ACM_Syringe_10_Atropine: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_10_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 10, localize 'STR_ACM_Circulation_Medication_Atropine']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 10, localize 'STR_ACM_Circulation_Medication_Atropine']");
        count = 1000;
        mass = 0.9;
    };
    class ACM_Syringe_5_Atropine: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_5_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 5, localize 'STR_ACM_Circulation_Medication_Atropine']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 5, localize 'STR_ACM_Circulation_Medication_Atropine']");
        count = 500;
        mass = 0.7;
    };
    class ACM_Syringe_3_Atropine: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_3_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 3, localize 'STR_ACM_Circulation_Medication_Atropine']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 3, localize 'STR_ACM_Circulation_Medication_Atropine']");
        count = 300;
        mass = 0.6;
    };
    class ACM_Syringe_1_Atropine: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_1_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 1, localize 'STR_ACM_Circulation_Medication_Atropine']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 1, localize 'STR_ACM_Circulation_Medication_Atropine']");
        count = 100;
        mass = 0.5;
    };
    class ACM_Syringe_10_Fentanyl: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_10_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 10, localize 'STR_ACM_Circulation_Medication_Fentanyl']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 10, localize 'STR_ACM_Circulation_Medication_Fentanyl']");
        count = 1000;
        mass = 0.9;
    };
    class ACM_Syringe_5_Fentanyl: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_5_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 5, localize 'STR_ACM_Circulation_Medication_Fentanyl']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 5, localize 'STR_ACM_Circulation_Medication_Fentanyl']");
        count = 500;
        mass = 0.7;
    };
    class ACM_Syringe_3_Fentanyl: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_3_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 3, localize 'STR_ACM_Circulation_Medication_Fentanyl']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 3, localize 'STR_ACM_Circulation_Medication_Fentanyl']");
        count = 300;
        mass = 0.6;
    };
    class ACM_Syringe_1_Fentanyl: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_1_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 1, localize 'STR_ACM_Circulation_Medication_Fentanyl']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 1, localize 'STR_ACM_Circulation_Medication_Fentanyl']");
        count = 100;
        mass = 0.5;
    };
    class ACM_Syringe_10_Ondansetron: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_10_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 10, localize 'STR_ACM_Circulation_Medication_Ondansetron']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 10, localize 'STR_ACM_Circulation_Medication_Ondansetron']");
        count = 1000;
        mass = 0.9;
    };
    class ACM_Syringe_5_Ondansetron: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_5_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 5, localize 'STR_ACM_Circulation_Medication_Ondansetron']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 5, localize 'STR_ACM_Circulation_Medication_Ondansetron']");
        count = 500;
        mass = 0.7;
    };
    class ACM_Syringe_3_Ondansetron: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_3_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 3, localize 'STR_ACM_Circulation_Medication_Ondansetron']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 3, localize 'STR_ACM_Circulation_Medication_Ondansetron']");
        count = 300;
        mass = 0.6;
    };
    class ACM_Syringe_1_Ondansetron: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_1_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 1, localize 'STR_ACM_Circulation_Medication_Ondansetron']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 1, localize 'STR_ACM_Circulation_Medication_Ondansetron']");
        count = 100;
        mass = 0.5;
    };
    class ACM_Syringe_10_TXA: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_10_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 10, localize 'STR_ACM_Circulation_Medication_TXA']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 10, localize 'STR_ACM_Circulation_Medication_TXA']");
        count = 1000;
        mass = 0.9;
    };
    class ACM_Syringe_5_TXA: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_5_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 5, localize 'STR_ACM_Circulation_Medication_TXA']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 5, localize 'STR_ACM_Circulation_Medication_TXA']");
        count = 500;
        mass = 0.7;
    };
    class ACM_Syringe_3_TXA: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_3_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 3, localize 'STR_ACM_Circulation_Medication_TXA']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 3, localize 'STR_ACM_Circulation_Medication_TXA']");
        count = 300;
        mass = 0.6;
    };
    class ACM_Syringe_1_TXA: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_1_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 1, localize 'STR_ACM_Circulation_Medication_TXA']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 1, localize 'STR_ACM_Circulation_Medication_TXA']");
        count = 100;
        mass = 0.5;
    };
    class ACM_Syringe_10_Lidocaine: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_10_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 10, localize 'STR_ACM_Circulation_Medication_Lidocaine']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 10, localize 'STR_ACM_Circulation_Medication_Lidocaine']");
        count = 1000;
        mass = 0.9;
    };
    class ACM_Syringe_5_Lidocaine: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_5_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 5, localize 'STR_ACM_Circulation_Medication_Lidocaine']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 5, localize 'STR_ACM_Circulation_Medication_Lidocaine']");
        count = 500;
        mass = 0.7;
    };
    class ACM_Syringe_3_Lidocaine: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_3_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 3, localize 'STR_ACM_Circulation_Medication_Lidocaine']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 3, localize 'STR_ACM_Circulation_Medication_Lidocaine']");
        count = 300;
        mass = 0.6;
    };
    class ACM_Syringe_1_Lidocaine: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_1_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 1, localize 'STR_ACM_Circulation_Medication_Lidocaine']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 1, localize 'STR_ACM_Circulation_Medication_Lidocaine']");
        count = 100;
        mass = 0.5;
    };
    class ACM_Syringe_10_CalciumChloride: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_10_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 10, localize 'STR_ACM_Circulation_Medication_CalciumChloride']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 10, localize 'STR_ACM_Circulation_Medication_CalciumChloride']");
        count = 1000;
        mass = 0.9;
    };
    class ACM_Syringe_5_CalciumChloride: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_5_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 5, localize 'STR_ACM_Circulation_Medication_CalciumChloride']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 5, localize 'STR_ACM_Circulation_Medication_CalciumChloride']");
        count = 500;
        mass = 0.7;
    };
    class ACM_Syringe_3_CalciumChloride: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_3_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 3, localize 'STR_ACM_Circulation_Medication_CalciumChloride']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 3, localize 'STR_ACM_Circulation_Medication_CalciumChloride']");
        count = 300;
        mass = 0.6;
    };
    class ACM_Syringe_1_CalciumChloride: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_1_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 1, localize 'STR_ACM_Circulation_Medication_CalciumChloride']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 1, localize 'STR_ACM_Circulation_Medication_CalciumChloride']");
        count = 100;
        mass = 0.5;
    };
    class ACM_Syringe_10_Ertapenem: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_10_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 10, localize 'STR_ACM_Circulation_Medication_Ertapenem']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 10, localize 'STR_ACM_Circulation_Medication_Ertapenem']");
        count = 1000;
        mass = 0.9;
    };
    class ACM_Syringe_5_Ertapenem: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_5_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 5, localize 'STR_ACM_Circulation_Medication_Ertapenem']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 5, localize 'STR_ACM_Circulation_Medication_Ertapenem']");
        count = 500;
        mass = 0.7;
    };
    class ACM_Syringe_3_Ertapenem: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_3_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 3, localize 'STR_ACM_Circulation_Medication_Ertapenem']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 3, localize 'STR_ACM_Circulation_Medication_Ertapenem']");
        count = 300;
        mass = 0.6;
    };
    class ACM_Syringe_1_Ertapenem: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_1_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 1, localize 'STR_ACM_Circulation_Medication_Ertapenem']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 1, localize 'STR_ACM_Circulation_Medication_Ertapenem']");
        count = 100;
        mass = 0.5;
    };
    class ACM_Syringe_10_Esmolol: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_10_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 10, localize 'STR_ACM_Circulation_Medication_Esmolol']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 10, localize 'STR_ACM_Circulation_Medication_Esmolol']");
        count = 1000;
        mass = 0.9;
    };
    class ACM_Syringe_5_Esmolol: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_5_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 5, localize 'STR_ACM_Circulation_Medication_Esmolol']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 5, localize 'STR_ACM_Circulation_Medication_Esmolol']");
        count = 500;
        mass = 0.7;
    };
    class ACM_Syringe_3_Esmolol: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_3_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 3, localize 'STR_ACM_Circulation_Medication_Esmolol']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 3, localize 'STR_ACM_Circulation_Medication_Esmolol']");
        count = 300;
        mass = 0.6;
    };
    class ACM_Syringe_1_Esmolol: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_1_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 1, localize 'STR_ACM_Circulation_Medication_Esmolol']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 1, localize 'STR_ACM_Circulation_Medication_Esmolol']");
        count = 100;
        mass = 0.5;
    };
    class ACM_Syringe_10_Dimercaprol: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_10_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 10, localize 'STR_ACM_Circulation_Medication_Dimercaprol']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 10, localize 'STR_ACM_Circulation_Medication_Dimercaprol']");
        count = 1000;
        mass = 0.9;
    };
    class ACM_Syringe_5_Dimercaprol: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_5_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 5, localize 'STR_ACM_Circulation_Medication_Dimercaprol']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 5, localize 'STR_ACM_Circulation_Medication_Dimercaprol']");
        count = 500;
        mass = 0.7;
    };
    class ACM_Syringe_3_Dimercaprol: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_3_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 3, localize 'STR_ACM_Circulation_Medication_Dimercaprol']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 3, localize 'STR_ACM_Circulation_Medication_Dimercaprol']");
        count = 300;
        mass = 0.6;
    };
    class ACM_Syringe_1_Dimercaprol: ACM_Syringe_10_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\syringe_1_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (%2ml) [%3]', localize 'STR_ACM_Circulation_Syringe', 1, localize 'STR_ACM_Circulation_Medication_Dimercaprol']");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_PreparedWith', 1, localize 'STR_ACM_Circulation_Medication_Dimercaprol']");
        count = 100;
        mass = 0.5;
    };
};
class CfgMovesBasic {
    class Default;
};
class CfgMovesMaleSdr: CfgMovesBasic {
    class States {
        class AmovPknlMstpSnonWnonDnon;
        class ACM_CPR: Default {
            file = "a3\anims_f\data\anim\sdr\inj\healing\ainvpknlmstpsnonwnondr_medic0.rtm";
            speed = 0.11;
            looped = 1;
            disableWeapons = 1;
            disableWeaponsLong = 1;
            showWeaponAim = 0;
            canPullTrigger = 0;
            duty = 0.2;
            limitGunMovement = 0;
            aiming = "empty";
            aimingBody = "empty";
            ConnectFrom[] = {"ACM_CPR", 0.1};
            ConnectTo[] = {
                "ACM_CPR",
                0.1,
                "AinvPknlMstpSnonWnonDnon_medicEnd",
                0.1,
                "AmovPknlMstpSnonWnonDnon",
                0.1
            };
            forceAim = 1;
            InterpolateTo[] = {
                "ACM_CPR",
                0.1,
                "AinvPknlMstpSnonWnonDnon_medicEnd",
                0.1,
                "AmovPknlMstpSnonWnonDnon",
                0.1,
                "Unconscious",
                0.02
            };
        };
        class ACM_CPR_Stop: Default {
            file = "\x\ACM\addons\circulation\anim\ACM_CPR_Stop.rtm";
            speed = -100;
            looped = 1;
            disableWeapons = 1;
            disableWeaponsLong = 1;
            showWeaponAim = 0;
            canPullTrigger = 0;
            duty = 0.2;
            limitGunMovement = 0;
            aiming = "empty";
            aimingBody = "empty";
            ConnectFrom[] = {"ACM_CPR", 0.1};
            ConnectTo[] = {
                "ACM_CPR",
                0.1,
                "AinvPknlMstpSnonWnonDnon_medicEnd",
                0.1,
                "AmovPknlMstpSnonWnonDnon",
                0.1
            };
            forceAim = 1;
            InterpolateTo[] = {
                "ACM_CPR",
                0.1,
                "AinvPknlMstpSnonWnonDnon_medicEnd",
                0.1,
                "AmovPknlMstpSnonWnonDnon",
                0.1,
                "Unconscious",
                0.02
            };
        };
    };
};
class CfgWeapons {
    class ACE_ItemCore;
    class CBA_MiscItem_ItemInfo;
    class ACM_AED: ACE_ItemCore {
        scope = 2;
        author = "Blue";
        picture = "\x\ACM\addons\circulation\ui\AED_ca.paa";
        displayName = "$STR_ACM_circulation_AED";
        descriptionShort = "$STR_ACM_circulation_AED_Desc";
        ACE_isMedicalItem = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 40;
        };
    };
    class ACM_PressureCuff: ACM_AED {
        picture = "\x\ACM\addons\circulation\ui\pressureCuff_ca.paa";
        displayName = "$STR_ACM_circulation_PressureCuff";
        descriptionShort = "$STR_ACM_circulation_PressureCuff_Desc";
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 4;
        };
    };
    class ACM_IV_16g: ACE_ItemCore {
        scope = 2;
        author = "Blue";
        picture = "\x\ACM\addons\circulation\ui\iv_16g_ca.paa";
        displayName = "$STR_ACM_circulation_IV_16g";
        descriptionShort = "$STR_ACM_circulation_IV_16g_Desc";
        ACE_isMedicalItem = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 0.2;
        };
    };
    class ACM_IV_14g: ACM_IV_16g {
        picture = "\x\ACM\addons\circulation\ui\iv_14g_ca.paa";
        displayName = "$STR_ACM_circulation_IV_14g";
        descriptionShort = "$STR_ACM_circulation_IV_14g_Desc";
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 0.5;
        };
    };
    class ACM_IO_FAST: ACM_IV_16g {
        picture = "\x\ACM\addons\circulation\ui\io_fast1_ca.paa";
        displayName = "$STR_ACM_circulation_IO_FAST1";
        descriptionShort = "$STR_ACM_circulation_IO_FAST1_Desc";
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 0.3;
        };
    };
    class ACM_IO_EZ: ACM_IV_16g {
        picture = "\x\ACM\addons\circulation\ui\IO_EZ_ca.paa";
        displayName = "$STR_ACM_circulation_IO_EZ";
        descriptionShort = "$STR_ACM_circulation_IO_EZ_Desc";
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 0.2;
        };
    };
    class ACM_Syringe_10: ACE_ItemCore {
        scope = 2;
        author = "Blue";
        picture = "\x\ACM\addons\circulation\ui\syringe_10_ca.paa";
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_%1', 10]");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Desc_%1', 10]");
        ACE_isMedicalItem = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 0.9;
        };
    };
    class ACM_Syringe_5: ACM_Syringe_10 {
        picture = "\x\ACM\addons\circulation\ui\syringe_5_ca.paa";
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_%1', 5]");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Desc_%1', 5]");
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 0.7;
        };
    };
    class ACM_Syringe_3: ACM_Syringe_10 {
        picture = "\x\ACM\addons\circulation\ui\syringe_3_ca.paa";
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_%1', 3]");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Desc_%1', 3]");
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 0.6;
        };
    };
    class ACM_Syringe_1: ACM_Syringe_10 {
        picture = "\x\ACM\addons\circulation\ui\syringe_1_ca.paa";
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_%1', 1]");
        descriptionShort = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Syringe_Desc_%1', 1]");
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 0.5;
        };
    };
    class ACM_Vial_Epinephrine: ACE_ItemCore {
        scope = 2;
        author = "Blue";
        picture = "\x\ACM\addons\circulation\ui\vial_epinephrine_ca.paa";
        displayName = "$STR_ACM_circulation_Vial_Epinephrine";
        descriptionShort = "$STR_ACM_circulation_Vial_Epinephrine_Desc";
        ACE_isMedicalItem = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 0.2;
        };
        ACM_isVial = 1;
    };
    class ACM_Vial_Adenosine: ACM_Vial_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\vial_adenosine_ca.paa";
        displayName = "$STR_ACM_circulation_Vial_Adenosine";
        descriptionShort = "$STR_ACM_circulation_Vial_Adenosine_Desc";
    };
    class ACM_Vial_Morphine: ACM_Vial_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\vial_morphine_ca.paa";
        displayName = "$STR_ACM_circulation_Vial_Morphine";
        descriptionShort = "$STR_ACM_circulation_Vial_Morphine_Desc";
    };
    class ACM_Vial_Ketamine: ACM_Vial_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\vial_ketamine_ca.paa";
        displayName = "$STR_ACM_circulation_Vial_Ketamine";
        descriptionShort = "$STR_ACM_circulation_Vial_Ketamine_Desc";
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 0.2;
        };
    };
    class ACM_Vial_Lidocaine: ACM_Vial_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\vial_lidocaine_ca.paa";
        displayName = "$STR_ACM_circulation_Vial_Lidocaine";
        descriptionShort = "$STR_ACM_circulation_Vial_Lidocaine_Desc";
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 0.2;
        };
    };
    class ACM_Vial_TXA: ACM_Vial_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\vial_txa_ca.paa";
        displayName = "$STR_ACM_circulation_Vial_TXA";
        descriptionShort = "$STR_ACM_circulation_Vial_TXA_Desc";
    };
    class ACM_Vial_Amiodarone: ACM_Vial_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\vial_amiodarone_ca.paa";
        displayName = "$STR_ACM_circulation_Vial_Amiodarone";
        descriptionShort = "$STR_ACM_circulation_Vial_Amiodarone_Desc";
    };
    class ACM_Vial_Atropine: ACM_Vial_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\vial_atropine_ca.paa";
        displayName = "$STR_ACM_circulation_Vial_Atropine";
        descriptionShort = "$STR_ACM_circulation_Vial_Atropine_Desc";
    };
    class ACM_Vial_Fentanyl: ACM_Vial_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\vial_fentanyl_ca.paa";
        displayName = "$STR_ACM_circulation_Vial_Fentanyl";
        descriptionShort = "$STR_ACM_circulation_Vial_Fentanyl_Desc";
    };
    class ACM_Vial_Ondansetron: ACM_Vial_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\vial_ondansetron_ca.paa";
        displayName = "$STR_ACM_circulation_Vial_Ondansetron";
        descriptionShort = "$STR_ACM_circulation_Vial_Ondansetron_Desc";
    };
    class ACM_Vial_CalciumChloride: ACM_Vial_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\vial_calciumchloride_ca.paa";
        displayName = "$STR_ACM_circulation_Vial_CalciumChloride";
        descriptionShort = "$STR_ACM_circulation_Vial_CalciumChloride_Desc";
    };
    class ACM_Vial_Ertapenem: ACM_Vial_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\vial_ertapenem_ca.paa";
        displayName = "$STR_ACM_circulation_Vial_Ertapenem";
        descriptionShort = "$STR_ACM_circulation_Vial_Ertapenem_Desc";
    };
    class ACM_Vial_Esmolol: ACM_Vial_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\vial_esmolol_ca.paa";
        displayName = "$STR_ACM_circulation_Vial_Esmolol";
        descriptionShort = "$STR_ACM_circulation_Vial_Esmolol_Desc";
    };
    class ACM_Spray_Naloxone: ACM_Vial_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\spray_naloxone_ca.paa";
        displayName = "$STR_ACM_circulation_Spray_Naloxone";
        descriptionShort = "$STR_ACM_circulation_Spray_Naloxone_Desc";
        ACM_isVial = 0;
    };
    class ACM_Lozenge_Fentanyl: ACM_Vial_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\lozenge_fentanyl_ca.paa";
        displayName = "$STR_ACM_circulation_Lozenge_Fentanyl";
        descriptionShort = "$STR_ACM_circulation_Lozenge_Fentanyl_Desc";
        ACM_isVial = 0;
    };
    class ACM_Ampule_Dimercaprol: ACM_Vial_Epinephrine {
        picture = "\x\ACM\addons\circulation\ui\ampule_dimercaprol_ca.paa";
        displayName = "$STR_ACM_circulation_Ampule_Dimercaprol";
        descriptionShort = "$STR_ACM_circulation_Ampule_Dimercaprol_Desc";
        scope = 1;
    };
    class ACM_Paracetamol_SinglePack: ACM_Spray_Naloxone {
        scope = 1;
        picture = "\x\ACM\addons\circulation\ui\paracetamol_singlepack_ca.paa";
        displayName = "$STR_ACM_circulation_Paracetamol_SinglePack";
        descriptionShort = "$STR_ACM_circulation_Paracetamol_Desc";
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 0.03;
        };
    };
    class ACM_FieldBloodTransfusionKit_500: ACE_ItemCore {
        scope = 2;
        author = "Blue";
        picture = "\x\ACM\addons\circulation\ui\fieldBloodTransfusionKit_ca.paa";
        displayName = __EVAL(call compile "format ['%1 (500ml)', localize 'STR_ACM_Circulation_FieldBloodTransfusionKit']");
        shortName = __EVAL(call compile "format ['%1 (500ml)', localize 'STR_ACM_Circulation_FieldBloodTransfusionKit_Short']");
        descriptionShort = "$STR_ACM_circulation_FieldBloodTransfusionKit_Desc";
        ACE_isMedicalItem = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 1;
        };
    };
    class ACM_FieldBloodTransfusionKit_250: ACM_FieldBloodTransfusionKit_500 {
        displayName = __EVAL(call compile "format ['%1 (250ml)', localize 'STR_ACM_Circulation_FieldBloodTransfusionKit']");
        shortName = __EVAL(call compile "format ['%1 (250ml)', localize 'STR_ACM_Circulation_FieldBloodTransfusionKit_Short']");
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 0.5;
        };
    };
    class ACE_adenosine: ACE_ItemCore {
        scope = 1;
    };
    class ACE_morphine: ACE_ItemCore {
        picture = "\x\ACM\addons\core\ui\override\morphine_ca.paa";
    };
    class ACE_bloodIV: ACE_ItemCore {
        scope = 1;
    };
    class ACM_BloodBag_O_1000: ACE_bloodIV {
        scope = 2;
        author = "Blue";
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_BloodBag', 'O+ (1000ml)']");
        descriptionShort = "$STR_ACM_circulation_BloodBag_Desc";
    };
    class ACM_BloodBag_ON_1000: ACM_BloodBag_O_1000 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_BloodBag', 'O- (1000ml)']");
    };
    class ACM_BloodBag_A_1000: ACM_BloodBag_O_1000 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_BloodBag', 'A+ (1000ml)']");
    };
    class ACM_BloodBag_AN_1000: ACM_BloodBag_O_1000 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_BloodBag', 'A- (1000ml)']");
    };
    class ACM_BloodBag_B_1000: ACM_BloodBag_O_1000 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_BloodBag', 'B+ (1000ml)']");
    };
    class ACM_BloodBag_BN_1000: ACM_BloodBag_O_1000 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_BloodBag', 'B- (1000ml)']");
    };
    class ACM_BloodBag_AB_1000: ACM_BloodBag_O_1000 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_BloodBag', 'AB+ (1000ml)']");
    };
    class ACM_BloodBag_ABN_1000: ACM_BloodBag_O_1000 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_BloodBag', 'AB- (1000ml)']");
    };
    class ACE_bloodIV_500: ACE_bloodIV {
        scope = 1;
    };
    class ACM_BloodBag_O_500: ACE_bloodIV_500 {
        scope = 2;
        author = "Blue";
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_BloodBag', 'O+ (500ml)']");
        descriptionShort = "$STR_ACM_circulation_BloodBag_Desc";
    };
    class ACM_BloodBag_ON_500: ACM_BloodBag_O_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_BloodBag', 'O- (500ml)']");
    };
    class ACM_BloodBag_A_500: ACM_BloodBag_O_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_BloodBag', 'A+ (500ml)']");
    };
    class ACM_BloodBag_AN_500: ACM_BloodBag_O_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_BloodBag', 'A- (500ml)']");
    };
    class ACM_BloodBag_B_500: ACM_BloodBag_O_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_BloodBag', 'B+ (500ml)']");
    };
    class ACM_BloodBag_BN_500: ACM_BloodBag_O_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_BloodBag', 'B- (500ml)']");
    };
    class ACM_BloodBag_AB_500: ACM_BloodBag_O_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_BloodBag', 'AB+ (500ml)']");
    };
    class ACM_BloodBag_ABN_500: ACM_BloodBag_O_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_BloodBag', 'AB- (500ml)']");
    };
    class ACE_bloodIV_250: ACE_bloodIV {
        scope = 1;
    };
    class ACM_BloodBag_O_250: ACE_bloodIV_250 {
        scope = 2;
        author = "Blue";
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_BloodBag', 'O+ (250ml)']");
        descriptionShort = "$STR_ACM_circulation_BloodBag_Desc";
    };
    class ACM_BloodBag_ON_250: ACM_BloodBag_O_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_BloodBag', 'O- (250ml)']");
    };
    class ACM_BloodBag_A_250: ACM_BloodBag_O_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_BloodBag', 'A+ (250ml)']");
    };
    class ACM_BloodBag_AN_250: ACM_BloodBag_O_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_BloodBag', 'A- (250ml)']");
    };
    class ACM_BloodBag_B_250: ACM_BloodBag_O_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_BloodBag', 'B+ (250ml)']");
    };
    class ACM_BloodBag_BN_250: ACM_BloodBag_O_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_BloodBag', 'B- (250ml)']");
    };
    class ACM_BloodBag_AB_250: ACM_BloodBag_O_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_BloodBag', 'AB+ (250ml)']");
    };
    class ACM_BloodBag_ABN_250: ACM_BloodBag_O_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_BloodBag', 'AB- (250ml)']");
    };
    class ACM_FreshBloodBag_500: ACE_bloodIV_500 {
        scope = 1;
        author = "Blue";
        picture = "\x\ACM\addons\circulation\ui\fieldBloodTransfusionKit_Full_ca.paa";
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [0]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [0]']");
        descriptionShort = "$STR_ACM_circulation_BloodBag_Desc";
    };
    class ACM_FreshBloodBag_500_1: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [1]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [1]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_2: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [2]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [2]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_3: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [3]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [3]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_4: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [4]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [4]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_5: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [5]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [5]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_6: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [6]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [6]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_7: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [7]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [7]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_8: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [8]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [8]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_9: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [9]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [9]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_10: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [10]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [10]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_11: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [11]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [11]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_12: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [12]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [12]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_13: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [13]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [13]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_14: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [14]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [14]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_15: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [15]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [15]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_16: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [16]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [16]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_17: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [17]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [17]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_18: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [18]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [18]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_19: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [19]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [19]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_20: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [20]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [20]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_21: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [21]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [21]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_22: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [22]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [22]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_23: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [23]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [23]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_24: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [24]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [24]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_25: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [25]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [25]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_26: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [26]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [26]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_27: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [27]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [27]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_28: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [28]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [28]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_29: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [29]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [29]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_30: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [30]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [30]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_31: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [31]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [31]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_32: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [32]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [32]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_33: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [33]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [33]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_34: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [34]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [34]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_35: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [35]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [35]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_36: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [36]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [36]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_37: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [37]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [37]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_38: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [38]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [38]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_39: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [39]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [39]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_40: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [40]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [40]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_41: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [41]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [41]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_42: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [42]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [42]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_43: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [43]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [43]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_44: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [44]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [44]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_45: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [45]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [45]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_46: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [46]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [46]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_47: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [47]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [47]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_48: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [48]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [48]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_49: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [49]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [49]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_50: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [50]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [50]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_51: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [51]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [51]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_52: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [52]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [52]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_53: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [53]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [53]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_54: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [54]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [54]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_55: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [55]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [55]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_56: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [56]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [56]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_57: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [57]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [57]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_58: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [58]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [58]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_59: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [59]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [59]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_60: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [60]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [60]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_61: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [61]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [61]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_62: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [62]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [62]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_63: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [63]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [63]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_64: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [64]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [64]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_65: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [65]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [65]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_66: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [66]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [66]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_67: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [67]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [67]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_68: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [68]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [68]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_69: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [69]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [69]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_70: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [70]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [70]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_71: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [71]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [71]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_72: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [72]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [72]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_73: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [73]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [73]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_74: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [74]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [74]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_75: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [75]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [75]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_76: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [76]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [76]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_77: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [77]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [77]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_78: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [78]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [78]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_79: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [79]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [79]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_80: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [80]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [80]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_81: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [81]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [81]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_82: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [82]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [82]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_83: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [83]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [83]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_84: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [84]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [84]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_85: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [85]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [85]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_86: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [86]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [86]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_87: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [87]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [87]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_88: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [88]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [88]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_89: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [89]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [89]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_90: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [90]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [90]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_91: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [91]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [91]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_92: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [92]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [92]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_93: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [93]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [93]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_94: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [94]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [94]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_95: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [95]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [95]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_96: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [96]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [96]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_97: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [97]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [97]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_98: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [98]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [98]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_99: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [99]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [99]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_100: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [100]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [100]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_101: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [101]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [101]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_102: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [102]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [102]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_103: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [103]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [103]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_104: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [104]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [104]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_105: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [105]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [105]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_106: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [106]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [106]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_107: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [107]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [107]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_108: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [108]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [108]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_109: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [109]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [109]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_110: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [110]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [110]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_111: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [111]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [111]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_112: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [112]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [112]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_113: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [113]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [113]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_114: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [114]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [114]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_115: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [115]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [115]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_116: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [116]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [116]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_117: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [117]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [117]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_118: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [118]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [118]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_119: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [119]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [119]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_120: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [120]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [120]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_121: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [121]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [121]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_122: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [122]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [122]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_123: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [123]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [123]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_124: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [124]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [124]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_125: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [125]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [125]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_126: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [126]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [126]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_127: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [127]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [127]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_128: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [128]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [128]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_129: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [129]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [129]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_130: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [130]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [130]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_131: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [131]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [131]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_132: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [132]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [132]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_133: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [133]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [133]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_134: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [134]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [134]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_135: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [135]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [135]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_136: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [136]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [136]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_137: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [137]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [137]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_138: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [138]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [138]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_139: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [139]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [139]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_140: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [140]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [140]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_141: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [141]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [141]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_142: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [142]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [142]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_143: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [143]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [143]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_144: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [144]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [144]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_145: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [145]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [145]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_146: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [146]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [146]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_147: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [147]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [147]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_148: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [148]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [148]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_149: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [149]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [149]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_150: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [150]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [150]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_151: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [151]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [151]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_152: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [152]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [152]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_153: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [153]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [153]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_154: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [154]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [154]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_155: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [155]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [155]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_156: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [156]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [156]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_157: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [157]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [157]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_158: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [158]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [158]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_159: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [159]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [159]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_160: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [160]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [160]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_161: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [161]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [161]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_162: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [162]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [162]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_163: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [163]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [163]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_164: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [164]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [164]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_165: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [165]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [165]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_166: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [166]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [166]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_167: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [167]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [167]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_168: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [168]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [168]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_169: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [169]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [169]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_170: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [170]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [170]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_171: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [171]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [171]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_172: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [172]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [172]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_173: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [173]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [173]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_174: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [174]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [174]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_175: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [175]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [175]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_176: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [176]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [176]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_177: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [177]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [177]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_178: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [178]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [178]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_179: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [179]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [179]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_180: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [180]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [180]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_181: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [181]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [181]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_182: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [182]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [182]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_183: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [183]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [183]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_184: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [184]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [184]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_185: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [185]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [185]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_186: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [186]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [186]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_187: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [187]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [187]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_188: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [188]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [188]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_189: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [189]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [189]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_190: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [190]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [190]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_191: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [191]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [191]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_192: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [192]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [192]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_193: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [193]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [193]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_194: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [194]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [194]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_195: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [195]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [195]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_196: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [196]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [196]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_197: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [197]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [197]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_198: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [198]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [198]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_199: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [199]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [199]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_200: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [200]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [200]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_201: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [201]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [201]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_202: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [202]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [202]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_203: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [203]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [203]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_204: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [204]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [204]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_205: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [205]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [205]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_206: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [206]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [206]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_207: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [207]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [207]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_208: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [208]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [208]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_209: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [209]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [209]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_210: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [210]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [210]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_211: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [211]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [211]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_212: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [212]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [212]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_213: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [213]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [213]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_214: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [214]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [214]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_215: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [215]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [215]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_216: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [216]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [216]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_217: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [217]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [217]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_218: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [218]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [218]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_219: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [219]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [219]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_220: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [220]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [220]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_221: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [221]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [221]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_222: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [222]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [222]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_223: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [223]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [223]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_224: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [224]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [224]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_225: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [225]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [225]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_226: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [226]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [226]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_227: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [227]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [227]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_228: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [228]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [228]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_229: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [229]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [229]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_230: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [230]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [230]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_231: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [231]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [231]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_232: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [232]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [232]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_233: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [233]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [233]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_234: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [234]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [234]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_235: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [235]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [235]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_236: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [236]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [236]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_237: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [237]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [237]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_238: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [238]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [238]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_239: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [239]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [239]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_240: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [240]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [240]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_241: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [241]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [241]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_242: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [242]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [242]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_243: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [243]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [243]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_244: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [244]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [244]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_245: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [245]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [245]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_246: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [246]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [246]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_247: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [247]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [247]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_248: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [248]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [248]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_249: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [249]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [249]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_250: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [250]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [250]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_251: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [251]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [251]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_252: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [252]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [252]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_253: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [253]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [253]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_254: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [254]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [254]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_255: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [255]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [255]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_256: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [256]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [256]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_257: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [257]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [257]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_258: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [258]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [258]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_259: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [259]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [259]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_260: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [260]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [260]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_261: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [261]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [261]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_262: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [262]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [262]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_263: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [263]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [263]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_264: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [264]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [264]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_265: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [265]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [265]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_266: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [266]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [266]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_267: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [267]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [267]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_268: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [268]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [268]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_269: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [269]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [269]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_270: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [270]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [270]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_271: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [271]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [271]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_272: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [272]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [272]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_273: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [273]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [273]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_274: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [274]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [274]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_275: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [275]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [275]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_276: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [276]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [276]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_277: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [277]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [277]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_278: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [278]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [278]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_279: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [279]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [279]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_280: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [280]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [280]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_281: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [281]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [281]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_282: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [282]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [282]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_283: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [283]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [283]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_284: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [284]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [284]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_285: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [285]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [285]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_286: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [286]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [286]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_287: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [287]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [287]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_288: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [288]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [288]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_289: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [289]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [289]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_290: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [290]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [290]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_291: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [291]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [291]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_292: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [292]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [292]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_293: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [293]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [293]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_294: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [294]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [294]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_295: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [295]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [295]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_296: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [296]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [296]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_297: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [297]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [297]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_298: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [298]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [298]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_299: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [299]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [299]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_300: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [300]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [300]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_301: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [301]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [301]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_302: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [302]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [302]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_303: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [303]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [303]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_304: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [304]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [304]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_305: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [305]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [305]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_306: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [306]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [306]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_307: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [307]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [307]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_308: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [308]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [308]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_309: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [309]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [309]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_310: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [310]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [310]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_311: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [311]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [311]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_312: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [312]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [312]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_313: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [313]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [313]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_314: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [314]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [314]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_315: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [315]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [315]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_316: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [316]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [316]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_317: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [317]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [317]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_318: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [318]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [318]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_319: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [319]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [319]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_320: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [320]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [320]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_321: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [321]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [321]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_322: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [322]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [322]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_323: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [323]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [323]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_324: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [324]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [324]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_325: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [325]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [325]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_326: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [326]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [326]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_327: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [327]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [327]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_328: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [328]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [328]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_329: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [329]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [329]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_330: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [330]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [330]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_331: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [331]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [331]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_332: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [332]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [332]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_333: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [333]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [333]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_334: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [334]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [334]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_335: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [335]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [335]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_336: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [336]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [336]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_337: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [337]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [337]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_338: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [338]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [338]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_339: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [339]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [339]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_340: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [340]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [340]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_341: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [341]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [341]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_342: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [342]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [342]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_343: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [343]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [343]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_344: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [344]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [344]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_345: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [345]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [345]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_346: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [346]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [346]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_347: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [347]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [347]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_348: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [348]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [348]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_349: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [349]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [349]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_350: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [350]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [350]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_351: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [351]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [351]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_352: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [352]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [352]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_353: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [353]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [353]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_354: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [354]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [354]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_355: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [355]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [355]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_356: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [356]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [356]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_357: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [357]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [357]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_358: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [358]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [358]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_359: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [359]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [359]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_360: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [360]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [360]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_361: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [361]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [361]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_362: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [362]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [362]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_363: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [363]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [363]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_364: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [364]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [364]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_365: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [365]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [365]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_366: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [366]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [366]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_367: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [367]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [367]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_368: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [368]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [368]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_369: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [369]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [369]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_370: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [370]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [370]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_371: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [371]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [371]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_372: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [372]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [372]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_373: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [373]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [373]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_374: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [374]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [374]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_375: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [375]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [375]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_376: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [376]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [376]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_377: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [377]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [377]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_378: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [378]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [378]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_379: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [379]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [379]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_380: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [380]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [380]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_381: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [381]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [381]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_382: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [382]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [382]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_383: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [383]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [383]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_384: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [384]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [384]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_385: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [385]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [385]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_386: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [386]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [386]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_387: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [387]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [387]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_388: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [388]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [388]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_389: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [389]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [389]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_390: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [390]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [390]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_391: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [391]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [391]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_392: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [392]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [392]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_393: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [393]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [393]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_394: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [394]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [394]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_395: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [395]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [395]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_396: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [396]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [396]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_397: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [397]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [397]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_398: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [398]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [398]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_399: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [399]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [399]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_400: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [400]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [400]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_401: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [401]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [401]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_402: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [402]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [402]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_403: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [403]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [403]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_404: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [404]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [404]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_405: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [405]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [405]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_406: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [406]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [406]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_407: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [407]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [407]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_408: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [408]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [408]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_409: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [409]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [409]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_410: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [410]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [410]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_411: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [411]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [411]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_412: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [412]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [412]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_413: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [413]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [413]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_414: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [414]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [414]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_415: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [415]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [415]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_416: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [416]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [416]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_417: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [417]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [417]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_418: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [418]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [418]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_419: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [419]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [419]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_420: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [420]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [420]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_421: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [421]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [421]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_422: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [422]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [422]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_423: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [423]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [423]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_424: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [424]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [424]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_425: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [425]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [425]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_426: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [426]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [426]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_427: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [427]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [427]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_428: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [428]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [428]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_429: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [429]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [429]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_430: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [430]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [430]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_431: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [431]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [431]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_432: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [432]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [432]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_433: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [433]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [433]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_434: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [434]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [434]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_435: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [435]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [435]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_436: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [436]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [436]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_437: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [437]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [437]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_438: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [438]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [438]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_439: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [439]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [439]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_440: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [440]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [440]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_441: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [441]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [441]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_442: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [442]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [442]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_443: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [443]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [443]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_444: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [444]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [444]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_445: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [445]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [445]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_446: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [446]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [446]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_447: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [447]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [447]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_448: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [448]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [448]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_449: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [449]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [449]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_450: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [450]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [450]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_451: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [451]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [451]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_452: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [452]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [452]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_453: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [453]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [453]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_454: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [454]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [454]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_455: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [455]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [455]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_456: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [456]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [456]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_457: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [457]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [457]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_458: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [458]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [458]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_459: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [459]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [459]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_460: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [460]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [460]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_461: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [461]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [461]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_462: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [462]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [462]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_463: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [463]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [463]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_464: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [464]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [464]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_465: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [465]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [465]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_466: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [466]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [466]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_467: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [467]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [467]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_468: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [468]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [468]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_469: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [469]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [469]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_470: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [470]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [470]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_471: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [471]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [471]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_472: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [472]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [472]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_473: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [473]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [473]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_474: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [474]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [474]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_475: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [475]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [475]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_476: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [476]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [476]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_477: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [477]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [477]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_478: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [478]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [478]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_479: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [479]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [479]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_480: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [480]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [480]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_481: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [481]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [481]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_482: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [482]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [482]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_483: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [483]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [483]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_484: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [484]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [484]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_485: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [485]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [485]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_486: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [486]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [486]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_487: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [487]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [487]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_488: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [488]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [488]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_489: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [489]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [489]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_490: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [490]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [490]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_491: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [491]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [491]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_492: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [492]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [492]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_493: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [493]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [493]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_494: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [494]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [494]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_495: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [495]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [495]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_496: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [496]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [496]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_497: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [497]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [497]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_498: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [498]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [498]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_499: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [499]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [499]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_500: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [500]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [500]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_501: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [501]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [501]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_502: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [502]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [502]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_503: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [503]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [503]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_504: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [504]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [504]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_505: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [505]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [505]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_506: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [506]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [506]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_507: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [507]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [507]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_508: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [508]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [508]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_509: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [509]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [509]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_510: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [510]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [510]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_511: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [511]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [511]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_500_512: ACM_FreshBloodBag_500 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(500ml) [512]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(500ml) [512]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250: ACE_bloodIV_250 {
        scope = 1;
        author = "Blue";
        picture = "\x\ACM\addons\circulation\ui\fieldBloodTransfusionKit_Full_ca.paa";
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [0]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [0]']");
        descriptionShort = "$STR_ACM_circulation_BloodBag_Desc";
    };
    class ACM_FreshBloodBag_250_1: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [1]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [1]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_2: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [2]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [2]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_3: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [3]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [3]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_4: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [4]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [4]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_5: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [5]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [5]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_6: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [6]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [6]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_7: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [7]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [7]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_8: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [8]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [8]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_9: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [9]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [9]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_10: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [10]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [10]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_11: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [11]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [11]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_12: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [12]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [12]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_13: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [13]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [13]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_14: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [14]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [14]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_15: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [15]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [15]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_16: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [16]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [16]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_17: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [17]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [17]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_18: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [18]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [18]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_19: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [19]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [19]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_20: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [20]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [20]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_21: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [21]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [21]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_22: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [22]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [22]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_23: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [23]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [23]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_24: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [24]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [24]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_25: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [25]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [25]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_26: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [26]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [26]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_27: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [27]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [27]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_28: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [28]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [28]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_29: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [29]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [29]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_30: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [30]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [30]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_31: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [31]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [31]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_32: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [32]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [32]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_33: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [33]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [33]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_34: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [34]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [34]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_35: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [35]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [35]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_36: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [36]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [36]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_37: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [37]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [37]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_38: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [38]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [38]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_39: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [39]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [39]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_40: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [40]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [40]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_41: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [41]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [41]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_42: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [42]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [42]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_43: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [43]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [43]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_44: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [44]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [44]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_45: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [45]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [45]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_46: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [46]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [46]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_47: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [47]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [47]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_48: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [48]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [48]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_49: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [49]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [49]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_50: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [50]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [50]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_51: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [51]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [51]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_52: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [52]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [52]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_53: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [53]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [53]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_54: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [54]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [54]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_55: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [55]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [55]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_56: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [56]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [56]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_57: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [57]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [57]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_58: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [58]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [58]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_59: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [59]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [59]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_60: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [60]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [60]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_61: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [61]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [61]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_62: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [62]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [62]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_63: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [63]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [63]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_64: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [64]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [64]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_65: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [65]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [65]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_66: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [66]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [66]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_67: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [67]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [67]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_68: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [68]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [68]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_69: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [69]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [69]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_70: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [70]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [70]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_71: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [71]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [71]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_72: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [72]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [72]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_73: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [73]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [73]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_74: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [74]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [74]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_75: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [75]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [75]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_76: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [76]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [76]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_77: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [77]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [77]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_78: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [78]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [78]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_79: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [79]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [79]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_80: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [80]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [80]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_81: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [81]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [81]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_82: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [82]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [82]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_83: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [83]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [83]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_84: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [84]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [84]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_85: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [85]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [85]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_86: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [86]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [86]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_87: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [87]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [87]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_88: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [88]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [88]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_89: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [89]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [89]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_90: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [90]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [90]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_91: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [91]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [91]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_92: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [92]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [92]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_93: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [93]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [93]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_94: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [94]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [94]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_95: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [95]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [95]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_96: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [96]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [96]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_97: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [97]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [97]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_98: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [98]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [98]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_99: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [99]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [99]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_100: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [100]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [100]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_101: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [101]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [101]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_102: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [102]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [102]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_103: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [103]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [103]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_104: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [104]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [104]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_105: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [105]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [105]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_106: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [106]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [106]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_107: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [107]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [107]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_108: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [108]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [108]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_109: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [109]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [109]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_110: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [110]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [110]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_111: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [111]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [111]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_112: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [112]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [112]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_113: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [113]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [113]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_114: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [114]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [114]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_115: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [115]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [115]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_116: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [116]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [116]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_117: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [117]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [117]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_118: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [118]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [118]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_119: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [119]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [119]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_120: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [120]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [120]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_121: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [121]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [121]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_122: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [122]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [122]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_123: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [123]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [123]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_124: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [124]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [124]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_125: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [125]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [125]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_126: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [126]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [126]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_127: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [127]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [127]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_128: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [128]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [128]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_129: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [129]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [129]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_130: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [130]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [130]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_131: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [131]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [131]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_132: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [132]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [132]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_133: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [133]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [133]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_134: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [134]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [134]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_135: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [135]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [135]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_136: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [136]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [136]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_137: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [137]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [137]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_138: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [138]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [138]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_139: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [139]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [139]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_140: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [140]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [140]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_141: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [141]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [141]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_142: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [142]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [142]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_143: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [143]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [143]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_144: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [144]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [144]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_145: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [145]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [145]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_146: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [146]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [146]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_147: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [147]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [147]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_148: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [148]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [148]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_149: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [149]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [149]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_150: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [150]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [150]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_151: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [151]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [151]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_152: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [152]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [152]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_153: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [153]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [153]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_154: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [154]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [154]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_155: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [155]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [155]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_156: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [156]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [156]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_157: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [157]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [157]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_158: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [158]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [158]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_159: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [159]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [159]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_160: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [160]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [160]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_161: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [161]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [161]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_162: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [162]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [162]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_163: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [163]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [163]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_164: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [164]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [164]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_165: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [165]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [165]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_166: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [166]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [166]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_167: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [167]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [167]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_168: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [168]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [168]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_169: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [169]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [169]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_170: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [170]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [170]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_171: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [171]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [171]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_172: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [172]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [172]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_173: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [173]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [173]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_174: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [174]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [174]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_175: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [175]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [175]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_176: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [176]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [176]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_177: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [177]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [177]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_178: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [178]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [178]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_179: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [179]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [179]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_180: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [180]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [180]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_181: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [181]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [181]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_182: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [182]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [182]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_183: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [183]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [183]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_184: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [184]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [184]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_185: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [185]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [185]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_186: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [186]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [186]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_187: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [187]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [187]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_188: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [188]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [188]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_189: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [189]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [189]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_190: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [190]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [190]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_191: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [191]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [191]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_192: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [192]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [192]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_193: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [193]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [193]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_194: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [194]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [194]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_195: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [195]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [195]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_196: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [196]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [196]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_197: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [197]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [197]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_198: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [198]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [198]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_199: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [199]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [199]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_200: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [200]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [200]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_201: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [201]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [201]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_202: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [202]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [202]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_203: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [203]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [203]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_204: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [204]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [204]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_205: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [205]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [205]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_206: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [206]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [206]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_207: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [207]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [207]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_208: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [208]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [208]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_209: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [209]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [209]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_210: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [210]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [210]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_211: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [211]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [211]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_212: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [212]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [212]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_213: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [213]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [213]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_214: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [214]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [214]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_215: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [215]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [215]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_216: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [216]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [216]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_217: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [217]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [217]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_218: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [218]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [218]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_219: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [219]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [219]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_220: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [220]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [220]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_221: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [221]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [221]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_222: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [222]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [222]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_223: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [223]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [223]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_224: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [224]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [224]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_225: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [225]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [225]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_226: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [226]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [226]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_227: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [227]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [227]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_228: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [228]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [228]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_229: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [229]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [229]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_230: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [230]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [230]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_231: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [231]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [231]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_232: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [232]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [232]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_233: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [233]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [233]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_234: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [234]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [234]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_235: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [235]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [235]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_236: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [236]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [236]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_237: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [237]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [237]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_238: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [238]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [238]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_239: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [239]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [239]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_240: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [240]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [240]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_241: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [241]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [241]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_242: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [242]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [242]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_243: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [243]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [243]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_244: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [244]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [244]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_245: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [245]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [245]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_246: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [246]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [246]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_247: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [247]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [247]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_248: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [248]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [248]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_249: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [249]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [249]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_250: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [250]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [250]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_251: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [251]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [251]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_252: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [252]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [252]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_253: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [253]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [253]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_254: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [254]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [254]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_255: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [255]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [255]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_256: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [256]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [256]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_257: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [257]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [257]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_258: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [258]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [258]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_259: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [259]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [259]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_260: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [260]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [260]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_261: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [261]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [261]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_262: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [262]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [262]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_263: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [263]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [263]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_264: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [264]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [264]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_265: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [265]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [265]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_266: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [266]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [266]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_267: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [267]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [267]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_268: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [268]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [268]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_269: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [269]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [269]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_270: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [270]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [270]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_271: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [271]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [271]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_272: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [272]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [272]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_273: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [273]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [273]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_274: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [274]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [274]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_275: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [275]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [275]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_276: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [276]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [276]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_277: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [277]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [277]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_278: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [278]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [278]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_279: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [279]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [279]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_280: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [280]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [280]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_281: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [281]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [281]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_282: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [282]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [282]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_283: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [283]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [283]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_284: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [284]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [284]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_285: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [285]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [285]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_286: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [286]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [286]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_287: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [287]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [287]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_288: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [288]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [288]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_289: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [289]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [289]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_290: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [290]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [290]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_291: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [291]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [291]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_292: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [292]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [292]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_293: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [293]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [293]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_294: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [294]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [294]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_295: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [295]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [295]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_296: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [296]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [296]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_297: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [297]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [297]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_298: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [298]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [298]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_299: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [299]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [299]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_300: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [300]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [300]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_301: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [301]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [301]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_302: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [302]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [302]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_303: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [303]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [303]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_304: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [304]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [304]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_305: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [305]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [305]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_306: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [306]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [306]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_307: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [307]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [307]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_308: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [308]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [308]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_309: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [309]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [309]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_310: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [310]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [310]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_311: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [311]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [311]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_312: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [312]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [312]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_313: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [313]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [313]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_314: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [314]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [314]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_315: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [315]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [315]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_316: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [316]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [316]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_317: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [317]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [317]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_318: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [318]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [318]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_319: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [319]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [319]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_320: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [320]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [320]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_321: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [321]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [321]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_322: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [322]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [322]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_323: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [323]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [323]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_324: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [324]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [324]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_325: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [325]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [325]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_326: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [326]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [326]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_327: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [327]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [327]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_328: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [328]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [328]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_329: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [329]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [329]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_330: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [330]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [330]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_331: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [331]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [331]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_332: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [332]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [332]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_333: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [333]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [333]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_334: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [334]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [334]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_335: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [335]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [335]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_336: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [336]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [336]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_337: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [337]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [337]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_338: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [338]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [338]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_339: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [339]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [339]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_340: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [340]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [340]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_341: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [341]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [341]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_342: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [342]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [342]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_343: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [343]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [343]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_344: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [344]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [344]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_345: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [345]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [345]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_346: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [346]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [346]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_347: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [347]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [347]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_348: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [348]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [348]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_349: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [349]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [349]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_350: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [350]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [350]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_351: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [351]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [351]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_352: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [352]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [352]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_353: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [353]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [353]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_354: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [354]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [354]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_355: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [355]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [355]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_356: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [356]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [356]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_357: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [357]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [357]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_358: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [358]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [358]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_359: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [359]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [359]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_360: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [360]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [360]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_361: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [361]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [361]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_362: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [362]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [362]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_363: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [363]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [363]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_364: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [364]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [364]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_365: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [365]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [365]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_366: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [366]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [366]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_367: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [367]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [367]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_368: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [368]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [368]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_369: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [369]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [369]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_370: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [370]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [370]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_371: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [371]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [371]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_372: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [372]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [372]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_373: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [373]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [373]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_374: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [374]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [374]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_375: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [375]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [375]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_376: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [376]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [376]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_377: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [377]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [377]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_378: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [378]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [378]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_379: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [379]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [379]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_380: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [380]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [380]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_381: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [381]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [381]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_382: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [382]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [382]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_383: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [383]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [383]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_384: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [384]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [384]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_385: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [385]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [385]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_386: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [386]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [386]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_387: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [387]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [387]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_388: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [388]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [388]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_389: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [389]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [389]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_390: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [390]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [390]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_391: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [391]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [391]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_392: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [392]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [392]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_393: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [393]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [393]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_394: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [394]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [394]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_395: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [395]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [395]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_396: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [396]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [396]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_397: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [397]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [397]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_398: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [398]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [398]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_399: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [399]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [399]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_400: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [400]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [400]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_401: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [401]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [401]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_402: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [402]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [402]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_403: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [403]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [403]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_404: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [404]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [404]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_405: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [405]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [405]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_406: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [406]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [406]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_407: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [407]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [407]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_408: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [408]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [408]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_409: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [409]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [409]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_410: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [410]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [410]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_411: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [411]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [411]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_412: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [412]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [412]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_413: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [413]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [413]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_414: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [414]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [414]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_415: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [415]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [415]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_416: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [416]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [416]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_417: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [417]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [417]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_418: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [418]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [418]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_419: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [419]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [419]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_420: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [420]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [420]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_421: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [421]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [421]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_422: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [422]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [422]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_423: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [423]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [423]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_424: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [424]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [424]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_425: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [425]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [425]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_426: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [426]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [426]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_427: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [427]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [427]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_428: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [428]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [428]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_429: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [429]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [429]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_430: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [430]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [430]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_431: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [431]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [431]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_432: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [432]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [432]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_433: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [433]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [433]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_434: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [434]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [434]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_435: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [435]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [435]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_436: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [436]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [436]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_437: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [437]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [437]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_438: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [438]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [438]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_439: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [439]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [439]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_440: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [440]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [440]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_441: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [441]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [441]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_442: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [442]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [442]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_443: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [443]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [443]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_444: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [444]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [444]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_445: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [445]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [445]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_446: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [446]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [446]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_447: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [447]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [447]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_448: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [448]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [448]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_449: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [449]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [449]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_450: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [450]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [450]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_451: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [451]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [451]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_452: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [452]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [452]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_453: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [453]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [453]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_454: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [454]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [454]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_455: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [455]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [455]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_456: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [456]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [456]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_457: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [457]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [457]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_458: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [458]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [458]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_459: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [459]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [459]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_460: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [460]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [460]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_461: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [461]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [461]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_462: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [462]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [462]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_463: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [463]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [463]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_464: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [464]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [464]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_465: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [465]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [465]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_466: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [466]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [466]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_467: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [467]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [467]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_468: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [468]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [468]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_469: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [469]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [469]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_470: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [470]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [470]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_471: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [471]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [471]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_472: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [472]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [472]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_473: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [473]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [473]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_474: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [474]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [474]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_475: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [475]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [475]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_476: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [476]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [476]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_477: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [477]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [477]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_478: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [478]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [478]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_479: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [479]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [479]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_480: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [480]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [480]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_481: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [481]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [481]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_482: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [482]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [482]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_483: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [483]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [483]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_484: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [484]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [484]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_485: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [485]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [485]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_486: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [486]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [486]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_487: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [487]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [487]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_488: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [488]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [488]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_489: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [489]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [489]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_490: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [490]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [490]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_491: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [491]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [491]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_492: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [492]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [492]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_493: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [493]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [493]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_494: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [494]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [494]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_495: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [495]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [495]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_496: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [496]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [496]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_497: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [497]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [497]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_498: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [498]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [498]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_499: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [499]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [499]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_500: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [500]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [500]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_501: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [501]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [501]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_502: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [502]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [502]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_503: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [503]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [503]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_504: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [504]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [504]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_505: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [505]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [505]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_506: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [506]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [506]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_507: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [507]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [507]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_508: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [508]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [508]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_509: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [509]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [509]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_510: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [510]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [510]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_511: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [511]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [511]']");
        uniqueBag = 1;
    };
    class ACM_FreshBloodBag_250_512: ACM_FreshBloodBag_250 {
        displayName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag', '(250ml) [512]']");
        shortName = __EVAL(call compile "format [localize 'STR_ACM_Circulation_FreshBloodBag_Short', '(250ml) [512]']");
        uniqueBag = 1;
    };
};
class ace_medical_treatment_actions {
    class Diagnose;
    class CheckPulse: Diagnose {
        displayName = "$STR_ACM_circulation_FeelPulse";
        displayNameProgress = "";
        treatmentTime = 0.001;
        allowedSelections[] = {
            "Head",
            "LeftArm",
            "RightArm",
            "LeftLeg",
            "RightLeg"
        };
        condition = "true";
        callbackSuccess = "ACM_circulation_fnc_feelPulse";
    };
    class PressureCuff_Attach: CheckPulse {
        displayName = "$STR_ACM_circulation_PressureCuff_Attach";
        displayNameProgress = "$STR_ACM_circulation_PressureCuff_Attach_Progress";
        icon = "";
        category = "examine";
        treatmentLocations = 0;
        medicRequired = 0;
        treatmentTime = 4;
        allowedSelections[] = {"LeftArm", "RightArm"};
        items[] = {"ACM_PressureCuff"};
        consumeItem = 1;
        condition = "!([_patient, _bodyPart, 3] call ACM_circulation_fnc_hasAED) && !([_patient, _bodyPart] call ACM_circulation_fnc_hasPressureCuff) && !([_patient, _bodyPart, 0, 0] call ACM_circulation_fnc_hasIV)";
        callbackSuccess = "[_medic, _patient, _bodyPart, true] call ACM_circulation_fnc_setPressureCuff";
        ACM_cancelRecovery = 1;
        ACM_rollToBack = 1;
        ACM_menuIcon = "ACM_PressureCuff";
    };
    class PressureCuff_Remove: PressureCuff_Attach {
        displayName = "$STR_ACM_circulation_PressureCuff_Remove";
        displayNameProgress = "$STR_ACM_circulation_PressureCuff_Remove_Progress";
        icon = "";
        treatmentTime = 2;
        items[] = {};
        consumeItem = 0;
        condition = "[_patient, _bodyPart] call ACM_circulation_fnc_hasPressureCuff";
        callbackSuccess = "[_medic, _patient, _bodyPart, false] call ACM_circulation_fnc_setPressureCuff";
    };
    class AED_ViewMonitor: CheckPulse {
        displayName = "$STR_ACM_circulation_AED_ViewMonitor";
        displayNameProgress = "";
        icon = "";
        category = "examine";
        treatmentLocations = 0;
        medicRequired = "ACM_circulation_allowAED";
        treatmentTime = 0.01;
        allowedSelections[] = {"All"};
        allowSelfTreatment = 0;
        condition = "([_patient, _bodyPart] call ACM_circulation_fnc_hasAED)";
        callbackSuccess = "[_medic, _patient] call ACM_circulation_fnc_displayAEDMonitor";
        ACM_menuIcon = "ACM_AED";
    };
    class AED_ApplyPads: CheckPulse {
        displayName = "$STR_ACM_circulation_AED_ApplyPads";
        displayNameProgress = "$STR_ACM_circulation_AED_ApplyPads";
        icon = "";
        category = "advanced";
        treatmentLocations = 0;
        medicRequired = "ACM_circulation_allowAED";
        treatmentTime = "ACM_circulation_fnc_getApplyPadsTime";
        allowedSelections[] = {"Body"};
        allowSelfTreatment = 0;
        consumeItem = 0;
        condition = "!([_patient, _bodyPart, 1] call ACM_circulation_fnc_hasAED) && ([_medic, _patient] call ACM_circulation_fnc_canConnectAED)";
        callbackSuccess = "[_medic, _patient, _bodyPart, 0] call ACM_circulation_fnc_setAED";
        ACM_cancelRecovery = 1;
        ACM_rollToBack = 1;
        ACM_menuIcon = "ACM_AED";
    };
    class AED_RemovePads: AED_ApplyPads {
        displayName = "$STR_ACM_circulation_AED_RemovePads";
        displayNameProgress = "$STR_ACM_circulation_AED_RemovePads_Progress";
        treatmentLocations = 0;
        treatmentTime = 1;
        allowSelfTreatment = 1;
        condition = "[_patient, _bodyPart, 1] call ACM_circulation_fnc_hasAED";
        callbackSuccess = "[_medic, _patient, _bodyPart, 0, false] call ACM_circulation_fnc_setAED";
        ACM_cancelRecovery = 0;
    };
    class AED_ConnectPulseOximeter: AED_ApplyPads {
        displayName = "$STR_ACM_circulation_AED_ConnectPulseOximeter";
        displayNameProgress = "$STR_ACM_circulation_AED_ConnectPulseOximeter_Progress";
        icon = "";
        category = "examine";
        treatmentTime = 2;
        allowedSelections[] = {"LeftArm", "RightArm"};
        condition = "!([_patient, '', 2] call ACM_circulation_fnc_hasAED) && ([_medic, _patient] call ACM_circulation_fnc_canConnectAED)";
        callbackSuccess = "[_medic, _patient, _bodyPart, 1] call ACM_circulation_fnc_setAED";
        ACM_cancelRecovery = 0;
        ACM_rollToBack = 0;
    };
    class AED_DisconnectPulseOximeter: AED_RemovePads {
        displayName = "$STR_ACM_circulation_AED_DisconnectPulseOximeter";
        displayNameProgress = "$STR_ACM_circulation_AED_DisconnectPulseOximeter_Progress";
        category = "examine";
        treatmentTime = 1;
        allowedSelections[] = {"LeftArm", "RightArm"};
        condition = "[_patient, _bodyPart, 2] call ACM_circulation_fnc_hasAED";
        callbackSuccess = "[_medic, _patient, _bodyPart, 1, false] call ACM_circulation_fnc_setAED";
        ACM_rollToBack = 0;
    };
    class AED_ConnectPressureCuff: AED_ApplyPads {
        displayName = "$STR_ACM_circulation_AED_ConnectPressureCuff";
        displayNameProgress = "$STR_ACM_circulation_AED_ConnectPressureCuff_Progress";
        icon = "";
        category = "examine";
        treatmentTime = 3;
        allowedSelections[] = {"LeftArm", "RightArm"};
        condition = "!([_patient, '', 3] call ACM_circulation_fnc_hasAED) && !([_patient, _bodyPart] call ACM_circulation_fnc_hasPressureCuff) && ([_medic, _patient] call ACM_circulation_fnc_canConnectAED) && !([_patient, _bodyPart, 0, 0] call ACM_circulation_fnc_hasIV)";
        callbackSuccess = "[_medic, _patient, _bodyPart, 2] call ACM_circulation_fnc_setAED";
        ACM_cancelRecovery = 0;
    };
    class AED_DisconnectPressureCuff: AED_RemovePads {
        displayName = "$STR_ACM_circulation_AED_DisconnectPressureCuff";
        displayNameProgress = "$STR_ACM_circulation_AED_DisconnectPressureCuff_Progress";
        category = "examine";
        treatmentTime = 1;
        allowedSelections[] = {"LeftArm", "RightArm"};
        condition = "[_patient, _bodyPart, 3] call ACM_circulation_fnc_hasAED";
        callbackSuccess = "[_medic, _patient, _bodyPart, 2, false] call ACM_circulation_fnc_setAED";
    };
    class AED_ConnectCapnograph: AED_ApplyPads {
        displayName = "$STR_ACM_circulation_AED_ConnectCapnograph";
        displayNameProgress = "$STR_ACM_circulation_AED_ConnectCapnograph_Progress";
        icon = "";
        category = "examine";
        treatmentTime = 3;
        allowedSelections[] = {"Head"};
        condition = "!([_patient, _bodyPart, 4] call ACM_circulation_fnc_hasAED) && ([_medic, _patient] call ACM_circulation_fnc_canConnectAED)";
        callbackSuccess = "[_medic, _patient, _bodyPart, 3] call ACM_circulation_fnc_setAED";
        ACM_cancelRecovery = 0;
    };
    class AED_DisconnectCapnograph: AED_RemovePads {
        displayName = "$STR_ACM_circulation_AED_DisconnectCapnograph";
        displayNameProgress = "$STR_ACM_circulation_AED_DisconnectCapnograph_Progress";
        category = "examine";
        treatmentTime = 1;
        allowedSelections[] = {"Head"};
        condition = "[_patient, _bodyPart, 4] call ACM_circulation_fnc_hasAED";
        callbackSuccess = "[_medic, _patient, _bodyPart, 3, false] call ACM_circulation_fnc_setAED";
    };
    class AED_AnalyzeRhythm: AED_ViewMonitor {
        displayName = "$STR_ACM_circulation_AED_AnalyzeRhythm";
        category = "examine";
        allowedSelections[] = {"Body"};
        condition = "[_medic, _patient] call ACM_circulation_fnc_AED_CanAnalyzeRhythm";
        callbackSuccess = "[_medic, _patient] call ACM_circulation_fnc_AED_AnalyzeRhythm";
    };
    class AED_ManualCharge: AED_AnalyzeRhythm {
        displayName = "$STR_ACM_circulation_AED_ManualCharge";
        category = "advanced";
        condition = "[_medic, _patient] call ACM_circulation_fnc_AED_CanManualCharge";
        callbackSuccess = "[_medic, _patient, true] call ACM_circulation_fnc_AED_BeginCharge";
    };
    class AED_Shock: AED_ManualCharge {
        displayName = "$STR_ACM_circulation_AED_Shock";
        condition = "[_medic, _patient] call ACM_circulation_fnc_AED_CanAdministerShock";
        callbackSuccess = "[_medic, _patient] call ACM_circulation_fnc_AED_AdministerShock";
    };
    class AED_CancelCharge: AED_ManualCharge {
        displayName = "$STR_ACM_circulation_AED_CancelCharge";
        condition = "[_medic, _patient] call ACM_circulation_fnc_AED_CanCancelCharge";
        callbackSuccess = "[_medic, _patient] call ACM_circulation_fnc_AED_CancelCharge";
    };
    class AED_MeasureBP: AED_AnalyzeRhythm {
        displayName = "$STR_ACM_circulation_AED_MeasureBP";
        allowedSelections[] = {"LeftArm", "RightArm", "Body"};
        condition = "ACM_circulation_fnc_AED_CanMeasureBP";
        callbackSuccess = "[_medic, _patient] call ACM_circulation_fnc_AED_MeasureBP";
    };
    class CPR {
        displayName = "$STR_ACM_circulation_BeginCPR";
        displayNameProgress = "";
        treatmentTime = 0.01;
        callbackStart = "";
        callbackProgress = "";
        callbackFailure = "";
        callbackSuccess = "[_medic, _patient] call ACM_circulation_fnc_beginCPR";
        condition = "[_medic, _patient] call ace_medical_treatment_fnc_canCPR";
        ACM_rollToBack = 1;
        ACM_cancelRecovery = 1;
        ACM_menuIcon = "CPR";
    };
    class BasicBandage;
    class BloodIV: BasicBandage {
        condition = "false";
    };
    class PlasmaIV: BloodIV {
        condition = "false";
    };
    class SalineIV: BloodIV {
        condition = "false";
    };
};
class RscText;
class RscLine;
class RscStructuredText;
class RscButton;
class RscButtonMenu;
class RscPicture;
class RscPictureKeepAspect;
class RscListBox;
class ACM_circulation_Lifepak_Monitor_Dialog {
    idd = 70000;
    movingEnable = 0;
    onLoad = "";
    onUnload = "uiNamespace setVariable [""ACM_circulation_AEDMonitor_DLG"", nil]";
    objects[] = {};
    class ControlsBackground {
        class Black_Background: RscText {
            idc = -1;
            x = "((624 - 20) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            y = "((546 - 20) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
            w = "(1000 / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55))";
            h = "(700 / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3))";
            colorBackground[] = {0, 0, 0, 1};
        };
        class Black_Background2: Black_Background {};
        class VitalsSection_Background: RscText {
            idc = -1;
            x = "((624 - 10) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            y = "(546 / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
            w = "(180 / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55))";
            h = "(550 / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3))";
            colorBackground[] = {0.18, 0.26, 0.29, 1};
            text = "";
        };
        class HR_Vitals_Background: RscText {
            idc = -1;
            x = "((624 - 10) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            y = "(((546 + 20) + (160 * 0)) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
            w = "(180 / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55))";
            h = "(140 / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3))";
            colorBackground[] = {0, 0, 0, 1};
        };
        class SpO2_Vitals_Background: HR_Vitals_Background {
            idc = -1;
            y = "(((546 + 20) + (160 * 1)) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
        };
        class CO2_Vitals_Background: HR_Vitals_Background {
            idc = -1;
            y = "(((546 + 20) + (160 * 2)) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
        };
        class BP_Vitals_Background: HR_Vitals_Background {
            idc = -1;
            y = "(((546 + 20) + (160 * 3)) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
        };
        class Top_Bar_Background: VitalsSection_Background {
            idc = -1;
            y = "(546 / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
            w = "(900 / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55))";
            h = "(20 / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3))";
        };
        class Vitals_SectionDivider_Background: VitalsSection_Background {
            idc = -1;
            x = "((624 + 169) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            w = "(2 / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55))";
            h = "(660 / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3))";
        };
        class HR_Vitals_Header: RscText {
            idc = 70011;
            x = "((624 - 10) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            y = "(((546 - 2) + (160 * 0)) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
            w = "(80 / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55))";
            h = "(25 / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3))";
            colorBackground[] = {0, 0, 0, 0};
            colorText[] = {0, 1, 0, 1};
            font = "RobotoCondensed";
            shadow = 0;
            type = 0;
            style = 0;
            sizeEx = "((((((safeZoneW) min (safeZoneH * 1.7777777778)) / safeZoneH) min 1.2) / 1.2) / 22) * 0.4 * (0.55 / (getResolution select 5))";
            text = "$STR_ACM_circulation_AED_Monitor_HR";
        };
        class SpO2_Vitals_Header: HR_Vitals_Header {
            idc = -1;
            y = "(((546 - 2) + (160 * 1)) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
            colorText[] = {0, 0.6, 1, 1};
            text = "$STR_ACM_circulation_AED_Monitor_SpO2";
        };
        class CO2_Vitals_Header: HR_Vitals_Header {
            idc = -1;
            y = "(((546 - 2) + (160 * 2)) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
            colorText[] = {1, 0.5, 0.2, 1};
            text = "$STR_ACM_circulation_AED_Monitor_CO2";
        };
        class BP_Vitals_Header: HR_Vitals_Header {
            idc = -1;
            y = "(((546 - 2) + (160 * 3)) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
            colorText[] = {1, 1, 1, 1};
            text = "$STR_ACM_circulation_AED_Monitor_NIBP";
        };
        class HR_Vitals_Display: RscText {
            idc = 70001;
            x = "((624 + 50) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            y = "(((546 + 5) + (160 * 0)) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
            w = "(125 / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55))";
            h = "(90 / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3))";
            colorBackground[] = {0, 0, 0, 0};
            colorText[] = {0, 1, 0, 1};
            font = "RobotoCondensedBold";
            shadow = 0;
            type = 0;
            style = 1;
            sizeEx = "((((((safeZoneW) min (safeZoneH * 1.7777777778)) / safeZoneH) min 1.2) / 1.2) / 22) * 1.9 * (0.55 / (getResolution select 5))";
            text = "0";
        };
        class SpO2_Vitals_Display: HR_Vitals_Display {
            idc = 70002;
            x = "((624 + 60) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            y = "(((546 + 5) + (160 * 1)) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
            w = "(115 / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55))";
            h = "(93 / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3))";
            colorText[] = {0, 0.6, 1, 1};
            font = "RobotoCondensedBold";
            sizeEx = "((((((safeZoneW) min (safeZoneH * 1.7777777778)) / safeZoneH) min 1.2) / 1.2) / 22) * 1.7 * (0.55 / (getResolution select 5))";
            text = "0";
        };
        class CO2_Vitals_Display: SpO2_Vitals_Display {
            idc = 70003;
            y = "(((546 + 5) + (160 * 2)) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
            w = "(115 / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55))";
            h = "(93 / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3))";
            colorText[] = {1, 0.5, 0.2, 1};
            text = "0";
        };
        class RR_Vitals_Display: CO2_Vitals_Display {
            idc = 70004;
            x = "((624 - 38) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            y = "((((546 + 5) + (160 * 2)) + 12) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
            w = "(80 / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55))";
            h = "(80 / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3))";
            sizeEx = "((((((safeZoneW) min (safeZoneH * 1.7777777778)) / safeZoneH) min 1.2) / 1.2) / 22) * 0.8 * (0.55 / (getResolution select 5))";
            text = "0";
        };
        class RR_Text_Vitals_Display: RR_Vitals_Display {
            idc = 70005;
            x = "((624 - 14) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            y = "((((546 + 5) + (160 * 2)) + 9) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
            sizeEx = "((((((safeZoneW) min (safeZoneH * 1.7777777778)) / safeZoneH) min 1.2) / 1.2) / 22) * 0.45 * (0.55 / (getResolution select 5))";
            text = "$STR_ACM_circulation_AED_Monitor_RR";
        };
        class NIBP_S_Vitals_Display: SpO2_Vitals_Display {
            idc = 70006;
            y = "(((546 + 5) + (160 * 3)) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
            w = "(115 / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55))";
            h = "(93 / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3))";
            colorText[] = {1, 1, 1, 1};
            text = "0";
        };
        class NIBP_D_Vitals_Display: SpO2_Vitals_Display {
            idc = 70007;
            y = "((((546 + 5) + (160 * 3)) + 55) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
            colorText[] = {1, 1, 1, 1};
            text = "0";
        };
        class NIBP_Mean_Vitals_Display: NIBP_D_Vitals_Display {
            idc = 70008;
            x = "((624 - 48) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            y = "((((546 + 5) + (160 * 3)) + 68) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
            w = "(100 / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55))";
            h = "(90 / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3))";
            sizeEx = "((((((safeZoneW) min (safeZoneH * 1.7777777778)) / safeZoneH) min 1.2) / 1.2) / 22) * 0.8 * (0.55 / (getResolution select 5))";
            text = "0";
        };
        class EKG_Line_0: RscLine {
            idc = 71000;
            x = "(((624 + 177) + 4*0) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            y = "(((546 + 105) + 0) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
            w = "(4 / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55))";
            h = "(0 / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3))";
            colorBackground[] = {0, 0, 0, 0};
            colorText[] = {0, 1, 0, 1};
            text = "";
        };
        class EKG_Line_1: EKG_Line_0 {
            idc = 71001;
            x = "(((624 + 177) + 4*1) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_2: EKG_Line_0 {
            idc = 71002;
            x = "(((624 + 177) + 4*2) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_3: EKG_Line_0 {
            idc = 71003;
            x = "(((624 + 177) + 4*3) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_4: EKG_Line_0 {
            idc = 71004;
            x = "(((624 + 177) + 4*4) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_5: EKG_Line_0 {
            idc = 71005;
            x = "(((624 + 177) + 4*5) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_6: EKG_Line_0 {
            idc = 71006;
            x = "(((624 + 177) + 4*6) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_7: EKG_Line_0 {
            idc = 71007;
            x = "(((624 + 177) + 4*7) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_8: EKG_Line_0 {
            idc = 71008;
            x = "(((624 + 177) + 4*8) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_9: EKG_Line_0 {
            idc = 71009;
            x = "(((624 + 177) + 4*9) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_10: EKG_Line_0 {
            idc = 71010;
            x = "(((624 + 177) + 4*10) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_11: EKG_Line_0 {
            idc = 71011;
            x = "(((624 + 177) + 4*11) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_12: EKG_Line_0 {
            idc = 71012;
            x = "(((624 + 177) + 4*12) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_13: EKG_Line_0 {
            idc = 71013;
            x = "(((624 + 177) + 4*13) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_14: EKG_Line_0 {
            idc = 71014;
            x = "(((624 + 177) + 4*14) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_15: EKG_Line_0 {
            idc = 71015;
            x = "(((624 + 177) + 4*15) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_16: EKG_Line_0 {
            idc = 71016;
            x = "(((624 + 177) + 4*16) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_17: EKG_Line_0 {
            idc = 71017;
            x = "(((624 + 177) + 4*17) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_18: EKG_Line_0 {
            idc = 71018;
            x = "(((624 + 177) + 4*18) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_19: EKG_Line_0 {
            idc = 71019;
            x = "(((624 + 177) + 4*19) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_20: EKG_Line_0 {
            idc = 71020;
            x = "(((624 + 177) + 4*20) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_21: EKG_Line_0 {
            idc = 71021;
            x = "(((624 + 177) + 4*21) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_22: EKG_Line_0 {
            idc = 71022;
            x = "(((624 + 177) + 4*22) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_23: EKG_Line_0 {
            idc = 71023;
            x = "(((624 + 177) + 4*23) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_24: EKG_Line_0 {
            idc = 71024;
            x = "(((624 + 177) + 4*24) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_25: EKG_Line_0 {
            idc = 71025;
            x = "(((624 + 177) + 4*25) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_26: EKG_Line_0 {
            idc = 71026;
            x = "(((624 + 177) + 4*26) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_27: EKG_Line_0 {
            idc = 71027;
            x = "(((624 + 177) + 4*27) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_28: EKG_Line_0 {
            idc = 71028;
            x = "(((624 + 177) + 4*28) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_29: EKG_Line_0 {
            idc = 71029;
            x = "(((624 + 177) + 4*29) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_30: EKG_Line_0 {
            idc = 71030;
            x = "(((624 + 177) + 4*30) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_31: EKG_Line_0 {
            idc = 71031;
            x = "(((624 + 177) + 4*31) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_32: EKG_Line_0 {
            idc = 71032;
            x = "(((624 + 177) + 4*32) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_33: EKG_Line_0 {
            idc = 71033;
            x = "(((624 + 177) + 4*33) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_34: EKG_Line_0 {
            idc = 71034;
            x = "(((624 + 177) + 4*34) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_35: EKG_Line_0 {
            idc = 71035;
            x = "(((624 + 177) + 4*35) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_36: EKG_Line_0 {
            idc = 71036;
            x = "(((624 + 177) + 4*36) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_37: EKG_Line_0 {
            idc = 71037;
            x = "(((624 + 177) + 4*37) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_38: EKG_Line_0 {
            idc = 71038;
            x = "(((624 + 177) + 4*38) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_39: EKG_Line_0 {
            idc = 71039;
            x = "(((624 + 177) + 4*39) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_40: EKG_Line_0 {
            idc = 71040;
            x = "(((624 + 177) + 4*40) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_41: EKG_Line_0 {
            idc = 71041;
            x = "(((624 + 177) + 4*41) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_42: EKG_Line_0 {
            idc = 71042;
            x = "(((624 + 177) + 4*42) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_43: EKG_Line_0 {
            idc = 71043;
            x = "(((624 + 177) + 4*43) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_44: EKG_Line_0 {
            idc = 71044;
            x = "(((624 + 177) + 4*44) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_45: EKG_Line_0 {
            idc = 71045;
            x = "(((624 + 177) + 4*45) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_46: EKG_Line_0 {
            idc = 71046;
            x = "(((624 + 177) + 4*46) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_47: EKG_Line_0 {
            idc = 71047;
            x = "(((624 + 177) + 4*47) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_48: EKG_Line_0 {
            idc = 71048;
            x = "(((624 + 177) + 4*48) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_49: EKG_Line_0 {
            idc = 71049;
            x = "(((624 + 177) + 4*49) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_50: EKG_Line_0 {
            idc = 71050;
            x = "(((624 + 177) + 4*50) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_51: EKG_Line_0 {
            idc = 71051;
            x = "(((624 + 177) + 4*51) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_52: EKG_Line_0 {
            idc = 71052;
            x = "(((624 + 177) + 4*52) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_53: EKG_Line_0 {
            idc = 71053;
            x = "(((624 + 177) + 4*53) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_54: EKG_Line_0 {
            idc = 71054;
            x = "(((624 + 177) + 4*54) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_55: EKG_Line_0 {
            idc = 71055;
            x = "(((624 + 177) + 4*55) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_56: EKG_Line_0 {
            idc = 71056;
            x = "(((624 + 177) + 4*56) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_57: EKG_Line_0 {
            idc = 71057;
            x = "(((624 + 177) + 4*57) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_58: EKG_Line_0 {
            idc = 71058;
            x = "(((624 + 177) + 4*58) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_59: EKG_Line_0 {
            idc = 71059;
            x = "(((624 + 177) + 4*59) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_60: EKG_Line_0 {
            idc = 71060;
            x = "(((624 + 177) + 4*60) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_61: EKG_Line_0 {
            idc = 71061;
            x = "(((624 + 177) + 4*61) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_62: EKG_Line_0 {
            idc = 71062;
            x = "(((624 + 177) + 4*62) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_63: EKG_Line_0 {
            idc = 71063;
            x = "(((624 + 177) + 4*63) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_64: EKG_Line_0 {
            idc = 71064;
            x = "(((624 + 177) + 4*64) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_65: EKG_Line_0 {
            idc = 71065;
            x = "(((624 + 177) + 4*65) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_66: EKG_Line_0 {
            idc = 71066;
            x = "(((624 + 177) + 4*66) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_67: EKG_Line_0 {
            idc = 71067;
            x = "(((624 + 177) + 4*67) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_68: EKG_Line_0 {
            idc = 71068;
            x = "(((624 + 177) + 4*68) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_69: EKG_Line_0 {
            idc = 71069;
            x = "(((624 + 177) + 4*69) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_70: EKG_Line_0 {
            idc = 71070;
            x = "(((624 + 177) + 4*70) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_71: EKG_Line_0 {
            idc = 71071;
            x = "(((624 + 177) + 4*71) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_72: EKG_Line_0 {
            idc = 71072;
            x = "(((624 + 177) + 4*72) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_73: EKG_Line_0 {
            idc = 71073;
            x = "(((624 + 177) + 4*73) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_74: EKG_Line_0 {
            idc = 71074;
            x = "(((624 + 177) + 4*74) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_75: EKG_Line_0 {
            idc = 71075;
            x = "(((624 + 177) + 4*75) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_76: EKG_Line_0 {
            idc = 71076;
            x = "(((624 + 177) + 4*76) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_77: EKG_Line_0 {
            idc = 71077;
            x = "(((624 + 177) + 4*77) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_78: EKG_Line_0 {
            idc = 71078;
            x = "(((624 + 177) + 4*78) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_79: EKG_Line_0 {
            idc = 71079;
            x = "(((624 + 177) + 4*79) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_80: EKG_Line_0 {
            idc = 71080;
            x = "(((624 + 177) + 4*80) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_81: EKG_Line_0 {
            idc = 71081;
            x = "(((624 + 177) + 4*81) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_82: EKG_Line_0 {
            idc = 71082;
            x = "(((624 + 177) + 4*82) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_83: EKG_Line_0 {
            idc = 71083;
            x = "(((624 + 177) + 4*83) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_84: EKG_Line_0 {
            idc = 71084;
            x = "(((624 + 177) + 4*84) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_85: EKG_Line_0 {
            idc = 71085;
            x = "(((624 + 177) + 4*85) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_86: EKG_Line_0 {
            idc = 71086;
            x = "(((624 + 177) + 4*86) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_87: EKG_Line_0 {
            idc = 71087;
            x = "(((624 + 177) + 4*87) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_88: EKG_Line_0 {
            idc = 71088;
            x = "(((624 + 177) + 4*88) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_89: EKG_Line_0 {
            idc = 71089;
            x = "(((624 + 177) + 4*89) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_90: EKG_Line_0 {
            idc = 71090;
            x = "(((624 + 177) + 4*90) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_91: EKG_Line_0 {
            idc = 71091;
            x = "(((624 + 177) + 4*91) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_92: EKG_Line_0 {
            idc = 71092;
            x = "(((624 + 177) + 4*92) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_93: EKG_Line_0 {
            idc = 71093;
            x = "(((624 + 177) + 4*93) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_94: EKG_Line_0 {
            idc = 71094;
            x = "(((624 + 177) + 4*94) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_95: EKG_Line_0 {
            idc = 71095;
            x = "(((624 + 177) + 4*95) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_96: EKG_Line_0 {
            idc = 71096;
            x = "(((624 + 177) + 4*96) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_97: EKG_Line_0 {
            idc = 71097;
            x = "(((624 + 177) + 4*97) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_98: EKG_Line_0 {
            idc = 71098;
            x = "(((624 + 177) + 4*98) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_99: EKG_Line_0 {
            idc = 71099;
            x = "(((624 + 177) + 4*99) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_100: EKG_Line_0 {
            idc = 71100;
            x = "(((624 + 177) + 4*100) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_101: EKG_Line_0 {
            idc = 71101;
            x = "(((624 + 177) + 4*101) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_102: EKG_Line_0 {
            idc = 71102;
            x = "(((624 + 177) + 4*102) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_103: EKG_Line_0 {
            idc = 71103;
            x = "(((624 + 177) + 4*103) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_104: EKG_Line_0 {
            idc = 71104;
            x = "(((624 + 177) + 4*104) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_105: EKG_Line_0 {
            idc = 71105;
            x = "(((624 + 177) + 4*105) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_106: EKG_Line_0 {
            idc = 71106;
            x = "(((624 + 177) + 4*106) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_107: EKG_Line_0 {
            idc = 71107;
            x = "(((624 + 177) + 4*107) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_108: EKG_Line_0 {
            idc = 71108;
            x = "(((624 + 177) + 4*108) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_109: EKG_Line_0 {
            idc = 71109;
            x = "(((624 + 177) + 4*109) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_110: EKG_Line_0 {
            idc = 71110;
            x = "(((624 + 177) + 4*110) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_111: EKG_Line_0 {
            idc = 71111;
            x = "(((624 + 177) + 4*111) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_112: EKG_Line_0 {
            idc = 71112;
            x = "(((624 + 177) + 4*112) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_113: EKG_Line_0 {
            idc = 71113;
            x = "(((624 + 177) + 4*113) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_114: EKG_Line_0 {
            idc = 71114;
            x = "(((624 + 177) + 4*114) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_115: EKG_Line_0 {
            idc = 71115;
            x = "(((624 + 177) + 4*115) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_116: EKG_Line_0 {
            idc = 71116;
            x = "(((624 + 177) + 4*116) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_117: EKG_Line_0 {
            idc = 71117;
            x = "(((624 + 177) + 4*117) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_118: EKG_Line_0 {
            idc = 71118;
            x = "(((624 + 177) + 4*118) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_119: EKG_Line_0 {
            idc = 71119;
            x = "(((624 + 177) + 4*119) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_120: EKG_Line_0 {
            idc = 71120;
            x = "(((624 + 177) + 4*120) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_121: EKG_Line_0 {
            idc = 71121;
            x = "(((624 + 177) + 4*121) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_122: EKG_Line_0 {
            idc = 71122;
            x = "(((624 + 177) + 4*122) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_123: EKG_Line_0 {
            idc = 71123;
            x = "(((624 + 177) + 4*123) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_124: EKG_Line_0 {
            idc = 71124;
            x = "(((624 + 177) + 4*124) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_125: EKG_Line_0 {
            idc = 71125;
            x = "(((624 + 177) + 4*125) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_126: EKG_Line_0 {
            idc = 71126;
            x = "(((624 + 177) + 4*126) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_127: EKG_Line_0 {
            idc = 71127;
            x = "(((624 + 177) + 4*127) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_128: EKG_Line_0 {
            idc = 71128;
            x = "(((624 + 177) + 4*128) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_129: EKG_Line_0 {
            idc = 71129;
            x = "(((624 + 177) + 4*129) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_130: EKG_Line_0 {
            idc = 71130;
            x = "(((624 + 177) + 4*130) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_131: EKG_Line_0 {
            idc = 71131;
            x = "(((624 + 177) + 4*131) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_132: EKG_Line_0 {
            idc = 71132;
            x = "(((624 + 177) + 4*132) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_133: EKG_Line_0 {
            idc = 71133;
            x = "(((624 + 177) + 4*133) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_134: EKG_Line_0 {
            idc = 71134;
            x = "(((624 + 177) + 4*134) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_135: EKG_Line_0 {
            idc = 71135;
            x = "(((624 + 177) + 4*135) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_136: EKG_Line_0 {
            idc = 71136;
            x = "(((624 + 177) + 4*136) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_137: EKG_Line_0 {
            idc = 71137;
            x = "(((624 + 177) + 4*137) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_138: EKG_Line_0 {
            idc = 71138;
            x = "(((624 + 177) + 4*138) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_139: EKG_Line_0 {
            idc = 71139;
            x = "(((624 + 177) + 4*139) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_140: EKG_Line_0 {
            idc = 71140;
            x = "(((624 + 177) + 4*140) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_141: EKG_Line_0 {
            idc = 71141;
            x = "(((624 + 177) + 4*141) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_142: EKG_Line_0 {
            idc = 71142;
            x = "(((624 + 177) + 4*142) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_143: EKG_Line_0 {
            idc = 71143;
            x = "(((624 + 177) + 4*143) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_144: EKG_Line_0 {
            idc = 71144;
            x = "(((624 + 177) + 4*144) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_145: EKG_Line_0 {
            idc = 71145;
            x = "(((624 + 177) + 4*145) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_146: EKG_Line_0 {
            idc = 71146;
            x = "(((624 + 177) + 4*146) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_147: EKG_Line_0 {
            idc = 71147;
            x = "(((624 + 177) + 4*147) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_148: EKG_Line_0 {
            idc = 71148;
            x = "(((624 + 177) + 4*148) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_149: EKG_Line_0 {
            idc = 71149;
            x = "(((624 + 177) + 4*149) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_150: EKG_Line_0 {
            idc = 71150;
            x = "(((624 + 177) + 4*150) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_151: EKG_Line_0 {
            idc = 71151;
            x = "(((624 + 177) + 4*151) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_152: EKG_Line_0 {
            idc = 71152;
            x = "(((624 + 177) + 4*152) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_153: EKG_Line_0 {
            idc = 71153;
            x = "(((624 + 177) + 4*153) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_154: EKG_Line_0 {
            idc = 71154;
            x = "(((624 + 177) + 4*154) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_155: EKG_Line_0 {
            idc = 71155;
            x = "(((624 + 177) + 4*155) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_156: EKG_Line_0 {
            idc = 71156;
            x = "(((624 + 177) + 4*156) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_157: EKG_Line_0 {
            idc = 71157;
            x = "(((624 + 177) + 4*157) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_158: EKG_Line_0 {
            idc = 71158;
            x = "(((624 + 177) + 4*158) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_159: EKG_Line_0 {
            idc = 71159;
            x = "(((624 + 177) + 4*159) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_160: EKG_Line_0 {
            idc = 71160;
            x = "(((624 + 177) + 4*160) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_161: EKG_Line_0 {
            idc = 71161;
            x = "(((624 + 177) + 4*161) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_162: EKG_Line_0 {
            idc = 71162;
            x = "(((624 + 177) + 4*162) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_163: EKG_Line_0 {
            idc = 71163;
            x = "(((624 + 177) + 4*163) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_164: EKG_Line_0 {
            idc = 71164;
            x = "(((624 + 177) + 4*164) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_165: EKG_Line_0 {
            idc = 71165;
            x = "(((624 + 177) + 4*165) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_166: EKG_Line_0 {
            idc = 71166;
            x = "(((624 + 177) + 4*166) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_167: EKG_Line_0 {
            idc = 71167;
            x = "(((624 + 177) + 4*167) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_168: EKG_Line_0 {
            idc = 71168;
            x = "(((624 + 177) + 4*168) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_169: EKG_Line_0 {
            idc = 71169;
            x = "(((624 + 177) + 4*169) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_170: EKG_Line_0 {
            idc = 71170;
            x = "(((624 + 177) + 4*170) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_171: EKG_Line_0 {
            idc = 71171;
            x = "(((624 + 177) + 4*171) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_172: EKG_Line_0 {
            idc = 71172;
            x = "(((624 + 177) + 4*172) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_173: EKG_Line_0 {
            idc = 71173;
            x = "(((624 + 177) + 4*173) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Line_174: EKG_Line_0 {
            idc = 71174;
            x = "(((624 + 177) + 4*174) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class EKG_Dot_0: RscText {
            idc = 72000;
            x = "(((624 + 177) + 4*0) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            y = "(((546 + 105) + 0) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
            w = "(4 / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55))";
            h = "(2 / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3))";
            colorBackground[] = {0, 1, 0, 1};
            text = "";
        };
        class EKG_Dot_1: EKG_Dot_0 {
            idc = 72001;
            x = "(((624 + 177) + 4*1) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_2: EKG_Dot_0 {
            idc = 72002;
            x = "(((624 + 177) + 4*2) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_3: EKG_Dot_0 {
            idc = 72003;
            x = "(((624 + 177) + 4*3) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_4: EKG_Dot_0 {
            idc = 72004;
            x = "(((624 + 177) + 4*4) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_5: EKG_Dot_0 {
            idc = 72005;
            x = "(((624 + 177) + 4*5) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_6: EKG_Dot_0 {
            idc = 72006;
            x = "(((624 + 177) + 4*6) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_7: EKG_Dot_0 {
            idc = 72007;
            x = "(((624 + 177) + 4*7) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_8: EKG_Dot_0 {
            idc = 72008;
            x = "(((624 + 177) + 4*8) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_9: EKG_Dot_0 {
            idc = 72009;
            x = "(((624 + 177) + 4*9) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_10: EKG_Dot_0 {
            idc = 72010;
            x = "(((624 + 177) + 4*10) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_11: EKG_Dot_0 {
            idc = 72011;
            x = "(((624 + 177) + 4*11) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_12: EKG_Dot_0 {
            idc = 72012;
            x = "(((624 + 177) + 4*12) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_13: EKG_Dot_0 {
            idc = 72013;
            x = "(((624 + 177) + 4*13) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_14: EKG_Dot_0 {
            idc = 72014;
            x = "(((624 + 177) + 4*14) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_15: EKG_Dot_0 {
            idc = 72015;
            x = "(((624 + 177) + 4*15) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_16: EKG_Dot_0 {
            idc = 72016;
            x = "(((624 + 177) + 4*16) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_17: EKG_Dot_0 {
            idc = 72017;
            x = "(((624 + 177) + 4*17) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_18: EKG_Dot_0 {
            idc = 72018;
            x = "(((624 + 177) + 4*18) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_19: EKG_Dot_0 {
            idc = 72019;
            x = "(((624 + 177) + 4*19) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_20: EKG_Dot_0 {
            idc = 72020;
            x = "(((624 + 177) + 4*20) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_21: EKG_Dot_0 {
            idc = 72021;
            x = "(((624 + 177) + 4*21) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_22: EKG_Dot_0 {
            idc = 72022;
            x = "(((624 + 177) + 4*22) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_23: EKG_Dot_0 {
            idc = 72023;
            x = "(((624 + 177) + 4*23) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_24: EKG_Dot_0 {
            idc = 72024;
            x = "(((624 + 177) + 4*24) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_25: EKG_Dot_0 {
            idc = 72025;
            x = "(((624 + 177) + 4*25) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_26: EKG_Dot_0 {
            idc = 72026;
            x = "(((624 + 177) + 4*26) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_27: EKG_Dot_0 {
            idc = 72027;
            x = "(((624 + 177) + 4*27) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_28: EKG_Dot_0 {
            idc = 72028;
            x = "(((624 + 177) + 4*28) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_29: EKG_Dot_0 {
            idc = 72029;
            x = "(((624 + 177) + 4*29) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_30: EKG_Dot_0 {
            idc = 72030;
            x = "(((624 + 177) + 4*30) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_31: EKG_Dot_0 {
            idc = 72031;
            x = "(((624 + 177) + 4*31) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_32: EKG_Dot_0 {
            idc = 72032;
            x = "(((624 + 177) + 4*32) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_33: EKG_Dot_0 {
            idc = 72033;
            x = "(((624 + 177) + 4*33) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_34: EKG_Dot_0 {
            idc = 72034;
            x = "(((624 + 177) + 4*34) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_35: EKG_Dot_0 {
            idc = 72035;
            x = "(((624 + 177) + 4*35) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_36: EKG_Dot_0 {
            idc = 72036;
            x = "(((624 + 177) + 4*36) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_37: EKG_Dot_0 {
            idc = 72037;
            x = "(((624 + 177) + 4*37) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_38: EKG_Dot_0 {
            idc = 72038;
            x = "(((624 + 177) + 4*38) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_39: EKG_Dot_0 {
            idc = 72039;
            x = "(((624 + 177) + 4*39) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_40: EKG_Dot_0 {
            idc = 72040;
            x = "(((624 + 177) + 4*40) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_41: EKG_Dot_0 {
            idc = 72041;
            x = "(((624 + 177) + 4*41) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_42: EKG_Dot_0 {
            idc = 72042;
            x = "(((624 + 177) + 4*42) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_43: EKG_Dot_0 {
            idc = 72043;
            x = "(((624 + 177) + 4*43) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_44: EKG_Dot_0 {
            idc = 72044;
            x = "(((624 + 177) + 4*44) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_45: EKG_Dot_0 {
            idc = 72045;
            x = "(((624 + 177) + 4*45) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_46: EKG_Dot_0 {
            idc = 72046;
            x = "(((624 + 177) + 4*46) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_47: EKG_Dot_0 {
            idc = 72047;
            x = "(((624 + 177) + 4*47) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_48: EKG_Dot_0 {
            idc = 72048;
            x = "(((624 + 177) + 4*48) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_49: EKG_Dot_0 {
            idc = 72049;
            x = "(((624 + 177) + 4*49) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_50: EKG_Dot_0 {
            idc = 72050;
            x = "(((624 + 177) + 4*50) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_51: EKG_Dot_0 {
            idc = 72051;
            x = "(((624 + 177) + 4*51) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_52: EKG_Dot_0 {
            idc = 72052;
            x = "(((624 + 177) + 4*52) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_53: EKG_Dot_0 {
            idc = 72053;
            x = "(((624 + 177) + 4*53) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_54: EKG_Dot_0 {
            idc = 72054;
            x = "(((624 + 177) + 4*54) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_55: EKG_Dot_0 {
            idc = 72055;
            x = "(((624 + 177) + 4*55) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_56: EKG_Dot_0 {
            idc = 72056;
            x = "(((624 + 177) + 4*56) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_57: EKG_Dot_0 {
            idc = 72057;
            x = "(((624 + 177) + 4*57) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_58: EKG_Dot_0 {
            idc = 72058;
            x = "(((624 + 177) + 4*58) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_59: EKG_Dot_0 {
            idc = 72059;
            x = "(((624 + 177) + 4*59) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_60: EKG_Dot_0 {
            idc = 72060;
            x = "(((624 + 177) + 4*60) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_61: EKG_Dot_0 {
            idc = 72061;
            x = "(((624 + 177) + 4*61) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_62: EKG_Dot_0 {
            idc = 72062;
            x = "(((624 + 177) + 4*62) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_63: EKG_Dot_0 {
            idc = 72063;
            x = "(((624 + 177) + 4*63) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_64: EKG_Dot_0 {
            idc = 72064;
            x = "(((624 + 177) + 4*64) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_65: EKG_Dot_0 {
            idc = 72065;
            x = "(((624 + 177) + 4*65) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_66: EKG_Dot_0 {
            idc = 72066;
            x = "(((624 + 177) + 4*66) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_67: EKG_Dot_0 {
            idc = 72067;
            x = "(((624 + 177) + 4*67) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_68: EKG_Dot_0 {
            idc = 72068;
            x = "(((624 + 177) + 4*68) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_69: EKG_Dot_0 {
            idc = 72069;
            x = "(((624 + 177) + 4*69) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_70: EKG_Dot_0 {
            idc = 72070;
            x = "(((624 + 177) + 4*70) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_71: EKG_Dot_0 {
            idc = 72071;
            x = "(((624 + 177) + 4*71) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_72: EKG_Dot_0 {
            idc = 72072;
            x = "(((624 + 177) + 4*72) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_73: EKG_Dot_0 {
            idc = 72073;
            x = "(((624 + 177) + 4*73) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_74: EKG_Dot_0 {
            idc = 72074;
            x = "(((624 + 177) + 4*74) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_75: EKG_Dot_0 {
            idc = 72075;
            x = "(((624 + 177) + 4*75) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_76: EKG_Dot_0 {
            idc = 72076;
            x = "(((624 + 177) + 4*76) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_77: EKG_Dot_0 {
            idc = 72077;
            x = "(((624 + 177) + 4*77) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_78: EKG_Dot_0 {
            idc = 72078;
            x = "(((624 + 177) + 4*78) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_79: EKG_Dot_0 {
            idc = 72079;
            x = "(((624 + 177) + 4*79) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_80: EKG_Dot_0 {
            idc = 72080;
            x = "(((624 + 177) + 4*80) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_81: EKG_Dot_0 {
            idc = 72081;
            x = "(((624 + 177) + 4*81) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_82: EKG_Dot_0 {
            idc = 72082;
            x = "(((624 + 177) + 4*82) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_83: EKG_Dot_0 {
            idc = 72083;
            x = "(((624 + 177) + 4*83) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_84: EKG_Dot_0 {
            idc = 72084;
            x = "(((624 + 177) + 4*84) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_85: EKG_Dot_0 {
            idc = 72085;
            x = "(((624 + 177) + 4*85) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_86: EKG_Dot_0 {
            idc = 72086;
            x = "(((624 + 177) + 4*86) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_87: EKG_Dot_0 {
            idc = 72087;
            x = "(((624 + 177) + 4*87) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_88: EKG_Dot_0 {
            idc = 72088;
            x = "(((624 + 177) + 4*88) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_89: EKG_Dot_0 {
            idc = 72089;
            x = "(((624 + 177) + 4*89) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_90: EKG_Dot_0 {
            idc = 72090;
            x = "(((624 + 177) + 4*90) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_91: EKG_Dot_0 {
            idc = 72091;
            x = "(((624 + 177) + 4*91) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_92: EKG_Dot_0 {
            idc = 72092;
            x = "(((624 + 177) + 4*92) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_93: EKG_Dot_0 {
            idc = 72093;
            x = "(((624 + 177) + 4*93) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_94: EKG_Dot_0 {
            idc = 72094;
            x = "(((624 + 177) + 4*94) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_95: EKG_Dot_0 {
            idc = 72095;
            x = "(((624 + 177) + 4*95) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_96: EKG_Dot_0 {
            idc = 72096;
            x = "(((624 + 177) + 4*96) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_97: EKG_Dot_0 {
            idc = 72097;
            x = "(((624 + 177) + 4*97) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_98: EKG_Dot_0 {
            idc = 72098;
            x = "(((624 + 177) + 4*98) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_99: EKG_Dot_0 {
            idc = 72099;
            x = "(((624 + 177) + 4*99) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_100: EKG_Dot_0 {
            idc = 72100;
            x = "(((624 + 177) + 4*100) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_101: EKG_Dot_0 {
            idc = 72101;
            x = "(((624 + 177) + 4*101) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_102: EKG_Dot_0 {
            idc = 72102;
            x = "(((624 + 177) + 4*102) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_103: EKG_Dot_0 {
            idc = 72103;
            x = "(((624 + 177) + 4*103) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_104: EKG_Dot_0 {
            idc = 72104;
            x = "(((624 + 177) + 4*104) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_105: EKG_Dot_0 {
            idc = 72105;
            x = "(((624 + 177) + 4*105) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_106: EKG_Dot_0 {
            idc = 72106;
            x = "(((624 + 177) + 4*106) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_107: EKG_Dot_0 {
            idc = 72107;
            x = "(((624 + 177) + 4*107) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_108: EKG_Dot_0 {
            idc = 72108;
            x = "(((624 + 177) + 4*108) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_109: EKG_Dot_0 {
            idc = 72109;
            x = "(((624 + 177) + 4*109) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_110: EKG_Dot_0 {
            idc = 72110;
            x = "(((624 + 177) + 4*110) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_111: EKG_Dot_0 {
            idc = 72111;
            x = "(((624 + 177) + 4*111) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_112: EKG_Dot_0 {
            idc = 72112;
            x = "(((624 + 177) + 4*112) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_113: EKG_Dot_0 {
            idc = 72113;
            x = "(((624 + 177) + 4*113) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_114: EKG_Dot_0 {
            idc = 72114;
            x = "(((624 + 177) + 4*114) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_115: EKG_Dot_0 {
            idc = 72115;
            x = "(((624 + 177) + 4*115) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_116: EKG_Dot_0 {
            idc = 72116;
            x = "(((624 + 177) + 4*116) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_117: EKG_Dot_0 {
            idc = 72117;
            x = "(((624 + 177) + 4*117) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_118: EKG_Dot_0 {
            idc = 72118;
            x = "(((624 + 177) + 4*118) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_119: EKG_Dot_0 {
            idc = 72119;
            x = "(((624 + 177) + 4*119) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_120: EKG_Dot_0 {
            idc = 72120;
            x = "(((624 + 177) + 4*120) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_121: EKG_Dot_0 {
            idc = 72121;
            x = "(((624 + 177) + 4*121) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_122: EKG_Dot_0 {
            idc = 72122;
            x = "(((624 + 177) + 4*122) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_123: EKG_Dot_0 {
            idc = 72123;
            x = "(((624 + 177) + 4*123) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_124: EKG_Dot_0 {
            idc = 72124;
            x = "(((624 + 177) + 4*124) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_125: EKG_Dot_0 {
            idc = 72125;
            x = "(((624 + 177) + 4*125) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_126: EKG_Dot_0 {
            idc = 72126;
            x = "(((624 + 177) + 4*126) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_127: EKG_Dot_0 {
            idc = 72127;
            x = "(((624 + 177) + 4*127) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_128: EKG_Dot_0 {
            idc = 72128;
            x = "(((624 + 177) + 4*128) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_129: EKG_Dot_0 {
            idc = 72129;
            x = "(((624 + 177) + 4*129) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_130: EKG_Dot_0 {
            idc = 72130;
            x = "(((624 + 177) + 4*130) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_131: EKG_Dot_0 {
            idc = 72131;
            x = "(((624 + 177) + 4*131) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_132: EKG_Dot_0 {
            idc = 72132;
            x = "(((624 + 177) + 4*132) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_133: EKG_Dot_0 {
            idc = 72133;
            x = "(((624 + 177) + 4*133) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_134: EKG_Dot_0 {
            idc = 72134;
            x = "(((624 + 177) + 4*134) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_135: EKG_Dot_0 {
            idc = 72135;
            x = "(((624 + 177) + 4*135) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_136: EKG_Dot_0 {
            idc = 72136;
            x = "(((624 + 177) + 4*136) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_137: EKG_Dot_0 {
            idc = 72137;
            x = "(((624 + 177) + 4*137) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_138: EKG_Dot_0 {
            idc = 72138;
            x = "(((624 + 177) + 4*138) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_139: EKG_Dot_0 {
            idc = 72139;
            x = "(((624 + 177) + 4*139) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_140: EKG_Dot_0 {
            idc = 72140;
            x = "(((624 + 177) + 4*140) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_141: EKG_Dot_0 {
            idc = 72141;
            x = "(((624 + 177) + 4*141) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_142: EKG_Dot_0 {
            idc = 72142;
            x = "(((624 + 177) + 4*142) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_143: EKG_Dot_0 {
            idc = 72143;
            x = "(((624 + 177) + 4*143) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_144: EKG_Dot_0 {
            idc = 72144;
            x = "(((624 + 177) + 4*144) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_145: EKG_Dot_0 {
            idc = 72145;
            x = "(((624 + 177) + 4*145) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_146: EKG_Dot_0 {
            idc = 72146;
            x = "(((624 + 177) + 4*146) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_147: EKG_Dot_0 {
            idc = 72147;
            x = "(((624 + 177) + 4*147) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_148: EKG_Dot_0 {
            idc = 72148;
            x = "(((624 + 177) + 4*148) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_149: EKG_Dot_0 {
            idc = 72149;
            x = "(((624 + 177) + 4*149) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_150: EKG_Dot_0 {
            idc = 72150;
            x = "(((624 + 177) + 4*150) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_151: EKG_Dot_0 {
            idc = 72151;
            x = "(((624 + 177) + 4*151) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_152: EKG_Dot_0 {
            idc = 72152;
            x = "(((624 + 177) + 4*152) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_153: EKG_Dot_0 {
            idc = 72153;
            x = "(((624 + 177) + 4*153) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_154: EKG_Dot_0 {
            idc = 72154;
            x = "(((624 + 177) + 4*154) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_155: EKG_Dot_0 {
            idc = 72155;
            x = "(((624 + 177) + 4*155) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_156: EKG_Dot_0 {
            idc = 72156;
            x = "(((624 + 177) + 4*156) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_157: EKG_Dot_0 {
            idc = 72157;
            x = "(((624 + 177) + 4*157) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_158: EKG_Dot_0 {
            idc = 72158;
            x = "(((624 + 177) + 4*158) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_159: EKG_Dot_0 {
            idc = 72159;
            x = "(((624 + 177) + 4*159) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_160: EKG_Dot_0 {
            idc = 72160;
            x = "(((624 + 177) + 4*160) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_161: EKG_Dot_0 {
            idc = 72161;
            x = "(((624 + 177) + 4*161) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_162: EKG_Dot_0 {
            idc = 72162;
            x = "(((624 + 177) + 4*162) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_163: EKG_Dot_0 {
            idc = 72163;
            x = "(((624 + 177) + 4*163) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_164: EKG_Dot_0 {
            idc = 72164;
            x = "(((624 + 177) + 4*164) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_165: EKG_Dot_0 {
            idc = 72165;
            x = "(((624 + 177) + 4*165) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_166: EKG_Dot_0 {
            idc = 72166;
            x = "(((624 + 177) + 4*166) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_167: EKG_Dot_0 {
            idc = 72167;
            x = "(((624 + 177) + 4*167) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_168: EKG_Dot_0 {
            idc = 72168;
            x = "(((624 + 177) + 4*168) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_169: EKG_Dot_0 {
            idc = 72169;
            x = "(((624 + 177) + 4*169) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_170: EKG_Dot_0 {
            idc = 72170;
            x = "(((624 + 177) + 4*170) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_171: EKG_Dot_0 {
            idc = 72171;
            x = "(((624 + 177) + 4*171) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_172: EKG_Dot_0 {
            idc = 72172;
            x = "(((624 + 177) + 4*172) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_173: EKG_Dot_0 {
            idc = 72173;
            x = "(((624 + 177) + 4*173) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class EKG_Dot_174: EKG_Dot_0 {
            idc = 72174;
            x = "(((624 + 177) + 4*174) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Line_0: RscLine {
            idc = 73000;
            x = "(((624 + 177) + 4*0) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            y = "(((546 + 105) + 160) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
            w = "(4 / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55))";
            h = "(0 / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3))";
            colorBackground[] = {0, 0, 0, 0};
            colorText[] = {0, 0.6, 1, 1};
            text = "";
        };
        class PO_Line_1: PO_Line_0 {
            idc = 73001;
            x = "(((624 + 177) + 4*1) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_2: PO_Line_0 {
            idc = 73002;
            x = "(((624 + 177) + 4*2) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_3: PO_Line_0 {
            idc = 73003;
            x = "(((624 + 177) + 4*3) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_4: PO_Line_0 {
            idc = 73004;
            x = "(((624 + 177) + 4*4) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_5: PO_Line_0 {
            idc = 73005;
            x = "(((624 + 177) + 4*5) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_6: PO_Line_0 {
            idc = 73006;
            x = "(((624 + 177) + 4*6) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_7: PO_Line_0 {
            idc = 73007;
            x = "(((624 + 177) + 4*7) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_8: PO_Line_0 {
            idc = 73008;
            x = "(((624 + 177) + 4*8) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_9: PO_Line_0 {
            idc = 73009;
            x = "(((624 + 177) + 4*9) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_10: PO_Line_0 {
            idc = 73010;
            x = "(((624 + 177) + 4*10) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_11: PO_Line_0 {
            idc = 73011;
            x = "(((624 + 177) + 4*11) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_12: PO_Line_0 {
            idc = 73012;
            x = "(((624 + 177) + 4*12) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_13: PO_Line_0 {
            idc = 73013;
            x = "(((624 + 177) + 4*13) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_14: PO_Line_0 {
            idc = 73014;
            x = "(((624 + 177) + 4*14) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_15: PO_Line_0 {
            idc = 73015;
            x = "(((624 + 177) + 4*15) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_16: PO_Line_0 {
            idc = 73016;
            x = "(((624 + 177) + 4*16) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_17: PO_Line_0 {
            idc = 73017;
            x = "(((624 + 177) + 4*17) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_18: PO_Line_0 {
            idc = 73018;
            x = "(((624 + 177) + 4*18) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_19: PO_Line_0 {
            idc = 73019;
            x = "(((624 + 177) + 4*19) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_20: PO_Line_0 {
            idc = 73020;
            x = "(((624 + 177) + 4*20) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_21: PO_Line_0 {
            idc = 73021;
            x = "(((624 + 177) + 4*21) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_22: PO_Line_0 {
            idc = 73022;
            x = "(((624 + 177) + 4*22) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_23: PO_Line_0 {
            idc = 73023;
            x = "(((624 + 177) + 4*23) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_24: PO_Line_0 {
            idc = 73024;
            x = "(((624 + 177) + 4*24) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_25: PO_Line_0 {
            idc = 73025;
            x = "(((624 + 177) + 4*25) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_26: PO_Line_0 {
            idc = 73026;
            x = "(((624 + 177) + 4*26) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_27: PO_Line_0 {
            idc = 73027;
            x = "(((624 + 177) + 4*27) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_28: PO_Line_0 {
            idc = 73028;
            x = "(((624 + 177) + 4*28) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_29: PO_Line_0 {
            idc = 73029;
            x = "(((624 + 177) + 4*29) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_30: PO_Line_0 {
            idc = 73030;
            x = "(((624 + 177) + 4*30) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_31: PO_Line_0 {
            idc = 73031;
            x = "(((624 + 177) + 4*31) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_32: PO_Line_0 {
            idc = 73032;
            x = "(((624 + 177) + 4*32) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_33: PO_Line_0 {
            idc = 73033;
            x = "(((624 + 177) + 4*33) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_34: PO_Line_0 {
            idc = 73034;
            x = "(((624 + 177) + 4*34) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_35: PO_Line_0 {
            idc = 73035;
            x = "(((624 + 177) + 4*35) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_36: PO_Line_0 {
            idc = 73036;
            x = "(((624 + 177) + 4*36) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_37: PO_Line_0 {
            idc = 73037;
            x = "(((624 + 177) + 4*37) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_38: PO_Line_0 {
            idc = 73038;
            x = "(((624 + 177) + 4*38) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_39: PO_Line_0 {
            idc = 73039;
            x = "(((624 + 177) + 4*39) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_40: PO_Line_0 {
            idc = 73040;
            x = "(((624 + 177) + 4*40) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_41: PO_Line_0 {
            idc = 73041;
            x = "(((624 + 177) + 4*41) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_42: PO_Line_0 {
            idc = 73042;
            x = "(((624 + 177) + 4*42) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_43: PO_Line_0 {
            idc = 73043;
            x = "(((624 + 177) + 4*43) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_44: PO_Line_0 {
            idc = 73044;
            x = "(((624 + 177) + 4*44) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_45: PO_Line_0 {
            idc = 73045;
            x = "(((624 + 177) + 4*45) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_46: PO_Line_0 {
            idc = 73046;
            x = "(((624 + 177) + 4*46) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_47: PO_Line_0 {
            idc = 73047;
            x = "(((624 + 177) + 4*47) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_48: PO_Line_0 {
            idc = 73048;
            x = "(((624 + 177) + 4*48) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_49: PO_Line_0 {
            idc = 73049;
            x = "(((624 + 177) + 4*49) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_50: PO_Line_0 {
            idc = 73050;
            x = "(((624 + 177) + 4*50) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_51: PO_Line_0 {
            idc = 73051;
            x = "(((624 + 177) + 4*51) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_52: PO_Line_0 {
            idc = 73052;
            x = "(((624 + 177) + 4*52) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_53: PO_Line_0 {
            idc = 73053;
            x = "(((624 + 177) + 4*53) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_54: PO_Line_0 {
            idc = 73054;
            x = "(((624 + 177) + 4*54) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_55: PO_Line_0 {
            idc = 73055;
            x = "(((624 + 177) + 4*55) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_56: PO_Line_0 {
            idc = 73056;
            x = "(((624 + 177) + 4*56) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_57: PO_Line_0 {
            idc = 73057;
            x = "(((624 + 177) + 4*57) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_58: PO_Line_0 {
            idc = 73058;
            x = "(((624 + 177) + 4*58) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_59: PO_Line_0 {
            idc = 73059;
            x = "(((624 + 177) + 4*59) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_60: PO_Line_0 {
            idc = 73060;
            x = "(((624 + 177) + 4*60) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_61: PO_Line_0 {
            idc = 73061;
            x = "(((624 + 177) + 4*61) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_62: PO_Line_0 {
            idc = 73062;
            x = "(((624 + 177) + 4*62) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_63: PO_Line_0 {
            idc = 73063;
            x = "(((624 + 177) + 4*63) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_64: PO_Line_0 {
            idc = 73064;
            x = "(((624 + 177) + 4*64) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_65: PO_Line_0 {
            idc = 73065;
            x = "(((624 + 177) + 4*65) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_66: PO_Line_0 {
            idc = 73066;
            x = "(((624 + 177) + 4*66) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_67: PO_Line_0 {
            idc = 73067;
            x = "(((624 + 177) + 4*67) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_68: PO_Line_0 {
            idc = 73068;
            x = "(((624 + 177) + 4*68) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_69: PO_Line_0 {
            idc = 73069;
            x = "(((624 + 177) + 4*69) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_70: PO_Line_0 {
            idc = 73070;
            x = "(((624 + 177) + 4*70) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_71: PO_Line_0 {
            idc = 73071;
            x = "(((624 + 177) + 4*71) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_72: PO_Line_0 {
            idc = 73072;
            x = "(((624 + 177) + 4*72) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_73: PO_Line_0 {
            idc = 73073;
            x = "(((624 + 177) + 4*73) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_74: PO_Line_0 {
            idc = 73074;
            x = "(((624 + 177) + 4*74) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_75: PO_Line_0 {
            idc = 73075;
            x = "(((624 + 177) + 4*75) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_76: PO_Line_0 {
            idc = 73076;
            x = "(((624 + 177) + 4*76) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_77: PO_Line_0 {
            idc = 73077;
            x = "(((624 + 177) + 4*77) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_78: PO_Line_0 {
            idc = 73078;
            x = "(((624 + 177) + 4*78) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_79: PO_Line_0 {
            idc = 73079;
            x = "(((624 + 177) + 4*79) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_80: PO_Line_0 {
            idc = 73080;
            x = "(((624 + 177) + 4*80) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_81: PO_Line_0 {
            idc = 73081;
            x = "(((624 + 177) + 4*81) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_82: PO_Line_0 {
            idc = 73082;
            x = "(((624 + 177) + 4*82) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_83: PO_Line_0 {
            idc = 73083;
            x = "(((624 + 177) + 4*83) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_84: PO_Line_0 {
            idc = 73084;
            x = "(((624 + 177) + 4*84) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_85: PO_Line_0 {
            idc = 73085;
            x = "(((624 + 177) + 4*85) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_86: PO_Line_0 {
            idc = 73086;
            x = "(((624 + 177) + 4*86) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_87: PO_Line_0 {
            idc = 73087;
            x = "(((624 + 177) + 4*87) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_88: PO_Line_0 {
            idc = 73088;
            x = "(((624 + 177) + 4*88) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_89: PO_Line_0 {
            idc = 73089;
            x = "(((624 + 177) + 4*89) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_90: PO_Line_0 {
            idc = 73090;
            x = "(((624 + 177) + 4*90) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_91: PO_Line_0 {
            idc = 73091;
            x = "(((624 + 177) + 4*91) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_92: PO_Line_0 {
            idc = 73092;
            x = "(((624 + 177) + 4*92) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_93: PO_Line_0 {
            idc = 73093;
            x = "(((624 + 177) + 4*93) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_94: PO_Line_0 {
            idc = 73094;
            x = "(((624 + 177) + 4*94) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_95: PO_Line_0 {
            idc = 73095;
            x = "(((624 + 177) + 4*95) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_96: PO_Line_0 {
            idc = 73096;
            x = "(((624 + 177) + 4*96) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_97: PO_Line_0 {
            idc = 73097;
            x = "(((624 + 177) + 4*97) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_98: PO_Line_0 {
            idc = 73098;
            x = "(((624 + 177) + 4*98) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_99: PO_Line_0 {
            idc = 73099;
            x = "(((624 + 177) + 4*99) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_100: PO_Line_0 {
            idc = 73100;
            x = "(((624 + 177) + 4*100) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_101: PO_Line_0 {
            idc = 73101;
            x = "(((624 + 177) + 4*101) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_102: PO_Line_0 {
            idc = 73102;
            x = "(((624 + 177) + 4*102) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_103: PO_Line_0 {
            idc = 73103;
            x = "(((624 + 177) + 4*103) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_104: PO_Line_0 {
            idc = 73104;
            x = "(((624 + 177) + 4*104) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_105: PO_Line_0 {
            idc = 73105;
            x = "(((624 + 177) + 4*105) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_106: PO_Line_0 {
            idc = 73106;
            x = "(((624 + 177) + 4*106) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_107: PO_Line_0 {
            idc = 73107;
            x = "(((624 + 177) + 4*107) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_108: PO_Line_0 {
            idc = 73108;
            x = "(((624 + 177) + 4*108) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_109: PO_Line_0 {
            idc = 73109;
            x = "(((624 + 177) + 4*109) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_110: PO_Line_0 {
            idc = 73110;
            x = "(((624 + 177) + 4*110) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_111: PO_Line_0 {
            idc = 73111;
            x = "(((624 + 177) + 4*111) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_112: PO_Line_0 {
            idc = 73112;
            x = "(((624 + 177) + 4*112) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_113: PO_Line_0 {
            idc = 73113;
            x = "(((624 + 177) + 4*113) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_114: PO_Line_0 {
            idc = 73114;
            x = "(((624 + 177) + 4*114) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_115: PO_Line_0 {
            idc = 73115;
            x = "(((624 + 177) + 4*115) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_116: PO_Line_0 {
            idc = 73116;
            x = "(((624 + 177) + 4*116) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_117: PO_Line_0 {
            idc = 73117;
            x = "(((624 + 177) + 4*117) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_118: PO_Line_0 {
            idc = 73118;
            x = "(((624 + 177) + 4*118) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_119: PO_Line_0 {
            idc = 73119;
            x = "(((624 + 177) + 4*119) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_120: PO_Line_0 {
            idc = 73120;
            x = "(((624 + 177) + 4*120) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_121: PO_Line_0 {
            idc = 73121;
            x = "(((624 + 177) + 4*121) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_122: PO_Line_0 {
            idc = 73122;
            x = "(((624 + 177) + 4*122) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_123: PO_Line_0 {
            idc = 73123;
            x = "(((624 + 177) + 4*123) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_124: PO_Line_0 {
            idc = 73124;
            x = "(((624 + 177) + 4*124) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_125: PO_Line_0 {
            idc = 73125;
            x = "(((624 + 177) + 4*125) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_126: PO_Line_0 {
            idc = 73126;
            x = "(((624 + 177) + 4*126) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_127: PO_Line_0 {
            idc = 73127;
            x = "(((624 + 177) + 4*127) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_128: PO_Line_0 {
            idc = 73128;
            x = "(((624 + 177) + 4*128) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_129: PO_Line_0 {
            idc = 73129;
            x = "(((624 + 177) + 4*129) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_130: PO_Line_0 {
            idc = 73130;
            x = "(((624 + 177) + 4*130) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_131: PO_Line_0 {
            idc = 73131;
            x = "(((624 + 177) + 4*131) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_132: PO_Line_0 {
            idc = 73132;
            x = "(((624 + 177) + 4*132) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_133: PO_Line_0 {
            idc = 73133;
            x = "(((624 + 177) + 4*133) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_134: PO_Line_0 {
            idc = 73134;
            x = "(((624 + 177) + 4*134) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_135: PO_Line_0 {
            idc = 73135;
            x = "(((624 + 177) + 4*135) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_136: PO_Line_0 {
            idc = 73136;
            x = "(((624 + 177) + 4*136) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_137: PO_Line_0 {
            idc = 73137;
            x = "(((624 + 177) + 4*137) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_138: PO_Line_0 {
            idc = 73138;
            x = "(((624 + 177) + 4*138) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_139: PO_Line_0 {
            idc = 73139;
            x = "(((624 + 177) + 4*139) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_140: PO_Line_0 {
            idc = 73140;
            x = "(((624 + 177) + 4*140) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_141: PO_Line_0 {
            idc = 73141;
            x = "(((624 + 177) + 4*141) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_142: PO_Line_0 {
            idc = 73142;
            x = "(((624 + 177) + 4*142) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_143: PO_Line_0 {
            idc = 73143;
            x = "(((624 + 177) + 4*143) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_144: PO_Line_0 {
            idc = 73144;
            x = "(((624 + 177) + 4*144) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_145: PO_Line_0 {
            idc = 73145;
            x = "(((624 + 177) + 4*145) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_146: PO_Line_0 {
            idc = 73146;
            x = "(((624 + 177) + 4*146) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_147: PO_Line_0 {
            idc = 73147;
            x = "(((624 + 177) + 4*147) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_148: PO_Line_0 {
            idc = 73148;
            x = "(((624 + 177) + 4*148) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_149: PO_Line_0 {
            idc = 73149;
            x = "(((624 + 177) + 4*149) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_150: PO_Line_0 {
            idc = 73150;
            x = "(((624 + 177) + 4*150) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_151: PO_Line_0 {
            idc = 73151;
            x = "(((624 + 177) + 4*151) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_152: PO_Line_0 {
            idc = 73152;
            x = "(((624 + 177) + 4*152) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_153: PO_Line_0 {
            idc = 73153;
            x = "(((624 + 177) + 4*153) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_154: PO_Line_0 {
            idc = 73154;
            x = "(((624 + 177) + 4*154) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_155: PO_Line_0 {
            idc = 73155;
            x = "(((624 + 177) + 4*155) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_156: PO_Line_0 {
            idc = 73156;
            x = "(((624 + 177) + 4*156) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_157: PO_Line_0 {
            idc = 73157;
            x = "(((624 + 177) + 4*157) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_158: PO_Line_0 {
            idc = 73158;
            x = "(((624 + 177) + 4*158) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_159: PO_Line_0 {
            idc = 73159;
            x = "(((624 + 177) + 4*159) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_160: PO_Line_0 {
            idc = 73160;
            x = "(((624 + 177) + 4*160) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_161: PO_Line_0 {
            idc = 73161;
            x = "(((624 + 177) + 4*161) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_162: PO_Line_0 {
            idc = 73162;
            x = "(((624 + 177) + 4*162) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_163: PO_Line_0 {
            idc = 73163;
            x = "(((624 + 177) + 4*163) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_164: PO_Line_0 {
            idc = 73164;
            x = "(((624 + 177) + 4*164) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_165: PO_Line_0 {
            idc = 73165;
            x = "(((624 + 177) + 4*165) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_166: PO_Line_0 {
            idc = 73166;
            x = "(((624 + 177) + 4*166) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_167: PO_Line_0 {
            idc = 73167;
            x = "(((624 + 177) + 4*167) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_168: PO_Line_0 {
            idc = 73168;
            x = "(((624 + 177) + 4*168) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_169: PO_Line_0 {
            idc = 73169;
            x = "(((624 + 177) + 4*169) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_170: PO_Line_0 {
            idc = 73170;
            x = "(((624 + 177) + 4*170) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_171: PO_Line_0 {
            idc = 73171;
            x = "(((624 + 177) + 4*171) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_172: PO_Line_0 {
            idc = 73172;
            x = "(((624 + 177) + 4*172) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_173: PO_Line_0 {
            idc = 73173;
            x = "(((624 + 177) + 4*173) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Line_174: PO_Line_0 {
            idc = 73174;
            x = "(((624 + 177) + 4*174) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            show = 0;
        };
        class PO_Dot_0: RscText {
            idc = 74000;
            x = "(((624 + 177) + 4*0) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            y = "(((546 + 105) + 160) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
            w = "(4 / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55))";
            h = "(2 / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3))";
            colorBackground[] = {0, 0.6, 1, 1};
            text = "";
        };
        class PO_Dot_1: PO_Dot_0 {
            idc = 74001;
            x = "(((624 + 177) + 4*1) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_2: PO_Dot_0 {
            idc = 74002;
            x = "(((624 + 177) + 4*2) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_3: PO_Dot_0 {
            idc = 74003;
            x = "(((624 + 177) + 4*3) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_4: PO_Dot_0 {
            idc = 74004;
            x = "(((624 + 177) + 4*4) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_5: PO_Dot_0 {
            idc = 74005;
            x = "(((624 + 177) + 4*5) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_6: PO_Dot_0 {
            idc = 74006;
            x = "(((624 + 177) + 4*6) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_7: PO_Dot_0 {
            idc = 74007;
            x = "(((624 + 177) + 4*7) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_8: PO_Dot_0 {
            idc = 74008;
            x = "(((624 + 177) + 4*8) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_9: PO_Dot_0 {
            idc = 74009;
            x = "(((624 + 177) + 4*9) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_10: PO_Dot_0 {
            idc = 74010;
            x = "(((624 + 177) + 4*10) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_11: PO_Dot_0 {
            idc = 74011;
            x = "(((624 + 177) + 4*11) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_12: PO_Dot_0 {
            idc = 74012;
            x = "(((624 + 177) + 4*12) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_13: PO_Dot_0 {
            idc = 74013;
            x = "(((624 + 177) + 4*13) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_14: PO_Dot_0 {
            idc = 74014;
            x = "(((624 + 177) + 4*14) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_15: PO_Dot_0 {
            idc = 74015;
            x = "(((624 + 177) + 4*15) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_16: PO_Dot_0 {
            idc = 74016;
            x = "(((624 + 177) + 4*16) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_17: PO_Dot_0 {
            idc = 74017;
            x = "(((624 + 177) + 4*17) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_18: PO_Dot_0 {
            idc = 74018;
            x = "(((624 + 177) + 4*18) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_19: PO_Dot_0 {
            idc = 74019;
            x = "(((624 + 177) + 4*19) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_20: PO_Dot_0 {
            idc = 74020;
            x = "(((624 + 177) + 4*20) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_21: PO_Dot_0 {
            idc = 74021;
            x = "(((624 + 177) + 4*21) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_22: PO_Dot_0 {
            idc = 74022;
            x = "(((624 + 177) + 4*22) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_23: PO_Dot_0 {
            idc = 74023;
            x = "(((624 + 177) + 4*23) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_24: PO_Dot_0 {
            idc = 74024;
            x = "(((624 + 177) + 4*24) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_25: PO_Dot_0 {
            idc = 74025;
            x = "(((624 + 177) + 4*25) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_26: PO_Dot_0 {
            idc = 74026;
            x = "(((624 + 177) + 4*26) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_27: PO_Dot_0 {
            idc = 74027;
            x = "(((624 + 177) + 4*27) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_28: PO_Dot_0 {
            idc = 74028;
            x = "(((624 + 177) + 4*28) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_29: PO_Dot_0 {
            idc = 74029;
            x = "(((624 + 177) + 4*29) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_30: PO_Dot_0 {
            idc = 74030;
            x = "(((624 + 177) + 4*30) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_31: PO_Dot_0 {
            idc = 74031;
            x = "(((624 + 177) + 4*31) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_32: PO_Dot_0 {
            idc = 74032;
            x = "(((624 + 177) + 4*32) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_33: PO_Dot_0 {
            idc = 74033;
            x = "(((624 + 177) + 4*33) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_34: PO_Dot_0 {
            idc = 74034;
            x = "(((624 + 177) + 4*34) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_35: PO_Dot_0 {
            idc = 74035;
            x = "(((624 + 177) + 4*35) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_36: PO_Dot_0 {
            idc = 74036;
            x = "(((624 + 177) + 4*36) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_37: PO_Dot_0 {
            idc = 74037;
            x = "(((624 + 177) + 4*37) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_38: PO_Dot_0 {
            idc = 74038;
            x = "(((624 + 177) + 4*38) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_39: PO_Dot_0 {
            idc = 74039;
            x = "(((624 + 177) + 4*39) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_40: PO_Dot_0 {
            idc = 74040;
            x = "(((624 + 177) + 4*40) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_41: PO_Dot_0 {
            idc = 74041;
            x = "(((624 + 177) + 4*41) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_42: PO_Dot_0 {
            idc = 74042;
            x = "(((624 + 177) + 4*42) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_43: PO_Dot_0 {
            idc = 74043;
            x = "(((624 + 177) + 4*43) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_44: PO_Dot_0 {
            idc = 74044;
            x = "(((624 + 177) + 4*44) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_45: PO_Dot_0 {
            idc = 74045;
            x = "(((624 + 177) + 4*45) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_46: PO_Dot_0 {
            idc = 74046;
            x = "(((624 + 177) + 4*46) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_47: PO_Dot_0 {
            idc = 74047;
            x = "(((624 + 177) + 4*47) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_48: PO_Dot_0 {
            idc = 74048;
            x = "(((624 + 177) + 4*48) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_49: PO_Dot_0 {
            idc = 74049;
            x = "(((624 + 177) + 4*49) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_50: PO_Dot_0 {
            idc = 74050;
            x = "(((624 + 177) + 4*50) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_51: PO_Dot_0 {
            idc = 74051;
            x = "(((624 + 177) + 4*51) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_52: PO_Dot_0 {
            idc = 74052;
            x = "(((624 + 177) + 4*52) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_53: PO_Dot_0 {
            idc = 74053;
            x = "(((624 + 177) + 4*53) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_54: PO_Dot_0 {
            idc = 74054;
            x = "(((624 + 177) + 4*54) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_55: PO_Dot_0 {
            idc = 74055;
            x = "(((624 + 177) + 4*55) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_56: PO_Dot_0 {
            idc = 74056;
            x = "(((624 + 177) + 4*56) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_57: PO_Dot_0 {
            idc = 74057;
            x = "(((624 + 177) + 4*57) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_58: PO_Dot_0 {
            idc = 74058;
            x = "(((624 + 177) + 4*58) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_59: PO_Dot_0 {
            idc = 74059;
            x = "(((624 + 177) + 4*59) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_60: PO_Dot_0 {
            idc = 74060;
            x = "(((624 + 177) + 4*60) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_61: PO_Dot_0 {
            idc = 74061;
            x = "(((624 + 177) + 4*61) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_62: PO_Dot_0 {
            idc = 74062;
            x = "(((624 + 177) + 4*62) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_63: PO_Dot_0 {
            idc = 74063;
            x = "(((624 + 177) + 4*63) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_64: PO_Dot_0 {
            idc = 74064;
            x = "(((624 + 177) + 4*64) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_65: PO_Dot_0 {
            idc = 74065;
            x = "(((624 + 177) + 4*65) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_66: PO_Dot_0 {
            idc = 74066;
            x = "(((624 + 177) + 4*66) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_67: PO_Dot_0 {
            idc = 74067;
            x = "(((624 + 177) + 4*67) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_68: PO_Dot_0 {
            idc = 74068;
            x = "(((624 + 177) + 4*68) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_69: PO_Dot_0 {
            idc = 74069;
            x = "(((624 + 177) + 4*69) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_70: PO_Dot_0 {
            idc = 74070;
            x = "(((624 + 177) + 4*70) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_71: PO_Dot_0 {
            idc = 74071;
            x = "(((624 + 177) + 4*71) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_72: PO_Dot_0 {
            idc = 74072;
            x = "(((624 + 177) + 4*72) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_73: PO_Dot_0 {
            idc = 74073;
            x = "(((624 + 177) + 4*73) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_74: PO_Dot_0 {
            idc = 74074;
            x = "(((624 + 177) + 4*74) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_75: PO_Dot_0 {
            idc = 74075;
            x = "(((624 + 177) + 4*75) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_76: PO_Dot_0 {
            idc = 74076;
            x = "(((624 + 177) + 4*76) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_77: PO_Dot_0 {
            idc = 74077;
            x = "(((624 + 177) + 4*77) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_78: PO_Dot_0 {
            idc = 74078;
            x = "(((624 + 177) + 4*78) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_79: PO_Dot_0 {
            idc = 74079;
            x = "(((624 + 177) + 4*79) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_80: PO_Dot_0 {
            idc = 74080;
            x = "(((624 + 177) + 4*80) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_81: PO_Dot_0 {
            idc = 74081;
            x = "(((624 + 177) + 4*81) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_82: PO_Dot_0 {
            idc = 74082;
            x = "(((624 + 177) + 4*82) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_83: PO_Dot_0 {
            idc = 74083;
            x = "(((624 + 177) + 4*83) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_84: PO_Dot_0 {
            idc = 74084;
            x = "(((624 + 177) + 4*84) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_85: PO_Dot_0 {
            idc = 74085;
            x = "(((624 + 177) + 4*85) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_86: PO_Dot_0 {
            idc = 74086;
            x = "(((624 + 177) + 4*86) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_87: PO_Dot_0 {
            idc = 74087;
            x = "(((624 + 177) + 4*87) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_88: PO_Dot_0 {
            idc = 74088;
            x = "(((624 + 177) + 4*88) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_89: PO_Dot_0 {
            idc = 74089;
            x = "(((624 + 177) + 4*89) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_90: PO_Dot_0 {
            idc = 74090;
            x = "(((624 + 177) + 4*90) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_91: PO_Dot_0 {
            idc = 74091;
            x = "(((624 + 177) + 4*91) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_92: PO_Dot_0 {
            idc = 74092;
            x = "(((624 + 177) + 4*92) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_93: PO_Dot_0 {
            idc = 74093;
            x = "(((624 + 177) + 4*93) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_94: PO_Dot_0 {
            idc = 74094;
            x = "(((624 + 177) + 4*94) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_95: PO_Dot_0 {
            idc = 74095;
            x = "(((624 + 177) + 4*95) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_96: PO_Dot_0 {
            idc = 74096;
            x = "(((624 + 177) + 4*96) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_97: PO_Dot_0 {
            idc = 74097;
            x = "(((624 + 177) + 4*97) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_98: PO_Dot_0 {
            idc = 74098;
            x = "(((624 + 177) + 4*98) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_99: PO_Dot_0 {
            idc = 74099;
            x = "(((624 + 177) + 4*99) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_100: PO_Dot_0 {
            idc = 74100;
            x = "(((624 + 177) + 4*100) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_101: PO_Dot_0 {
            idc = 74101;
            x = "(((624 + 177) + 4*101) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_102: PO_Dot_0 {
            idc = 74102;
            x = "(((624 + 177) + 4*102) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_103: PO_Dot_0 {
            idc = 74103;
            x = "(((624 + 177) + 4*103) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_104: PO_Dot_0 {
            idc = 74104;
            x = "(((624 + 177) + 4*104) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_105: PO_Dot_0 {
            idc = 74105;
            x = "(((624 + 177) + 4*105) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_106: PO_Dot_0 {
            idc = 74106;
            x = "(((624 + 177) + 4*106) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_107: PO_Dot_0 {
            idc = 74107;
            x = "(((624 + 177) + 4*107) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_108: PO_Dot_0 {
            idc = 74108;
            x = "(((624 + 177) + 4*108) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_109: PO_Dot_0 {
            idc = 74109;
            x = "(((624 + 177) + 4*109) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_110: PO_Dot_0 {
            idc = 74110;
            x = "(((624 + 177) + 4*110) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_111: PO_Dot_0 {
            idc = 74111;
            x = "(((624 + 177) + 4*111) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_112: PO_Dot_0 {
            idc = 74112;
            x = "(((624 + 177) + 4*112) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_113: PO_Dot_0 {
            idc = 74113;
            x = "(((624 + 177) + 4*113) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_114: PO_Dot_0 {
            idc = 74114;
            x = "(((624 + 177) + 4*114) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_115: PO_Dot_0 {
            idc = 74115;
            x = "(((624 + 177) + 4*115) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_116: PO_Dot_0 {
            idc = 74116;
            x = "(((624 + 177) + 4*116) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_117: PO_Dot_0 {
            idc = 74117;
            x = "(((624 + 177) + 4*117) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_118: PO_Dot_0 {
            idc = 74118;
            x = "(((624 + 177) + 4*118) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_119: PO_Dot_0 {
            idc = 74119;
            x = "(((624 + 177) + 4*119) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_120: PO_Dot_0 {
            idc = 74120;
            x = "(((624 + 177) + 4*120) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_121: PO_Dot_0 {
            idc = 74121;
            x = "(((624 + 177) + 4*121) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_122: PO_Dot_0 {
            idc = 74122;
            x = "(((624 + 177) + 4*122) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_123: PO_Dot_0 {
            idc = 74123;
            x = "(((624 + 177) + 4*123) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_124: PO_Dot_0 {
            idc = 74124;
            x = "(((624 + 177) + 4*124) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_125: PO_Dot_0 {
            idc = 74125;
            x = "(((624 + 177) + 4*125) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_126: PO_Dot_0 {
            idc = 74126;
            x = "(((624 + 177) + 4*126) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_127: PO_Dot_0 {
            idc = 74127;
            x = "(((624 + 177) + 4*127) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_128: PO_Dot_0 {
            idc = 74128;
            x = "(((624 + 177) + 4*128) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_129: PO_Dot_0 {
            idc = 74129;
            x = "(((624 + 177) + 4*129) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_130: PO_Dot_0 {
            idc = 74130;
            x = "(((624 + 177) + 4*130) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_131: PO_Dot_0 {
            idc = 74131;
            x = "(((624 + 177) + 4*131) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_132: PO_Dot_0 {
            idc = 74132;
            x = "(((624 + 177) + 4*132) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_133: PO_Dot_0 {
            idc = 74133;
            x = "(((624 + 177) + 4*133) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_134: PO_Dot_0 {
            idc = 74134;
            x = "(((624 + 177) + 4*134) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_135: PO_Dot_0 {
            idc = 74135;
            x = "(((624 + 177) + 4*135) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_136: PO_Dot_0 {
            idc = 74136;
            x = "(((624 + 177) + 4*136) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_137: PO_Dot_0 {
            idc = 74137;
            x = "(((624 + 177) + 4*137) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_138: PO_Dot_0 {
            idc = 74138;
            x = "(((624 + 177) + 4*138) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_139: PO_Dot_0 {
            idc = 74139;
            x = "(((624 + 177) + 4*139) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_140: PO_Dot_0 {
            idc = 74140;
            x = "(((624 + 177) + 4*140) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_141: PO_Dot_0 {
            idc = 74141;
            x = "(((624 + 177) + 4*141) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_142: PO_Dot_0 {
            idc = 74142;
            x = "(((624 + 177) + 4*142) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_143: PO_Dot_0 {
            idc = 74143;
            x = "(((624 + 177) + 4*143) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_144: PO_Dot_0 {
            idc = 74144;
            x = "(((624 + 177) + 4*144) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_145: PO_Dot_0 {
            idc = 74145;
            x = "(((624 + 177) + 4*145) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_146: PO_Dot_0 {
            idc = 74146;
            x = "(((624 + 177) + 4*146) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_147: PO_Dot_0 {
            idc = 74147;
            x = "(((624 + 177) + 4*147) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_148: PO_Dot_0 {
            idc = 74148;
            x = "(((624 + 177) + 4*148) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_149: PO_Dot_0 {
            idc = 74149;
            x = "(((624 + 177) + 4*149) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_150: PO_Dot_0 {
            idc = 74150;
            x = "(((624 + 177) + 4*150) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_151: PO_Dot_0 {
            idc = 74151;
            x = "(((624 + 177) + 4*151) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_152: PO_Dot_0 {
            idc = 74152;
            x = "(((624 + 177) + 4*152) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_153: PO_Dot_0 {
            idc = 74153;
            x = "(((624 + 177) + 4*153) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_154: PO_Dot_0 {
            idc = 74154;
            x = "(((624 + 177) + 4*154) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_155: PO_Dot_0 {
            idc = 74155;
            x = "(((624 + 177) + 4*155) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_156: PO_Dot_0 {
            idc = 74156;
            x = "(((624 + 177) + 4*156) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_157: PO_Dot_0 {
            idc = 74157;
            x = "(((624 + 177) + 4*157) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_158: PO_Dot_0 {
            idc = 74158;
            x = "(((624 + 177) + 4*158) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_159: PO_Dot_0 {
            idc = 74159;
            x = "(((624 + 177) + 4*159) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_160: PO_Dot_0 {
            idc = 74160;
            x = "(((624 + 177) + 4*160) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_161: PO_Dot_0 {
            idc = 74161;
            x = "(((624 + 177) + 4*161) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_162: PO_Dot_0 {
            idc = 74162;
            x = "(((624 + 177) + 4*162) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_163: PO_Dot_0 {
            idc = 74163;
            x = "(((624 + 177) + 4*163) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_164: PO_Dot_0 {
            idc = 74164;
            x = "(((624 + 177) + 4*164) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_165: PO_Dot_0 {
            idc = 74165;
            x = "(((624 + 177) + 4*165) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_166: PO_Dot_0 {
            idc = 74166;
            x = "(((624 + 177) + 4*166) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_167: PO_Dot_0 {
            idc = 74167;
            x = "(((624 + 177) + 4*167) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_168: PO_Dot_0 {
            idc = 74168;
            x = "(((624 + 177) + 4*168) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_169: PO_Dot_0 {
            idc = 74169;
            x = "(((624 + 177) + 4*169) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_170: PO_Dot_0 {
            idc = 74170;
            x = "(((624 + 177) + 4*170) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_171: PO_Dot_0 {
            idc = 74171;
            x = "(((624 + 177) + 4*171) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_172: PO_Dot_0 {
            idc = 74172;
            x = "(((624 + 177) + 4*172) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_173: PO_Dot_0 {
            idc = 74173;
            x = "(((624 + 177) + 4*173) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class PO_Dot_174: PO_Dot_0 {
            idc = 74174;
            x = "(((624 + 177) + 4*174) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_0: RscLine {
            idc = 75000;
            x = "(((624 + 177) + 4*0) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            y = "(((546 + 105) + 400) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
            w = "(4 / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55))";
            h = "(0 / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3))";
            colorBackground[] = {0, 0, 0, 0};
            colorText[] = {1, 0.5, 0.2, 1};
            text = "";
        };
        class CO_Line_1: CO_Line_0 {
            idc = 75001;
            x = "(((624 + 177) + 4*1) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_2: CO_Line_0 {
            idc = 75002;
            x = "(((624 + 177) + 4*2) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_3: CO_Line_0 {
            idc = 75003;
            x = "(((624 + 177) + 4*3) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_4: CO_Line_0 {
            idc = 75004;
            x = "(((624 + 177) + 4*4) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_5: CO_Line_0 {
            idc = 75005;
            x = "(((624 + 177) + 4*5) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_6: CO_Line_0 {
            idc = 75006;
            x = "(((624 + 177) + 4*6) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_7: CO_Line_0 {
            idc = 75007;
            x = "(((624 + 177) + 4*7) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_8: CO_Line_0 {
            idc = 75008;
            x = "(((624 + 177) + 4*8) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_9: CO_Line_0 {
            idc = 75009;
            x = "(((624 + 177) + 4*9) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_10: CO_Line_0 {
            idc = 75010;
            x = "(((624 + 177) + 4*10) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_11: CO_Line_0 {
            idc = 75011;
            x = "(((624 + 177) + 4*11) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_12: CO_Line_0 {
            idc = 75012;
            x = "(((624 + 177) + 4*12) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_13: CO_Line_0 {
            idc = 75013;
            x = "(((624 + 177) + 4*13) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_14: CO_Line_0 {
            idc = 75014;
            x = "(((624 + 177) + 4*14) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_15: CO_Line_0 {
            idc = 75015;
            x = "(((624 + 177) + 4*15) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_16: CO_Line_0 {
            idc = 75016;
            x = "(((624 + 177) + 4*16) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_17: CO_Line_0 {
            idc = 75017;
            x = "(((624 + 177) + 4*17) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_18: CO_Line_0 {
            idc = 75018;
            x = "(((624 + 177) + 4*18) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_19: CO_Line_0 {
            idc = 75019;
            x = "(((624 + 177) + 4*19) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_20: CO_Line_0 {
            idc = 75020;
            x = "(((624 + 177) + 4*20) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_21: CO_Line_0 {
            idc = 75021;
            x = "(((624 + 177) + 4*21) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_22: CO_Line_0 {
            idc = 75022;
            x = "(((624 + 177) + 4*22) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_23: CO_Line_0 {
            idc = 75023;
            x = "(((624 + 177) + 4*23) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_24: CO_Line_0 {
            idc = 75024;
            x = "(((624 + 177) + 4*24) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_25: CO_Line_0 {
            idc = 75025;
            x = "(((624 + 177) + 4*25) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_26: CO_Line_0 {
            idc = 75026;
            x = "(((624 + 177) + 4*26) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_27: CO_Line_0 {
            idc = 75027;
            x = "(((624 + 177) + 4*27) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_28: CO_Line_0 {
            idc = 75028;
            x = "(((624 + 177) + 4*28) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_29: CO_Line_0 {
            idc = 75029;
            x = "(((624 + 177) + 4*29) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_30: CO_Line_0 {
            idc = 75030;
            x = "(((624 + 177) + 4*30) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_31: CO_Line_0 {
            idc = 75031;
            x = "(((624 + 177) + 4*31) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_32: CO_Line_0 {
            idc = 75032;
            x = "(((624 + 177) + 4*32) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_33: CO_Line_0 {
            idc = 75033;
            x = "(((624 + 177) + 4*33) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_34: CO_Line_0 {
            idc = 75034;
            x = "(((624 + 177) + 4*34) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_35: CO_Line_0 {
            idc = 75035;
            x = "(((624 + 177) + 4*35) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_36: CO_Line_0 {
            idc = 75036;
            x = "(((624 + 177) + 4*36) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_37: CO_Line_0 {
            idc = 75037;
            x = "(((624 + 177) + 4*37) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_38: CO_Line_0 {
            idc = 75038;
            x = "(((624 + 177) + 4*38) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_39: CO_Line_0 {
            idc = 75039;
            x = "(((624 + 177) + 4*39) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_40: CO_Line_0 {
            idc = 75040;
            x = "(((624 + 177) + 4*40) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_41: CO_Line_0 {
            idc = 75041;
            x = "(((624 + 177) + 4*41) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_42: CO_Line_0 {
            idc = 75042;
            x = "(((624 + 177) + 4*42) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_43: CO_Line_0 {
            idc = 75043;
            x = "(((624 + 177) + 4*43) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_44: CO_Line_0 {
            idc = 75044;
            x = "(((624 + 177) + 4*44) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_45: CO_Line_0 {
            idc = 75045;
            x = "(((624 + 177) + 4*45) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_46: CO_Line_0 {
            idc = 75046;
            x = "(((624 + 177) + 4*46) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_47: CO_Line_0 {
            idc = 75047;
            x = "(((624 + 177) + 4*47) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_48: CO_Line_0 {
            idc = 75048;
            x = "(((624 + 177) + 4*48) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_49: CO_Line_0 {
            idc = 75049;
            x = "(((624 + 177) + 4*49) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_50: CO_Line_0 {
            idc = 75050;
            x = "(((624 + 177) + 4*50) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_51: CO_Line_0 {
            idc = 75051;
            x = "(((624 + 177) + 4*51) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_52: CO_Line_0 {
            idc = 75052;
            x = "(((624 + 177) + 4*52) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_53: CO_Line_0 {
            idc = 75053;
            x = "(((624 + 177) + 4*53) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_54: CO_Line_0 {
            idc = 75054;
            x = "(((624 + 177) + 4*54) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_55: CO_Line_0 {
            idc = 75055;
            x = "(((624 + 177) + 4*55) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_56: CO_Line_0 {
            idc = 75056;
            x = "(((624 + 177) + 4*56) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_57: CO_Line_0 {
            idc = 75057;
            x = "(((624 + 177) + 4*57) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_58: CO_Line_0 {
            idc = 75058;
            x = "(((624 + 177) + 4*58) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_59: CO_Line_0 {
            idc = 75059;
            x = "(((624 + 177) + 4*59) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_60: CO_Line_0 {
            idc = 75060;
            x = "(((624 + 177) + 4*60) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_61: CO_Line_0 {
            idc = 75061;
            x = "(((624 + 177) + 4*61) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_62: CO_Line_0 {
            idc = 75062;
            x = "(((624 + 177) + 4*62) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_63: CO_Line_0 {
            idc = 75063;
            x = "(((624 + 177) + 4*63) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_64: CO_Line_0 {
            idc = 75064;
            x = "(((624 + 177) + 4*64) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_65: CO_Line_0 {
            idc = 75065;
            x = "(((624 + 177) + 4*65) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_66: CO_Line_0 {
            idc = 75066;
            x = "(((624 + 177) + 4*66) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_67: CO_Line_0 {
            idc = 75067;
            x = "(((624 + 177) + 4*67) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_68: CO_Line_0 {
            idc = 75068;
            x = "(((624 + 177) + 4*68) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_69: CO_Line_0 {
            idc = 75069;
            x = "(((624 + 177) + 4*69) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_70: CO_Line_0 {
            idc = 75070;
            x = "(((624 + 177) + 4*70) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_71: CO_Line_0 {
            idc = 75071;
            x = "(((624 + 177) + 4*71) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_72: CO_Line_0 {
            idc = 75072;
            x = "(((624 + 177) + 4*72) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_73: CO_Line_0 {
            idc = 75073;
            x = "(((624 + 177) + 4*73) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_74: CO_Line_0 {
            idc = 75074;
            x = "(((624 + 177) + 4*74) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_75: CO_Line_0 {
            idc = 75075;
            x = "(((624 + 177) + 4*75) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_76: CO_Line_0 {
            idc = 75076;
            x = "(((624 + 177) + 4*76) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_77: CO_Line_0 {
            idc = 75077;
            x = "(((624 + 177) + 4*77) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_78: CO_Line_0 {
            idc = 75078;
            x = "(((624 + 177) + 4*78) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_79: CO_Line_0 {
            idc = 75079;
            x = "(((624 + 177) + 4*79) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_80: CO_Line_0 {
            idc = 75080;
            x = "(((624 + 177) + 4*80) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_81: CO_Line_0 {
            idc = 75081;
            x = "(((624 + 177) + 4*81) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_82: CO_Line_0 {
            idc = 75082;
            x = "(((624 + 177) + 4*82) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_83: CO_Line_0 {
            idc = 75083;
            x = "(((624 + 177) + 4*83) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_84: CO_Line_0 {
            idc = 75084;
            x = "(((624 + 177) + 4*84) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_85: CO_Line_0 {
            idc = 75085;
            x = "(((624 + 177) + 4*85) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_86: CO_Line_0 {
            idc = 75086;
            x = "(((624 + 177) + 4*86) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_87: CO_Line_0 {
            idc = 75087;
            x = "(((624 + 177) + 4*87) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_88: CO_Line_0 {
            idc = 75088;
            x = "(((624 + 177) + 4*88) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_89: CO_Line_0 {
            idc = 75089;
            x = "(((624 + 177) + 4*89) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_90: CO_Line_0 {
            idc = 75090;
            x = "(((624 + 177) + 4*90) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_91: CO_Line_0 {
            idc = 75091;
            x = "(((624 + 177) + 4*91) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_92: CO_Line_0 {
            idc = 75092;
            x = "(((624 + 177) + 4*92) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_93: CO_Line_0 {
            idc = 75093;
            x = "(((624 + 177) + 4*93) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_94: CO_Line_0 {
            idc = 75094;
            x = "(((624 + 177) + 4*94) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_95: CO_Line_0 {
            idc = 75095;
            x = "(((624 + 177) + 4*95) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_96: CO_Line_0 {
            idc = 75096;
            x = "(((624 + 177) + 4*96) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_97: CO_Line_0 {
            idc = 75097;
            x = "(((624 + 177) + 4*97) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_98: CO_Line_0 {
            idc = 75098;
            x = "(((624 + 177) + 4*98) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_99: CO_Line_0 {
            idc = 75099;
            x = "(((624 + 177) + 4*99) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_100: CO_Line_0 {
            idc = 75100;
            x = "(((624 + 177) + 4*100) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_101: CO_Line_0 {
            idc = 75101;
            x = "(((624 + 177) + 4*101) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_102: CO_Line_0 {
            idc = 75102;
            x = "(((624 + 177) + 4*102) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_103: CO_Line_0 {
            idc = 75103;
            x = "(((624 + 177) + 4*103) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_104: CO_Line_0 {
            idc = 75104;
            x = "(((624 + 177) + 4*104) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_105: CO_Line_0 {
            idc = 75105;
            x = "(((624 + 177) + 4*105) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_106: CO_Line_0 {
            idc = 75106;
            x = "(((624 + 177) + 4*106) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_107: CO_Line_0 {
            idc = 75107;
            x = "(((624 + 177) + 4*107) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_108: CO_Line_0 {
            idc = 75108;
            x = "(((624 + 177) + 4*108) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_109: CO_Line_0 {
            idc = 75109;
            x = "(((624 + 177) + 4*109) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_110: CO_Line_0 {
            idc = 75110;
            x = "(((624 + 177) + 4*110) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_111: CO_Line_0 {
            idc = 75111;
            x = "(((624 + 177) + 4*111) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_112: CO_Line_0 {
            idc = 75112;
            x = "(((624 + 177) + 4*112) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_113: CO_Line_0 {
            idc = 75113;
            x = "(((624 + 177) + 4*113) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_114: CO_Line_0 {
            idc = 75114;
            x = "(((624 + 177) + 4*114) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_115: CO_Line_0 {
            idc = 75115;
            x = "(((624 + 177) + 4*115) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_116: CO_Line_0 {
            idc = 75116;
            x = "(((624 + 177) + 4*116) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_117: CO_Line_0 {
            idc = 75117;
            x = "(((624 + 177) + 4*117) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_118: CO_Line_0 {
            idc = 75118;
            x = "(((624 + 177) + 4*118) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_119: CO_Line_0 {
            idc = 75119;
            x = "(((624 + 177) + 4*119) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_120: CO_Line_0 {
            idc = 75120;
            x = "(((624 + 177) + 4*120) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_121: CO_Line_0 {
            idc = 75121;
            x = "(((624 + 177) + 4*121) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_122: CO_Line_0 {
            idc = 75122;
            x = "(((624 + 177) + 4*122) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_123: CO_Line_0 {
            idc = 75123;
            x = "(((624 + 177) + 4*123) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_124: CO_Line_0 {
            idc = 75124;
            x = "(((624 + 177) + 4*124) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_125: CO_Line_0 {
            idc = 75125;
            x = "(((624 + 177) + 4*125) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_126: CO_Line_0 {
            idc = 75126;
            x = "(((624 + 177) + 4*126) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_127: CO_Line_0 {
            idc = 75127;
            x = "(((624 + 177) + 4*127) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_128: CO_Line_0 {
            idc = 75128;
            x = "(((624 + 177) + 4*128) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_129: CO_Line_0 {
            idc = 75129;
            x = "(((624 + 177) + 4*129) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_130: CO_Line_0 {
            idc = 75130;
            x = "(((624 + 177) + 4*130) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_131: CO_Line_0 {
            idc = 75131;
            x = "(((624 + 177) + 4*131) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_132: CO_Line_0 {
            idc = 75132;
            x = "(((624 + 177) + 4*132) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_133: CO_Line_0 {
            idc = 75133;
            x = "(((624 + 177) + 4*133) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_134: CO_Line_0 {
            idc = 75134;
            x = "(((624 + 177) + 4*134) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_135: CO_Line_0 {
            idc = 75135;
            x = "(((624 + 177) + 4*135) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_136: CO_Line_0 {
            idc = 75136;
            x = "(((624 + 177) + 4*136) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_137: CO_Line_0 {
            idc = 75137;
            x = "(((624 + 177) + 4*137) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_138: CO_Line_0 {
            idc = 75138;
            x = "(((624 + 177) + 4*138) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_139: CO_Line_0 {
            idc = 75139;
            x = "(((624 + 177) + 4*139) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_140: CO_Line_0 {
            idc = 75140;
            x = "(((624 + 177) + 4*140) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_141: CO_Line_0 {
            idc = 75141;
            x = "(((624 + 177) + 4*141) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_142: CO_Line_0 {
            idc = 75142;
            x = "(((624 + 177) + 4*142) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_143: CO_Line_0 {
            idc = 75143;
            x = "(((624 + 177) + 4*143) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_144: CO_Line_0 {
            idc = 75144;
            x = "(((624 + 177) + 4*144) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_145: CO_Line_0 {
            idc = 75145;
            x = "(((624 + 177) + 4*145) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_146: CO_Line_0 {
            idc = 75146;
            x = "(((624 + 177) + 4*146) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_147: CO_Line_0 {
            idc = 75147;
            x = "(((624 + 177) + 4*147) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_148: CO_Line_0 {
            idc = 75148;
            x = "(((624 + 177) + 4*148) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_149: CO_Line_0 {
            idc = 75149;
            x = "(((624 + 177) + 4*149) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_150: CO_Line_0 {
            idc = 75150;
            x = "(((624 + 177) + 4*150) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_151: CO_Line_0 {
            idc = 75151;
            x = "(((624 + 177) + 4*151) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_152: CO_Line_0 {
            idc = 75152;
            x = "(((624 + 177) + 4*152) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_153: CO_Line_0 {
            idc = 75153;
            x = "(((624 + 177) + 4*153) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_154: CO_Line_0 {
            idc = 75154;
            x = "(((624 + 177) + 4*154) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_155: CO_Line_0 {
            idc = 75155;
            x = "(((624 + 177) + 4*155) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_156: CO_Line_0 {
            idc = 75156;
            x = "(((624 + 177) + 4*156) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_157: CO_Line_0 {
            idc = 75157;
            x = "(((624 + 177) + 4*157) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_158: CO_Line_0 {
            idc = 75158;
            x = "(((624 + 177) + 4*158) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_159: CO_Line_0 {
            idc = 75159;
            x = "(((624 + 177) + 4*159) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_160: CO_Line_0 {
            idc = 75160;
            x = "(((624 + 177) + 4*160) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_161: CO_Line_0 {
            idc = 75161;
            x = "(((624 + 177) + 4*161) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_162: CO_Line_0 {
            idc = 75162;
            x = "(((624 + 177) + 4*162) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_163: CO_Line_0 {
            idc = 75163;
            x = "(((624 + 177) + 4*163) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_164: CO_Line_0 {
            idc = 75164;
            x = "(((624 + 177) + 4*164) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_165: CO_Line_0 {
            idc = 75165;
            x = "(((624 + 177) + 4*165) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_166: CO_Line_0 {
            idc = 75166;
            x = "(((624 + 177) + 4*166) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_167: CO_Line_0 {
            idc = 75167;
            x = "(((624 + 177) + 4*167) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_168: CO_Line_0 {
            idc = 75168;
            x = "(((624 + 177) + 4*168) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_169: CO_Line_0 {
            idc = 75169;
            x = "(((624 + 177) + 4*169) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_170: CO_Line_0 {
            idc = 75170;
            x = "(((624 + 177) + 4*170) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_171: CO_Line_0 {
            idc = 75171;
            x = "(((624 + 177) + 4*171) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_172: CO_Line_0 {
            idc = 75172;
            x = "(((624 + 177) + 4*172) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_173: CO_Line_0 {
            idc = 75173;
            x = "(((624 + 177) + 4*173) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Line_174: CO_Line_0 {
            idc = 75174;
            x = "(((624 + 177) + 4*174) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_0: RscText {
            idc = 76000;
            x = "(((624 + 177) + 4*0) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            y = "(((546 + 105) + 400) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
            w = "(4 / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55))";
            h = "(2 / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3))";
            colorBackground[] = {1, 0.5, 0.2, 1};
            text = "";
        };
        class CO_Dot_1: CO_Dot_0 {
            idc = 76001;
            x = "(((624 + 177) + 4*1) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_2: CO_Dot_0 {
            idc = 76002;
            x = "(((624 + 177) + 4*2) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_3: CO_Dot_0 {
            idc = 76003;
            x = "(((624 + 177) + 4*3) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_4: CO_Dot_0 {
            idc = 76004;
            x = "(((624 + 177) + 4*4) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_5: CO_Dot_0 {
            idc = 76005;
            x = "(((624 + 177) + 4*5) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_6: CO_Dot_0 {
            idc = 76006;
            x = "(((624 + 177) + 4*6) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_7: CO_Dot_0 {
            idc = 76007;
            x = "(((624 + 177) + 4*7) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_8: CO_Dot_0 {
            idc = 76008;
            x = "(((624 + 177) + 4*8) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_9: CO_Dot_0 {
            idc = 76009;
            x = "(((624 + 177) + 4*9) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_10: CO_Dot_0 {
            idc = 76010;
            x = "(((624 + 177) + 4*10) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_11: CO_Dot_0 {
            idc = 76011;
            x = "(((624 + 177) + 4*11) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_12: CO_Dot_0 {
            idc = 76012;
            x = "(((624 + 177) + 4*12) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_13: CO_Dot_0 {
            idc = 76013;
            x = "(((624 + 177) + 4*13) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_14: CO_Dot_0 {
            idc = 76014;
            x = "(((624 + 177) + 4*14) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_15: CO_Dot_0 {
            idc = 76015;
            x = "(((624 + 177) + 4*15) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_16: CO_Dot_0 {
            idc = 76016;
            x = "(((624 + 177) + 4*16) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_17: CO_Dot_0 {
            idc = 76017;
            x = "(((624 + 177) + 4*17) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_18: CO_Dot_0 {
            idc = 76018;
            x = "(((624 + 177) + 4*18) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_19: CO_Dot_0 {
            idc = 76019;
            x = "(((624 + 177) + 4*19) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_20: CO_Dot_0 {
            idc = 76020;
            x = "(((624 + 177) + 4*20) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_21: CO_Dot_0 {
            idc = 76021;
            x = "(((624 + 177) + 4*21) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_22: CO_Dot_0 {
            idc = 76022;
            x = "(((624 + 177) + 4*22) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_23: CO_Dot_0 {
            idc = 76023;
            x = "(((624 + 177) + 4*23) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_24: CO_Dot_0 {
            idc = 76024;
            x = "(((624 + 177) + 4*24) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_25: CO_Dot_0 {
            idc = 76025;
            x = "(((624 + 177) + 4*25) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_26: CO_Dot_0 {
            idc = 76026;
            x = "(((624 + 177) + 4*26) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_27: CO_Dot_0 {
            idc = 76027;
            x = "(((624 + 177) + 4*27) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_28: CO_Dot_0 {
            idc = 76028;
            x = "(((624 + 177) + 4*28) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_29: CO_Dot_0 {
            idc = 76029;
            x = "(((624 + 177) + 4*29) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_30: CO_Dot_0 {
            idc = 76030;
            x = "(((624 + 177) + 4*30) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_31: CO_Dot_0 {
            idc = 76031;
            x = "(((624 + 177) + 4*31) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_32: CO_Dot_0 {
            idc = 76032;
            x = "(((624 + 177) + 4*32) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_33: CO_Dot_0 {
            idc = 76033;
            x = "(((624 + 177) + 4*33) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_34: CO_Dot_0 {
            idc = 76034;
            x = "(((624 + 177) + 4*34) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_35: CO_Dot_0 {
            idc = 76035;
            x = "(((624 + 177) + 4*35) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_36: CO_Dot_0 {
            idc = 76036;
            x = "(((624 + 177) + 4*36) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_37: CO_Dot_0 {
            idc = 76037;
            x = "(((624 + 177) + 4*37) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_38: CO_Dot_0 {
            idc = 76038;
            x = "(((624 + 177) + 4*38) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_39: CO_Dot_0 {
            idc = 76039;
            x = "(((624 + 177) + 4*39) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_40: CO_Dot_0 {
            idc = 76040;
            x = "(((624 + 177) + 4*40) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_41: CO_Dot_0 {
            idc = 76041;
            x = "(((624 + 177) + 4*41) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_42: CO_Dot_0 {
            idc = 76042;
            x = "(((624 + 177) + 4*42) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_43: CO_Dot_0 {
            idc = 76043;
            x = "(((624 + 177) + 4*43) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_44: CO_Dot_0 {
            idc = 76044;
            x = "(((624 + 177) + 4*44) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_45: CO_Dot_0 {
            idc = 76045;
            x = "(((624 + 177) + 4*45) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_46: CO_Dot_0 {
            idc = 76046;
            x = "(((624 + 177) + 4*46) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_47: CO_Dot_0 {
            idc = 76047;
            x = "(((624 + 177) + 4*47) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_48: CO_Dot_0 {
            idc = 76048;
            x = "(((624 + 177) + 4*48) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_49: CO_Dot_0 {
            idc = 76049;
            x = "(((624 + 177) + 4*49) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_50: CO_Dot_0 {
            idc = 76050;
            x = "(((624 + 177) + 4*50) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_51: CO_Dot_0 {
            idc = 76051;
            x = "(((624 + 177) + 4*51) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_52: CO_Dot_0 {
            idc = 76052;
            x = "(((624 + 177) + 4*52) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_53: CO_Dot_0 {
            idc = 76053;
            x = "(((624 + 177) + 4*53) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_54: CO_Dot_0 {
            idc = 76054;
            x = "(((624 + 177) + 4*54) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_55: CO_Dot_0 {
            idc = 76055;
            x = "(((624 + 177) + 4*55) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_56: CO_Dot_0 {
            idc = 76056;
            x = "(((624 + 177) + 4*56) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_57: CO_Dot_0 {
            idc = 76057;
            x = "(((624 + 177) + 4*57) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_58: CO_Dot_0 {
            idc = 76058;
            x = "(((624 + 177) + 4*58) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_59: CO_Dot_0 {
            idc = 76059;
            x = "(((624 + 177) + 4*59) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_60: CO_Dot_0 {
            idc = 76060;
            x = "(((624 + 177) + 4*60) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_61: CO_Dot_0 {
            idc = 76061;
            x = "(((624 + 177) + 4*61) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_62: CO_Dot_0 {
            idc = 76062;
            x = "(((624 + 177) + 4*62) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_63: CO_Dot_0 {
            idc = 76063;
            x = "(((624 + 177) + 4*63) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_64: CO_Dot_0 {
            idc = 76064;
            x = "(((624 + 177) + 4*64) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_65: CO_Dot_0 {
            idc = 76065;
            x = "(((624 + 177) + 4*65) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_66: CO_Dot_0 {
            idc = 76066;
            x = "(((624 + 177) + 4*66) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_67: CO_Dot_0 {
            idc = 76067;
            x = "(((624 + 177) + 4*67) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_68: CO_Dot_0 {
            idc = 76068;
            x = "(((624 + 177) + 4*68) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_69: CO_Dot_0 {
            idc = 76069;
            x = "(((624 + 177) + 4*69) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_70: CO_Dot_0 {
            idc = 76070;
            x = "(((624 + 177) + 4*70) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_71: CO_Dot_0 {
            idc = 76071;
            x = "(((624 + 177) + 4*71) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_72: CO_Dot_0 {
            idc = 76072;
            x = "(((624 + 177) + 4*72) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_73: CO_Dot_0 {
            idc = 76073;
            x = "(((624 + 177) + 4*73) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_74: CO_Dot_0 {
            idc = 76074;
            x = "(((624 + 177) + 4*74) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_75: CO_Dot_0 {
            idc = 76075;
            x = "(((624 + 177) + 4*75) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_76: CO_Dot_0 {
            idc = 76076;
            x = "(((624 + 177) + 4*76) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_77: CO_Dot_0 {
            idc = 76077;
            x = "(((624 + 177) + 4*77) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_78: CO_Dot_0 {
            idc = 76078;
            x = "(((624 + 177) + 4*78) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_79: CO_Dot_0 {
            idc = 76079;
            x = "(((624 + 177) + 4*79) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_80: CO_Dot_0 {
            idc = 76080;
            x = "(((624 + 177) + 4*80) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_81: CO_Dot_0 {
            idc = 76081;
            x = "(((624 + 177) + 4*81) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_82: CO_Dot_0 {
            idc = 76082;
            x = "(((624 + 177) + 4*82) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_83: CO_Dot_0 {
            idc = 76083;
            x = "(((624 + 177) + 4*83) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_84: CO_Dot_0 {
            idc = 76084;
            x = "(((624 + 177) + 4*84) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_85: CO_Dot_0 {
            idc = 76085;
            x = "(((624 + 177) + 4*85) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_86: CO_Dot_0 {
            idc = 76086;
            x = "(((624 + 177) + 4*86) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_87: CO_Dot_0 {
            idc = 76087;
            x = "(((624 + 177) + 4*87) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_88: CO_Dot_0 {
            idc = 76088;
            x = "(((624 + 177) + 4*88) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_89: CO_Dot_0 {
            idc = 76089;
            x = "(((624 + 177) + 4*89) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_90: CO_Dot_0 {
            idc = 76090;
            x = "(((624 + 177) + 4*90) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_91: CO_Dot_0 {
            idc = 76091;
            x = "(((624 + 177) + 4*91) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_92: CO_Dot_0 {
            idc = 76092;
            x = "(((624 + 177) + 4*92) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_93: CO_Dot_0 {
            idc = 76093;
            x = "(((624 + 177) + 4*93) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_94: CO_Dot_0 {
            idc = 76094;
            x = "(((624 + 177) + 4*94) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_95: CO_Dot_0 {
            idc = 76095;
            x = "(((624 + 177) + 4*95) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_96: CO_Dot_0 {
            idc = 76096;
            x = "(((624 + 177) + 4*96) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_97: CO_Dot_0 {
            idc = 76097;
            x = "(((624 + 177) + 4*97) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_98: CO_Dot_0 {
            idc = 76098;
            x = "(((624 + 177) + 4*98) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_99: CO_Dot_0 {
            idc = 76099;
            x = "(((624 + 177) + 4*99) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_100: CO_Dot_0 {
            idc = 76100;
            x = "(((624 + 177) + 4*100) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_101: CO_Dot_0 {
            idc = 76101;
            x = "(((624 + 177) + 4*101) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_102: CO_Dot_0 {
            idc = 76102;
            x = "(((624 + 177) + 4*102) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_103: CO_Dot_0 {
            idc = 76103;
            x = "(((624 + 177) + 4*103) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_104: CO_Dot_0 {
            idc = 76104;
            x = "(((624 + 177) + 4*104) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_105: CO_Dot_0 {
            idc = 76105;
            x = "(((624 + 177) + 4*105) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_106: CO_Dot_0 {
            idc = 76106;
            x = "(((624 + 177) + 4*106) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_107: CO_Dot_0 {
            idc = 76107;
            x = "(((624 + 177) + 4*107) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_108: CO_Dot_0 {
            idc = 76108;
            x = "(((624 + 177) + 4*108) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_109: CO_Dot_0 {
            idc = 76109;
            x = "(((624 + 177) + 4*109) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_110: CO_Dot_0 {
            idc = 76110;
            x = "(((624 + 177) + 4*110) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_111: CO_Dot_0 {
            idc = 76111;
            x = "(((624 + 177) + 4*111) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_112: CO_Dot_0 {
            idc = 76112;
            x = "(((624 + 177) + 4*112) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_113: CO_Dot_0 {
            idc = 76113;
            x = "(((624 + 177) + 4*113) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_114: CO_Dot_0 {
            idc = 76114;
            x = "(((624 + 177) + 4*114) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_115: CO_Dot_0 {
            idc = 76115;
            x = "(((624 + 177) + 4*115) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_116: CO_Dot_0 {
            idc = 76116;
            x = "(((624 + 177) + 4*116) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_117: CO_Dot_0 {
            idc = 76117;
            x = "(((624 + 177) + 4*117) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_118: CO_Dot_0 {
            idc = 76118;
            x = "(((624 + 177) + 4*118) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_119: CO_Dot_0 {
            idc = 76119;
            x = "(((624 + 177) + 4*119) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_120: CO_Dot_0 {
            idc = 76120;
            x = "(((624 + 177) + 4*120) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_121: CO_Dot_0 {
            idc = 76121;
            x = "(((624 + 177) + 4*121) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_122: CO_Dot_0 {
            idc = 76122;
            x = "(((624 + 177) + 4*122) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_123: CO_Dot_0 {
            idc = 76123;
            x = "(((624 + 177) + 4*123) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_124: CO_Dot_0 {
            idc = 76124;
            x = "(((624 + 177) + 4*124) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_125: CO_Dot_0 {
            idc = 76125;
            x = "(((624 + 177) + 4*125) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_126: CO_Dot_0 {
            idc = 76126;
            x = "(((624 + 177) + 4*126) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_127: CO_Dot_0 {
            idc = 76127;
            x = "(((624 + 177) + 4*127) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_128: CO_Dot_0 {
            idc = 76128;
            x = "(((624 + 177) + 4*128) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_129: CO_Dot_0 {
            idc = 76129;
            x = "(((624 + 177) + 4*129) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_130: CO_Dot_0 {
            idc = 76130;
            x = "(((624 + 177) + 4*130) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_131: CO_Dot_0 {
            idc = 76131;
            x = "(((624 + 177) + 4*131) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_132: CO_Dot_0 {
            idc = 76132;
            x = "(((624 + 177) + 4*132) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_133: CO_Dot_0 {
            idc = 76133;
            x = "(((624 + 177) + 4*133) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_134: CO_Dot_0 {
            idc = 76134;
            x = "(((624 + 177) + 4*134) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_135: CO_Dot_0 {
            idc = 76135;
            x = "(((624 + 177) + 4*135) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_136: CO_Dot_0 {
            idc = 76136;
            x = "(((624 + 177) + 4*136) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_137: CO_Dot_0 {
            idc = 76137;
            x = "(((624 + 177) + 4*137) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_138: CO_Dot_0 {
            idc = 76138;
            x = "(((624 + 177) + 4*138) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_139: CO_Dot_0 {
            idc = 76139;
            x = "(((624 + 177) + 4*139) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_140: CO_Dot_0 {
            idc = 76140;
            x = "(((624 + 177) + 4*140) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_141: CO_Dot_0 {
            idc = 76141;
            x = "(((624 + 177) + 4*141) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_142: CO_Dot_0 {
            idc = 76142;
            x = "(((624 + 177) + 4*142) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_143: CO_Dot_0 {
            idc = 76143;
            x = "(((624 + 177) + 4*143) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_144: CO_Dot_0 {
            idc = 76144;
            x = "(((624 + 177) + 4*144) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_145: CO_Dot_0 {
            idc = 76145;
            x = "(((624 + 177) + 4*145) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_146: CO_Dot_0 {
            idc = 76146;
            x = "(((624 + 177) + 4*146) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_147: CO_Dot_0 {
            idc = 76147;
            x = "(((624 + 177) + 4*147) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_148: CO_Dot_0 {
            idc = 76148;
            x = "(((624 + 177) + 4*148) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_149: CO_Dot_0 {
            idc = 76149;
            x = "(((624 + 177) + 4*149) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_150: CO_Dot_0 {
            idc = 76150;
            x = "(((624 + 177) + 4*150) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_151: CO_Dot_0 {
            idc = 76151;
            x = "(((624 + 177) + 4*151) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_152: CO_Dot_0 {
            idc = 76152;
            x = "(((624 + 177) + 4*152) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_153: CO_Dot_0 {
            idc = 76153;
            x = "(((624 + 177) + 4*153) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_154: CO_Dot_0 {
            idc = 76154;
            x = "(((624 + 177) + 4*154) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_155: CO_Dot_0 {
            idc = 76155;
            x = "(((624 + 177) + 4*155) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_156: CO_Dot_0 {
            idc = 76156;
            x = "(((624 + 177) + 4*156) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_157: CO_Dot_0 {
            idc = 76157;
            x = "(((624 + 177) + 4*157) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_158: CO_Dot_0 {
            idc = 76158;
            x = "(((624 + 177) + 4*158) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_159: CO_Dot_0 {
            idc = 76159;
            x = "(((624 + 177) + 4*159) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_160: CO_Dot_0 {
            idc = 76160;
            x = "(((624 + 177) + 4*160) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_161: CO_Dot_0 {
            idc = 76161;
            x = "(((624 + 177) + 4*161) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_162: CO_Dot_0 {
            idc = 76162;
            x = "(((624 + 177) + 4*162) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_163: CO_Dot_0 {
            idc = 76163;
            x = "(((624 + 177) + 4*163) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_164: CO_Dot_0 {
            idc = 76164;
            x = "(((624 + 177) + 4*164) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_165: CO_Dot_0 {
            idc = 76165;
            x = "(((624 + 177) + 4*165) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_166: CO_Dot_0 {
            idc = 76166;
            x = "(((624 + 177) + 4*166) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_167: CO_Dot_0 {
            idc = 76167;
            x = "(((624 + 177) + 4*167) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_168: CO_Dot_0 {
            idc = 76168;
            x = "(((624 + 177) + 4*168) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_169: CO_Dot_0 {
            idc = 76169;
            x = "(((624 + 177) + 4*169) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_170: CO_Dot_0 {
            idc = 76170;
            x = "(((624 + 177) + 4*170) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_171: CO_Dot_0 {
            idc = 76171;
            x = "(((624 + 177) + 4*171) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_172: CO_Dot_0 {
            idc = 76172;
            x = "(((624 + 177) + 4*172) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_173: CO_Dot_0 {
            idc = 76173;
            x = "(((624 + 177) + 4*173) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Dot_174: CO_Dot_0 {
            idc = 76174;
            x = "(((624 + 177) + 4*174) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
        };
        class CO_Scale_Line_0: RscText {
            idc = 76180;
            x = "((624 + 855) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            y = "((546 + 505 - (30 * 0)) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
            w = "(25 / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55))";
            h = "(2 / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3))";
            colorBackground[] = {1, 0.5, 0.2, 1};
            text = "";
        };
        class CO_Scale_Line_1: CO_Scale_Line_0 {
            idc = 76181;
            x = "((624 + 870) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            y = "((546 + 505 - (30 * 1)) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
            w = "(10 / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55))";
        };
        class CO_Scale_Line_2: CO_Scale_Line_1 {
            idc = 76182;
            y = "((546 + 505 - (30 * 2)) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
        };
        class CO_Scale_Line_3: CO_Scale_Line_1 {
            idc = 76183;
            y = "((546 + 505 - (30 * 3)) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
        };
        class CO_Scale_Line_4: CO_Scale_Line_1 {
            idc = 76184;
            y = "((546 + 505 - (30 * 4)) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
        };
        class CO_Scale_Line_5: CO_Scale_Line_0 {
            idc = 76185;
            y = "((546 + 505 - (30 * 5)) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
        };
        class CO_Scale_Text_0: RscText {
            idc = 76186;
            x = "((624 + 845) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            y = "(((546 + 505 - (30 * 1)) + 10) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
            w = "(30 / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55))";
            h = "(20 / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3))";
            font = "RobotoCondensed";
            shadow = 0;
            type = 0;
            style = 1;
            colorText[] = {1, 0.5, 0.2, 1};
            sizeEx = "((((((safeZoneW) min (safeZoneH * 1.7777777778)) / safeZoneH) min 1.2) / 1.2) / 22) * 0.4 * (0.55 / (getResolution select 5))";
            text = "0";
        };
        class CO_Scale_Text_50: CO_Scale_Text_0 {
            idc = 76187;
            y = "(((546 + 505 - (30 * 5)) + 2) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
            text = "50";
        };
        class AEDBackground: RscPicture {
            idc = -1;
            x = "((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2)";
            y = "(safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2)";
            w = "(((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05";
            h = "((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05";
            type = 0;
            style = 48;
            size = 0;
            text = "\x\ACM\addons\circulation\ui\lifepak\background_ca.paa";
        };
    };
    class Controls {
        class Button_Power: RscButton {
            text = "";
            colorText[] = {1, 1, 1, 0};
            colorDisabled[] = {1, 1, 1, 0};
            colorBackground[] = {1, 1, 1, 0};
            colorBackgroundDisabled[] = {1, 1, 1, 0};
            colorBackgroundActive[] = {1, 1, 1, 0};
            colorFocused[] = {1, 1, 1, 0};
            colorBorder[] = {0, 0, 0, 0};
            soundEnter[] = {};
            soundPush[] = {};
            soundEscape[] = {};
            idc = -1;
            style = 0;
            x = "((1632 + 189) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            y = "(512 / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
            w = "(142 / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55))";
            h = "(43 / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3))";
            shadow = 0;
            font = "RobotoCondensed";
            sizeEx = "0";
            onButtonClick = "";
            tooltip = "";
        };
        class Button_CPR: Button_Power {
            idc = -1;
            x = "(1632 / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            y = "((512 + 70) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
            onButtonClick = "[ACM_circulation_AED_Monitor_Target] call ACM_circulation_fnc_AED_Button_CPR";
            tooltip = "$STR_ACM_circulation_AED_Monitor_Button_CPR";
        };
        class Button_Analyze: Button_CPR {
            idc = -1;
            x = "(1632 / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            y = "((512 + (70 * 2) - 15) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
            onButtonClick = "[ACM_circulation_AED_Monitor_Target] call ACM_circulation_fnc_AED_Button_Analyze";
            tooltip = "$STR_ACM_circulation_AED_Monitor_Button_Analyze";
        };
        class Button_NIBP: Button_CPR {
            idc = -1;
            x = "((1632 + 3) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            y = "((512 + (70 * 4) + 27) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
            onButtonClick = "[ACM_circulation_AED_Monitor_Target] call ACM_circulation_fnc_AED_Button_MeasureBP";
            tooltip = "$STR_ACM_circulation_AED_Monitor_Button_NIBP";
        };
        class Button_Alarms: Button_CPR {
            idc = -1;
            x = "((1632 + 3) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            y = "((512 + (70 * 5) + 12) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
            onButtonClick = "[ACM_circulation_AED_Monitor_Target] call ACM_circulation_fnc_AED_Button_MuteAlarms";
            tooltip = "$STR_ACM_circulation_AED_Monitor_Button_Alarms";
        };
        class Button_EnergySelect: Button_Power {
            idc = -1;
            x = "((1632 + 189) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            y = "((512 + 70) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
            onButtonClick = "";
            tooltip = "";
        };
        class Button_Charge: Button_Power {
            idc = -1;
            x = "((1632 + 189) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            y = "((512 + (70 * 2) - 16) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
            onButtonClick = "[ACM_circulation_AED_Monitor_Target] call ACM_circulation_fnc_AED_Button_ManualCharge";
            tooltip = "$STR_ACM_circulation_AED_Monitor_Button_Charge";
        };
        class Button_Shock: Button_Power {
            idc = -1;
            x = "((1632 + 223) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            y = "((512 + (70 * 3) - 25) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
            w = "(80 / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55))";
            h = "(80 / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3))";
            onButtonClick = "[ACM_circulation_AED_Monitor_Target] call ACM_circulation_fnc_AED_Button_Shock";
            tooltip = "$STR_ACM_circulation_AED_Monitor_Button_Shock";
        };
        class Button_SpeedDial: Button_Power {
            soundClick[] = {"x\ACM\addons\circulation\sound\aed_button_speeddial.wav", 1, 1};
            idc = -1;
            x = "((1632 + 140) / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) + ((safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 1.05)) / 2))";
            y = "((512 + 670) / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) + (safeZoneY + (safeZoneH - (((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3) * 1.05)) / 2))";
            w = "(180 / 2048 * (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55))";
            h = "(180 / 2048 * ((((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.55) * 4/3))";
            onButtonClick = "[ACM_circulation_AED_Monitor_Target] call ACM_circulation_fnc_AED_Button_SpeedDial";
            tooltip = "$STR_ACM_circulation_AED_Monitor_Button_SpeedDial";
        };
    };
};
class RscTitles {
    class RscFeelPulse {
        idd = 80000;
        fadein = 0;
        fadeout = 0;
        duration = 100000000000;
        onLoad = "uiNamespace setVariable ['ACM_FeelPulse', (_this select 0)];";
        onUnLoad = "uiNamespace setVariable ['ACM_FeelPulse', nil];";
        class Controls {
            class TopText: RscText {
                idc = -1;
                style = 2;
                font = "RobotoCondensed";
                x = "safeZoneX";
                y = "safeZoneY";
                w = "safeZoneW";
                h = "safeZoneH / 10";
                colorText[] = {1, 1, 1, 1};
                colorBackground[] = {0, 0, 0, 0};
                text = "$STR_ACM_circulation_FeelPulse_FeelingForPulse";
                lineSpacing = 0;
                sizeEx = "((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) * 1.4 * (0.55 / (getResolution select 5))";
                fixedWidth = 0;
                deletable = 0;
                fade = 0;
                access = 0;
                type = 0;
                shadow = 1;
                colorShadow[] = {0, 0, 0, 0.5};
            };
            class BottomText: TopText {
                idc = 80001;
                h = "safeZoneH / 6";
                text = "";
            };
            class HeartBack: RscPicture {
                idc = -1;
                x = "((20 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2)) - ((4 * (((safeZoneW / safeZoneH) min 1.2) / 40)) / 2))";
                y = "((12.5 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2)) - ((3 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25)) / 2))";
                w = "(4 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                h = "(3 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                type = 0;
                size = 0;
                text = "\x\ACM\addons\circulation\ui\feelpulse\heart_ca.paa";
                colorText[] = {1, 1, 1, 1};
            };
            class Heart: HeartBack {
                idc = 80002;
                x = "((20 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2)) - ((1 * (((safeZoneW / safeZoneH) min 1.2) / 40)) / 2))";
                y = "((12.5 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2)) - ((0.75 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25)) / 2))";
                w = "(1 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
                h = "(0.75 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
                colorText[] = {1, 0, 0, 1};
            };
        };
    };
};
class ACM_circulation_MeasureBP_Dialog {
    idd = 82000;
    movingEnable = 0;
    onLoad = "";
    onUnload = "uiNamespace setVariable [""ACM_circulation_MeasureBP_DLG"", nil]";
    objects[] = {};
    class ControlsBackground {
        class BodyBackground: RscPicture {
            idc = -1;
            x = "((50 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2)) - ((180 * (((safeZoneW / safeZoneH) min 1.2) / 40)) / 2))";
            y = "((36 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2)) - ((135 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25)) / 2))";
            w = "(180 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(135 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            type = 0;
            size = 0;
            text = "\x\ACM\addons\circulation\ui\pressurecuff\body_background_pressurecuff.paa";
        };
        class PressureCuffInteractables: BodyBackground {
            x = "(-12 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            y = "(12 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
            w = "(32 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(24 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            text = "\x\ACM\addons\circulation\ui\pressurecuff\pressurecuff_interactables.paa";
        };
        class Stethoscope_Bell: RscPicture {
            idc = 82004;
            x = "((29.5 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2)) - ((4 * (((safeZoneW / safeZoneH) min 1.2) / 40)) / 2))";
            y = "((18 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2)) - ((3 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25)) / 2))";
            w = "(4 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(3 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            text = "\x\ACM\addons\breathing\ui\stethoscope_bell.paa";
            show = 0;
        };
        class GaugeDial: RscPicture {
            idc = 82007;
            x = "(2.65 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            y = "(13.12 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
            w = "(16 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(12 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            text = "\x\ACM\addons\circulation\ui\pressurecuff\dial\dial_0.paa";
            colorText[] = {0, 0, 0, 1};
        };
        class HeartBack: RscPicture {
            idc = 82005;
            x = "((29.5 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2)) - ((4 * (((safeZoneW / safeZoneH) min 1.2) / 40)) / 2))";
            y = "((18 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2)) - ((3 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25)) / 2))";
            w = "(4 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(3 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            type = 0;
            size = 0;
            text = "\x\ACM\addons\circulation\ui\feelpulse\heart_ca.paa";
            colorText[] = {1, 1, 1, 1};
            show = 0;
        };
        class Heart: HeartBack {
            idc = 82006;
            x = "((29.5 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2)) - ((1 * (((safeZoneW / safeZoneH) min 1.2) / 40)) / 2))";
            y = "((18 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2)) - ((0.75 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25)) / 2))";
            w = "(1 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(0.75 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            colorText[] = {1, 0, 0, 1};
        };
    };
    class Controls {
        class TopText: RscText {
            idc = -1;
            style = 2;
            font = "RobotoCondensed";
            x = "safeZoneX";
            y = "safeZoneY";
            w = "safeZoneW";
            h = "safeZoneH / 10";
            colorText[] = {1, 1, 1, 1};
            colorBackground[] = {0, 0, 0, 0};
            text = "$STR_ACM_circulation_MeasureBP_Measuring";
            lineSpacing = 0;
            sizeEx = "((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) * 1.4 * (0.55 / (getResolution select 5))";
            fixedWidth = 0;
            deletable = 0;
            fade = 0;
            access = 0;
            type = 0;
            shadow = 1;
            colorShadow[] = {0, 0, 0, 0.5};
        };
        class BottomText: TopText {
            idc = 82001;
            h = "safeZoneH / 6";
            text = "";
        };
        class Button_Bulb: RscButton {
            text = "";
            colorText[] = {1, 1, 1, 0};
            colorDisabled[] = {1, 1, 1, 0};
            colorBackground[] = {1, 1, 1, 0};
            colorBackgroundDisabled[] = {1, 1, 1, 0};
            colorBackgroundActive[] = {1, 1, 1, 0};
            colorFocused[] = {1, 1, 1, 0};
            colorBorder[] = {0, 0, 0, 0};
            soundClick[] = {};
            soundEnter[] = {};
            soundPush[] = {};
            soundEscape[] = {};
            idc = 82002;
            style = 0;
            x = "(-11 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            y = "(14.8 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
            w = "(9.2 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(13 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            shadow = 0;
            font = "RobotoCondensed";
            sizeEx = "0";
            onMouseButtonUp = "call ACM_circulation_fnc_MeasureBP_press";
            tooltip = "$STR_ACM_circulation_MeasureBP_Hint_Bulb";
        };
        class Button_Valve: Button_Bulb {
            soundClick[] = {};
            idc = 82003;
            x = "(-7.5 * (((safeZoneW / safeZoneH) min 1.2) / 40) + (safeZoneX + (safeZoneW - ((safeZoneW / safeZoneH) min 1.2))/2))";
            y = "(28 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2))";
            w = "(2.8 * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "(2.2 * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            tooltip = "$STR_ACM_circulation_MeasureBP_Hint_Valve";
        };
    };
};
class ACM_circulation_SyringeDraw_Dialog {
    idd = 84000;
    movingEnable = 0;
    onLoad = "";
    onUnload = "uiNamespace setVariable [""ACM_circulation_SyringeDraw_DLG"", nil]";
    objects[] = {};
    class ControlsBackground {
        class Syringe_10_Backbit: RscPicture {
            idc = 84011;
            x = "(safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + ((((safeZoneW) min (safeZoneH * 1.7777777778)) - ((42 * ((0.55 / (getResolution select 5)) min 1)) * (((safeZoneW / safeZoneH) min 1.2) / 40))) / 2)";
            y = "(safeZoneY + ((safeZoneH - ((42 * ((0.55 / (getResolution select 5)) min 1)) * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))) / 2)) - ((5 * ((0.55 / (getResolution select 5)) min 1)) * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2) / ((0.55 / (getResolution select 5)) min 1))";
            w = "((42 * ((0.55 / (getResolution select 5)) min 1)) * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "((42 * ((0.55 / (getResolution select 5)) min 1)) * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            type = 0;
            style = 48;
            size = 0;
            text = "\x\ACM\addons\circulation\ui\syringe\syringe_10_backbit_ca.paa";
            show = 0;
        };
        class Syringe_10_Plunger: Syringe_10_Backbit {
            idc = 84010;
            text = "\x\ACM\addons\circulation\ui\syringe\syringe_10_plunger_ca.paa";
        };
        class Syringe_10_Barrel: Syringe_10_Backbit {
            idc = 84012;
            text = "\x\ACM\addons\circulation\ui\syringe\syringe_10_barrel_ca.paa";
        };
        class Syringe_5_Backbit: Syringe_10_Backbit {
            idc = 84014;
            text = "\x\ACM\addons\circulation\ui\syringe\syringe_5_backbit_ca.paa";
        };
        class Syringe_5_Plunger: Syringe_5_Backbit {
            idc = 84013;
            text = "\x\ACM\addons\circulation\ui\syringe\syringe_5_plunger_ca.paa";
        };
        class Syringe_5_Barrel: Syringe_5_Backbit {
            idc = 84015;
            text = "\x\ACM\addons\circulation\ui\syringe\syringe_5_barrel_ca.paa";
        };
        class Syringe_3_Backbit: Syringe_10_Backbit {
            idc = 84017;
            text = "\x\ACM\addons\circulation\ui\syringe\syringe_3_backbit_ca.paa";
        };
        class Syringe_3_Plunger: Syringe_3_Backbit {
            idc = 84016;
            text = "\x\ACM\addons\circulation\ui\syringe\syringe_3_plunger_ca.paa";
        };
        class Syringe_3_Barrel: Syringe_3_Backbit {
            idc = 84018;
            text = "\x\ACM\addons\circulation\ui\syringe\syringe_3_barrel_ca.paa";
        };
        class Syringe_1_Backbit: Syringe_10_Backbit {
            idc = 84020;
            text = "\x\ACM\addons\circulation\ui\syringe\syringe_1_backbit_ca.paa";
        };
        class Syringe_1_Plunger: Syringe_1_Backbit {
            idc = 84019;
            text = "\x\ACM\addons\circulation\ui\syringe\syringe_1_plunger_ca.paa";
        };
        class Syringe_1_Barrel: Syringe_1_Backbit {
            idc = 84021;
            text = "\x\ACM\addons\circulation\ui\syringe\syringe_1_barrel_ca.paa";
        };
        class TopText: RscText {
            idc = 84001;
            style = 2;
            font = "RobotoCondensed";
            x = "(safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2))";
            y = "safeZoneY";
            w = "((safeZoneW) min (safeZoneH * 1.7777777778))";
            h = "safeZoneH / 10";
            colorText[] = {1, 1, 1, 1};
            colorBackground[] = {0, 0, 0, 0};
            text = "$STR_ACM_circulation_Syringe_NoMedicationSelected";
            lineSpacing = 0;
            sizeEx = "((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) * 1.4 * (0.55 / (getResolution select 5))";
            fixedWidth = 0;
            deletable = 0;
            fade = 0;
            access = 0;
            type = 0;
            shadow = 1;
            colorShadow[] = {0, 0, 0, 0.5};
        };
        class BottomText: TopText {
            idc = 84002;
            h = "safeZoneH / 6";
            text = "";
        };
        class MedicationListSelection: TopText {
            idc = 84008;
            sizeEx = "((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) * 1.1 * (0.55 / (getResolution select 5))";
            x = "(safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) / 2) + (((safeZoneW) min (safeZoneH * 1.7777777778)) / 3.05)";
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 4.2)";
            w = "((safeZoneW) min (safeZoneH * 1.7777777778)) / 10";
            h = "safeZoneH / 25";
            text = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Common_InventoryTarget', localize 'STR_ACM_Circulation_Common_Self']");
        };
    };
    class Controls {
        class Plunger: RscButton {
            text = "";
            colorText[] = {1, 1, 1, 0};
            colorDisabled[] = {1, 1, 1, 0};
            colorBackground[] = {0, 0, 1, 0};
            colorBackgroundDisabled[] = {0, 0, 1, 0};
            colorBackgroundActive[] = {0, 0, 1, 0};
            colorFocused[] = {0, 0, 1, 0};
            colorBorder[] = {0, 0, 0, 0};
            soundClick[] = {};
            soundEnter[] = {};
            soundPush[] = {};
            soundEscape[] = {};
            idc = 84009;
            style = 0;
            x = "(safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + ((((safeZoneW) min (safeZoneH * 1.7777777778)) - ((2.78 * ((0.55 / (getResolution select 5)) min 1)) * (((safeZoneW / safeZoneH) min 1.2) / 40))) / 2)";
            y = "(safeZoneY + (safeZoneH / 2) + ((7.5 * ((0.55 / (getResolution select 5)) min 1)) * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) + (safeZoneY + (safeZoneH - (((safeZoneW / safeZoneH) min 1.2) / 1.2))/2) / ((0.55 / (getResolution select 5)) min 1)))";
            w = "((2.78 * ((0.55 / (getResolution select 5)) min 1)) * (((safeZoneW / safeZoneH) min 1.2) / 40))";
            h = "((0.9 * ((0.55 / (getResolution select 5)) min 1)) * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
            shadow = 0;
            font = "RobotoCondensed";
            sizeEx = "0";
            onMouseButtonUp = "call ACM_circulation_fnc_Syringe_Draw_Move";
            tooltip = "";
        };
        class Button_Draw: RscButton {
            text = "$STR_ACM_circulation_Syringe_Draw";
            colorText[] = {1, 1, 1, 1};
            colorDisabled[] = {1, 1, 1, 0.1};
            colorBackground[] = {0, 0, 0, 1};
            colorBackgroundDisabled[] = {0, 0, 0, 0.1};
            colorBackgroundActive[] = {0, 0, 0, 1};
            colorFocused[] = {0, 0, 0, 1};
            colorBorder[] = {0, 0, 0, 0};
            soundClick[] = {};
            soundEnter[] = {};
            soundPush[] = {};
            soundEscape[] = {};
            idc = 84003;
            style = 2;
            x = "(safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) / 2) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) / 24) / 2) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) / 24) * 1.1)";
            y = "safeZoneY + (safeZoneH / 1.2)";
            w = "((safeZoneW) min (safeZoneH * 1.7777777778)) / 24";
            h = "safeZoneH / 30";
            shadow = 0;
            font = "RobotoCondensed";
            sizeEx = "((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) * (0.55 / (getResolution select 5))";
            onButtonClick = "[0] call ACM_circulation_fnc_Syringe_Draw_Button";
            tooltip = "";
        };
        class Button_Inject: Button_Draw {
            text = "$STR_ACM_circulation_Syringe_DrawInject";
            idc = 84005;
            x = "(safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) / 2) - ((((safeZoneW) min (safeZoneH * 1.7777777778)) / 24) / 2) + ((((safeZoneW) min (safeZoneH * 1.7777777778)) / 24) * 1.1)";
            w = "((safeZoneW) min (safeZoneH * 1.7777777778)) / 13";
            onButtonClick = "[2] call ACM_circulation_fnc_Syringe_Draw_Button";
        };
        class Button_Push: Button_Inject {
            text = "$STR_ACM_circulation_Syringe_DrawPush";
            idc = 84004;
            y = "safeZoneY + (safeZoneH / 1.14)";
            onButtonClick = "[1] call ACM_circulation_fnc_Syringe_Draw_Button";
            show = 0;
        };
        class SwitchTargetInventory: RscButtonMenu {
            idc = 84007;
            x = "(safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) / 2) + (((safeZoneW) min (safeZoneH * 1.7777777778)) / 3.1)";
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 4.3)";
            w = "((safeZoneW) min (safeZoneH * 1.7777777778)) / 65";
            h = "safeZoneH / 35";
            shadow = 0;
            font = "RobotoCondensed";
            sizeEx = "0";
            action = "call ACM_circulation_fnc_Syringe_SwitchTargetInventory";
            textureNoShortcut = "\x\ACM\addons\circulation\ui\transfusionmenu\inventory_select_ca.paa";
            tooltip = "$STR_ACM_circulation_Common_SwitchTargetInventory";
            colorBackground[] = {1, 1, 1, 0};
            colorBackgroundFocused[] = {1, 1, 1, 0};
            color[] = {1, 0, 0, 1};
            period = 0;
            periodFocus = 0;
            periodOver = 0;
            class ShortcutPos {
                left = 0;
                top = 0;
                w = "((safeZoneW) min (safeZoneH * 1.7777777778)) / 55";
                h = "safeZoneH / 30";
            };
        };
        class MedicationListPanel: RscListBox {
            idc = 84006;
            x = "(safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) / 2) + (((safeZoneW) min (safeZoneH * 1.7777777778)) / 3.3)";
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 5.3)";
            w = "((safeZoneW) min (safeZoneH * 1.7777777778)) / 6.5";
            h = "safeZoneH / 2.5";
            rowHeight = "safeZoneH / 20";
            colorText[] = {1, 1, 1, 1};
            colorSelect[] = {0, 0, 0, 1};
            colorSelect2[] = {0, 0, 0, 1};
            colorBackground[] = {0, 0, 0, 0.1};
            colorSelectBackground[] = {0.7, 0.7, 0.7, 1};
            colorSelectBackground2[] = {0.7, 0.7, 0.7, 1};
            sizeEx = "((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) * 0.9 * (0.55 / (getResolution select 5))";
            class Items {};
        };
    };
};
class ACM_circulation_TransfusionMenu_Dialog {
    idd = 86000;
    movingEnable = 0;
    onLoad = "";
    onUnload = "uiNamespace setVariable [""ACM_circulation_TransfusionMenu_DLG"", nil]";
    onKeyDown = "['onKeyDown', _this, ""ACM_circulation_display""] call ACM_circulation_fnc_TransfusionMenu_onKeyDown";
    objects[] = {};
    class ControlsBackground {
        class MenuBackground: RscText {
            idc = -1;
            x = "(safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) / 2) - (((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.35)";
            y = "safeZoneY + (safeZoneH * 0.08)";
            w = "((safeZoneW) min (safeZoneH * 1.7777777778)) * 0.70";
            h = "safeZoneH * 0.84";
            colorBackground[] = {0, 0, 0, 0.7};
        };
        class PatientName: RscText {
            idc = 86001;
            style = 2;
            font = "RobotoCondensed";
            x = "(safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2))";
            y = "safeZoneY + (safeZoneH * 0.095)";
            w = "((safeZoneW) min (safeZoneH * 1.7777777778))";
            h = "safeZoneH / 20";
            colorText[] = {1, 1, 1, 1};
            colorBackground[] = {0, 0, 0, 0};
            text = "";
            lineSpacing = 0;
            sizeEx = "((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) * 1.8 * (0.55 / (getResolution select 5))";
            shadow = 1;
            colorShadow[] = {0, 0, 0, 0.5};
        };
        class SelectedLimbText: PatientName {
            idc = 86002;
            x = "(safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) / 2) - (((safeZoneW) min (safeZoneH * 1.7777777778)) / 3.28)";
            y = "safeZoneY + (safeZoneH * 0.155)";
            w = "((safeZoneW) min (safeZoneH * 1.7777777778)) / 5.9";
            h = "safeZoneH / 25";
            text = "";
            sizeEx = "((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) * 1.1 * (0.55 / (getResolution select 5))";
        };
        class SelectedInventoryText: SelectedLimbText {
            idc = 86003;
            x = "(safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) / 2) + (((safeZoneW) min (safeZoneH * 1.7777777778)) / 7.75)";
            text = __EVAL(call compile "format [localize 'STR_ACM_Circulation_Common_InventoryTarget', localize 'STR_ACM_Circulation_Common_Self']");
        };
        class BodyBackground: RscPictureKeepAspect {
            idc = -1;
            x = "(safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) / 2) - (((safeZoneW) min (safeZoneH * 1.7777777778)) / 6.8)";
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 3.5)";
            w = "((safeZoneW) min (safeZoneH * 1.7777777778)) / 3.4";
            h = "safeZoneH / 1.75";
            type = 0;
            size = 0;
            text = "\x\ACM\addons\gui\ui\body_background.paa";
        };
        class BodyBackground_IO_Torso: BodyBackground {
            idc = 86010;
            text = "\x\ACM\addons\gui\data\body_image\torso_fast_io.paa";
            colorText[] = {0.2, 0.65, 0.2, 1};
        };
        class BodyBackground_IO_RightArm: BodyBackground_IO_Torso {
            idc = 86011;
            text = "\x\ACM\addons\gui\data\body_image\rightarm_io.paa";
        };
        class BodyBackground_IO_LeftArm: BodyBackground_IO_Torso {
            idc = 86012;
            text = "\x\ACM\addons\gui\data\body_image\leftarm_io.paa";
        };
        class BodyBackground_IO_RightLeg: BodyBackground_IO_Torso {
            idc = 86013;
            text = "\x\ACM\addons\gui\data\body_image\rightleg_io.paa";
        };
        class BodyBackground_IO_LeftLeg: BodyBackground_IO_Torso {
            idc = 86014;
            text = "\x\ACM\addons\gui\data\body_image\leftleg_io.paa";
        };
        class BodyBackground_IV_RightArm_Upper: BodyBackground_IO_Torso {
            idc = 86020;
            text = "\x\ACM\addons\gui\data\body_image\RightArm_iv_Upper.paa";
        };
        class BodyBackground_IV_RightArm_Middle: BodyBackground_IO_Torso {
            idc = 86021;
            text = "\x\ACM\addons\gui\data\body_image\RightArm_iv_Middle.paa";
        };
        class BodyBackground_IV_RightArm_Lower: BodyBackground_IO_Torso {
            idc = 86022;
            text = "\x\ACM\addons\gui\data\body_image\RightArm_iv_Lower.paa";
        };
        class BodyBackground_IV_LeftArm_Upper: BodyBackground_IO_Torso {
            idc = 86023;
            text = "\x\ACM\addons\gui\data\body_image\LeftArm_iv_Upper.paa";
        };
        class BodyBackground_IV_LeftArm_Middle: BodyBackground_IO_Torso {
            idc = 86024;
            text = "\x\ACM\addons\gui\data\body_image\LeftArm_iv_Middle.paa";
        };
        class BodyBackground_IV_LeftArm_Lower: BodyBackground_IO_Torso {
            idc = 86025;
            text = "\x\ACM\addons\gui\data\body_image\LeftArm_iv_Lower.paa";
        };
        class BodyBackground_IV_RightLeg_Upper: BodyBackground_IO_Torso {
            idc = 86026;
            text = "\x\ACM\addons\gui\data\body_image\RightLeg_iv_Upper.paa";
        };
        class BodyBackground_IV_RightLeg_Middle: BodyBackground_IO_Torso {
            idc = 86027;
            text = "\x\ACM\addons\gui\data\body_image\RightLeg_iv_Middle.paa";
        };
        class BodyBackground_IV_RightLeg_Lower: BodyBackground_IO_Torso {
            idc = 86028;
            text = "\x\ACM\addons\gui\data\body_image\RightLeg_iv_Lower.paa";
        };
        class BodyBackground_IV_LeftLeg_Upper: BodyBackground_IO_Torso {
            idc = 86029;
            text = "\x\ACM\addons\gui\data\body_image\LeftLeg_iv_Upper.paa";
        };
        class BodyBackground_IV_LeftLeg_Middle: BodyBackground_IO_Torso {
            idc = 86030;
            text = "\x\ACM\addons\gui\data\body_image\LeftLeg_iv_Middle.paa";
        };
        class BodyBackground_IV_LeftLeg_Lower: BodyBackground_IO_Torso {
            idc = 86031;
            text = "\x\ACM\addons\gui\data\body_image\LeftLeg_iv_Lower.paa";
        };
        class BodyBackground_Tourniquet_RightArm: BodyBackground {
            idc = 86032;
            text = "\x\ACM\addons\gui\data\body_image\rightarm_tourniquet.paa";
            colorText[] = {0, 0, 0.8, 1};
        };
        class BodyBackground_Tourniquet_LeftArm: BodyBackground_Tourniquet_RightArm {
            idc = 86033;
            text = "\x\ACM\addons\gui\data\body_image\leftarm_tourniquet.paa";
        };
        class BodyBackground_Tourniquet_RightLeg: BodyBackground_Tourniquet_RightArm {
            idc = 86034;
            text = "\z\ace\addons\medical_gui\data\body_image\leg_right_t.paa";
        };
        class BodyBackground_Tourniquet_LeftLeg: BodyBackground_Tourniquet_RightArm {
            idc = 86035;
            text = "\z\ace\addons\medical_gui\data\body_image\leg_left_t.paa";
        };
    };
    class Controls {
        class BodyPart_Torso: RscButton {
            text = "";
            colorText[] = {1, 1, 1, 0};
            colorDisabled[] = {1, 1, 1, 0};
            colorBackground[] = {1, 1, 1, 0};
            colorBackgroundDisabled[] = {1, 1, 1, 0};
            colorBackgroundActive[] = {1, 1, 1, 0};
            colorFocused[] = {1, 1, 1, 0};
            colorBorder[] = {0, 0, 0, 0};
            idc = -1;
            style = 0;
            x = "(safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) / 2) - (((safeZoneW) min (safeZoneH * 1.7777777778)) / 54)";
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 9)";
            w = "((safeZoneW) min (safeZoneH * 1.7777777778)) / 27";
            h = "safeZoneH / 7.15";
            shadow = 0;
            font = "RobotoCondensed";
            sizeEx = "0";
            tooltip = "$STR_ace_medical_gui_Torso";
            enable = 0;
            action = "";
        };
        class BodyPart_RightArm_Upper: BodyPart_Torso {
            idc = -1;
            x = "(safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) / 2) - (((safeZoneW) min (safeZoneH * 1.7777777778)) / 22)";
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 9.4)";
            w = "((safeZoneW) min (safeZoneH * 1.7777777778)) / 37";
            h = "safeZoneH / 13.9";
            tooltip = __EVAL(call compile "format ['%1 (%2)', localize 'STR_ACE_Medical_GUI_RightArm', localize 'STR_ACM_Circulation_IV_Upper']");
            action = "";
        };
        class BodyPart_RightArm_Middle: BodyPart_RightArm_Upper {
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 29)";
            h = "safeZoneH / 26";
            tooltip = __EVAL(call compile "format ['%1 (%2)', localize 'STR_ACE_Medical_GUI_RightArm', localize 'STR_ACM_Circulation_IV_Middle']");
            action = "";
        };
        class BodyPart_RightArm_Lower: BodyPart_RightArm_Upper {
            y = "safeZoneY + (safeZoneH / 2) + (safeZoneH / 300)";
            h = "safeZoneH / 20";
            tooltip = __EVAL(call compile "format ['%1 (%2)', localize 'STR_ACE_Medical_GUI_RightArm', localize 'STR_ACM_Circulation_IV_Lower']");
            action = "";
        };
        class BodyPart_LeftArm_Upper: BodyPart_RightArm_Upper {
            x = "(safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) / 2) + (((safeZoneW) min (safeZoneH * 1.7777777778)) / 54)";
            tooltip = __EVAL(call compile "format ['%1 (%2)', localize 'STR_ACE_Medical_GUI_LeftArm', localize 'STR_ACM_Circulation_IV_Upper']");
            action = "";
        };
        class BodyPart_LeftArm_Middle: BodyPart_LeftArm_Upper {
            y = "safeZoneY + (safeZoneH / 2) - (safeZoneH / 29)";
            h = "safeZoneH / 26";
            tooltip = __EVAL(call compile "format ['%1 (%2)', localize 'STR_ACE_Medical_GUI_LeftArm', localize 'STR_ACM_Circulation_IV_Middle']");
            action = "";
        };
        class BodyPart_LeftArm_Lower: BodyPart_LeftArm_Upper {
            y = "safeZoneY + (safeZoneH / 2) + (safeZoneH / 300)";
            h = "safeZoneH / 20";
            tooltip = __EVAL(call compile "format ['%1 (%2)', localize 'STR_ACE_Medical_GUI_LeftArm', localize 'STR_ACM_Circulation_IV_Lower']");
            action = "";
        };
        class BodyPart_RightLeg_Upper: BodyPart_Torso {
            x = "(safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) / 2) - (((safeZoneW) min (safeZoneH * 1.7777777778)) / 47)";
            y = "safeZoneY + (safeZoneH / 2) + (safeZoneH / 35)";
            w = "((safeZoneW) min (safeZoneH * 1.7777777778)) / 47";
            h = "safeZoneH / 16";
            tooltip = __EVAL(call compile "format ['%1 (%2)', localize 'STR_ACE_Medical_GUI_RightLeg', localize 'STR_ACM_Circulation_IV_Upper']");
            action = "";
        };
        class BodyPart_RightLeg_Middle: BodyPart_RightLeg_Upper {
            y = "safeZoneY + (safeZoneH / 2) + (safeZoneH / 11)";
            tooltip = __EVAL(call compile "format ['%1 (%2)', localize 'STR_ACE_Medical_GUI_RightLeg', localize 'STR_ACM_Circulation_IV_Middle']");
            action = "";
        };
        class BodyPart_RightLeg_Lower: BodyPart_RightLeg_Upper {
            y = "safeZoneY + (safeZoneH / 2) + (safeZoneH / 6.55)";
            tooltip = __EVAL(call compile "format ['%1 (%2)', localize 'STR_ACE_Medical_GUI_RightLeg', localize 'STR_ACM_Circulation_IV_Lower']");
            action = "";
        };
        class BodyPart_LeftLeg_Upper: BodyPart_RightLeg_Upper {
            x = "(safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) / 2) + (((safeZoneW) min (safeZoneH * 1.7777777778)) / 5000)";
            tooltip = __EVAL(call compile "format ['%1 (%2)', localize 'STR_ACE_Medical_GUI_LeftLeg', localize 'STR_ACM_Circulation_IV_Upper']");
            action = "";
        };
        class BodyPart_LeftLeg_Middle: BodyPart_LeftLeg_Upper {
            y = "safeZoneY + (safeZoneH / 2) + (safeZoneH / 11)";
            tooltip = __EVAL(call compile "format ['%1 (%2)', localize 'STR_ACE_Medical_GUI_LeftLeg', localize 'STR_ACM_Circulation_IV_Middle']");
            action = "";
        };
        class BodyPart_LeftLeg_Lower: BodyPart_LeftLeg_Upper {
            y = "safeZoneY + (safeZoneH / 2) + (safeZoneH / 6.55)";
            tooltip = __EVAL(call compile "format ['%1 (%2)', localize 'STR_ACE_Medical_GUI_LeftLeg', localize 'STR_ACM_Circulation_IV_Lower']");
            action = "";
        };
        class LeftPanelList: RscListBox {
            idc = 86004;
            x = "(safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) / 2) - (((safeZoneW) min (safeZoneH * 1.7777777778)) / 3.28)";
            y = "safeZoneY + (safeZoneH * 0.22)";
            w = "((safeZoneW) min (safeZoneH * 1.7777777778)) / 5.9";
            h = "safeZoneH * 0.62";
            rowHeight = "safeZoneH / 20";
            colorText[] = {1, 1, 1, 1};
            colorSelect[] = {0, 0, 0, 1};
            colorSelect2[] = {0, 0, 0, 1};
            colorBackground[] = {0, 0, 0, 0.1};
            colorSelectBackground[] = {0.7, 0.7, 0.7, 1};
            colorSelectBackground2[] = {0.7, 0.7, 0.7, 1};
            sizeEx = "((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) * 0.9 * (0.55 / (getResolution select 5))";
            class Items {};
        };
        class SwitchTargetInventory: RscButtonMenu {
            idc = -1;
            x = "(safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) / 2) + (((safeZoneW) min (safeZoneH * 1.7777777778)) / 7.8)";
            y = "safeZoneY + (safeZoneH * 0.155)";
            w = "((safeZoneW) min (safeZoneH * 1.7777777778)) / 65";
            h = "safeZoneH / 35";
            shadow = 0;
            font = "RobotoCondensed";
            sizeEx = "0";
            action = "call ACM_circulation_fnc_TransfusionMenu_SwitchTargetInventory";
            textureNoShortcut = "\x\ACM\addons\circulation\ui\transfusionmenu\inventory_select_ca.paa";
            tooltip = "$STR_ACM_circulation_Common_SwitchTargetInventory";
            colorBackground[] = {1, 1, 1, 0};
            colorBackgroundFocused[] = {1, 1, 1, 0};
            period = 0;
            periodFocus = 0;
            periodOver = 0;
            class ShortcutPos {
                left = 0;
                top = 0;
                w = "((safeZoneW) min (safeZoneH * 1.7777777778)) / 55";
                h = "safeZoneH / 30";
            };
        };
        class StopTransfusionButton: RscButton {
            text = "";
            colorText[] = {1, 1, 1, 1};
            colorDisabled[] = {1, 1, 1, 1};
            colorBackground[] = {0, 0, 0, 1};
            colorBackgroundDisabled[] = {0, 0, 0, 1};
            colorBackgroundActive[] = {0, 0, 0, 1};
            colorFocused[] = {0, 0, 0, 1};
            colorBorder[] = {0, 0, 0, 0};
            idc = 86006;
            style = 2;
            x = "(safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) / 2) - (((safeZoneW) min (safeZoneH * 1.7777777778)) / 3.28)";
            y = "safeZoneY + (safeZoneH * 0.18)";
            w = "((safeZoneW) min (safeZoneH * 1.7777777778)) / 5.9";
            h = "safeZoneH / 40";
            shadow = 0;
            font = "RobotoCondensed";
            sizeEx = "((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25) * 0.9 * (0.55 / (getResolution select 5))";
            action = "call ACM_circulation_fnc_TransfusionMenu_ToggleIVFlow";
            tooltip = "";
        };
        class MoveBagButton: StopTransfusionButton {
            text = "$STR_ACM_circulation_TransfusionMenu_MoveBag_Display";
            idc = 86007;
            x = "(safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) / 2) - (((safeZoneW) min (safeZoneH * 1.7777777778)) / 8)";
            y = "safeZoneY + (safeZoneH * 0.22)";
            w = "((safeZoneW) min (safeZoneH * 1.7777777778)) / 22";
            action = "call ACM_circulation_fnc_TransfusionMenu_MoveBag";
            tooltip = "$STR_ACM_circulation_TransfusionMenu_MoveBag_ToolTip";
        };
        class RemoveBagButton: MoveBagButton {
            text = "$STR_ACM_circulation_TransfusionMenu_RemoveBag_Display";
            idc = 86008;
            y = "safeZoneY + (safeZoneH * 0.255)";
            action = "call ACM_circulation_fnc_TransfusionMenu_RemoveBag";
            tooltip = "$STR_ACM_circulation_TransfusionMenu_RemoveBag_ToolTip";
        };
        class RightPanelList: LeftPanelList {
            idc = 86005;
            x = "(safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) / 2) + (((safeZoneW) min (safeZoneH * 1.7777777778)) / 7.75)";
        };
        class AddBagButton: StopTransfusionButton {
            text = "$STR_ACM_circulation_TransfusionMenu_AddBag_Display";
            idc = 86036;
            x = "(safeZoneX + ((safeZoneW - ((safeZoneW) min (safeZoneH * 1.7777777778))) / 2)) + (((safeZoneW) min (safeZoneH * 1.7777777778)) / 2) + (((safeZoneW) min (safeZoneH * 1.7777777778)) / 6.8)";
            action = "call ACM_circulation_fnc_TransfusionMenu_AddBag";
            tooltip = "$STR_ACM_circulation_TransfusionMenu_AddBag_ToolTip";
        };
    };
};

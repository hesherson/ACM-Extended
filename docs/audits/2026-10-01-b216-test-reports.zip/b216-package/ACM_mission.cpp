class CfgPatches {
    class ACM_mission {
        acmeBuildBatch = "B216";
        acmeNetworkProtocol = 1;
        acmeComponent = "mission";
        name = "ACM - Mission";
        units[] = {
            "ACM_mission_TrainingPatient",
            "ACM_mission_TrainingCivilian",
            "ACM_mission_Eden_FullHealFacility",
            "ACM_mission_Eden_ElevationOverride"
        };
        weapons[] = {};
        requiredVersion = 2.18;
        requiredAddons[] = {
            "A3_Characters_F",
            "cba_main",
            "ace_main",
            "ace_medical_treatment",
            "ACM_main"
        };
        author = "Blue";
        version = 1.2;
        versionStr = "1.2.4.1";
        versionAr[] = {1, 2, 4, 1};
    };
};
class CfgVehicles {
    class B_Survivor_F;
    class ACM_mission_TrainingPatient: B_Survivor_F {
        scope = 1;
        scopeCurator = 0;
        scopeArsenal = 0;
        linkedItems[] = {"V_PlateCarrier1_rgr"};
        respawnLinkedItems[] = {"V_PlateCarrier1_rgr"};
    };
    class C_man_1;
    class ACM_mission_TrainingCivilian: C_man_1 {
        scope = 1;
        scopeCurator = 0;
        scopeArsenal = 0;
        linkedItems[] = {};
        respawnLinkedItems[] = {};
    };
    class Logic;
    class Module_F: Logic {
        class AttributesBase {
            class Default;
            class Combo;
            class Edit;
            class Checkbox;
            class ModuleDescription;
        };
    };
    class ACM_mission_Eden_FullHealFacility: Module_F {
        scope = 2;
        displayName = "$STR_ACM_mission_FullHealFacility_Module";
        icon = "\x\ACM\addons\mission\ui\Icon_Module_FullHealFacility_ca.paa";
        portrait = "\x\ACM\addons\mission\ui\Icon_Module_FullHealFacility_ca.paa";
        category = "ACM_mission_Category_Mission";
        function = "ACM_mission_fnc_moduleInitFullHealFacility_Eden";
        functionPriority = 1;
        isGlobal = 1;
        isTriggerActivated = 0;
        author = "Blue";
        class Attributes: AttributesBase {
            class InteractionDistance: Edit {
                property = "ACM_mission_Eden_FullHealFacility_InteractionDistance";
                displayName = "$STR_ACM_core_Common_Module_InteractionDistance";
                typeName = "NUMBER";
                defaultValue = 5;
            };
            class InteractionPosition: Edit {
                property = "ACM_mission_Eden_FullHealFacility_InteractionPosition";
                displayName = "$STR_ACM_core_Common_Module_InteractionPosition";
                tooltip = "$STR_ACM_core_Common_Module_InteractionPosition_Tooltip";
                typeName = "STRING";
                defaultValue = "[0,0,0]";
            };
        };
    };
    class ACM_mission_Eden_ElevationOverride: Module_F {
        scope = 2;
        displayName = "ACME Elevation Override";
        category = "ACM_mission_Category_Mission";
        function = "ACM_mission_fnc_moduleInitElevationOverride_Eden";
        functionPriority = 1;
        isGlobal = 1;
        isTriggerActivated = 0;
        isDisposable = 0;
        author = "Blue";
        class Attributes: AttributesBase {
            class DetectedBaseElevation: Edit {
                property = "ACM_mission_Eden_ElevationOverride_DetectedBaseElevation";
                displayName = "Detected ACE Base Elevation (m)";
                tooltip = "Informational. Prefilled from ACE's resolved map altitude when available, otherwise the terrain elevationOffset. The runtime report shows the value ACME actually replaced.";
                typeName = "NUMBER";
                defaultValue = "missionNamespace getVariable ['ace_common_mapAltitude', getNumber (configFile >> 'CfgWorlds' >> worldName >> 'elevationOffset')]";
            };
            class Mode: Combo {
                property = "ACM_mission_Eden_ElevationOverride_Mode";
                displayName = "Override Mode";
                tooltip = "Calibration is recommended: place this module at a location with a known real elevation and enter that elevation below. Manual mode sets ACE's base map elevation directly.";
                typeName = "NUMBER";
                defaultValue = 0;
                class values {
                    class CalibrateAtModule {
                        name = "Calibrate at module position (recommended)";
                        value = 0;
                    };
                    class ManualBase {
                        name = "Set ACE base elevation manually";
                        value = 1;
                    };
                };
            };
            class ElevationUnits: Combo {
                property = "ACM_mission_Eden_ElevationOverride_Units";
                displayName = "Elevation Units";
                tooltip = "Units used by Desired Elevation below.";
                typeName = "NUMBER";
                defaultValue = 1;
                class values {
                    class Meters {
                        name = "Meters";
                        value = 0;
                    };
                    class Feet {
                        name = "Feet";
                        value = 1;
                    };
                };
            };
            class DesiredElevation: Edit {
                property = "ACM_mission_Eden_ElevationOverride_DesiredElevation";
                displayName = "Desired Elevation";
                tooltip = "Calibration mode: the real elevation at this module's position. Manual mode: the desired ACE map base elevation. Relative hills and valleys are preserved.";
                typeName = "NUMBER";
                defaultValue = 0;
            };
            class ShowStartupReport: Checkbox {
                property = "ACM_mission_Eden_ElevationOverride_ShowStartupReport";
                displayName = "Show Startup Report";
                tooltip = "Shows the original ACE base, corrected base, and effective elevation at this module once when the mission starts. The same information is always written to the RPT.";
                typeName = "BOOL";
                defaultValue = 1;
            };
        };
    };
};
class CfgFactionClasses {
    class ACM_mission_Category_Mission {
        displayName = "ACM Mission";
        priority = 2;
        side = 7;
    };
};
class Extended_PreStart_EventHandlers {
    class ACM_mission {
        init = "call compileScript ['\x\ACM\addons\mission\XEH_preStart.sqf']";
    };
};
class Extended_PreInit_EventHandlers {
    class ACM_mission {
        init = "call compileScript ['\x\ACM\addons\mission\XEH_preInit.sqf']";
    };
};
class Extended_PostInit_EventHandlers {
    class ACM_mission {
        init = "call compileScript ['\x\ACM\addons\mission\XEH_postInit.sqf']";
    };
};
class RscControlsGroupNoScrollbars;
class RscStandardDisplay;
class RscDisplayMain: RscStandardDisplay {
    class controls {
        class GroupSingleplayer: RscControlsGroupNoScrollbars {
            class Controls;
        };
        class GroupTutorials: GroupSingleplayer {
            h = "(6 *   1.5) *  (pixelH * pixelGrid * 2)";
            class Controls: Controls {
                class Bootcamp;
                class Arsenal;
                class ACM_mission_mission: Arsenal {
                    idc = -1;
                    text = "ACM Testing Zone";
                    tooltip = "#1 Malpractice Simulator™";
                    y = "(4 *   1.5) *  (pixelH * pixelGrid * 2) +  (pixelH)";
                    onbuttonclick = "playMission ['', '\x\ACM\addons\mission\ACM_TestZone.VR']";
                    animTextureNormal = "\x\ACM\addons\mission\ui\buttonMainMenu_ca.paa";
                    animTextureDisabled = "\x\ACM\addons\mission\ui\buttonMainMenu_ca.paa";
                    animTextureOver = "\x\ACM\addons\mission\ui\buttonMainMenuHover_ca.paa";
                    animTextureFocused = "\x\ACM\addons\mission\ui\buttonMainMenuHover_ca.paa";
                    animTexturePressed = "\x\ACM\addons\mission\ui\buttonMainMenu_ca.paa";
                    animTextureDefault = "\x\ACM\addons\mission\ui\buttonMainMenu_ca.paa";
                };
                class FieldManual: Bootcamp {
                    y = "(5 *   1.5) *  (pixelH * pixelGrid * 2) +  (pixelH)";
                };
                class CommunityGuides: Bootcamp {
                    y = "(6 *   1.5) *  (pixelH * pixelGrid * 2) +  (pixelH)";
                };
            };
        };
    };
};
class CfgMissions {
    class Missions {
        class ACM_TestZone {
            directory = "x\ACM\addons\mission\ACM_TestZone.VR";
            overviewPicture = "x\ACM\addons\main\logo.paa";
            overviewText = "#1 Malpractice Simulator™";
        };
    };
    class MPMissions {
        class ACM_TestZone {
            directory = "x\ACM\addons\mission\ACM_TestZone.VR";
            overviewPicture = "x\ACM\addons\main\logo.paa";
            overviewText = "#1 Malpractice Simulator™";
        };
    };
};

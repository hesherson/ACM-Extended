class CfgPatches {
    class ACM_damage {
        acmeBuildBatch = "B216";
        acmeNetworkProtocol = 1;
        acmeComponent = "damage";
        name = "ACM - Damage";
        units[] = {};
        weapons[] = {"ACM_PressureBandage", "ACM_EmergencyTraumaDressing", "ACM_ElasticWrap"};
        requiredVersion = 2.18;
        requiredAddons[] = {"cba_main", "ace_main", "ace_medical_treatment"};
        author = "Blue";
        version = 1.2;
        versionStr = "1.2.4.1";
        versionAr[] = {1, 2, 4, 1};
    };
};
class ACE_Medical_Injuries {
    class wounds {
        class ThermalBurn;
        class ChemicalBurn: ThermalBurn {
            pain = 0.8;
        };
    };
    class damageTypes {
        class slap {
            thresholds[] = {{0.05, 1}, {0.05, 0}};
            selectionSpecific = 1;
            class Contusion {
                weighting[] = {{0.35, 0}, {0.35, 1}};
            };
        };
        class incision {
            thresholds[] = {{0.1, 1}, {0.1, 0}};
            selectionSpecific = 1;
            class Cut {
                weighting[] = {{0.1, 1}, {0.1, 0}};
            };
        };
        class lewisiteburn {
            thresholds[] = {{0, 1}};
            selectionSpecific = 0;
            noBlood = 1;
            class ChemicalBurn {
                weighting[] = {{0, 1}};
            };
        };
    };
};
class Extended_PreInit_EventHandlers {
    class ACM_damage {
        init = "call compileScript ['\x\ACM\addons\damage\XEH_preInit.sqf']";
    };
};
class Extended_PostInit_EventHandlers {
    class ACM_damage {
        init = "call compileScript ['\x\ACM\addons\damage\XEH_postInit.sqf']";
    };
};
class CfgWeapons {
    class ACE_ItemCore;
    class CBA_MiscItem_ItemInfo;
    class ACM_PressureBandage: ACE_ItemCore {
        scope = 2;
        author = "Blue";
        model = "\z\ace\addons\medical_treatment\data\bandage.p3d";
        picture = "\x\ACM\addons\damage\ui\pressurebandage.paa";
        displayName = "$STR_ACM_damage_PressureBandage";
        descriptionShort = "$STR_ACM_damage_PressureBandage_Desc";
        ACE_isMedicalItem = 1;
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 0.6;
        };
    };
    class ACM_EmergencyTraumaDressing: ACM_PressureBandage {
        picture = "\x\ACM\addons\damage\ui\etd.paa";
        displayName = "$STR_ACM_damage_EmergencyTraumaDressing";
        descriptionShort = "$STR_ACM_damage_EmergencyTraumaDressing_Desc";
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 2;
        };
    };
    class ACM_ElasticWrap: ACM_PressureBandage {
        picture = "\z\ace\addons\medical_treatment\ui\elasticbandage_ca.paa";
        displayName = "$STR_ACM_damage_ElasticWrap";
        descriptionShort = "$STR_ACM_damage_ElasticWrap_Desc";
        class ItemInfo: CBA_MiscItem_ItemInfo {
            mass = 0.3;
        };
    };
};

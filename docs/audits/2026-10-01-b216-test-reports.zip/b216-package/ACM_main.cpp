class CfgPatches {
    class ACM_main {
        acmeBuildBatch = "B216";
        acmeNetworkProtocol = 1;
        acmeComponent = "main";
        name = "ACM - Main";
        units[] = {};
        weapons[] = {};
        requiredVersion = 2.18;
        requiredAddons[] = {"cba_main", "ace_main"};
        author = "Blue";
        url = "https://discord.gg/5MNPpBpsEr/";
        version = 1.2;
        versionStr = "1.2.4.1";
        versionAr[] = {1, 2, 4, 1};
    };
};
class CfgSettings {
    class CBA {
        class Versioning {
            class ACM {
                class Dependencies {
                    CBA[] = {"cba_main", {3, 18, 0}, "(true)"};
                    ACE[] = {"ace_main", {3, 18, 0}, "(true)"};
                };
            };
        };
    };
};

class CfgPatches {
    class ACM_gui {
        acmeBuildBatch = "B216";
        acmeNetworkProtocol = 1;
        acmeComponent = "gui";
        name = "ACM - GUI";
        units[] = {};
        weapons[] = {};
        requiredVersion = 2.18;
        requiredAddons[] = {"cba_main", "ace_main", "ace_medical_gui"};
        author = "Blue";
        version = 1.2;
        versionStr = "1.2.4.1";
        versionAr[] = {1, 2, 4, 1};
    };
};
class CfgFunctions {
    class overwrite_medical_gui {
        tag = "ace_medical_gui";
        class ace_medical_gui {
            class collectActions {
                file = "\x\ACM\addons\gui\overrides\fnc_collectActions.sqf";
            };
            class canOpenMenu {
                file = "\x\ACM\addons\gui\overrides\fnc_canOpenMenu.sqf";
            };
            class onMenuOpen {
                file = "\x\ACM\addons\gui\overrides\fnc_onMenuOpen.sqf";
            };
            class onMenuClose {
                file = "\x\ACM\addons\gui\overrides\fnc_onMenuClose.sqf";
            };
            class updateActions {
                file = "\x\ACM\addons\gui\overrides\fnc_updateActions.sqf";
            };
            class updateBodyImage {
                file = "\x\ACM\addons\gui\overrides\fnc_updateBodyImage.sqf";
            };
            class updateInjuryList {
                file = "\x\ACM\addons\gui\overrides\fnc_updateInjuryList.sqf";
            };
        };
    };
};
class Extended_PreInit_EventHandlers {
    class ACM_gui {
        init = "call compileScript ['\x\ACM\addons\gui\XEH_preInit.sqf']";
    };
};
class Extended_PostInit_EventHandlers {
    class ACM_gui {
        init = "call compileScript ['\x\ACM\addons\gui\XEH_postInit.sqf']";
    };
};
class RscText;
class RscButton;
class RscPicture;
class RscListBox;
class RscActivePicture;
class RscButtonMenu;
class RscControlsGroup;
class RscControlsGroupNoScrollbars;
class ace_medical_gui_BodyImage: RscControlsGroupNoScrollbars {
    class Controls {
        class Background;
        class Head: Background {};
        class Torso: Background {};
        class ArmLeft: Background {};
        class ArmRight: Background {};
        class LegLeft: Background {};
        class LegRight: Background {};
        class ArmLeftB: Background {};
        class ArmRightB: ArmLeftB {};
        class LegLeftB: ArmLeftB {};
        class LegRightB: ArmLeftB {};
        class Torso_ChestSeal: Background {
            idc = 70111;
            text = "\x\ACM\addons\gui\data\body_image\torso_chestseal.paa";
            colorText[] = {1, 0.95, 0, 1};
            show = 0;
        };
        class Head_OPA: Torso_ChestSeal {
            idc = 70100;
            text = "\x\ACM\addons\gui\data\body_image\head_opa.paa";
            colorText[] = {0.19, 0.91, 0.93, 1};
        };
        class Head_NPA: Head_OPA {
            idc = 70101;
            text = "\x\ACM\addons\gui\data\body_image\head_npa.paa";
        };
        class Head_iGel: Head_OPA {
            idc = 70102;
            text = "\x\ACM\addons\gui\data\body_image\head_igel.paa";
        };
        class Head_SurgicalAirway_0: Head_OPA {
            idc = 70103;
            text = "\x\ACM\addons\gui\data\body_image\head_surgical_airway_0.paa";
        };
        class Head_SurgicalAirway_1: Head_SurgicalAirway_0 {
            idc = 70104;
            text = "\x\ACM\addons\gui\data\body_image\head_surgical_airway_1.paa";
        };
        class Head_Lozenge: Head_OPA {
            idc = 70106;
            text = "\x\ACM\addons\gui\data\body_image\head_lozenge.paa";
            colorText[] = {0.2, 0.65, 0.2, 1};
        };
        class RightArm_PulseOximeter: Background {
            idc = 70126;
            text = "\x\ACM\addons\gui\data\body_image\rightarm_pulseoximeter.paa";
            colorText[] = {0.3, 0.8, 0.8, 1};
            show = 0;
        };
        class LeftArm_PulseOximeter: RightArm_PulseOximeter {
            idc = 70127;
            text = "\x\ACM\addons\gui\data\body_image\leftarm_pulseoximeter.paa";
        };
        class Torso_AED_Pads: Background {
            idc = 70110;
            text = "\x\ACM\addons\gui\data\body_image\torso_aed_pads.paa";
            colorText[] = {0.18, 0.6, 0.96, 1};
            show = 0;
        };
        class Head_AED_Capnograph: Torso_AED_Pads {
            idc = 70105;
            text = "\x\ACM\addons\gui\data\body_image\head_aed_capnograph.paa";
        };
        class RightArm_AED_PulseOximeter: Torso_AED_Pads {
            idc = 70120;
            text = "\x\ACM\addons\gui\data\body_image\rightarm_aed_pulseoximeter.paa";
        };
        class LeftArm_AED_PulseOximeter: RightArm_AED_PulseOximeter {
            idc = 70121;
            text = "\x\ACM\addons\gui\data\body_image\leftarm_aed_pulseoximeter.paa";
        };
        class RightArm_AED_PressureCuff: Torso_AED_Pads {
            idc = 70122;
            text = "\x\ACM\addons\gui\data\body_image\rightarm_aed_pressurecuff.paa";
        };
        class LeftArm_AED_PressureCuff: RightArm_AED_PulseOximeter {
            idc = 70123;
            text = "\x\ACM\addons\gui\data\body_image\leftarm_aed_pressurecuff.paa";
        };
        class Torso_IO: Torso_ChestSeal {
            idc = 70113;
            text = "\x\ACM\addons\gui\data\body_image\torso_fast_io.paa";
            colorText[] = {0.2, 0.65, 0.2, 1};
        };
        class RightArm_IO: Torso_IO {
            idc = 70136;
            text = "\x\ACM\addons\gui\data\body_image\rightarm_io.paa";
        };
        class LeftArm_IO: RightArm_IO {
            idc = 70137;
            text = "\x\ACM\addons\gui\data\body_image\leftarm_io.paa";
        };
        class RightLeg_IO: RightArm_IO {
            idc = 70146;
            text = "\x\ACM\addons\gui\data\body_image\rightleg_io.paa";
        };
        class LeftLeg_IO: RightArm_IO {
            idc = 70147;
            text = "\x\ACM\addons\gui\data\body_image\leftleg_io.paa";
        };
        class RightArm_IV_Upper: Torso_IO {
            idc = 70130;
            text = "\x\ACM\addons\gui\data\body_image\RightArm_iv_Upper.paa";
        };
        class RightArm_IV_Middle: Torso_IO {
            idc = 70131;
            text = "\x\ACM\addons\gui\data\body_image\RightArm_iv_Middle.paa";
        };
        class RightArm_IV_Lower: Torso_IO {
            idc = 70132;
            text = "\x\ACM\addons\gui\data\body_image\RightArm_iv_Lower.paa";
        };
        class LeftArm_IV_Upper: Torso_IO {
            idc = 70133;
            text = "\x\ACM\addons\gui\data\body_image\LeftArm_iv_Upper.paa";
        };
        class LeftArm_IV_Middle: Torso_IO {
            idc = 70134;
            text = "\x\ACM\addons\gui\data\body_image\LeftArm_iv_Middle.paa";
        };
        class LeftArm_IV_Lower: Torso_IO {
            idc = 70135;
            text = "\x\ACM\addons\gui\data\body_image\LeftArm_iv_Lower.paa";
        };
        class RightLeg_IV_Upper: Torso_IO {
            idc = 70140;
            text = "\x\ACM\addons\gui\data\body_image\RightLeg_iv_Upper.paa";
        };
        class RightLeg_IV_Middle: Torso_IO {
            idc = 70141;
            text = "\x\ACM\addons\gui\data\body_image\RightLeg_iv_Middle.paa";
        };
        class RightLeg_IV_Lower: Torso_IO {
            idc = 70142;
            text = "\x\ACM\addons\gui\data\body_image\RightLeg_iv_Lower.paa";
        };
        class LeftLeg_IV_Upper: Torso_IO {
            idc = 70143;
            text = "\x\ACM\addons\gui\data\body_image\LeftLeg_iv_Upper.paa";
        };
        class LeftLeg_IV_Middle: Torso_IO {
            idc = 70144;
            text = "\x\ACM\addons\gui\data\body_image\LeftLeg_iv_Middle.paa";
        };
        class LeftLeg_IV_Lower: Torso_IO {
            idc = 70145;
            text = "\x\ACM\addons\gui\data\body_image\LeftLeg_iv_Lower.paa";
        };
        class RightArm_PressureCuff: Torso_IO {
            idc = 70124;
            text = "\x\ACM\addons\gui\data\body_image\rightarm_aed_pressurecuff.paa";
        };
        class LeftArm_PressureCuff: Torso_IO {
            idc = 70125;
            text = "\x\ACM\addons\gui\data\body_image\leftarm_aed_pressurecuff.paa";
        };
        class ArmLeftT: Background {
            text = "\x\ACM\addons\gui\data\body_image\leftarm_tourniquet.paa";
        };
        class ArmRightT: ArmLeftT {
            text = "\x\ACM\addons\gui\data\body_image\rightarm_tourniquet.paa";
        };
        class LegLeftT: ArmLeftT {};
        class LegRightT: ArmLeftT {};
    };
};
class ACE_Medical_Menu {
    class Controls {
        class BodyLabelLeft: RscText {
            idc = 8001;
            show = 0;
        };
        class BodyLabelRight: BodyLabelLeft {
            idc = 8002;
            show = 0;
        };
    };
};
class ace_medical_gui_TriageSelect: RscControlsGroupNoScrollbars {
    class Controls {
        class None: RscButton {};
        class Deceased: None {
            text = "$STR_ACM_gui_Triage_Priority4";
        };
    };
};
class ACE_Medical_Menu_ActionButton;
class ACM_MedicalMenu_ActionButton_None: ACE_Medical_Menu_ActionButton {
    class ShortcutPos {
        left = 0.01;
        top = 0;
        w = "((1) * (((safeZoneW / safeZoneH) min 1.2) / 40))";
        h = "((1) * ((((safeZoneW / safeZoneH) min 1.2) / 1.2) / 25))";
    };
};
class ACM_MedicalMenu_ActionButton_ACE_tourniquet: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\z\ace\addons\medical_treatment\ui\tourniquet_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACE_surgicalKit: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\z\ace\addons\medical_treatment\ui\surgicalKit_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACE_personalAidKit: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\z\ace\addons\medical_treatment\ui\surgicalKit_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACE_bodyBag: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\z\ace\addons\medical_treatment\ui\bodybag_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACE_bodyBag_blue: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\z\ace\addons\medical_treatment\ui\bodybag_blue_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACE_bodyBag_white: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\z\ace\addons\medical_treatment\ui\bodybag_white_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACE_adenosine: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\z\ace\addons\medical_treatment\ui\adenosine_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACE_epinephrine: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\z\ace\addons\medical_treatment\ui\epinephrine_ca.paa";
};
class ACM_MedicalMenu_ActionButton_CPR: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\x\ACM\addons\core\ui\icon_patient_cpr.paa";
};
class ACM_MedicalMenu_ActionButton_ACE_morphine: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\x\ACM\addons\core\ui\override\morphine_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_OPA: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\x\ACM\addons\airway\ui\opa_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_IGel: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\x\ACM\addons\airway\ui\igel_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_NPA: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\x\ACM\addons\airway\ui\npa_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_SuctionBag: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\x\ACM\addons\airway\ui\suctionbag_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_ACCUVAC: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\x\ACM\addons\airway\ui\accuvac_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_CricKit: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\x\ACM\addons\airway\ui\crickit_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_ChestSeal: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\x\ACM\addons\breathing\ui\chestseal_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_PulseOximeter: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\x\ACM\addons\breathing\ui\pulseoximeter_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_Stethoscope: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\x\ACM\addons\breathing\ui\stethoscope_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_NCDKit: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\x\ACM\addons\breathing\ui\ncdkit_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_ChestTubeKit: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\x\ACM\addons\breathing\ui\chestTubeKit_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_ThoracostomyKit: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\x\ACM\addons\breathing\ui\thoracostomyKit_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_PocketBVM: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\x\ACM\addons\breathing\ui\pocketbvm_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_BVM: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\x\ACM\addons\breathing\ui\bvm_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_AED: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\x\ACM\addons\circulation\ui\AED_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_PressureCuff: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\x\ACM\addons\circulation\ui\pressureCuff_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_IV_16G: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\x\ACM\addons\circulation\ui\IV_16g_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_IV_14G: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\x\ACM\addons\circulation\ui\IV_14g_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_IO_FAST: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\x\ACM\addons\circulation\ui\IO_FAST1_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_IO_EZ: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\x\ACM\addons\circulation\ui\IO_EZ_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_Syringe_10: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\x\ACM\addons\circulation\ui\syringe_10_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_Syringe_5: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\x\ACM\addons\circulation\ui\syringe_5_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_Syringe_3: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\x\ACM\addons\circulation\ui\syringe_3_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_Syringe_1: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\x\ACM\addons\circulation\ui\syringe_1_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_Spray_Naloxone: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\x\ACM\addons\circulation\ui\spray_naloxone_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_Paracetamol: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\x\ACM\addons\circulation\ui\paracetamol_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_AmmoniaInhalant: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\x\ACM\addons\circulation\ui\inhalant_ammonia_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_Inhaler_Penthrox: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\x\ACM\addons\circulation\ui\inhaler_penthrox_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_Lozenge_Fentanyl: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\x\ACM\addons\circulation\ui\lozenge_fentanyl_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_PressureBandage: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\x\ACM\addons\damage\ui\pressurebandage.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_EmergencyTraumaDressing: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\x\ACM\addons\damage\ui\etd.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_ElasticWrap: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\z\ace\addons\medical_treatment\ui\elasticbandage_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_SAMSplint: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\x\ACM\addons\disability\ui\samSplint.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_ATNA_Autoinjector: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\x\ACM\addons\cbrn\ui\autoinjector_ATNA_ca.paa";
};
class ACM_MedicalMenu_ActionButton_ACM_Midazolam_Autoinjector: ACM_MedicalMenu_ActionButton_None {
    textureNoShortcut = "\x\ACM\addons\cbrn\ui\autoinjector_midazolam_ca.paa";
};
